import * as prepend from './f.prepend';
import { fTabs } from './f.tabs';
import { fEditor } from './f.editor';
import { fBottomPanel } from './f.bottompanel';
import { fDetail } from './f.detail';
// This file initializes and controls the advanced coder panel

export function fAdvanceEditor(options) {
  var defaults = {};
  var currentFElement = null; //Current selected functionise target page element

  var objMainEditor = null;
  var blnFlagBlankElement = false;

  options = Object.assign({}, defaults, options);

  this.initialize = function() {
    //append the panel base template to the target div

    /// Assuming options.target is a CSS selector for the target element
    var targetElement = document.querySelector(options.target);

    // Assuming prepend.jsTemplate is a DOM node or an element
    if (prepend.jsTemplate) {
      targetElement.appendChild(prepend.jsTemplate);
    }
    // this.setJobPlanDescription();

    //Setup the different components of the panel
    this.oTabs = new fTabs(options);
    this.oEditor = new fEditor(options);
    this.oPanel = new fBottomPanel(options);
    this.oDetail = new fDetail(options);

    //setup the internal objects for the components to refer back to this main class.
    this.setMainEditorObject();

    //setup the tabs containe for the bottom panel
    this.oPanel.setTabsContainer(this.oTabs);

    //build the panel DOM and initialize it with the settings.
    this.oPanel.buildPanel();

    var self = this;

    //Callback while closing the main editor.
    document.querySelectorAll('.' + window.fUniqPrefix + '-css-advance-editor-main-close, .' + window.fUniqPrefix + '-cancel-panel').forEach(function(element) {
      element.addEventListener('click', function(e) {
        if (this.classList.contains('disable')) {
          e.preventDefault();
          return;
        }

        // Remove class from the button
        document.querySelector('#f-functionise-tc-manager-buttons #setting-button.active-bottompanel').classList.remove('active-bottompanel');

        // Add class to the wrapper
        document.querySelector('#' + window.fUniqPrefix + '-css-advance-editor-wrapper').classList.add('f-hideTab');

        // Show delete action panel
        document.querySelector('.' + window.fUniqPrefix + '-delete-action-panel').style.display = 'block';

        // Call the save function
        self.oTabs.attributeValues = {};

        // Check if we have an element selected or if the panel is being called from the recorder settings button without an element
        if (!blnFlagBlankElement || blnFlagBlankElement == false) {
          // Do not save user code on close click
          window.TCM.advancedEditor.oEditor.processSubmit(false, false);
        } else {
          // We do not have an element - close without saving
          self.setBlankElement(false);
          window.TCM.stopEdit();
        }

        // Simulate a click on the close button
        document.querySelector('.' + window.fUniqPrefix + '-k-i-close').click();
      });
    });

    // Hide recorder if functionizeIsSeleniumTest is true
    if (typeof window.functionizeIsSeleniumTest !== 'undefined' && window.functionizeIsSeleniumTest) {
      document.querySelector('#f-functionise-tc-manager').parentElement.classList.add('hideitem');
    }
  };

  //setup the internal references for the internal components to the AdvancedEditor object
  this.setMainEditorObject = function() {
    objMainEditor = this;
    this.oTabs.setMainEditorObject(objMainEditor);
    this.oEditor.setMainEditorObject(objMainEditor);
  };

  // set the flag to display the recorder panel with the Recorder Settings tab open
  this.setFlagSettings = function(ce) {
    this.oTabs.setFlagSettings(ce);
  };

  //set the curently selected element on the page and prepare the details panel accordingly.
  this.setElementDetails = function(ce) {
    this.oDetail.setCurrentElement(ce);
  };

  // indicate to the components that this is a custom user code call and the panel design needs to be updated accordingly
  this.setBlankElement = function(ce) {
    blnFlagBlankElement = ce;
    this.oTabs.setBlankElement(ce);
    this.oEditor.setBlankElement(ce);
  };

  //Set the current selected element in the individual panel components
  this.setCurrentElement = function(ce) {
    this.oTabs.setCurrentElement(ce);
    this.oEditor.setCurrentElement(ce);
    this.oDetail.setCurrentElement(ce);
    this.oPanel.setCurrentElement(ce);
    return true;
  };

  // High level function to access the individual components of the advanced coder panel
  this.getObject = function(
    objType // panel => BottomPanel
  ) {
    switch (objType) {
      case 'panel':
        // the bottom panel object using the mbExtruder library
        return this.oPanel;
      case 'tabcontainer':
        //the parent container for the various tabs
        return this.oTabs;
      case 'tabeditor':
        // the code & element editor panel
        return this.oEditor;
      case 'details':
        // the code & element editor panel
        return this.oDetail;
      default:
        return null;
    }
  };

  //Set the current Functionise target page element that is selected
  this.setCurrentFunctioniseElement = function(ce) {
    currentFElement = ce;
    if (currentFElement != null) currentFElement.data = {};
  };

  //Set the data (code or custom code) for the current selected functionise target element
  this.setElementData = function(key, value, actionId) {
    if (blnFlagBlankElement && currentFElement == null) {
      currentFElement = { action: 'customcode', data: {} }; //we create a custom code action
    }
    currentFElement.data[key] = value;

    if (key == 'element') {
      var editorObj = this.getObject('tabeditor');
      var strCode = editorObj.prepareUserCodeForExecution(value, 'element');
      strCode = strCode.replace('elementanon();', `window.fElement = elementanon(); window.TCM.advancedEditor.processElementData('${actionId}', window.fElement);`);
      strCode = window.WS.formatUserCode(strCode);
      setTimeout(strCode, 1);
    }
  };

  this.processElementData = function(actionId, element) {
    var changeSelector = {};
    if (element instanceof HTMLElement) {
      changeSelector = window.WS.targetElement(element, undefined, undefined, undefined, undefined, undefined, undefined, actionId);
    }

    if (actionId) {
      window.WS.updateActionByActionId(Object.assign(changeSelector, { updateVerifications: true }), actionId);
    } else {
      changeSelector['action'] = 'verify';
      window.WS.updateLastAction(changeSelector);
    }
  };

  //trigger the callback function passed in init.
  this.triggerCallBack = function(actionId) {
    //options.saveCallBack is the callback function that is passed in at init time
    this.oTabs.attributeValues = {};
    options.saveCallBack(currentFElement, actionId);
  };
}

import * as prepend from './f.prepend';
// This file build and controls the code editor component

export function fEditor(options) {
  var defaults = {};
  options = Object.assign({}, defaults, options);

  this.objMainEditor = null;
  this.currentElement = null;
  this.blnFlagBlankElement = false;
  // window.functioniseTestCodeTimer;

  //process the test code script in the editor and parse the results.
  this.processTestCode = function(tab) {
    //var tabArray = options.tabs['advanced_coder'].tabs;
    var tabArray = options.tabs;
    for (var i in tabArray) {
      if (i == tab && tab != 'overview') {
        var strCode = tabArray[i].codeMirror.getValue();
        strCode = this.prepareUserCodeForExecution(strCode, tab);
        var path = '';
        if (!this.blnFlagBlankElement && this.currentElement != null) path = this.currentElement.path;

        window.WS.testUserCode(strCode, tab, path);

        return;
      }
    }
  };

  //filters and prepares the user code for execution.
  this.prepareUserCodeForExecution = function(userCode, tab) {
    //console.log("Running prepare code for exe for tab:" + tab);
    //var tabArray = options.tabs['advanced_coder'].tabs;
    var tabArray = options.tabs;
    var selectorCode = '';
    if (tab == 'code') {
      //we go check on the element selector

      selectorCode = tabArray['element'].codeMirror.getValue();
      selectorCode = this.getCleanedCode(selectorCode);
      if (selectorCode.trim() != '') selectorCode = this.prepareUserCodeForExecution(selectorCode, 'element');
    }

    //get user provided selector if available
    if (tab == 'code') {
      //add default if user left if empty
      if (selectorCode.trim() == '' && !this.blnFlagBlankElement && this.currentElement != null) {
        var tagname = this.currentElement.element.toLowerCase();
        var index = this.currentElement.index;

        if (index < 0) index = 0;
        selectorCode = "var fElement = document.querySelectorAll('" + tagname + "')[" + index + ']; \n';
      } else if (!this.blnFlagBlankElement && this.currentElement != null) {
        //take out current anon() call...
        selectorCode = selectorCode.replace('elementanon();', '');
        selectorCode += '\nvar fElement = elementanon();\n';
      }
    }

    userCode = 'function ' + tab + 'anon() {\n ' + selectorCode + userCode + '\n}; ' + tab + 'anon();';
    //console.log("Retuning user code for eval: " + userCode);
    return this.getCleanedCode(userCode);
  };

  //filters and prepares the user code for saving with the element.
  this.prepareUserCodeForSave = function(userCode) {
    return this.getCleanedCode(userCode);
  };

  //validates the user code acccording to rules.
  this.validateUserCodes = function() {
    //var tabArray = options.tabs['advanced_coder'].tabs;
    var tabArray = options.tabs;
    window.fconsole.log('Validating coder data');
    //first we see if there is any user code.   If so its enough to validate that.  If not we only validate element
    var activeTab = 'code';
    var strCode = tabArray[activeTab].codeMirror.getValue();
    //skip if there is nothing to execute...
    if (this.getCleanedCode(strCode).trim() == '') {
      ///we only validate element code
      activeTab = 'element';
      strCode = tabArray[activeTab].codeMirror.getValue();
      if (this.getCleanedCode(strCode).trim() == '') {
        //no user code found…   we can safely save
        this.validateUserCodesCallback(true, '');
        return;
      }
    }
    //console.log("Preparing to validate user code " + strCode);
    strCode = this.prepareUserCodeForExecution(strCode, activeTab);
    var isValidate = true;
    var self = this;
    this.testCodeTimer = setTimeout(function() {
      self.validateUserCodeTimeout();
    }, 4000);
    var path = '';
    if (!this.blnFlagBlankElement && this.currentElement != null) path = this.currentElement.path;

    window.WS.testUserCode(strCode, activeTab, path, isValidate);
  };

  this.validateUserCodeTimeout = function() {
    this.validateUserCodesCallback(false, '', 'User code timed out. Target window may have been closed??');
  };

  //this gets called from window.WS when the call is returned
  this.validateUserCodesCallback = function(valid, error, errorMsg) {
    window.fconsole.log('Clearing timeout : ' + this.testCodeTimer);
    clearTimeout(this.testCodeTimer);
    if (!valid) {
      window.fconsole.log('User code found invalid with the following error: ' + error);
      var msg = 'Invalid advanced code found.   Please run your tests and be sure they validate before saving.';
      if (typeof errorMsg != 'undefined') msg = errorMsg;

      self.port.emit('message', {
        obj: 'TCM',
        call: 'showDialog',
        arguments: msg,
        forVue: true,
      });
      return false;
    } else {
      //only one code to validate so we make a callback…
      this.processSubmit(false);
    }
  };

  //Process called when the continue button is clicked in the advanced editor or when the panel is closed.
  this.processSubmit = function(doValidate, saveCode) {
    if (typeof doValidate == 'undefined') doValidate = true;

    if (typeof saveCode == 'undefined') saveCode = true;

    if (doValidate && saveCode) {
      //we call validation   after than we call the same without the validation option
      this.validateUserCodes();
      return false;
    }

    //var tabArray = options.tabs['advanced_coder'].tabs;
    var tabArray = options.tabs;
    var x = 0;
    if (!this.blnFlagBlankElement || this.blnFlagBlankElement == false) {
      this.objMainEditor.setCurrentFunctioniseElement(this.currentElement);
    } else {
      this.objMainEditor.setCurrentFunctioniseElement(null);
    }
    if (saveCode) {
      for (var i in tabArray) {
        window.fconsole.log('Found tab:' + i);
        if (i != 'code' && i != 'element') continue; //skip non code related tabs
        window.fconsole.log('Saving coder data');
        var activeTab = i;
        var strCode = tabArray[i].codeMirror.getValue();
        strCode = this.getCleanedCode(strCode).trim();
        strCode = this.prepareUserCodeForSave(strCode);
        window.fconsole.log('Saving coder data ' + strCode.trim());
        if (strCode.trim() != '') this.objMainEditor.setElementData(activeTab, strCode.trim());

        x++;
      }
    }
    // Select the element using querySelector
    var element = document.querySelector('#' + window.fUniqPrefix + '-css-advance-editor-wrapper');

    // Add the 'f-hideTab' class to the element
    if (element) {
      element.classList.add('f-hideTab');
    }

    if (window.WS.settings['disableMouseoutAction']) window.WS.settings['disableMouseoutAction'] = false;

    //trigger the save callback specified for the main editor
    this.objMainEditor.triggerCallBack();

    // Select all elements with the specified class
    var elements = document.querySelectorAll('.' + window.fUniqPrefix + '-k-i-close');

    // Trigger a click event on each element
    elements.forEach(function(element) {
      element.click();
    });
  };

  //cleans the user entered JS code.
  this.getCleanedCode = function(code) {
    var lines = code.split('\n');
    var fcode = '';
    //remove comment lines
    for (var i = 0; i < lines.length; i++) {
      if (lines[i].substr(0, 2) == '//' && lines[i].indexOf('[functionizeLabel') < 0) continue;
      fcode += lines[i] + '\n';
    }
    return fcode;
  };

  //called when the CLEAR button is called on the code editor panel
  this.clearSubmit = function(ce) {
    var tabKey = 'code';
    var strCode = '';
    // Select the textarea element by ID
    var textarea = document.getElementById(prepend.randomString + '_details_textarea');

    // Set the value of the textarea to an empty string
    if (textarea) {
      textarea.value = '';
    }

    this.objMainEditor.setElementData(tabKey, strCode);
  };

  //sets the text area content for the given code editor
  this.setTextAreaContent = function(ce) {
    this.objMainEditor.setTextAreaContent(ce);
  };

  //sets the current selected element

  this.setCurrentElement = function(ce) {
    this.currentElement = ce;
  };

  //attaches the main advanced editor object to the editor object.
  this.setMainEditorObject = function(ce) {
    this.objMainEditor = ce;
  };

  //Sets the flag to indicate we have a blank element being passed from the main editor.
  this.setBlankElement = function(blnFlagBlankElement) {
    this.blnFlagBlankElement = blnFlagBlankElement;
  };
}

import { randomString, operators, attributeotheroperators, attributeFunctions, clickattroperators } from './f.prepend';
import { hljs } from '../lib/panel/highlight.min.js';
// This file build and controls the various tabs for the advanced coder panel.

export function fTabs(options) {
  var defaults = {};
  function extend(target, ...sources) {
    sources.forEach(source => {
      for (let key in source) {
        if (source.hasOwnProperty(key)) {
          target[key] = source[key];
        }
      }
    });
    return target;
  }

  options = extend({}, defaults, options);

  this.objTabs = '';
  this.objTabsSub = '';
  this.currentTab = '';
  this.currentElement = null;
  this.currentElementType = null;
  this.disableElement = '';
  this.blnFlagSettings = false; //Flag to indicate whether to jump directly to the recorder settings tab
  this.blnFlagBlankElement = false;

  this.keyValuesGlobal = [];
  this.globalVariablesGlobal = {};
  this.globalStepAttribute = [];
  this.propString = {};
  this.flagVariablePreviousSelection = false;

  this.smartFormatPageVariable = [];

  this.domWalkElement = '';

  this.setCurrentElement = function(ce) {
    this.currentElement = ce;
  };

  //Associate the main code editor object with the tabs object to be used internally.
  this.setMainEditorObject = function(ce) {
    this.objMainEditor = ce;
  };

  this.domWalkElementSearch = false;
  this.domWalkElementSearchSelector = '';

  //returns the default values to be put in the editor and the code editors.
  this.getEditorDefaultValue = function(strTab) {
    var defaultValue = '';
    switch (strTab) {
      case 'element':
        if (this.blnFlagBlankElement) return ''; //no default here if blank...
        var tagname = this.currentElement.element.toLowerCase();
        //var index = this.currentElement.index-1;
        var index = this.currentElement.index;
        if (index < 0) index = 0;

        defaultValue =
          '//You can enter any j' +
          'Query selector and return it.     The code is executed in \n//an anonymous function and must always end with a return statement.   \n//Uncomment the lines below and edit as you desire.\n\n//var fElement = j' +
          "Query('" +
          tagname +
          "').get(" +
          index +
          ');\n//return fElement;';
        break;
      case 'code':
        defaultValue =
          '//You can manipulate the currently selected element for further logic.\n//Use j' +
          'Query(fElement) to reference the currently selected element.  You must return a boolean value to determine the success or failure of your code. \n\n';
        if (this.blnFlagBlankElement)
          defaultValue =
            '//You can write any custom javascript or j' +
            'Query code that will be executed by the functionise system at runtime.    You can not access objects and functions that are available in your webpage.    Code is executed as if in an anonymous function.  You must return a boolean value to determine the success or failure of your code. \n\n';

        break;
    }
    return defaultValue;
  };

  //Resets the DOM layout for the tabs for reinitialization.
  this.resetTabs = function() {
    var tabListingSelector = document.querySelector('#' + window.fUniqPrefix + '-tab-container ul.' + window.fUniqPrefix + '-etabs');
    var tabDetailsSelector = document.querySelector('#' + window.fUniqPrefix + '-tab-container .' + window.fUniqPrefix + '-panel-container');

    if (tabListingSelector) {
      tabListingSelector.innerHTML = '#TABLISTING#';
    }

    if (tabDetailsSelector) {
      tabDetailsSelector.innerHTML = '#TABDETAILS#';
    }
  };

  //Builds the tab outlay and initializes the view based on the element selected

  this.buildTabs = function() {
    //if(typeof window.WS.recorderTurkVersion != 'undefined' && window.WS.recorderTurkVersion)
    //{
    document.getElementById(window.fUniqPrefix + '-mTurk-job-description-close').click();
    //}

    var tabArray = this.getTabArray();

    var tabListingSelector = document.querySelector('#' + window.fUniqPrefix + '-tab-container ul.' + window.fUniqPrefix + '-etabs');
    var tabDetailsSelector = document.querySelector('#' + window.fUniqPrefix + '-tab-container .' + window.fUniqPrefix + '-panel-container');
    var WSRecordedData = window.WS.recordedData;

    this.setCurrentElementType(WSRecordedData[WSRecordedData.length - 1]);

    if (tabListingSelector.innerHTML.trim() === '#TABLISTING#' && tabDetailsSelector.innerHTML.trim() === '#TABDETAILS#') {
      // This is the first time the tabs are being built
      this.buildInitialMainTabs(tabArray, tabListingSelector, tabDetailsSelector, WSRecordedData);

      var editorObj = this.objMainEditor.getObject('tabeditor');
      var selfObj = this;

      this.setPostEvents(editorObj);

      this.setInitialTabsView();
    } else {
      // The tabs are already built and we need to reconfigure it for the new element.
      this.switchTab('#' + window.fUniqPrefix + '-overview');

      this.buildReinitialMainTabs(tabArray, WSRecordedData);

      this.setRenitialTabsView(selfObj);
    }

    var detailObj = this.objMainEditor.getObject('details');
    detailObj.updateDetailPanel();

    this.advanceEditAction(false);

    // Open DOM Walk when holding D key while shift+click
    if (window.WS.dKeyDown) {
      window.WS.dKeyDown = false;
      this.switchTab('#' + window.fUniqPrefix + '-advanced');
      document.querySelector('.' + window.fUniqPrefix + '-DomWalk').click();
    }

    if (typeof window.WS.recorderTurkVersion !== 'undefined' && window.WS.recorderTurkVersion) {
      this.switchTab('#' + window.fUniqPrefix + '-advanced');

      document.querySelectorAll('#f-functionise-tab-overview,#f-functionise-tab-code,#f-functionise-tab-element').forEach(el => {
        el.classList.remove('f-showTab');
        el.classList.add('f-hideTab');
      });

      document.querySelectorAll('.f-functionise-buttonList > div').forEach(el => {
        el.classList.add('hideitem');
      });

      document.querySelectorAll('.f-functionise-buttonList:nth-child(3), .f-functionise-buttonList:nth-child(5)').forEach(el => {
        el.classList.add('hideitem');
      });

      document
        .querySelectorAll(
          '.f-functionise-buttonList > div.f-functionise-waitAction, .f-functionise-buttonList > div.f-functionise-navigateAction, .f-functionise-buttonList > div.f-functionise-emailAction, .f-functionise-buttonList > div.f-functionise-DomWalk, .f-functionise-buttonList > div.f-functionise-fileViewer'
        )
        .forEach(el => {
          el.classList.remove('hideitem');
        });
    }
  };

  // Build the HTML DOM layout for the sub tabs (Element & Code) under the Advanced Coder tab.
  this.makeSubTabs = function(cTab) {
    var tabArray = cTab.tabs;
    var tabListing = '';
    var tabDetails = '';
    var tabStatus = '';

    for (var i in tabArray) {
      var tabType = tabArray[i].type;
      var tabContainer = tabArray[i].container;
      var tabLabel = tabArray[i].label;
      var showTab = tabArray[i].show;
      var tabKey = i;

      if (showTab == '1') {
        tabStatus = 'f-showTab';
      } else {
        tabStatus = 'f-hideTab';
      }
      var tabDetailsValue = '';

      switch (tabType) {
        case 'editor':
          var defaultValue = this.getEditorDefaultValue(i);

          if (!this.blnFlagBlankElement) {
            if (this.currentElementType == this.disableElement) {
              tabDetailsValue =
                '<textarea name="' +
                window.fUniqPrefix +
                '-css-contentarea-editor-textareaelement" class="' +
                window.fUniqPrefix +
                '-css-contentarea-editor-textarea ' +
                randomString +
                '" id="' +
                window.fUniqPrefix +
                '_' +
                i +
                '_details_textarea" ' +
                'disabled' +
                '>' +
                defaultValue +
                '</textarea>';
            } else {
              tabDetailsValue =
                '<textarea name="' +
                window.fUniqPrefix +
                '-css-contentarea-editor-textareaelement" class="' +
                window.fUniqPrefix +
                '-css-contentarea-editor-textarea ' +
                randomString +
                '" id="' +
                window.fUniqPrefix +
                '_' +
                i +
                '_details_textarea">' +
                defaultValue +
                '</textarea>';
            }
          } else {
            tabDetailsValue =
              '<textarea name="' +
              window.fUniqPrefix +
              '-css-contentarea-editor-textareaelement" class="' +
              window.fUniqPrefix +
              '-css-contentarea-editor-textarea ' +
              randomString +
              '" id="' +
              window.fUniqPrefix +
              '_' +
              i +
              '_details_textarea">' +
              defaultValue +
              '</textarea>';
            if (i == 'code') tabStatus = 'f-showTab';
          }

          tabListing +=
            '<li class="' +
            randomString +
            ' ' +
            window.fUniqPrefix +
            '-tab ' +
            tabStatus +
            '" id="' +
            window.fUniqPrefix +
            '-tab-' +
            i +
            '"><a href="' +
            tabContainer +
            '" class="' +
            randomString +
            '">' +
            tabLabel +
            '</a></li>';
          tabDetails +=
            '<div id="' + window.fUniqPrefix + '-' + i + '" class="' + window.fUniqPrefix + '-css-tabs-content ' + randomString + '">' + tabDetailsValue + '							<br/>' + '						</div>';
          break;
        default:
          break;
      }
    }
    var tabStr =
      '<div class="' +
      window.fUniqPrefix +
      '-css-contentarea-editor ' +
      randomString +
      ' ' +
      window.fUniqPrefix +
      '-sub-editor">' +
      '				<div id="' +
      window.fUniqPrefix +
      '-tab-container1" class="' +
      randomString +
      ' ' +
      window.fUniqPrefix +
      '-css-contentarea-tab-container">' +
      '					<ul class="' +
      window.fUniqPrefix +
      '-etabs ' +
      randomString +
      '">' +
      tabListing +
      '					</ul>' +
      '					<div class="' +
      window.fUniqPrefix +
      '-panel-container ' +
      randomString +
      '">' +
      tabDetails +
      '					</div>' +
      '					<input type="checkbox" value="1" name="' +
      window.fUniqPrefix +
      '-code_validate" id="' +
      window.fUniqPrefix +
      '-code_validate" checked="true"><a class="' +
      window.fUniqPrefix +
      '-code_validate_link checked">Validate</a>' +
      '				</div>' +
      '			</div>';
    return tabStr;
  };

  //programatically return the current active tab
  this.getActiveTab = function(subtabprefix) {
    var activeTab = document.querySelector(options.tabContainer + ' a.active');
    return activeTab ? activeTab.getAttribute('href') : null;
  };

  //programatically switch between main tabs
  this.switchTab = function(switchTab) {
    this.objTabs.easytabs('select', switchTab);
  };

  //programatically switch between sub tabs on the code editor
  this.switchTabSub = function(switchTab) {
    this.objTabsSub.easytabs('select', switchTab);
  };

  // Build the data to be displayed in the 'Action Log' tab
  this.addTabActionLog = function() {
    var WSRecordedData = window.WS.recordedData;
  };

  // Build the data to be displayed in the 'Action Log' tab
  this.addTabActionDetails = function() {
    this.addTabActionLog();

    var WSRecordedData = window.WS.recordedData;
    var allActions = '<div class="allActionData" id="allActionDataLog">';
    WSRecordedData.forEach(function(value, key) {
      // allActions += '' + JSON.stringify(value) + '\r\n\r\n';
    });
    allActions += '</div>';

    //Hide other two tabs

    document.getElementById('action_log').innerHTML = allActions;

    document.querySelectorAll('.' + window.fUniqPrefix + '-js-switch').forEach(element => {
      // Assuming checkable() is a custom function, you will need to rewrite or replicate its functionality in vanilla JS.
      // For example, if checkable toggles a checkbox state, you might replace it with:
      if (element.getAttribute('data-checked') === 'checked') {
        // or use your custom logic to set the value
        element.checked = true;
      }
    });

    document.querySelectorAll('#allActionDataLog').forEach(element => {
      hljs.highlightBlock(element);
    });
  };

  // sets the current element type (input, select etc) for the currently selected element -
  // this is used to disable the code editor for certain element types (deprecated?)

  this.setCurrentElementType = function(element) {
    var cETyppe = '';
    Object.keys(element).forEach(key => {
      if (key === 'element') {
        cETyppe = element[key];
      }
    });
    this.currentElementType = cETyppe;
  };

  // set the flag to display the recorder panel with the Recorder Settings tab open
  this.setFlagSettings = function(blnFlagSettings) {
    this.blnFlagSettings = blnFlagSettings;
  };

  //set the flag to indicate a blank element is selected - used when displaying the panel from the recorder settings button
  this.setBlankElement = function(blnFlagBlankElement) {
    this.blnFlagBlankElement = blnFlagBlankElement;
  };

  //get the tab array from the options being passed
  this.getTabArray = function() {
    var tabArray = options.tabs;

    //check if we need to set the tabs according to a blank element being passed - specially when clicked on the recorder settings button.
    if (this.blnFlagBlankElement) {
      var newTabArray = {};
      for (var i in tabArray) {
        newTabArray[i] = tabArray[i];
        newTabArray[i].show = '1';
      }
      tabArray = {};
      tabArray = newTabArray;
    }
    return tabArray;
  };

  //Build the tabs for the first time - including the sub tabs. This includes initializing all the elements contained in the tabs
  this.buildInitialMainTabs = function(tabArray, tabListingSelector, tabDetailsSelector, WSRecordedData) {
    var tabListing = '';
    var tabDetails = '';
    var tabStatus = '';
    for (var i in tabArray) {
      var tabType = tabArray[i].type;
      var tabContainer = tabArray[i].container;
      var tabLabel = tabArray[i].label;
      var showTab = tabArray[i].show;
      var tabKey = i;

      if (showTab == '1') tabStatus = 'f-showTab';
      else tabStatus = 'f-hideTab';

      switch (tabType) {
        case 'editor':
          var defaultValue = this.getEditorDefaultValue(i);
          tabListing +=
            '<li class="' +
            randomString +
            ' ' +
            window.fUniqPrefix +
            '-tab ' +
            tabStatus +
            '" id="' +
            window.fUniqPrefix +
            '-tab-' +
            i +
            '"><a href="' +
            tabContainer +
            '" class="' +
            randomString +
            '"><span>' +
            tabLabel +
            '</span></a></li>';
          tabDetails +=
            '<div id="' +
            window.fUniqPrefix +
            '-' +
            i +
            '" class="' +
            window.fUniqPrefix +
            '-css-tabs-content ' +
            randomString +
            '">' +
            '							<textarea name="' +
            window.fUniqPrefix +
            '-css-contentarea-editor-textareaelement" class="' +
            window.fUniqPrefix +
            '-css-contentarea-editor-textarea ' +
            randomString +
            '" id="' +
            window.fUniqPrefix +
            '_' +
            i +
            '_details_textarea">' +
            defaultValue +
            '</textarea>' +
            '						</div>';

          break;
        case 'subtabs':
          tabListing +=
            '<li class="' +
            randomString +
            ' ' +
            window.fUniqPrefix +
            '-tab ' +
            tabStatus +
            '" id="' +
            window.fUniqPrefix +
            '-tab-' +
            i +
            '"><a href="' +
            tabContainer +
            '" class="' +
            randomString +
            '">' +
            tabLabel +
            '</a></li>';
          tabDetails +=
            '<div id="' + window.fUniqPrefix + '-' + i + '" class="' + window.fUniqPrefix + '-css-tabs-content ' + randomString + '">' + this.makeSubTabs(tabArray[i]) + '</div>';
          break;
        case 'detail':
          tabListing +=
            '<li class="' +
            randomString +
            ' ' +
            window.fUniqPrefix +
            '-tab ' +
            tabStatus +
            '" id="' +
            window.fUniqPrefix +
            '-tab-' +
            i +
            '"><a href="' +
            tabContainer +
            '" class="' +
            randomString +
            '">' +
            tabLabel +
            '</a></li>';
          tabDetails += '<div id="' + window.fUniqPrefix + '-' + i + '" class="' + window.fUniqPrefix + '-css-tabs-content ' + randomString + '">' + i + '</div>';

          break;
        case 'buttons':
          tabListing +=
            '<li class="' +
            randomString +
            ' ' +
            window.fUniqPrefix +
            '-tab ' +
            tabStatus +
            '" id="' +
            window.fUniqPrefix +
            '-tab-' +
            i +
            '"><a href="' +
            tabContainer +
            '" class="' +
            randomString +
            '"><span>' +
            tabLabel +
            '</span></a></li>';
          tabDetails +=
            '<div id="' +
            window.fUniqPrefix +
            '-' +
            i +
            '" class="' +
            window.fUniqPrefix +
            '-css-tabs-content ' +
            randomString +
            '">' +
            '							<div class="' +
            window.fUniqPrefix +
            '-cElement"></div>' +
            '						</div>';
          break;
        case 'advancebuttons':
          tabListing +=
            '<li class="' +
            randomString +
            ' ' +
            window.fUniqPrefix +
            '-tab ' +
            tabStatus +
            '" id="' +
            window.fUniqPrefix +
            '-tab-' +
            i +
            '"><a href="' +
            tabContainer +
            '" class="' +
            randomString +
            '"><span>' +
            tabLabel +
            '</span></a></li>';
          tabDetails +=
            '<div id="' +
            window.fUniqPrefix +
            '-' +
            i +
            '" class="' +
            window.fUniqPrefix +
            '-css-tabs-content ' +
            randomString +
            '">' +
            '								<div class="' +
            window.fUniqPrefix +
            '-buttonList">' +
            '									<div class="' +
            window.fUniqPrefix +
            '-waitAction ' +
            window.fUniqPrefix +
            '-code_wait_link blue"><span class="f-functionise-web-action">Wait Action</span><span class="f-functionise-mobile-action">Wait</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-hoverAction blue"><span class="f-functionise-web-action">Hover Action</span><span class="f-functionise-mobile-action">Hover</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-navigateAction ' +
            window.fUniqPrefix +
            '-code_navigate_link blue"><span class="f-functionise-web-action">Navigate Action</span><span class="f-functionise-mobile-action">Navigate</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-deleteAction ' +
            window.fUniqPrefix +
            '-delete-action-panel red"><span class="f-functionise-web-action">Delete Last Action</span><span class="f-functionise-mobile-action">Delete Action</span></div>' +
            '								</div>' +
            '								<div class="' +
            window.fUniqPrefix +
            '-buttonList">' +
            '									<div class="' +
            window.fUniqPrefix +
            '-emailAction ' +
            window.fUniqPrefix +
            '-code_email_link blue"><span class="f-functionise-web-action">Email Action</span><span class="f-functionise-mobile-action">Email</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-smsAction ' +
            window.fUniqPrefix +
            '-code_sms_link blue"><span class="f-functionise-web-action">SMS Action</span><span class="f-functionise-mobile-action">SMS</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-apiAction ' +
            window.fUniqPrefix +
            '-code_api_link blue"><span class="f-functionise-web-action">API Action</span><span class="f-functionise-mobile-action">API</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-setCookie blue"><span class="f-functionise-web-action">Set Local Storage</span><span class="f-functionise-mobile-action">Set Storage</span></div>' +
            '								</div>' +
            '								<div class="' +
            window.fUniqPrefix +
            '-buttonList">' +
            '									<div class="' +
            window.fUniqPrefix +
            '-coverersetting ' +
            window.fUniqPrefix +
            '-code_coverersetting_link blue"><span class="f-functionise-web-action">Enable Coverer</span><span class="f-functionise-mobile-action">Coverer On</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-mouseoversetting ' +
            window.fUniqPrefix +
            '-code_mouseoversetting_link blue"><span class="f-functionise-web-action">Mouseover Off</span><span class="f-functionise-mobile-action">Hover Off</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-mouseoutsetting ' +
            window.fUniqPrefix +
            '-code_mouseoutsetting_link blue"><span class="f-functionise-web-action">Mouseout Off</span><span class="f-functionise-mobile-action">Mouseout Off</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-pageVariablesAction blue"><span class="f-functionise-web-action">Page Variables</span><span class="f-functionise-mobile-action">Page Vars</span></div>' +
            '								</div>' +
            '								<div class="' +
            window.fUniqPrefix +
            '-buttonList">' +
            '									<div class="' +
            window.fUniqPrefix +
            '-saveVariablesAction blue"><span class="f-functionise-web-action">Save Variable</span><span class="f-functionise-mobile-action">Save Var</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-loadVariablesAction blue"><span class="f-functionise-web-action">Load Variable</span><span class="f-functionise-mobile-action">Load Var</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-visualCheckAction blue"><span class="f-functionise-web-action">Visual Check</span><span class="f-functionise-mobile-action">Visual Check</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-fileViewer blue"><span class="f-functionise-web-action">File Viewer</span><span class="f-functionise-mobile-action">File View</span></div>' +
            '								</div>' +
            '								<div class="' +
            window.fUniqPrefix +
            '-buttonList">' +
            '									<div class="' +
            window.fUniqPrefix +
            '-DBExplorer blue"><span class="f-functionise-web-action">DB Explorer</span><span class="f-functionise-mobile-action">DB Explorer</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-addActionNote blue"><span class="f-functionise-web-action">Add Note</span><span class="f-functionise-mobile-action">Notes</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-relatedElement blue"><span class="f-functionise-web-action">Related Element</span><span class="f-functionise-mobile-action">Related Element</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-notonthePage blue"><span class="f-functionise-web-action">Not on Page</span><span class="f-functionise-mobile-action">Not on Page</span></div>' +
            '								</div>' +
            '								<div class="' +
            window.fUniqPrefix +
            '-buttonList">' +
            '									<div class="' +
            window.fUniqPrefix +
            '-DomWalk blue"><span class="f-functionise-web-action">Dom Walk</span><span class="f-functionise-mobile-action">Dom Walk</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-ActionLog blue"><span class="f-functionise-web-action">Action Log</span><span class="f-functionise-mobile-action">Actions</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-EnableFocusOnElement gray"><span class="f-functionise-web-action">Enable Focus</span><span class="f-functionise-mobile-action">Focus On</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-DisableFocusOnElement blue"><span class="f-functionise-web-action">Disable Focus</span><span class="f-functionise-mobile-action">Focus Off</span></div>' +
            '								</div>' +
            '								<div class="' +
            window.fUniqPrefix +
            '-buttonList">' +
            '									<div class="' +
            window.fUniqPrefix +
            '-eSignature blue"><span class="f-functionise-web-action">Start Signature</span><span class="f-functionise-mobile-action">Signature</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-dombasedselection blue"><span class="f-functionise-web-action">Use DOM</span><span class="f-functionise-mobile-action">Use DOM</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-confirmSelector blue"><span class="f-functionise-web-action">Confirm Selector</span><span class="f-functionise-mobile-action">Selector</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-wrongSelector blue hideitem"><span class="f-functionise-web-action">Wrong Step</span><span class="f-functionise-mobile-action">Wrong</span></div>' +
            '								</div>' +
            '								<div class="' +
            window.fUniqPrefix +
            '-buttonList">' +
            '									<div class="' +
            window.fUniqPrefix +
            '-backForward blue" alt="back"><span class="f-functionise-web-action">Backward</span><span class="f-functionise-mobile-action">Back</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-backForward blue" alt="forward"><span class="f-functionise-web-action">Forward</span><span class="f-functionise-mobile-action">Forward</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-captureLargeData blue"><span class="f-functionise-web-action">Enable Long Text</span><span class="f-functionise-mobile-action">Enable Long Text</span></div>' +
            '									<div class="' +
            window.fUniqPrefix +
            '-missingSelector blue hideitem"><span class="f-functionise-web-action">Missing Step</span><span class="f-functionise-mobile-action">Missing</span></div>' +
            '								</div>' +
            '						</div>';
          break;
        default:
          break;
      }
    }

    tabListingSelector.html(tabListing);
    tabDetailsSelector.html(window.WU.restoreJquery(tabDetails));

    var currentInstructionStep = window.WU.store('currentInstructionStep');
    if (typeof currentInstructionStep !== 'undefined' && currentInstructionStep !== 'undefined' && currentInstructionStep) {
      document.querySelectorAll('.f-functionise-missingSelector').forEach(element => {
        element.classList.remove('hideitem');
      });
      document.querySelectorAll('.f-functionise-wrongSelector').forEach(element => {
        element.classList.remove('hideitem');
      });
    }

    for (let i in tabArray) {
      let tabType = tabArray[i].type;
      if (tabType == 'buttons') {
        document.querySelectorAll('.f-lastCurrentAction').forEach(element => {
          hljs.highlightBlock(element);
        });
      }
      if (tabType == 'editor') {
        tabArray[i].codeMirror = window.CodeMirror.fromTextArea(
          document.getElementById(window.fUniqPrefix + '_' + i + '_details_textarea', {
            mode: 'javascript',
            lineNumbers: true,
            lineWrapping: true,
          })
        );

        tabArray[i].initComplete = false;
      }
      if (tabType == 'subtabs') {
        var subtabArray = tabArray[i].tabs;
        for (var ii in subtabArray) {
          tabType = subtabArray[ii].type;
          if (tabType == 'editor') {
            if (this.currentElementType == this.disableElement) {
              subtabArray[ii].codeMirror = window.CodeMirror.fromTextArea(
                document.getElementById(window.fUniqPrefix + '_' + ii + '_details_textarea', {
                  mode: 'javascript',
                  lineNumbers: true,
                  lineWrapping: true,
                })
              );
              document.getElementById(ii).dataset.codeMirrorInstance = subtabArray[ii].codeMirror;
            } else {
              subtabArray[ii].codeMirror = window.CodeMirror.fromTextArea(
                document.getElementById(window.fUniqPrefix + '_' + ii + '_details_textarea', {
                  mode: 'javascript',
                  lineNumbers: true,
                  lineWrapping: true,
                })
              );
              document.getElementById(ii).dataset.codeMirrorInstance = subtabArray[ii].codeMirror;
            }
          }
        }
      }
    }
    //this.subtabArr = subtabArray;
  };

  //setup the tab options and the current active tabs
  this.setInitialTabsView = function() {
    var selfObj = this;
    var tabElement = document.querySelector(options.tabContainer);

    this.objTabs = new EasyTabs(tabElement, {
      animate: false,
      updateHash: false,
    });

    this.objTabs.on('easytabs:after', function(event) {
      var tabArray = selfObj.getTabArray();
      var currenti = selfObj.getActiveTab().replace('#f-functionise-', '');
      var defaultValue = selfObj.getEditorDefaultValue(currenti);
      var d = window.CodeMirror.Doc(defaultValue, 'javascript');

      if (!tabArray[currenti].initComplete) {
        tabArray[currenti].codeMirror.swapDoc(d);
        tabArray[currenti].initComplete = true;
      }

      var activeTab = selfObj.getActiveTab();

      if (activeTab === '#f-functionise-overview' || activeTab === '#f-functionise-advanced') {
        document.querySelectorAll('.f-functionise-attributeEditor').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-waitAction').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-captureLargeData').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-eSignature').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-emailAction').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-fileViewer').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-smsAction').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-apiAction').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-navigateAction').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-code_validate_link').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-code_insert_variable').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-deleteAction').forEach(el => el.classList.remove('f-hide_event'));

        if (window.WS.settings['coverElementOnActionRec']) {
          document.querySelectorAll('.' + window.fUniqPrefix + '-coverersetting').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-coverersetting .f-functionise-web-action').forEach(el => (el.textContent = 'Disable Coverer'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-coverersetting .f-functionise-mobile-action').forEach(el => (el.textContent = 'Coverer Off'));
        } else {
          document.querySelectorAll('.' + window.fUniqPrefix + '-coverersetting').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-coverersetting .f-functionise-web-action').forEach(el => (el.textContent = 'Enable Coverer'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-coverersetting .f-functionise-mobile-action').forEach(el => (el.textContent = 'Coverer On'));
        }

        if (typeof window.WS.settings['disableMouseover'] === 'undefined') window.WS.settings['disableMouseover'] = false;

        if (!window.WS.settings['disableMouseout']) {
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoutsetting').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoutsetting .f-functionise-web-action').forEach(el => (el.textContent = 'Mouseout Off'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoutsetting .f-functionise-mobile-action').forEach(el => (el.textContent = 'Mouseout Off'));
        } else {
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoutsetting').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoutsetting .f-functionise-web-action').forEach(el => (el.textContent = 'Mouseout On'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoutsetting .f-functionise-mobile-action').forEach(el => (el.textContent = 'Mouseout On'));
        }

        if (!window.WS.settings['disableMouseover']) {
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoversetting').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoversetting .f-functionise-web-action').forEach(el => (el.textContent = 'Mouseover Off'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoversetting .f-functionise-mobile-action').forEach(el => (el.textContent = 'Hover Off'));
        } else {
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoversetting').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoversetting .f-functionise-web-action').forEach(el => (el.textContent = 'Mouseover On'));
          document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoversetting .f-functionise-mobile-action').forEach(el => (el.textContent = 'Hover On'));
        }

        var settingButton = document.getElementById('setting-button');
        if (settingButton.classList.contains('active-bottompanel')) {
          document.querySelectorAll('.f-functionise-attributeEditor').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-waitAction').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-captureLargeData').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-eSignature').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-emailAction').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-fileViewer').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-smsAction').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-DBExplorer').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-apiAction').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-pageVariablesAction').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-navigateAction').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-backForward').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-deleteAction').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-hoverAction').forEach(el => el.classList.add('f-disableLink'));

          document.querySelectorAll('.f-functionise-saveVariablesAction').forEach(el => el.classList.add('f-settingLink'));
          document.querySelectorAll('.f-functionise-loadVariablesAction').forEach(el => el.classList.add('f-settingLink'));

          document.querySelectorAll('.f-functionise-addActionNote').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-relatedElement').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-visualCheckAction').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-confirmSelector').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-notonthePage').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-DomWalk').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-dombasedselection').forEach(el => el.classList.add('f-disableLink'));

          if (!window.TCM.isVerifying) {
            document.querySelectorAll('.f-functionise-hoverAction').forEach(el => el.classList.add('f-disableLink'));
          }
        } else {
          document.querySelectorAll('.f-functionise-waitAction').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-captureLargeData').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-eSignature').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-emailAction').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-fileViewer').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-smsAction').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-DBExplorer').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-apiAction').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-pageVariablesAction').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-navigateAction').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-attributeEditor').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-deleteAction').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-hoverAction').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-backForward').forEach(el => el.classList.add('f-disableLink'));

          document.querySelectorAll('.f-functionise-saveVariablesAction').forEach(el => el.classList.remove('f-settingLink'));
          document.querySelectorAll('.f-functionise-loadVariablesAction').forEach(el => el.classList.remove('f-settingLink'));

          document.querySelectorAll('.f-functionise-addActionNote').forEach(el => el.classList.add('f-disableLink'));

          document.querySelectorAll('.f-functionise-relatedElement').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-visualCheckAction').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-confirmSelector').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-notonthePage').forEach(el => el.classList.add('f-disableLink'));
          document.querySelectorAll('.f-functionise-DomWalk').forEach(el => el.classList.remove('f-disableLink'));
          document.querySelectorAll('.f-functionise-dombasedselection').forEach(el => el.classList.remove('f-disableLink'));

          if (!window.TCM.isVerifying) {
            document.querySelectorAll('.f-functionise-hoverAction').forEach(el => el.classList.add('f-disableLink'));
          }
        }
      } else {
        document.querySelectorAll('.f-functionise-code_validate_link').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-code_insert_variable').forEach(el => el.classList.remove('f-hide_event'));
        document.querySelectorAll('.f-functionise-attributeEditor').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-waitAction').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-captureLargeData').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-eSignature').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-emailAction').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-DBExplorer').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-fileViewer').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-smsAction').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-apiAction').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-pageVariablesAction').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-navigateAction').forEach(el => el.classList.add('f-hide_event'));
        document.querySelectorAll('.f-functionise-deleteAction').forEach(el => el.classList.add('f-hide_event'));

        document.querySelectorAll('.f-functionise-addActionNote').forEach(el => el.classList.add('f-disableLink'));
        document.querySelectorAll('.f-functionise-relatedElement').forEach(el => el.classList.remove('f-disableLink'));
        document.querySelectorAll('.f-functionise-visualCheckAction').forEach(el => el.classList.remove('f-disableLink'));
        document.querySelectorAll('.f-functionise-confirmSelector').forEach(el => el.classList.remove('f-disableLink'));
        document.querySelectorAll('.f-functionise-notonthePage').forEach(el => el.classList.add('f-disableLink'));
        document.querySelectorAll('.f-functionise-DomWalk').forEach(el => el.classList.remove('f-disableLink'));
        document.querySelectorAll('.f-functionise-dombasedselection').forEach(el => el.classList.remove('f-disableLink'));

        if (!window.TCM.isVerifying) {
          document.querySelectorAll('.f-functionise-hoverAction').forEach(el => el.classList.add('f-disableLink'));
        }
      }
    });

    document.querySelectorAll('.f-functionise-EnableFocusOnElement').forEach(el => el.classList.remove('hideitem'));
    document.querySelectorAll('.f-functionise-DisableFocusOnElement').forEach(el => el.classList.remove('hideitem'));

    if (window.WS.focusOnElementFlag) {
      document.querySelectorAll('.f-functionise-EnableFocusOnElement').forEach(el => el.classList.add('hideitem'));
    } else {
      document.querySelectorAll('.f-functionise-DisableFocusOnElement').forEach(el => el.classList.add('hideitem'));
    }

    this.switchTab('#' + window.fUniqPrefix + '-overview');
    var tabElementSub = document.querySelector('#' + window.fUniqPrefix + '-tab-container1');
    this.objTabsSub = new EasyTabs(tabElementSub, {
      animate: false,
      updateHash: false,
    });

    this.objTabsSub.on('easytabs:after', function(a, b, c) {
      var el = c.selector.replace('#' + window.fUniqPrefix + '-', '');
      selfObj.subtabArr[el].codeMirror.refresh();
    });

    window.TH.createTabTP();

    if (this.blnFlagSettings) {
      // display the recorder panel with the Recorder Settings tab open
      document.querySelector('.' + window.fUniqPrefix + '-css-contentarea-buttons-advance-edit').click();
    }

    if (this.blnFlagBlankElement) {
      //we do not have an element selected - switch to the custom user code panel and hide the element details.
      selfObj.switchTabSub('#' + window.fUniqPrefix + '-code');
      document.querySelector('#' + window.fUniqPrefix + '-element').style.display = 'none';
    }
  };

  //Reconfigure the tabs for the next element - this is called on all subsequent times after the tabs have been first built.

  this.buildReinitialMainTabs = function(tabArray, WSRecordedData) {
    tabArray.forEach((tab, i) => {
      var tabType = tab.type;
      var defaultValue = null;

      if (tabType === 'buttons') {
        var wsdata = WSRecordedData[WSRecordedData.length - 1];
        if (typeof this.currentElement !== 'undefined') {
          if (this.currentElement) {
            if (this.currentElement.actionId !== wsdata.actionId) {
              wsdata = this.currentElement;
            }
          }
        }
        document.querySelectorAll('.f-lastCurrentAction').forEach(e => {
          e.innerHTML = JSON.stringify(wsdata);
          // Assuming hljs.highlightBlock is globally available
          hljs.highlightBlock(e);
        });
      }

      if (tabType === 'subtabs' && !this.blnFlagBlankElement) {
        var subtabArray = tab.tabs;
        subtabArray.forEach((subtab, ii) => {
          var subtabType = subtab.type;
          if (subtabType === 'editor') {
            defaultValue = this.getEditorDefaultValue(ii);
            subtab.codeMirror.getDoc().setValue(defaultValue);
          }
        });
      }

      if (tabType === 'editor') {
        defaultValue = this.getEditorDefaultValue(i);
        tab.codeMirror.getDoc().setValue(defaultValue);
        tab.initComplete = false;
      }
    });
  };

  //setup the tab options and the current active tabs on subsequent calls after the tabs have been first created.
  this.setRenitialTabsView = function(selfObj) {
    // Hide other two tabs
    document.querySelectorAll('.f-showTab').forEach(element => {
      element.classList.add('f-hideTab');
      element.classList.remove('f-showTab');
    });

    if (!this.blnFlagBlankElement) {
      let overviewTab = document.getElementById(window.fUniqPrefix + '-tab-overview');
      if (overviewTab) {
        overviewTab.classList.add('f-showTab');
        overviewTab.classList.remove('f-hideTab');
      }
    } else {
      document.querySelectorAll('.f-hideTab').forEach(element => {
        element.classList.add('f-showTab');
        element.classList.remove('f-hideTab');
      });

      let elementTab = document.getElementById(window.fUniqPrefix + '-tab-element');
      if (elementTab) {
        elementTab.classList.add('f-hideTab');
        elementTab.classList.remove('f-showTab');
      }

      this.switchTabSub('#' + window.fUniqPrefix + '-code');

      let elementContainer = document.getElementById(window.fUniqPrefix + '-element');
      if (elementContainer) {
        elementContainer.style.display = 'none';
      }
    }
  };

  this.processPageVariables = function(tObject, global, selfObj, editorObj, variabType) {
    if (tObject.classList.contains('f-disableLink')) {
      return false;
    }
    var waitString = '<div class="' + window.fUniqPrefix + '_formError f-hide_event"></div><div id="' + window.fUniqPrefix + '_pagevariables_table"><table style="width:100%">';

    var RVCHECKED = '';
    var RVSHOW = '';
    if (variabType == 'RV') {
      RVCHECKED = 'checked="true"';
      RVSHOW = 'style="display:table-row"';
    }

    var PVCHECKED = '';
    var PVSHOW = '';
    if (variabType == 'PV') {
      PVCHECKED = 'checked="true"';
      PVSHOW = 'style="display:table-row"';
    }

    var pageVariableKeyword = document.querySelector('.' + window.fUniqPrefix + '_page_variable_keyword').value;
    var resourceVariableURL = document.querySelector('.' + window.fUniqPrefix + '_resource_variable_url').value;

    waitString +=
      '<tr><td colspan="3" class="f-functionise-page-variable-select"><input type="radio" value="PV" name="f-functionise-page-variable" class="f-functionise-page-variable" ' +
      PVCHECKED +
      '><label>Page Variables</label><input type="radio" value="RV" name="f-functionise-page-variable" class="f-functionise-page-variable" ' +
      RVCHECKED +
      '><label>Resource Variables</label></td></tr>';
    waitString +=
      '<tr class="f-functionise-pv" ' +
      PVSHOW +
      '><td colspan="3" style="width: 700px !important;"><label class="f-functionise-pull-left" style="margin-top:5px;">Keyword:&nbsp;&nbsp;</label><input type="text" name="f-functionise_page_variable_keyword" value="' +
      pageVariableKeyword +
      '" class="f-functionise_page_variable_keyword f-functionise-pull-left"><a id="keywordSearchButton" class="f-functionise-pull-left">Search</a></td></tr>';

    var resourceDataUrlSelect =
      "<input class='" + window.fUniqPrefix + "_resource_variable_url' value='" + resourceVariableURL + "' placeholder='Start typing to see matching URLs'>";

    waitString +=
      '<tr class="f-functionise-rv" ' +
      RVSHOW +
      '><td colspan="3" style="width: 700px !important;"><label class="f-functionise-pull-left" style="margin-top:5px;">URL:&nbsp;&nbsp;</label>' +
      resourceDataUrlSelect +
      '</td></tr>';
    waitString +=
      '<tr><td colspan="2">&nbsp;</td></tr><tr class="f-functionise_page_variable_loader" style="display:none"><td colspan="2"><img src="https://' +
      window.WS.wbHost +
      '/wbjs/advanced/img/loadingicon.gif" style="float: left;margin-top: 20px;margin-bottom: 20px;" class="testsaveloader"></td></tr><tr class="f-functionise-pv-selection"><th>Variable</th><th class="f-functionise_attributeOperators">Operator</th><th>Value</th></tr>';

    var globalVariables = {};

    var keyValues = [];

    this.keyValuesGlobal = [];
    this.globalVariablesGlobal = {};

    global['_QueryString'] = {};
    window.location.search.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(str, key, value) {
      global['_QueryString'][key] = value;
    });

    try {
      this.setKeyValuesGlobal(global, '', 0);
    } catch (err) {}

    keyValues = this.keyValuesGlobal;
    globalVariables = this.globalVariablesGlobal;

    keyValues = keyValues.sort();

    var keyValuesSelect = "<select class='" + window.fUniqPrefix + "_pagevariables'  #ID#>";

    var checkedElement = document.querySelector('.f-functionise-page-variable:checked');
    var vav = checkedElement ? checkedElement.value : null;

    var fKeyValue = '';
    var maxToShow = 250;
    var counter = 0;
    if (keyValues.length > maxToShow)
      waitString +=
        "<tr class='f-functionise-pv-notfound'><td colspan='3'>Search limited to 250 records. Please enter a more specific search term for additional results.</td></tr>";

    try {
      for (var kVal in keyValues) {
        counter++;
        if (counter > maxToShow) break;
        if (vav == 'PV') keyValuesSelect += "<option value='" + keyValues[kVal] + "'>" + keyValues[kVal] + '</option>';
        else keyValuesSelect += '<option value="' + keyValues[kVal] + '" sValue="' + keyValues[kVal] + '">' + keyValues[kVal] + '</option>';

        if (!fKeyValue) {
          var keyname = String(keyValues[kVal])
            .trim()
            .replace('.', '_');
          fKeyValue = globalVariables[keyname];
          fKeyValue = fKeyValue.replace(/\"/g, '');
        }
      }
    } catch (err) {
      window.fconsole.log(err.message);
    }

    // Create the select element
    var select = document.createElement('select');
    select.className = window.fUniqPrefix + '_operatorselect';

    // Function to add options to the select element
    function addOptions(optionsArray) {
      optionsArray.forEach(function(attr, index) {
        var option = document.createElement('option');
        option.value = index;
        option.textContent = attr;
        select.appendChild(option);
      });
    }

    // Add the first set of options
    addOptions(operators);

    // Add the second set of options
    addOptions(attributeotheroperators.pageVariable);

    // Convert the select element to a string if needed
    var operatorString = select.outerHTML;

    // Create the select elements
    var stepvalueoptions = '';

    // Create the first select element
    var selectStepValue = document.createElement('select');
    selectStepValue.className = 'f-functionise-attrstepvalue hideitem';
    var defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.setAttribute('oValue', '');
    defaultOption.textContent = 'Select Step';
    selectStepValue.appendChild(defaultOption);

    // Populate the select element with options
    var WSRecordedData = window.WS.recordedData;
    WSRecordedData.forEach((value, index) => {
      if (value.action === 'verify') {
        var option = document.createElement('option');
        option.value = value.actionId;
        option.setAttribute('oValue', index);
        var stepText = 'Step ' + (index + 1) + ' - ' + value.action;
        option.textContent = stepText;
        selectStepValue.appendChild(option);
      }
    });
    stepvalueoptions += selectStepValue.outerHTML;

    // Create the second select element
    var selectStepAttribute = document.createElement('select');
    selectStepAttribute.className = 'f-functionise-attrstepattribute hideitem';
    stepvalueoptions += selectStepAttribute.outerHTML;

    // Create the third select element
    var selectStepFunction = document.createElement('select');
    selectStepFunction.className = 'f-functionise-attrstepfunction hideitem';
    var functionDefaultOption = document.createElement('option');
    functionDefaultOption.value = '';
    functionDefaultOption.textContent = 'Select Function';
    selectStepFunction.appendChild(functionDefaultOption);

    // Populate the third select element with options
    attributeFunctions.forEach(attr1 => {
      var option = document.createElement('option');
      option.value = attr1;
      option.textContent = attr1;
      selectStepFunction.appendChild(option);
    });
    stepvalueoptions += selectStepFunction.outerHTML;

    // Create the label element
    var label = document.createElement('label');
    label.className = 'f-functionise-attrstepvaluelabel hideitem';
    label.id = 'attrstepvaluelabel_pagevariable';
    stepvalueoptions += label.outerHTML;

    for (var i = 0; i < 1; i++) {
      var selectbox = keyValuesSelect.replace('#ID#', 'id="' + window.fUniqPrefix + '_pagevariables_' + i + '"');
      waitString +=
        '<tr class="f-functionise-pv-selection"><td><label>' +
        selectbox +
        '</label></td><td>' +
        operatorString +
        '</td><td><input id="' +
        window.fUniqPrefix +
        '_pagevariables_' +
        i +
        '_field" type="text" class="' +
        window.fUniqPrefix +
        '_pagevariables_fields" value="' +
        fKeyValue +
        '">' +
        stepvalueoptions +
        '</td></tr>';
    }

    waitString += '</table></div><div class="f-functionise-resourcevariablefullstring"></div>'; //<input id="hero-demo">';

    selfObj.keywordSearchButtonEvent(tObject, selfObj, editorObj);

    try {
      var autoCompleteChoices = [];
      Object.keys(window.TCM.resourceData).forEach(function(key) {
        var value = window.TCM.resourceData[key];
        if (Object.keys(value).length > 0) {
          autoCompleteChoices.push(key);
        }
      });
    } catch (err) {
      // Handle the error as needed
      console.error(err.message);
    }

    document.addEventListener('DOMContentLoaded', () => {
      var input = document.querySelector('.f-functionise_resource_variable_url');
      var autoCompleteChoices = []; // Ensure this is populated with your choices

      input.addEventListener('input', () => {
        var term = input.value.toLowerCase();
        var suggestions = autoCompleteChoices.filter(choice => {
          return choice.toLowerCase().includes(term);
        });

        // Custom logic to display suggestions
        // e.g., update a suggestion list element in the DOM
        console.log(suggestions); // Replace this with your suggestion rendering logic
      });

      var pageVariableElements = document.querySelectorAll('.' + window.fUniqPrefix + '_pagevariables');

      pageVariableElements.forEach(element => {
        element.addEventListener('change', () => {
          var textboxid = this.id + '_field';
          var keyname = this.value.trim().replace('.', '_');

          var gVariable = globalVariables[keyname];
          gVariable = gVariable.replace(/\"/g, '');
          document.getElementById(textboxid).value = gVariable;

          var pVal = this.value;
          if (pVal.indexOf('()') > 0) {
            var pos = pVal.indexOf('()');
            var res = pVal.substring(0, pos);
            var resSplit = res.split('.');
          }

          var selectedOption = this.querySelector('option:checked');
          var sValue = selectedOption ? selectedOption.getAttribute('sValue') : '';
          document.querySelector('.f-functionise-resourcevariablefullstring').innerHTML = sValue;
        });
      });

      // Select all elements with the class 'f-functionise_operatorselect'
      var operatorSelectElements = document.querySelectorAll('.f-functionise_operatorselect');

      operatorSelectElements.forEach(element => {
        element.addEventListener('change', () => {
          var inputTr = this.closest('tr'); // Get the closest <tr> element

          if (inputTr.querySelector('td:last-child [class*="attrstepvalue"]')) {
            // Show elements
            inputTr.querySelector('td:last-child .f-functionise_pagevariables_fields').classList.remove('hideitem');
            inputTr.querySelector('td:last-child [class*="attrstepvalue"]').classList.remove('hideitem');
            inputTr.querySelector('td:last-child [class*="attrstepfunction"]').classList.remove('hideitem');
            inputTr.querySelector('td:last-child [class*="attrstepattribute"]').classList.remove('hideitem');

            // Get the value of the select element
            var soperatorForInp = this.value;
            if (soperatorForInp.includes('stepval')) {
              inputTr.querySelector('td:last-child .f-functionise_pagevariables_fields').classList.add('hideitem');
            } else {
              inputTr.querySelector('td:last-child [class*="attrstepvalue"]').classList.add('hideitem');
              inputTr.querySelector('td:last-child [class*="attrstepfunction"]').classList.add('hideitem');
              inputTr.querySelector('td:last-child [class*="attrstepattribute"]').classList.add('hideitem');
            }
          }
        });
      });

      // Select all elements with the class 'f-functionise-attrstepvalue'
      var attrStepValueElements = document.querySelectorAll('.f-functionise-attrstepvalue');

      attrStepValueElements.forEach(element => {
        element.addEventListener('change', () => {
          var tvalue = this.value;
          var previousElement = this.previousElementSibling;
          if (previousElement) {
            previousElement.value = tvalue;
          }

          var label = document.getElementById('attrstepvaluelabel_pagevariable');
          if (label) {
            label.textContent = '';
          }

          var selectedOption = this.querySelector('option:checked');
          var oValue = selectedOption ? selectedOption.getAttribute('oValue') : '';
          var attt = window.WS.recordedData[oValue];

          // Assuming `orderKeys` is a method on an object accessible via `window.TCM.advancedEditor.oTabs`
          if (window.TCM && window.TCM.advancedEditor && window.TCM.advancedEditor.oTabs && typeof window.TCM.advancedEditor.oTabs.orderKeys === 'function') {
            window.TCM.advancedEditor.oTabs.orderKeys(attt);
          }

          var atttOptions = "<option value=''>Select Attribute</option>";

          Object.keys(attt).forEach(index => {
            var value = attt[index];
            var selectedText = '';
            var oValue = value;

            if (window.TCM.runtimeReplacementStrings && window.TCM.runtimeReplacementStrings[tvalue] && window.TCM.runtimeReplacementStrings[tvalue][index] != null) {
              oValue = window.TCM.runtimeReplacementStrings[tvalue][index];
            }

            if (window.TCM.variablePreviousSelection && window.TCM.variablePreviousSelection[1] && window.TCM.variablePreviousSelection[1] == index) {
              selectedText = "selected='selected'";
              var stepAttrValueFunction = document.querySelector('.f-functionise-stepAttrValueFunction');
              if (stepAttrValueFunction) {
                stepAttrValueFunction.textContent = oValue;
              }
            }

            if (attt.actualstring && index === 'value') {
              oValue = attt.actualstring;
            }

            atttOptions += `<option value="${index}" oValue="${oValue}" ${selectedText}>${index}</option>`;
          });

          var table = this.closest('table');
          if (table) {
            var attrStepAttributeElements = table.querySelectorAll('.f-functionise-attrstepattribute');
            attrStepAttributeElements.forEach(el => {
              el.innerHTML = atttOptions;
            });
          }
        });
      });

      // Event handler for .f-functionise-attrstepattribute change
      document.querySelectorAll('.f-functionise-attrstepattribute').forEach(element => {
        element.addEventListener('change', () => {
          var selectedOption = this.querySelector('option:checked');
          var oValue = selectedOption ? selectedOption.getAttribute('oValue') : '';

          var label = document.getElementById('attrstepvaluelabel_pagevariable');
          if (label) {
            label.textContent = oValue;
          }

          var tvalue = document.querySelector('.f-functionise-attrstepvalue').value;
          var cvalue = this.value;

          if (cvalue) {
            tvalue += '|FUNCSTEP|' + cvalue;
          }

          var fvalue = document.querySelector('.f-functionise-attrstepfunction').value;

          if (cvalue && fvalue) {
            tvalue += '|FUNCSTEP|' + fvalue;
          }

          var previousElement = document.querySelector('.f-functionise-attrstepvalue').previousElementSibling;
          if (previousElement) {
            previousElement.value = tvalue;
          }
        });
      });

      // Event handler for .f-functionise-attrstepfunction change
      document.querySelectorAll('.f-functionise-attrstepfunction').forEach(element => {
        element.addEventListener('change', function() {
          var selectedOption = this.querySelector('option:checked');
          var oValue = selectedOption ? selectedOption.getAttribute('oValue') : '';

          var tvalue = document.querySelector('.f-functionise-attrstepvalue').value;
          var cvalue = document.querySelector('.f-functionise-attrstepattribute').value;
          var fvalue = this.value;

          if (cvalue) {
            tvalue += '|FUNCSTEP|' + cvalue;
          }

          if (cvalue && fvalue) {
            tvalue += '|FUNCSTEP|' + fvalue;
          }

          var previousElement = document.querySelector('.f-functionise-attrstepvalue').previousElementSibling;
          if (previousElement) {
            previousElement.value = tvalue;
          }
        });
      });
    });
  };

  //Attach events and actions to different elements in the panel
  this.setPostEvents = function(editorObj) {
    var selfObj = this; // Or use appropriate context if not in a method
    document.addEventListener('DOMContentLoaded', () => {
      // Save Button
      document.querySelectorAll('.' + window.fUniqPrefix + '-css-contentarea-editor-saveButton').forEach(button => {
        button.addEventListener('click', e => {
          selfObj.attributeOperators = {};
          if (button.classList.contains('disable')) {
            e.preventDefault();
            return false;
          }
          var activeButton = document.querySelector('#f-functionise-tc-manager-buttons #setting-button.active-bottompanel');
          if (activeButton) {
            activeButton.classList.remove('active-bottompanel');
          }
          if (editorObj && typeof editorObj.processSubmit === 'function') {
            editorObj.processSubmit();
          }
          e.preventDefault();
          return false;
        });
      });

      // Clear Button
      document.querySelectorAll('.' + window.fUniqPrefix + '-css-contentarea-editor-clearButton').forEach(button => {
        button.addEventListener('click', e => {
          if (button.classList.contains('disable')) {
            e.preventDefault();
            return false;
          }
          if (editorObj && typeof editorObj.clearSubmit === 'function') {
            editorObj.clearSubmit(button);
          }
          e.preventDefault();
          return false;
        });
      });

      // Test Button
      document.querySelectorAll('.' + window.fUniqPrefix + '-css-contentarea-editor-testButton').forEach(button => {
        button.addEventListener('click', e => {
          if (button.classList.contains('disable')) {
            e.preventDefault();
            return false;
          }
          if (editorObj && typeof editorObj.processTestCode === 'function') {
            var activeTab = selfObj.getActiveTab('1').replace('#' + window.fUniqPrefix + '-', '');
            editorObj.processTestCode(activeTab);
          }
          e.preventDefault();
          return false;
        });
      });

      // Continue Button
      document.querySelectorAll('.' + window.fUniqPrefix + '-css-contentarea-buttons-continue').forEach(button => {
        button.addEventListener('click', e => {
          if (button.classList.contains('disable')) {
            e.preventDefault();
            return false;
          }
          if (editorObj && typeof editorObj.processSubmit === 'function') {
            editorObj.processSubmit();
          }
          currentElement = null;
          e.preventDefault();
          return false;
        });
      });

      // Advance Edit Button
      document.querySelectorAll('.' + window.fUniqPrefix + '-css-contentarea-buttons-advance-edit').forEach(function(button) {
        button.addEventListener('click', function() {
          selfObj.advanceEditAction(true);
        });
      });

      // Code Validate Link
      document.querySelectorAll('.' + window.fUniqPrefix + '-code_validate_link').forEach(function(link) {
        link.addEventListener('click', function(e) {
          if (editorObj && typeof editorObj.processTestCode === 'function') {
            editorObj.processTestCode(selfObj.getActiveTab().replace('#' + window.fUniqPrefix + '-', ''));
          }
          e.preventDefault();
          return false;
        });
      });

      // Code Insert Variable
      document.querySelectorAll('.' + window.fUniqPrefix + '-code_insert_variable').forEach(function(link) {
        link.addEventListener('click', function(e) {
          if (link.classList.contains('f-disableLink')) {
            e.preventDefault();
            return false;
          }

          var variablePreviousSelection = window.TCM.variablePreviousSelection || '';
          var variablePreviousSelectionArr = {};
          variablePreviousSelection = variablePreviousSelection.split('|');
          if (variablePreviousSelection.length == 3) {
            selfObj.flagVariablePreviousSelection = true;
          }

          var waitString =
            '<div class="' +
            window.fUniqPrefix +
            '_formError f-hide_event"></div>' +
            '<div id="' +
            window.fUniqPrefix +
            '_insert_Variable_table"><table>' +
            '<tr><td><label>Type:</label></td><td><select name="' +
            window.fUniqPrefix +
            '_set_variable_type" class="' +
            window.fUniqPrefix +
            '_set_variable_type">' +
            '<option value="FV">Functionize Variable</option></select></td></tr>';

          var selectboxstr = '<select class="f-functionise-attrstepvalue">' + '<option value="" oValue="">Select Step</option>';

          var WSRecordedData = window.WS.recordedData || {};
          Object.keys(WSRecordedData).forEach(function(index) {
            var value = WSRecordedData[index];
            if (value.action === 'verify' || value.action === 'input') {
              selectboxstr += '<option value="' + value.actionId + '" oValue="' + parseInt(index) + '">Step ' + (parseInt(index) + 1) + ' - ' + value.action + '</option>';
              try {
                selfObj.globalStepAttribute[index] = {};
              } catch (err) {}

              Object.keys(value).forEach(function(index1) {
                var value1 = value[index1];
                if (value1 && index1 !== 'actionId') {
                  selfObj.globalStepAttribute[index][index1] = value1;
                }
              });
            }
          });

          selectboxstr += '</select>';

          waitString +=
            '<tr><td><label>Step #:</label></td><td>' +
            selectboxstr +
            '</td></tr>' +
            '<tr><td><label>Attribute:</label></td><td><select class="f-functionise-attrstepattribute"><option value="">Select Attribute</option></select></td></tr>';

          selectboxstr = '<select class="f-functionise-attrstepfunction">' + '<option value="">Select Function</option>';

          (attributeFunctions || []).forEach(function(attr1) {
            if (typeof variablePreviousSelection[2] !== 'undefined' && variablePreviousSelection[2] && variablePreviousSelection[2] === attr1) {
              selectboxstr += "<option value='" + attr1 + "' selected='selected'>" + attr1 + '</option>';
            } else {
              selectboxstr += "<option value='" + attr1 + "'>" + attr1 + '</option>';
            }
          });

          selectboxstr += '</select>';
          waitString +=
            '<tr><td><label>Process Function:</label></td><td>' +
            selectboxstr +
            '</td></tr>' +
            '<tr><td><label>Step Value:</label></td><td class="f-functionise-stepAttrValueFunction"></td></tr>' +
            '</table></div>';

          // Insert the constructed HTML into the DOM
          document.querySelector('body').insertAdjacentHTML('beforeend', waitString);

          // Event handlers for dynamically added elements
          document.querySelectorAll('.f-functionise-attrstepattribute').forEach(function(select) {
            select.addEventListener('change', function() {
              var value = this.value;
              var oValue = this.querySelector('option:checked').getAttribute('oValue');
              document.querySelector('.f-functionise-stepAttrValueFunction').textContent = oValue;
            });
          });

          document.querySelectorAll('.f-functionise-attrstepvalue').forEach(function(select) {
            select.addEventListener('change', function() {
              var tvalue = this.value;
              var oValue = this.querySelector('option:checked').getAttribute('oValue');
              var attt = selfObj.globalStepAttribute[oValue] || {};

              selfObj.orderKeys(attt);

              var atttOptions = "<option value=''>Select Attribute</option>";
              Object.keys(attt).forEach(function(index) {
                var selectedText = '';
                var oValue = attt[index];
                if (
                  typeof window.TCM.runtimeReplacementStrings[tvalue] !== 'undefined' &&
                  typeof window.TCM.runtimeReplacementStrings[tvalue][index] !== 'undefined' &&
                  window.TCM.runtimeReplacementStrings[tvalue][index] !== null
                ) {
                  oValue = window.TCM.runtimeReplacementStrings[tvalue][index];
                }
                if (
                  typeof window.TCM.variablePreviousSelection[1] !== 'undefined' &&
                  window.TCM.variablePreviousSelection[1] &&
                  window.TCM.variablePreviousSelection[1] === index
                ) {
                  selectedText = "selected='selected'";
                  document.querySelector('.f-functionise-stepAttrValueFunction').textContent = oValue;
                }
                atttOptions += "<option value='" + index + "' oValue='" + oValue + "' " + selectedText + '>' + index + '</option>';
              });

              var parentTable = this.closest('table');
              if (parentTable) {
                parentTable.querySelector('.f-functionise-attrstepattribute').innerHTML = atttOptions;
              }
            });
          });

          if (typeof window.TCM.variablePreviousSelection[0] !== 'undefined' && window.TCM.variablePreviousSelection[0]) {
            var attrStepValue = document.querySelector('.f-functionise-attrstepvalue');
            if (attrStepValue) {
              attrStepValue.value = window.TCM.variablePreviousSelection[0];
              var event = new Event('change');
              attrStepValue.dispatchEvent(event);
            }
          }

          e.preventDefault();
          return false;
        });
      });

      // Attribute Editor Click Event
      document.querySelectorAll('.' + window.fUniqPrefix + '-attributeEditor').forEach(function(button) {
        button.addEventListener('click', function() {
          var isVerifying = window.TCM.isVerifying;

          if (button.classList.contains('f-disableLink')) {
            return false;
          }

          if (isVerifying) {
            selfObj.addVerifyAttributeEditor(selfObj);
          } else {
            selfObj.addClickAttributeEditor(selfObj);
          }
        });
      });

      // Deprecated Wait Action Click Event
      document.querySelectorAll('.' + window.fUniqPrefix + '-waitAction').forEach(function(button) {
        button.addEventListener('click', function(e) {
          if (button.classList.contains('f-disableLink')) {
            e.preventDefault();
            return false;
          }

          var waitString =
            '<div class="f-functionise_formError f-hide_event"></div>' +
            '<div id="' +
            window.fUniqPrefix +
            '_wait_table"><table>' +
            '<tr><td><label>Wait time (in ms) </label></td>' +
            '<td><input type="text" name="f-functionise_wait_interval_value" value="1000" class="f-functionise_wait_interval_value"></td></tr>' +
            '</table></div>';

          document.querySelector('body').insertAdjacentHTML('beforeend', waitString);

          e.preventDefault();
          return false;
        });
      });

      // Set Cookie Click Event
      document.querySelectorAll('.' + window.fUniqPrefix + '-setCookie').forEach(function(button) {
        button.addEventListener('click', function(e) {
          if (button.classList.contains('f-disableLink')) {
            e.preventDefault();
            return false;
          }

          var waitString =
            '<div class="' +
            window.fUniqPrefix +
            '_formError f-hide_event"></div>' +
            '<div id="' +
            window.fUniqPrefix +
            '_set_cookie_table"><table>' +
            '<tr><td><label>Storage Type:</label></td>' +
            '<td><select name="' +
            window.fUniqPrefix +
            '_set_storage_type" class="' +
            window.fUniqPrefix +
            '_set_cookie_fields ' +
            window.fUniqPrefix +
            '_set_storage_type">' +
            '<option value="COOKIE">COOKIE</option>' +
            '<option value="HTML5">HTML5</option></select></td></tr>' +
            '<tr><td><label>Storage Name:</label></td>' +
            '<td><input type="text" name="' +
            window.fUniqPrefix +
            '_set_storage_name" class="' +
            window.fUniqPrefix +
            '_set_cookie_fields ' +
            window.fUniqPrefix +
            '_set_storage_name"></td></tr>' +
            '<tr><td><label>Storage Value:</label></td>' +
            '<td><input type="text" name="' +
            window.fUniqPrefix +
            '_set_storage_value" class="' +
            window.fUniqPrefix +
            '_set_cookie_fields ' +
            window.fUniqPrefix +
            '_set_storage_value"></td></tr>' +
            '<tr class="' +
            window.fUniqPrefix +
            '_storage_duration"><td><label>Storage Duration (in sec): </label></td>' +
            '<td><input type="text" name="' +
            window.fUniqPrefix +
            '_set_storage_duration" class="' +
            window.fUniqPrefix +
            '_set_cookie_fields ' +
            window.fUniqPrefix +
            '_set_storage_duration"></td></tr>' +
            // '<tr class="' + window.fUniqPrefix + '_storage_expirecookie"><td><label>Expire COOKIE: </label></td>' +
            // '<td><input type="checkbox" name="' + window.fUniqPrefix + '_set_storage_expirecookie" class="' + window.fUniqPrefix + '_set_cookie_fields ' + window.fUniqPrefix + '_set_storage_expirecookie"></td></tr>' +
            '</table></div>';

          document.querySelector('body').insertAdjacentHTML('beforeend', waitString);

          // Event handler for dynamically added elements
          document.querySelectorAll('.' + window.fUniqPrefix + '_set_storage_type').forEach(function(select) {
            select.addEventListener('change', function() {
              var storageType = this.value;
              var storageDuration = document.querySelector('.' + window.fUniqPrefix + '_storage_duration');
              var storageExpireCookie = document.querySelector('.' + window.fUniqPrefix + '_storage_expirecookie');

              if (storageType === 'COOKIE') {
                if (storageDuration) storageDuration.classList.remove('hide');
                if (storageExpireCookie) storageExpireCookie.classList.remove('hide');
              } else {
                if (storageDuration) storageDuration.classList.add('hide');
                if (storageExpireCookie) storageExpireCookie.classList.add('hide');
              }
            });
          });

          e.preventDefault();
          return false;
        });
      });

      //Page Variables Window
      //chrome workflow
      var tObject;

      // Enable Focus on Element Click Event
      document.querySelectorAll('.' + window.fUniqPrefix + '-EnableFocusOnElement').forEach(function(button) {
        button.addEventListener('click', function() {
          document.querySelectorAll('.' + window.fUniqPrefix + '-DisableFocusOnElement').forEach(function(el) {
            el.classList.remove('hideitem');
          });
          document.querySelectorAll('.' + window.fUniqPrefix + '-EnableFocusOnElement').forEach(function(el) {
            el.classList.add('hideitem');
          });
          window.WS.focusOnElementFlag = true;
        });
      });

      // Disable Focus on Element Click Event
      document.querySelectorAll('.' + window.fUniqPrefix + '-DisableFocusOnElement').forEach(function(button) {
        button.addEventListener('click', function() {
          document.querySelectorAll('.' + window.fUniqPrefix + '-EnableFocusOnElement').forEach(function(el) {
            el.classList.remove('hideitem');
          });
          document.querySelectorAll('.' + window.fUniqPrefix + '-DisableFocusOnElement').forEach(function(el) {
            el.classList.add('hideitem');
          });
          window.WS.focusOnElementFlag = false;
        });
      });

      // Page Variables Action Click Event
      document.querySelectorAll('.' + window.fUniqPrefix + '-pageVariablesAction').forEach(function(button) {
        button.addEventListener('click', function() {
          tObject = this;

          var waitString =
            '<div class="f-functionise_formError f-hide_event"></div>' +
            '<div id="' +
            window.fUniqPrefix +
            '_pagevariables_table"><table>' +
            '<tr><td colspan="3" class="f-functionise-page-variable-select">' +
            '<input type="radio" value="PV" name="f-functionise-page-variable" class="f-functionise-page-variable">' +
            '<label>Page Variables</label>' +
            '<input type="radio" value="RV" name="f-functionise-page-variable" class="f-functionise-page-variable">' +
            '<label>Resource Variables</label></td></tr>' +
            '<tr class="f-functionise-pv"><td colspan="3" style="width: 700px !important;">' +
            '<label class="f-functionise-pull-left" style="margin-top:5px;">Keyword:&nbsp;&nbsp;</label>' +
            '<input type="text" name="f-functionise_page_variable_keyword" value="" class="f-functionise_page_variable_keyword f-functionise-pull-left">' +
            '<a id="keywordSearchButton" class="f-functionise-pull-left">Search</a></td></tr>' +
            '<tr class="f-functionise-rv"><td colspan="3" style="width: 700px !important;">' +
            '<label class="f-functionise-pull-left" style="margin-top:5px;">URL:&nbsp;&nbsp;</label>' +
            '<input class="' +
            window.fUniqPrefix +
            '_resource_variable_url" value="" placeholder="Start typing to see matching URLs"></td></tr>' +
            '<tr><td colspan="2">&nbsp;</td></tr>' +
            '<tr class="f-functionise_page_variable_loader" style="display:none">' +
            '<td colspan="2"><img src="https://' +
            window.WS.wbHost +
            '/wbjs/advanced/img/loadingicon.gif" style="float: left;" class="testsaveloader"></td></tr>' +
            '</table></div>';

          document.querySelector('body').insertAdjacentHTML('beforeend', waitString);

          try {
            selfObj.keywordSearchButtonEvent(this, selfObj, editorObj);
          } catch (err) {
            alert(err.message);
          }
        });
      });

      // Save Variables Action Click Event
      document.querySelectorAll('.' + window.fUniqPrefix + '-saveVariablesAction').forEach(function(button) {
        button.addEventListener('click', function() {
          if (button.classList.contains('f-disableLink')) {
            return false;
          }
          var waitString = '';

          if (button.classList.contains('f-settingLink')) {
            var fVarValue = '';

            waitString =
              '<div class="' +
              window.fUniqPrefix +
              '_formError f-hide_event"></div>' +
              '<div id="' +
              window.fUniqPrefix +
              '_projectvariables_table">' +
              '<div class="f-functionise_saveVariableActionTypeContent">' +
              '<input type="text" id="f-functionise_saveVariableActionName" placeholder="Variable Name">' +
              '<select id="f-functionise_projectVariableAttribute">';

            var cookies = window.WS.getOtherCookies();
            if (cookies.length > 0) {
              cookies.forEach(function(cookie) {
                if (!fVarValue) fVarValue = cookie.value;
                waitString += '<option value="COOKIE.' + cookie.name + '" ovalue="' + cookie.value + '">COOKIE.' + cookie.name + '</option>';
              });
            }

            for (var i = 0, len = localStorage.length; i < len; ++i) {
              var lkey = localStorage.key(i);
              var lvalue = localStorage.getItem(lkey);
              if (!fVarValue) fVarValue = lvalue;
              waitString += '<option value="HTML.' + lkey + '" ovalue="' + lvalue + '">HTML.' + lkey + '</option>';
            }
            waitString += '<option value="JS.CUSTOM_CODE" ovalue="">JS.CUSTOM_CODE</option>';
            waitString += '</select>';

            waitString += '<div class="' + window.fUniqPrefix + '_variableValue">' + decodeURI(fVarValue) + '</div>';

            waitString +=
              '<div class="' +
              window.fUniqPrefix +
              '_js_cutome_code hideitem" style="height: 100px !important; float: left; width: 100% !important; margin-top: 10px">' +
              '<textarea id="' +
              window.fUniqPrefix +
              '_js_cutome_code_input" style="height: 100px !important; width: 100% !important;"></textarea></div>';

            waitString += '</div></div>';

            document.querySelector('body').insertAdjacentHTML('beforeend', waitString);

            // Event handler for dynamically added elements
            document.querySelector('#f-functionise_projectVariableAttribute').addEventListener('change', function() {
              var oValue = this.options[this.selectedIndex].getAttribute('ovalue');
              document.querySelector('.f-functionise_variableValue').innerHTML = decodeURI(oValue);
              if (this.value === 'JS.CUSTOM_CODE') {
                document.querySelector('.' + window.fUniqPrefix + '_js_cutome_code').classList.remove('hideitem');
              } else {
                document.querySelector('.' + window.fUniqPrefix + '_js_cutome_code').classList.add('hideitem');
              }
            });

            return true;
          } else {
            waitString =
              '<div class="' +
              window.fUniqPrefix +
              '_formError f-hide_event"></div>' +
              '<div id="' +
              window.fUniqPrefix +
              '_projectvariables_table">' +
              '<div class="f-functionise_saveVariableActionTypeContent">' +
              '<input type="text" id="f-functionise_saveVariableActionName" placeholder="Variable Name">' +
              '<select id="f-functionise_projectVariableAttribute">';

            for (var key in attributeotheroperators) {
              if (attributeotheroperators.hasOwnProperty(key)) {
                switch (key) {
                  case 'text':
                    if (selfObj.currentElement.text !== undefined) {
                      waitString += '<option value="' + key + '" ovalue="' + selfObj.currentElement.text + '">' + key + '</option>';
                    }
                    break;
                  case 'value':
                    if (selfObj.currentElement.value !== undefined) {
                      waitString += '<option value="' + key + '" ovalue="' + selfObj.currentElement.value + '">' + key + '</option>';
                    }
                    break;
                  case 'html':
                    if (selfObj.currentElement.html !== undefined) {
                      waitString += '<option value="' + key + '" ovalue="' + selfObj.currentElement.html + '">' + key + '</option>';
                    }
                    break;
                }
              }
            }
            waitString += '</select></div></div>';

            document.querySelector('body').insertAdjacentHTML('beforeend', waitString);
          }
        });
      });

      var loadVariablesActions = document.querySelectorAll('.' + window.fUniqPrefix + '-loadVariablesAction');

      loadVariablesActions.forEach(function(action) {
        action.removeEventListener('click', handleLoadVariablesActionClick); // Remove previous event listener if needed
        action.addEventListener('click', handleLoadVariablesActionClick);
      });

      function handleLoadVariablesActionClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div class="' + window.fUniqPrefix + '_formError f-hide_event"></div><div id="' + window.fUniqPrefix + '_projectvariables_table">';
        waitString += '<div class="f-functionise_loadVariableActionTypeContent">';
        waitString += '<input type="text" id="f-functionise_loadVariableActionName" placeholder="Variable Name">';

        if (this.classList.contains('f-settingLink')) {
          waitString += '<input type="text" id="f-functionise_loadVariableAttribute" placeholder="Store into">';
          waitString += '<select id="f-functionise_loadVariableAttributeOperation"><option value="load">Load</option></select>';
        } else {
          waitString += '<select id="f-functionise_loadVariableAttribute">';
          Object.keys(attributeotheroperators).forEach(function(index) {
            switch (index) {
              case 'text':
                if (selfObj.currentElement.text !== 'undefined') waitString += '<option value="' + index + '" oValue="' + selfObj.currentElement.text + '">' + index + '</option>';
                break;
              case 'value':
                if (selfObj.currentElement.value !== 'undefined')
                  waitString += '<option value="' + index + '" oValue="' + selfObj.currentElement.value + '">' + index + '</option>';
                break;
              case 'html':
                if (selfObj.currentElement.html !== 'undefined') waitString += '<option value="' + index + '" oValue="' + selfObj.currentElement.html + '">' + index + '</option>';
                break;
            }
          });
          waitString += '</select>';
          waitString += '<select id="f-functionise_loadVariableAttributeOperation"><option value="load">Load</option><option value="verify">Verify</option></select>';
        }

        waitString += '</div>';
        waitString += '</div>';

        // Your code to handle `waitString`
      }

      var emailActions = document.querySelectorAll('.' + window.fUniqPrefix + '-emailAction');

      emailActions.forEach(function(action) {
        action.removeEventListener('click', handleEmailActionClick); // Remove previous event listener if needed
        action.addEventListener('click', handleEmailActionClick);
      });

      function handleEmailActionClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div id="' + window.fUniqPrefix + '_emailreader_table"><table>';
        waitString += '<tr><td colspan="2"><label>Do you want to open the functionize email reader?</label></td></tr>';
        waitString += '<tr><td colspan="2">&nbsp;</td></tr>';
        waitString +=
          '<tr><td style="width: 20px"><input type="checkbox" name="f-functionise_emailreader_confirm" value="" class="f-functionise_emailreader_confirm"></td><td><label>Open in a new tab</label></td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
      }

      var fileViewers = document.querySelectorAll('.' + window.fUniqPrefix + '-fileViewer');

      fileViewers.forEach(function(viewer) {
        viewer.removeEventListener('click', handleFileViewerClick); // Remove previous event listener if needed
        viewer.addEventListener('click', handleFileViewerClick);
      });

      function handleFileViewerClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div id="' + window.fUniqPrefix + '_emailreader_table"><table>';
        waitString += '<tr><td colspan="2"><label>Do you want to open the functionize file viewer?</label></td></tr>';
        waitString += '<tr><td colspan="2">&nbsp;</td></tr>';
        waitString +=
          '<tr><td style="width: 20px"><input type="checkbox" name="f-functionise_emailreader_confirm" value="" class="f-functionise_emailreader_confirm"></td><td><label>Open in a new tab</label></td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
      }

      var dbExplorers = document.querySelectorAll('.' + window.fUniqPrefix + '-DBExplorer');

      dbExplorers.forEach(function(explorer) {
        explorer.removeEventListener('click', handleDBExplorerClick); // Remove previous event listener if needed
        explorer.addEventListener('click', handleDBExplorerClick);
      });

      function handleDBExplorerClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div id="' + window.fUniqPrefix + '_emailreader_table"><table>';
        waitString += '<tr><td colspan="2"><label>Do you want to open the functionize DB Explorer?</label></td></tr>';
        waitString += '<tr><td colspan="2">&nbsp;</td></tr>';
        waitString +=
          '<tr><td style="width: 20px"><input type="checkbox" name="f-functionise_emailreader_confirm" value="" class="f-functionise_emailreader_confirm"></td><td><label>Open in a new tab</label></td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
      }

      var addActionNotes = document.querySelectorAll('.' + window.fUniqPrefix + '-addActionNote');

      addActionNotes.forEach(function(note) {
        note.removeEventListener('click', handleAddActionNoteClick); // Remove previous event listener if needed
        note.addEventListener('click', handleAddActionNoteClick);
      });

      function handleAddActionNoteClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var lastAction = window.WS.recordedData[window.WS.recordedData.length - 1];
        if (window.TCM.isVerifying || !window.TCM.recording || typeof lastAction === 'undefined' || !lastAction) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div class="f-functionise_formError f-hide_event"></div><div id="' + window.fUniqPrefix + '_notepad_table"><table>';
        waitString += '<tr><td><textarea name="f-functionise_notepad_area" class="f-functionise_notepad_area" placeholder="Action note..."></textarea></td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
      }

      var relatedElements = document.querySelectorAll('.' + window.fUniqPrefix + '-relatedElement');

      relatedElements.forEach(function(element) {
        element.removeEventListener('click', handleRelatedElementClick);
        element.addEventListener('click', handleRelatedElementClick);
      });

      function handleRelatedElementClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }
        window.TCM.currentElementForRelated = selfObj.currentElement;
        var waitString = '<div id="' + window.fUniqPrefix + '_emailreader_table"><table>';
        waitString += '<tr><td colspan="2"><label>Please select related element</label></td></tr>';
        waitString += '<tr><td colspan="2">&nbsp;</td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
        e.preventDefault();
        return false;
      }

      var domWalkElements = document.querySelectorAll('.' + window.fUniqPrefix + '-DomWalk');

      domWalkElements.forEach(function(element) {
        element.removeEventListener('click', handleDomWalkClick);
        element.addEventListener('click', handleDomWalkClick);
      });

      function handleDomWalkClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div id="' + window.fUniqPrefix + '_emailreader_table"><table style="width:100%;">';
        waitString += '<tr><td colspan="2"><label>Select the desired target element using the arrows below.</label></td></tr>';
        waitString +=
          '<tr><td colspan="2">' +
          '<div class="domWalkArrow">' +
          '<div class="domWalkArrowRow">' +
          '<div class="domWalkArrowSingle">&nbsp;</div>' +
          '<div class="domWalkArrowSingle domWalkArrowUp" rel="up">&uarr;</div>' +
          '<div class="domWalkArrowSingle">&nbsp;</div>' +
          '</div>' +
          '<div class="domWalkArrowRow">' +
          '<div class="domWalkArrowSingle domWalkArrowLeft" rel="left">&larr;</div>' +
          '<div class="domWalkArrowSingle">&nbsp;</div>' +
          '<div class="domWalkArrowSingle domWalkArrowRight" rel="right">&rarr;</div>' +
          '</div>' +
          '<div class="domWalkArrowRow">' +
          '<div class="domWalkArrowSingle">&nbsp;</div>' +
          '<div class="domWalkArrowSingle domWalkArrowDown" rel="down">&darr;</div>' +
          '<div class="domWalkArrowSingle">&nbsp;</div>' +
          '</div>' +
          '</div>' +
          '<div class="f_functionise_or_text">OR</div>' +
          '<div class="f_functionise_seach_query_selector_outer"><div class="f_functionise_seach_query_selector">' +
          '<div class="f_functionise_seach_query_selector_text">' +
          '<label>Enter the desired target element using the query selector.</label></div>' +
          '<input type="text" name="f-functionise_query_selector" value="" class="f-functionise f_functionise_query_selector">' +
          '<input type="hidden" class="f-functionise_element_found" value="0">' +
          '<a class="f-functionise f_functionise_useQuerySelector">Search</a></div></div>' +
          '<div class="domSelector"></div>' +
          '</td></tr>';
        waitString += '</table></div>';

        document
          .querySelector('#f-functionise-css-advance-editor-wrapper')
          .classList.remove('f-showTab')
          .classList.add('f-hideTab');

        var useQuerySelector = document.querySelector('.f_functionise_useQuerySelector');
        useQuerySelector.removeEventListener('click', handleQuerySelectorClick);
        useQuerySelector.addEventListener('click', handleQuerySelectorClick);

        function handleQuerySelectorClick(e) {
          document.querySelector('.f_functionise_hiddenElementFound').classList.add('hideitem');
          document.querySelector('.f-functionise_element_found').value = '0';
          var querySelector = document.querySelector('.f_functionise_query_selector').value;
          if (querySelector) {
            try {
              var selectedElements = document.querySelectorAll(querySelector);
              if (selectedElements.length > 0) {
                selfObj.domWalkElementSearch = true;
                selfObj.domWalkElementSearchSelector = querySelector;
                selfObj.validateDomWalkArrow('', selectedElements);
              } else {
                alert('Invalid Selector-1');
              }
            } catch (err) {
              alert('Invalid Selector-2');
            }
          }
        }

        selfObj.domWalkElement = document.querySelector(window.WS.getUniqueSelector(selfObj.currentElement));

        document.querySelectorAll('.f-domWalkSelector').forEach(function(el) {
          el.classList.remove('f-domWalkSelector');
        });

        selfObj.domWalkElement.classList.add('f-domWalkSelector');

        document.querySelectorAll('.domWalkArrowSingle').forEach(function(element) {
          element.removeEventListener('click', handleArrowClick);
          element.addEventListener('click', handleArrowClick);
        });

        function handleArrowClick(e) {
          selfObj.domWalkElementSearch = false;
          selfObj.validateDomWalkArrow(this);
        }

        selfObj.validateDomWalkArrow();
        e.preventDefault();
        return false;
      }

      var eSignatureElements = document.querySelectorAll('.' + window.fUniqPrefix + '-eSignature');

      eSignatureElements.forEach(function(element) {
        element.removeEventListener('click', handleESignatureClick);
        element.addEventListener('click', handleESignatureClick);
      });

      function handleESignatureClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        if (!window.WS.canvasSignatureStart) {
          var waitString = '<div id="' + window.fUniqPrefix + '_emailreader_table"><table>';
          waitString += '<tr><td colspan="2"><label>Please Enter Signature.</label></td></tr>';
          waitString += '</table></div>';

          // Your code to handle `waitString`
        } else {
          try {
            window.WS.createSignatureAction();
            window.WS.isMouseDown = false;
            window.WS.canvasSignature = [];
            window.WS.canvasSignatureSingle = {};
            window.WS.canvasSignatureCount = 0;
            window.WS.canvasSignatureStart = false;
            window.WS.canvasSignatureElement = '';
            document.querySelectorAll('.' + window.fUniqPrefix + '-eSignature').forEach(function(el) {
              el.textContent = 'Start Signature';
            });
          } catch (err) {
            alert(err.message);
            if (window.fconsole) window.fconsole.log(err);
          }
        }
        e.preventDefault();
        return false;
      }

      var actionLogElements = document.querySelectorAll('.' + window.fUniqPrefix + '-ActionLog');

      actionLogElements.forEach(function(element) {
        element.removeEventListener('click', handleActionLogClick);
        element.addEventListener('click', handleActionLogClick);
      });

      function handleActionLogClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div id="' + window.fUniqPrefix + '_actionlog_table" style="height:400px;"><table>';
        waitString += '<tr><td colspan="2"><label>Action Log:</label></td></tr>';
        waitString += '<tr><td colspan="2" class="f-functionise-actions_description"><div class="f-funcitonise-loader-image">&nbsp;</div></td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
        selfObj.getactionloghumanized();
        e.preventDefault();
        return false;
      }

      var smsActionElements = document.querySelectorAll('.' + window.fUniqPrefix + '-smsAction');

      smsActionElements.forEach(function(element) {
        element.removeEventListener('click', handleSmsActionClick);
        element.addEventListener('click', handleSmsActionClick);
      });

      function handleSmsActionClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div id="' + window.fUniqPrefix + '_emailreader_table"><table>';
        waitString += '<tr><td colspan="2"><label>Do you want to open the functionize SMS reader?</label></td></tr>';
        waitString += '<tr><td colspan="2">&nbsp;</td></tr>';
        waitString +=
          '<tr><td style="width: 20px"><input type="checkbox" name="f-functionise_emailreader_confirm" value="" class="f-functionise_emailreader_confirm"></td><td><label>Open in a new tab</label></td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
        e.preventDefault();
        return false;
      }

      var apiActionElements = document.querySelectorAll('.' + window.fUniqPrefix + '-apiAction');

      apiActionElements.forEach(function(element) {
        element.removeEventListener('click', handleApiActionClick);
        element.addEventListener('click', handleApiActionClick);
      });

      function handleApiActionClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div id="' + window.fUniqPrefix + '_emailreader_table"><table>';
        waitString += '<tr><td colspan="2"><label>Do you want to open the functionize API Call Action?</label></td></tr>';
        waitString += '<tr><td colspan="2">&nbsp;</td></tr>';
        waitString +=
          '<tr><td style="width: 20px"><input type="checkbox" name="f-functionise_apicall_confirm" value="" class="f-functionise_apicall_confirm"></td><td><label>Open in a new tab</label></td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
        e.preventDefault();
        return false;
      }

      var navigateActionElements = document.querySelectorAll('.' + window.fUniqPrefix + '-navigateAction');

      navigateActionElements.forEach(function(element) {
        element.removeEventListener('click', handleNavigateActionClick);
        element.addEventListener('click', handleNavigateActionClick);
      });

      function handleNavigateActionClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div class="f-functionise_formError f-hide_event"></div><div id="' + window.fUniqPrefix + '_navigate_table"><table>';
        waitString +=
          '<tr><td><label>Navigate Url </label></td><td><input type="text" name="f-functionise_navigate_action_url" value="" class="f-functionise_navigate_action_url"></td></tr>';
        waitString +=
          '<tr><td style="width: 20px"><input type="checkbox" name="f-functionise_navigate_confirm" value="" class="f-functionise_navigate_confirm"></td><td><label>Open in a new tab</label></td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
        e.preventDefault();
        return false;
      }

      var deleteActionElements = document.querySelectorAll('.' + window.fUniqPrefix + '-deleteAction');

      deleteActionElements.forEach(function(element) {
        element.removeEventListener('click', handleDeleteActionClick);
        element.addEventListener('click', handleDeleteActionClick);
      });

      function handleDeleteActionClick(e) {
        if (window.WS.recordedData.length > 1) {
          var lastAction = window.WS.recordedData[window.WS.recordedData.length - 1];
          var confirmMessage = 'Do you want to delete the last action from this recording?';
          confirmMessage += "<br/><br/>Action: '" + lastAction.action + "'";
          if (lastAction.xpath && lastAction.xpath !== 'undefined' && lastAction.xpath !== undefined) {
            confirmMessage += "<br/>Action Path: '" + lastAction.xpath + "'<br/><br/>";
          }

          // Your code to handle `confirmMessage`, e.g., show a confirmation dialog
          if (confirm(confirmMessage)) {
            // Proceed with deletion
          }
        }
        e.preventDefault();
        return false;
      }

      var hoverActionElements = document.querySelectorAll('.' + window.fUniqPrefix + '-hoverAction');

      hoverActionElements.forEach(function(element) {
        element.removeEventListener('click', handleHoverActionClick);
        element.addEventListener('click', handleHoverActionClick);
      });

      function handleHoverActionClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }
        if (window.WS.recordedData.length > 0 && window.TCM.recording) {
          window.fconsole.log('Creating hover action');
          window.WS.updateLastAction({ action: 'hover' });
          editorObj.processSubmit();
        }
        e.preventDefault();
        return false;
      }

      var missingSelectorElements = document.querySelectorAll('.' + window.fUniqPrefix + '-missingSelector');

      missingSelectorElements.forEach(function(element) {
        element.addEventListener('click', handleMissingSelectorClick);
      });

      function handleMissingSelectorClick(e) {
        var currentInstructionStep = window.WU.store('currentInstructionStep');
        if (currentInstructionStep) {
          var nextButton = document.querySelector('.f-functionise_instruction_buttons_next');
          if (nextButton && !nextButton.classList.contains('hideitem')) {
            nextButton.click();
          }
          if (!window.WS.recordedData[0]['missingSelector']) {
            window.WS.recordedData[0]['missingSelector'] = [];
          }
          window.WS.recordedData[0]['missingSelector'].push(currentInstructionStep);

          var jobDescriptionCollapse = document.querySelector('#f-functionise-mTurk-job-description-collapse');
          if (jobDescriptionCollapse && !jobDescriptionCollapse.classList.contains('hideitem')) {
            jobDescriptionCollapse.click();
          }
        }
        editorObj.processSubmit();
        e.preventDefault();
        return false;
      }

      var wrongSelectorElements = document.querySelectorAll('.' + window.fUniqPrefix + '-wrongSelector');

      wrongSelectorElements.forEach(function(element) {
        element.addEventListener('click', handleWrongSelectorClick);
      });

      function handleWrongSelectorClick(e) {
        var currentInstructionStep = window.WU.store('currentInstructionStep');
        if (currentInstructionStep) {
          if (!window.WS.recordedData[0]['wrongSelector']) {
            window.WS.recordedData[0]['wrongSelector'] = [];
          }
          window.WS.recordedData[0]['wrongSelector'].push(currentInstructionStep);

          var jobDescriptionCollapse = document.querySelector('#f-functionise-mTurk-job-description-collapse');
          if (jobDescriptionCollapse && !jobDescriptionCollapse.classList.contains('hideitem')) {
            jobDescriptionCollapse.click();
          }
        }
        editorObj.processSubmit();
        e.preventDefault();
        return false;
      }

      var confirmSelectorElements = document.querySelectorAll('.' + window.fUniqPrefix + '-confirmSelector');

      confirmSelectorElements.forEach(function(element) {
        element.addEventListener('click', handleConfirmSelectorClick);
      });

      function handleConfirmSelectorClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString =
          '<div class="' +
          window.fUniqPrefix +
          '_formError f-hide_event"></div><div id="' +
          window.fUniqPrefix +
          '_set_cookie_table" class="' +
          window.fUniqPrefix +
          '_visual_check_comparison_div"><table>';

        var confirmedSelectorSelectText = "<select class='" + window.fUniqPrefix + "_confirmed_selector'><option value=''>Select Selector</option>";

        Object.keys(selfObj.currentElement).forEach(function(index) {
          if (index.includes('xpath') || index.includes('cssSelector')) {
            confirmedSelectorSelectText += "<option value='" + index + "'>" + index + '</option>';
          }
        });

        confirmedSelectorSelectText += '</select>';

        waitString += '<tr><td><label>Confirmed Selector:</label></td><td>' + confirmedSelectorSelectText + '</td></tr>';
        waitString += '</table></div>';

        // Your code to handle `waitString`
        e.preventDefault();
        return false;
      }

      var backForwardElements = document.querySelectorAll('.' + window.fUniqPrefix + '-backForward');

      backForwardElements.forEach(function(element) {
        element.removeEventListener('click', handleBackForwardClick);
        element.addEventListener('click', handleBackForwardClick);
      });

      function handleBackForwardClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }
        try {
          var navigateStateType = this.getAttribute('alt');
          var elementCode = 'window.history.' + navigateStateType + '();';
          var data = {
            action: 'customcode',
            url: window.WS.locUrl,
            timestamp: window.WU.getTime(),
            elementCode: elementCode,
            custom_description: 'Browser ' + navigateStateType + ' button clicked.',
          };
          window.WS.getRecordingData(data);
          eval(elementCode);
          editorObj.processSubmit();
        } catch (err) {
          // Handle error
        }
        e.preventDefault();
        return false;
      }

      var visualCheckActionElements = document.querySelectorAll('.' + window.fUniqPrefix + '-visualCheckAction');

      visualCheckActionElements.forEach(function(element) {
        element.addEventListener('click', handleVisualCheckActionClick);
      });

      function handleVisualCheckActionClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }
        if (window.WS.recordedData.length > 0 && window.TCM.recording) {
          var settingButton = document.querySelector('#setting-button');
          if (settingButton && settingButton.classList.contains('active-bottompanel')) {
            editorObj.processSubmit();

            var kdString = '<div id="' + window.fUniqPrefix + '_visual_check_option_div"><table>';
            kdString += '<tr><td colspan="2"><label>Please select the target for visual check comparison:</label></td></tr>';
            kdString +=
              '<tr><td style="width: 20px"><input type="radio" name="f-functionise_visual_check_option" value="body" class="f-functionise_visual_check_option"></td><td><label>Full Page</label></td></tr>';
            kdString +=
              '<tr><td style="width: 20px"><input type="radio" name="f-functionise_visual_check_option" value="area" class="f-functionise_visual_check_option"></td><td><label>Selected Area</label></td></tr>';
            kdString += '</table></div>';

            // Insert kdString into the DOM
            // e.g., document.body.insertAdjacentHTML('beforeend', kdString);
          } else {
            var waitString =
              '<div class="' +
              window.fUniqPrefix +
              '_formError f-hide_event"></div><div id="' +
              window.fUniqPrefix +
              '_set_cookie_table" class="' +
              window.fUniqPrefix +
              '_visual_check_comparison_div"><table>';
            waitString +=
              '<tr><td><label>Visual Check Type:</label></td><td><select name="' +
              window.fUniqPrefix +
              '_visual_check_comparison" class="' +
              window.fUniqPrefix +
              '_set_cookie_fields ' +
              window.fUniqPrefix +
              '_visual_check_comparison"><option value="previousrun">Previous Run</option><option value="stepcomparison">Step Comparison</option></select></td></tr>';
            waitString +=
              '<tr class="' +
              window.fUniqPrefix +
              '_visual_check_comparison_stepnumber hideitem"><td><label>Operator:</label></td><td><select class="' +
              window.fUniqPrefix +
              '_visual_check_comparison_stepnumber_operator"><option value="ve">Visual Equal</option><option value="vne">Visual Not Equal</option></select></td></tr>';

            var lastAction = window.WS.recordedData[window.WS.recordedData.length - 1];
            var attrName = lastAction.text ? 'text' : lastAction.value ? 'value' : lastAction.element;

            var attrstepvalueoptions = selfObj.attrClickActionStepValue(attrName);

            waitString +=
              '<tr class="' + window.fUniqPrefix + '_visual_check_comparison_stepnumber hideitem"><td><label>Step#:</label></td><td>' + attrstepvalueoptions + '</td></tr>';
            waitString +=
              '<tr class="' +
              window.fUniqPrefix +
              '_visual_check_comparison_stepnumber hideitem"><td><label>Variance %:</label></td><td><input type="text" class="' +
              window.fUniqPrefix +
              '_visual_check_comparison_stepnumber_variance"></td></tr>';
            waitString += '</table></div>';

            // Insert waitString into the DOM
            // e.g., document.body.insertAdjacentHTML('beforeend', waitString);

            document.querySelectorAll('.' + window.fUniqPrefix + '_visual_check_comparison').forEach(function(el) {
              el.removeEventListener('change', handleVisualCheckComparisonChange);
              el.addEventListener('change', handleVisualCheckComparisonChange);
            });
          }
        }

        e.preventDefault();
        return false;
      }

      function handleVisualCheckComparisonChange(e) {
        var comparisonType = this.value;
        var stepNumberElements = document.querySelectorAll('.' + window.fUniqPrefix + '_visual_check_comparison_stepnumber');
        var attrStepValueElements = document.querySelectorAll('.' + window.fUniqPrefix + '-attrstepvalue');

        stepNumberElements.forEach(function(el) {
          el.classList.toggle('hideitem', comparisonType === 'previousrun');
        });
        attrStepValueElements.forEach(function(el) {
          el.classList.remove('hideitem');
        });
      }

      var domBasedSelectionElements = document.querySelectorAll('.' + window.fUniqPrefix + '-dombasedselection');

      domBasedSelectionElements.forEach(function(element) {
        element.removeEventListener('click', handleDomBasedSelectionClick);
        element.addEventListener('click', handleDomBasedSelectionClick);
      });

      function handleDomBasedSelectionClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }
        if (window.WS.recordedData.length > 0 && window.TCM.recording) {
          var attrData = { use_dom_based_selection: 1 };
          window.WS.appendToRecordedData(attrData);
          editorObj.processSubmit();
        }
        e.preventDefault();
        return false;
      }

      var notOnThePageElements = document.querySelectorAll('.' + window.fUniqPrefix + '-notonthePage');

      notOnThePageElements.forEach(function(element) {
        element.addEventListener('click', handleNotOnThePageClick);
      });

      function handleNotOnThePageClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }

        var waitString = '<div class="f-functionise_formError f-hide_event"></div><div id="' + window.fUniqPrefix + '_notonpage_table"><table>';
        waitString += '<tr><td colspan="2">&nbsp;</td></tr>';

        var operatorString = '<select class="operatorselect" id="notonthePageoperator">';
        operators.forEach(function(attr, index) {
          operatorString += '<option value="' + index + '">' + attr + '</option>';
        });
        operatorString += '</select>';

        waitString +=
          '<tr><td><input type="text" name="" value="" style="" class="" placeholder="element" id="notonthePageelement"></td><td><input placeholder="attribute" type="text" name="" value="" style="" class="" id="notonthePageattribute"></td><td>' +
          operatorString +
          '</td><td><input type="text" name="" value="" style="" class="" placeholder="element value" id="notonthePagevalue"></td></tr>';
        waitString += '</table></div>';

        // Insert waitString into the DOM
        // e.g., document.body.insertAdjacentHTML('beforeend', waitString);

        e.preventDefault();
        return false;
      }

      var covererSettingElements = document.querySelectorAll('.' + window.fUniqPrefix + '-coverersetting');

      covererSettingElements.forEach(function(element) {
        element.addEventListener('click', handleCovererSettingClick);
      });

      function handleCovererSettingClick(e) {
        if (window.WS.recordedData.length > 0 && window.TCM.recording) {
          var set = true;
          if (window.WS.settings['coverElementOnActionRec']) set = false;

          window.WS.setSettings('coverElementOnActionRec', set);
          window.WS.saveSettings();

          if (!set) {
            this.classList.add('f-disableLink');
            this.textContent = 'Enable Coverer';
          } else {
            this.classList.remove('f-disableLink');
            this.textContent = 'Disable Coverer';
          }
        }
        e.preventDefault();
        return false;
      }

      var captureLargeDataElements = document.querySelectorAll('.' + window.fUniqPrefix + '-captureLargeData');

      captureLargeDataElements.forEach(function(element) {
        element.addEventListener('click', handleCaptureLargeDataClick);
      });

      function handleCaptureLargeDataClick(e) {
        if (this.classList.contains('f-disableLink')) {
          e.preventDefault();
          return false;
        }
        if (window.WS.recordedData.length > 0 && window.TCM.recording) {
          window.WS.captureLargeData = true;
          editorObj.processSubmit();
        }
        e.preventDefault();
        return false;
      }

      var mouseoutSettingElements = document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoutsetting');

      mouseoutSettingElements.forEach(function(element) {
        element.addEventListener('click', handleMouseoutSettingClick);
      });

      function handleMouseoutSettingClick(e) {
        if (window.WS.recordedData.length > 0 && window.TCM.recording) {
          var set = true;
          if (typeof window.WS.settings['disableMouseout'] === 'undefined') window.WS.settings['disableMouseout'] = false;

          // Store flag that stops feature from auto-disabling on the first close.
          // On all subsequent panel closings, this will auto-disable
          if (typeof window.WS.settings['disableMouseoutAction'] === 'undefined') window.WS.settings['disableMouseoutAction'] = false;

          if (window.WS.settings['disableMouseout']) {
            set = false;
          } else {
            window.WS.settings['disableMouseoutAction'] = true;
          }

          window.WS.setSettings('disableMouseout', set);
          window.WS.saveSettings();

          if (!set) {
            this.classList.remove('f-disableLink');
            this.textContent = 'Mouseout Off';
          } else {
            this.classList.add('f-disableLink');
            this.textContent = 'Mouseout On';
          }
        }
        e.preventDefault();
        return false;
      }

      var helpElements = document.querySelectorAll('.' + window.fUniqPrefix + '-css-advance-editor-main-help');

      helpElements.forEach(function(element) {
        element.addEventListener('click', function(e) {
          if (this.classList.contains('f-disableLink')) {
            e.preventDefault();
            return false;
          }
          var helpString = "<div class='f-functionise-recordHelp'>Coming soon.</div>";
          // Assuming you want to display this helpString somewhere, e.g., in a modal or a specific div
          // Example: document.querySelector('#helpContainer').innerHTML = helpString;
        });
      });
    });
  };

  this.advanceEditAction = function(moveEdit) {
    // Show the buttonClickMessage element
    var buttonClickMessageElements = document.querySelectorAll('.buttonClickMessage');
    buttonClickMessageElements.forEach(function(element) {
      element.classList.remove('f-hide_event');
    });

    // Hide the advance-edit buttons
    var advanceEditElements = document.querySelectorAll('#' + window.fUniqPrefix + '-overview .' + window.fUniqPrefix + '-css-contentarea-buttons-advance-edit');
    advanceEditElements.forEach(function(element) {
      element.classList.add('f-hide_event');
    });

    // Call the addTabActionDetails method
    this.addTabActionDetails();

    // Show all elements with f-hideTab class
    var hideTabElements = document.querySelectorAll('.f-hideTab');
    hideTabElements.forEach(function(element) {
      element.classList.add('f-showTab');
      element.classList.remove('f-hideTab');
    });

    // Switch tab if moveEdit is true
    if (moveEdit) {
      this.switchTab('#' + window.fUniqPrefix + '-overview');
    }
  };

  this.attrStepValue = function(attribute) {
    var optionExist = false;
    var selectboxstr = '';

    if (attribute) {
      selectboxstr += "<select class='f-functionise-attrstepvalue hideitem' id='attrstepvalue_" + attribute + "'>";
      selectboxstr += "<option value='' oValue=''>Select Step</option>";

      var WSRecordedData = window.WS.recordedData;

      WSRecordedData.forEach(function(value, index) {
        Object.keys(attributeotheroperators).forEach(function(index1) {
          if (index1 === 'src') index1 = 'attr_src';
          if (index1 === 'href') index1 = 'attr_href';
          if (index1 === 'style') index1 = 'attr_style';

          if ((attribute !== 'href' && index1 !== 'attr_href') || (attribute === 'href' && index1 !== 'text')) {
            if (value[index1]) {
              var substroValue;

              if (attribute === 'style' && index1 === 'text') {
                // No action needed
              } else {
                if (
                  typeof window.TCM.runtimeReplacementStrings[value.actionId] !== 'undefined' &&
                  typeof window.TCM.runtimeReplacementStrings[value.actionId][index1] !== 'undefined' &&
                  window.TCM.runtimeReplacementStrings[value.actionId][index1]
                ) {
                  substroValue = window.TCM.runtimeReplacementStrings[value.actionId][index1];
                  substroValue = substroValue.substring(0, 60);
                  selectboxstr +=
                    '<option value="' +
                    value.actionId +
                    '|FUNCSTEP|' +
                    index1 +
                    '" oValue="' +
                    window.TCM.runtimeReplacementStrings[value.actionId][index1] +
                    '">Step ' +
                    (parseInt(index) + 1) +
                    ' - ' +
                    substroValue +
                    '</option>';
                } else if (typeof value.actualstring !== 'undefined' && value.actualstring && index1 === 'value') {
                  substroValue = value.actualstring;
                  substroValue = substroValue.substring(0, 60);
                  selectboxstr +=
                    '<option value="' +
                    value.actionId +
                    '|FUNCSTEP|' +
                    index1 +
                    '" oValue="' +
                    value.actualstring +
                    '">Step ' +
                    (parseInt(index) + 1) +
                    ' - ' +
                    substroValue +
                    '</option>';
                } else {
                  substroValue = value[index1];
                  substroValue = substroValue.substring(0, 60);
                  selectboxstr +=
                    '<option value="' +
                    value.actionId +
                    '|FUNCSTEP|' +
                    index1 +
                    '" oValue="' +
                    value[index1] +
                    '">Step ' +
                    (parseInt(index) + 1) +
                    ' - ' +
                    substroValue +
                    '</option>';
                }

                optionExist = true;
              }
            }
          }
        });
      });

      selectboxstr += '</select>';

      // Add Functions
      selectboxstr += '<select class="f-functionise-attrstepfunction hideitem" id="attrstepvalue_' + attribute + '">';
      selectboxstr += "<option value=''>Select Function</option>";

      attributeFunctions.forEach(function(attr1) {
        selectboxstr += "<option value='" + attr1 + "'>" + attr1 + '</option>';
      });

      selectboxstr +=
        "</select><input type='text' class='f-functionise-attrstepfunctionvalue hideitem' placeholder='start,end'><label class='f-functionise-attrstepvaluelabel hideitem' id='attrstepvaluelabel_" +
        attribute +
        "'></label>";
    }

    return optionExist ? selectboxstr : '';
  };

  this.setKeyValuesGlobal = function(cVariable, keyname, level) {
    const nLevel = level + 1;

    if (nLevel <= 4) {
      Object.keys(cVariable).forEach(prop => {
        if (typeof cVariable[prop] !== 'function') {
          try {
            cVariable[prop] = JSON.parse(cVariable[prop]);
          } catch (err) {}

          if (typeof cVariable[prop] === 'object') {
            const vav = document.querySelector('.f-functionise-page-variable:checked')?.value;
            const windowvariable = vav === 'PV' ? 'window' : 'window121212';

            if (
              prop !== 'self' &&
              prop !== '$' &&
              prop !== 'window.WS' &&
              prop !== 'TH' &&
              prop !== 'TCM' &&
              prop !== 'applicationCache' &&
              keyname !== 'document' &&
              keyname !== 'content' &&
              keyname !== 'frames' &&
              keyname !== 'parent' &&
              keyname !== '_pa' &&
              keyname !== windowvariable &&
              keyname !== 'top' &&
              !Number.isFinite(Number(prop)) &&
              !prop.startsWith('$')
            ) {
              const kVal = keyname ? `${keyname}.${prop}` : prop;

              if (kVal.indexOf('functionizeAjaxVariables') >= 0) {
                // No action needed
              }

              this.setKeyValuesGlobal(cVariable[prop], kVal, nLevel);
            }
          } else {
            if (prop !== 'self' && prop !== '$' && prop !== 'WS' && prop !== 'TH' && prop !== 'TCM') {
              let validEntry = true;

              if (keyname === 'content' || keyname === 'frames' || keyname === 'parent' || keyname === 'top' || keyname === 'window') {
                if (this.globalVariablesGlobal[prop]) {
                  validEntry = false;
                } else {
                  this.globalVariablesGlobal[prop] = String(cVariable[prop]);
                }
              }

              if (validEntry) {
                const kVal = keyname ? `${keyname}.${prop}` : prop;
                this.keyValuesGlobal.push(kVal);
                this.globalVariablesGlobal[kVal.replace(/\./g, '_')] = String(cVariable[prop]);
              }
            }
          }
        }
      });
    }
  };

  this.addVerifyAttributeEditor = function(selfObj) {
    const maxValChars = 1000;
    let attrString = `
        <div id="${window.fUniqPrefix}_attribute_selection_tab">
            <div class="${window.fUniqPrefix}_general_attribute selected" attr="attribute">General Attributes</div>
            <div class="${window.fUniqPrefix}_computed_attribute" attr="cattribute">Computed Attributes</div>
        </div>
        <div id="${window.fUniqPrefix}_attribute_table">
            <div class="f-functionise-attribute-header">General Attributes</div>
            <table style="width: 100%">
                <tr>
                    <th>&nbsp;</th>
                    <th>Attribute</th>
                    <th class="f-functionise_attributeOperators">Operator</th>
                    <th>Value</th>
                </tr>
    `;

    let operatorString = "<select class='operatorselect'>";
    operators.forEach((attr, index) => {
      operatorString += `<option value="${index}" #${index}_SELECTEDAREA#>${attr}</option>`;
    });
    operatorString += '</select>';

    const tagName = selfObj.currentElement.element.toLowerCase();

    attrString += `
        <tr>
            <td><input type="checkbox" name="attrChecked" value="1" id="${tagName}" /></td>
            <td><label>tag name</label></td>
            <td>${operatorString}</td>
            <td>
                <input type="text" name="${tagName}_value" value="${tagName}" style="z-index:2147483642" class="withmultipleoptions" />
                <a class="${window.fUniqPrefix}_multipleoptions" rel="${tagName}_value" href="#">multiple</a>
            </td>
        </tr>
    `;

    Object.keys(selfObj.currentElement).forEach(index => {
      if (index === 'attr_value') index = '';
      if (index === 'value') index = 'attr_' + index;

      if (index.startsWith('attr_') && !['attr_parent', 'attr_child', 'attr_sibling'].some(prefix => index.startsWith(prefix))) {
        let attrName = index.slice(5);
        let attrValue = String(selfObj.currentElement[index] || '');
        let attrOpr = '';

        if (attrValue.includes('z-highlighted')) {
          attrValue = attrValue.replace('z-highlighted', '').trim();
        }
        if (attrValue.length > maxValChars) attrValue = attrValue.substring(0, maxValChars) + '...';

        let checked = '';
        if (selfObj.attributeValues && selfObj.attributeValues[attrName]) {
          checked = 'checked="checked"';
          attrValue = selfObj.attributeValues[attrName];
        }

        let operatorStringTemp = operatorString;
        if (attributeotheroperators[attrName]) {
          const attrstepvalueoptions = selfObj.attrStepValue(attrName);

          operatorStringTemp = "<select class='operatorselect'>";
          operators.forEach((attr1, index1) => {
            operatorStringTemp += `<option value="${index1}" #${index1}_SELECTEDAREA#>${attr1}</option>`;
          });
          if (attrstepvalueoptions) {
            attributeotheroperators[attrName].forEach((attr1, index1) => {
              operatorStringTemp += `<option value="${index1}" #${index1}_SELECTEDAREA#>${attr1}</option>`;
            });
          }
          operatorStringTemp += '</select>';
        } else {
          operatorStringTemp = operatorString;
        }

        if (selfObj.attributeOperators && selfObj.attributeOperators[attrName]) {
          attrOpr = selfObj.attributeOperators[attrName];
          operatorStringTemp = operatorStringTemp.replace(`#${attrOpr}_SELECTEDAREA#`, 'selected="selected"');
        }

        const attrstepvalueoptions = `<a class="${window.fUniqPrefix}_multipleoptions" rel="${attrName}_value" href="#">multiple</a>`;

        attrString += `
          <tr>
            <td><input type="checkbox" name="attrChecked" value="1" id="${attrName}" ${checked} /></td>
            <td><label>${attrName.toLowerCase()}</label></td>
            <td>${operatorStringTemp}</td>
            <td>
              <input type="text" name="${attrName}_value" value="${attrValue.replace(/"/g, '&#34;')}" class="withmultipleoptions" />
              ${attrstepvalueoptions}
            </td>
          </tr>
        `;
      }
      if (index === 'text' && selfObj.currentElement.element !== 'img') {
        let textareaValue = (selfObj.attributeValues && selfObj.attributeValues['text']) || attr;

        let operatorStringTemp = operatorString;
        if (attributeotheroperators[index]) {
          const attrstepvalueoptions = selfObj.attrStepValue(index);

          operatorStringTemp = "<select class='operatorselect'>";
          operators.forEach((attr1, index1) => {
            operatorStringTemp += `<option value="${index1}" #${index1}_SELECTEDAREA#>${attr1}</option>`;
          });

          if (attrstepvalueoptions) {
            attributeotheroperators[index].forEach((attr1, index1) => {
              operatorStringTemp += `<option value="${index1}" #${index1}_SELECTEDAREA#>${attr1}</option>`;
            });
          }
          operatorStringTemp += '</select>';
        } else {
          const attrstepvalueoptions = '';
          operatorStringTemp = operatorString;
        }

        let attrOpr = '';
        if (selfObj.attributeOperators && selfObj.attributeOperators['text']) {
          attrOpr = selfObj.attributeOperators['text'];
          operatorStringTemp = operatorStringTemp.replace(`#${attrOpr}_SELECTEDAREA#`, 'selected="selected"');
        }

        attrString += `
          <tr>
            <td><input type="checkbox" name="attrChecked" value="1" id="${attr}" /></td>
            <td><label>text</label></td>
            <td>${operatorStringTemp}</td>
            <td>
              <textarea name="${index}_value" class="withmultipleoptions">${textareaValue}</textarea>
              <a class="${window.fUniqPrefix}_multipleoptions" rel="${index}_value" href="#">multiple</a>
            </td>
          </tr>
        `;
      }
    });

    attrString += '</table></div>';

    attrString += `
      <div id="${window.fUniqPrefix}_cattribute_table" class="hideitem">
        <table style="width: 100%">
          <div class="f-functionise-attribute-header">Computed Attributes</div>
          <tr>
            <th>&nbsp;</th>
            <th>Attribute</th>
            <th class="f-functionise_attributeOperators">Operator</th>
            <th>Value</th>
          </tr>
    `;

    try {
      const elementSelector = document.querySelector(selfObj.currentElement.cssSelector);
      const computedStyle = getComputedStyle(elementSelector);

      let elementSelectorString = "<select class='f-functionise-elementselectorselect'><option value=''>Select Style</option>";
      Object.keys(computedStyle).forEach(index => {
        if (!isNaN(index)) {
          const attr = computedStyle[index];
          elementSelectorString += `<option value="${attr}" #${attr}_SELECTEDAREA#>${attr}</option>`;
        }
      });
      elementSelectorString += '</select>';

      for (let i = 0; i < 5; i++) {
        attrString += `
          <tr>
            <td><input type="checkbox" name="attrChecked" value="1" /></td>
            <td>${elementSelectorString}</td>
            <td>${operatorString}</td>
            <td><input type="text" /></td>
          </tr>
        `;
      }
    } catch (err) {
      // handle error
    }

    attrString += '</table></div>';

    // Attribute selection tab click event
    document.querySelectorAll('#' + window.fUniqPrefix + '_attribute_selection_tab div').forEach(div => {
      div.removeEventListener('click', handleAttributeSelectionClick);
      div.addEventListener('click', handleAttributeSelectionClick);
    });

    function handleAttributeSelectionClick(e) {
      const target = e.currentTarget;
      document.querySelectorAll('#' + window.fUniqPrefix + '_attribute_selection_tab div').forEach(div => div.classList.remove('selected'));
      target.classList.add('selected');

      document.getElementById(window.fUniqPrefix + '_attribute_table').classList.add('hideitem');
      document.getElementById(window.fUniqPrefix + '_cattribute_table').classList.add('hideitem');

      const attr = target.getAttribute('attr');
      const enableSelection = '#' + window.fUniqPrefix + '_' + attr + '_table';
      document.querySelector(enableSelection).classList.remove('hideitem');
    }

    // Element selector change event
    document.querySelectorAll('.' + window.fUniqPrefix + '-elementselectorselect').forEach(select => {
      select.removeEventListener('change', handleElementSelectorChange);
      select.addEventListener('change', handleElementSelectorChange);
    });

    function handleElementSelectorChange(e) {
      const elementSelector = document.querySelector(selfObj.currentElement.cssSelector);
      const computedStyle = getComputedStyle(elementSelector);
      const cValue = e.target.value;
      const input = e.target.closest('tr').querySelector('td input[type=text]');
      const checkbox = e.target.closest('tr').querySelector('input[type=checkbox]');

      if (input) {
        input.value = computedStyle[cValue];
      }
      if (checkbox) {
        checkbox.checked = true;
      }
    }

    // Operator select change event
    document.querySelectorAll('.' + window.fUniqPrefix + '_cattribute_table .operatorselect').forEach(select => {
      select.removeEventListener('change', handleOperatorSelectChange);
      select.addEventListener('change', handleOperatorSelectChange);
    });

    function handleOperatorSelectChange(e) {
      const checkbox = e.target.closest('tr').querySelector('input[type=checkbox]');
      if (checkbox) {
        checkbox.checked = true;
      }
    }

    // Text input keyup event
    document.querySelectorAll('#' + window.fUniqPrefix + '_attribute_table input[type=text], #' + window.fUniqPrefix + '_attribute_table textarea').forEach(input => {
      input.removeEventListener('keyup', handleTextInputKeyup);
      input.addEventListener('keyup', handleTextInputKeyup);
    });

    function handleTextInputKeyup(e) {
      const checkbox = e.target.closest('tr').querySelector('input[type=checkbox]');
      if (checkbox) {
        checkbox.checked = true;
      }
    }

    // Multiple options click event
    document.querySelectorAll('.' + window.fUniqPrefix + '_multipleoptions').forEach(link => {
      link.removeEventListener('click', handleMultipleOptionsClick);
      link.addEventListener('click', handleMultipleOptionsClick);
    });

    function handleMultipleOptionsClick(e) {
      e.preventDefault();
      const rel = e.currentTarget.getAttribute('rel');
      const multipleoptionsrelVal = document.querySelector('.withmultipleoptions[name="' + rel + '"]').value || '';
      const multipleoptionsrelValArr = multipleoptionsrelVal.split('|FUNCOPR|');
      const multipleoptionsrelValInputArr = (multipleoptionsrelValArr[1] || '').split('|FUNCVAL|');

      let dialogHtml = `
        <div class="${window.fUniqPrefix}_multipleoptionDiv ${window.fUniqPrefix}" style="text-align:left;padding:4px;height: 400px;">
          <div class="${window.fUniqPrefix}_multipleOptionTitle">Multiple Options</div>
          <div class="myWebsites" style="overflow: auto; height: auto; max-height: 400px;">
            <div class="${window.fUniqPrefix}_multipleoptionsOperator ${window.fUniqPrefix}">
              <div class="${window.fUniqPrefix}_dialogHeading">Select Operator</div>
              <select name="operatortype" id="${window.fUniqPrefix}_operatortype">
                <option value="AND" ${multipleoptionsrelValArr[0] === 'AND' ? 'selected' : ''}>AND</option>
                <option value="OR" ${multipleoptionsrelValArr[0] === 'OR' ? 'selected' : ''}>OR</option>
              </select>
            </div>
            <div class="${window.fUniqPrefix}_multipleoptionsOption">
              <div class="${window.fUniqPrefix}_dialogHeading">Enter options</div>
              ${Array.from({ length: 10 })
                .map(
                  (_, i) => `
                  <input type="text" name="multipleoptionsinput" class="${window.fUniqPrefix}_multipleoptionsinput inputbox" value="${multipleoptionsrelValInputArr[i] || ''}">
              `
                )
                .join('')}
            </div>
          </div>
          <div class="${window.fUniqPrefix}_submitbuttons">
            <a type="button" class="${window.fUniqPrefix}_continuemultipleoption" href="#">Continue</a>
            <a class="${window.fUniqPrefix}_cancelmultipleoption" href="#">Cancel</a>
          </div>
        </div>
      `;

      document.body.insertAdjacentHTML('beforeend', dialogHtml);

      document.querySelector('.' + window.fUniqPrefix + '_continuemultipleoption').addEventListener('click', handleContinueMultipleOptionsClick);
      document.querySelector('.' + window.fUniqPrefix + '_cancelmultipleoption').addEventListener('click', handleCancelMultipleOptionsClick);
    }

    function handleContinueMultipleOptionsClick(e) {
      e.preventDefault();
      const rel = e.currentTarget
        .closest('.' + window.fUniqPrefix + '_multipleoptionDiv')
        .querySelector('.withmultipleoptions')
        .getAttribute('name');
      const multipleoptionsinput = Array.from(document.querySelectorAll('.' + window.fUniqPrefix + '_multipleoptionsinput'))
        .map(input => input.value)
        .filter(value => value);
      const operator = document.getElementById(window.fUniqPrefix + '_operatortype').value;

      const multipleoptionsinputT = multipleoptionsinput.length <= 1 ? multipleoptionsinput.join('') : operator + '|FUNCOPR|' + multipleoptionsinput.join('|FUNCVAL|');

      const inputTrr = document.querySelector('.withmultipleoptions[name="' + rel + '"]').closest('tr');
      inputTrr.querySelector('input[type=checkbox]').checked = true;
      document.querySelector('.withmultipleoptions[name="' + rel + '"]').value = multipleoptionsinputT;

      document.querySelector('.' + window.fUniqPrefix + '_multipleoptionDiv').remove();
    }

    function handleCancelMultipleOptionsClick(e) {
      e.preventDefault();
      document.querySelector('.' + window.fUniqPrefix + '_multipleoptionDiv').remove();
    }

    // Operator select default value
    document.querySelectorAll('.operatorselect').forEach(select => {
      if (select.value !== 'eq') {
        select.value = 'eq';
      }
    });

    // Operator select change event with step value
    document.querySelectorAll('.operatorselect').forEach(select => {
      select.removeEventListener('change', handleOperatorSelectChangeWithStep);
      select.addEventListener('change', handleOperatorSelectChangeWithStep);
    });

    function handleOperatorSelectChangeWithStep(e) {
      const tr = e.target.closest('tr');
      const checkbox = tr.querySelector('input[type=checkbox]');
      if (checkbox) {
        checkbox.checked = true;
      }

      const operatorValue = e.target.value;
      const stepValueElem = tr.querySelector('td:last [id*="attrstepvalue"]');
      const functionElem = tr.querySelector('td:last [id*="attrstepfunction"]');
      const multipleOptionsElem = tr.querySelector('td:last .' + window.fUniqPrefix + '_multipleoptions');

      if (stepValueElem) {
        if (operatorValue.includes('stepval')) {
          stepValueElem.classList.remove('hideitem');
          tr.querySelector('td:last textarea').classList.add('hideitem');
          tr.querySelector('td:last input').classList.add('hideitem');
          multipleOptionsElem.classList.add('hideitem');
        } else {
          stepValueElem.classList.add('hideitem');
          tr.querySelector('td:last textarea').classList.remove('hideitem');
          tr.querySelector('td:last input').classList.remove('hideitem');
          multipleOptionsElem.classList.remove('hideitem');
        }
      }

      if (functionElem) {
        functionElem.classList.add('hideitem');
      }
    }

    // Attribute step value change event
    document.querySelectorAll('.f-functionise-attrstepvalue').forEach(select => {
      select.removeEventListener('change', handleAttributeStepValueChange);
      select.addEventListener('change', handleAttributeStepValueChange);
    });

    function handleAttributeStepValueChange(e) {
      const value = e.target.value;
      const oValue = e.target.options[e.target.selectedIndex].getAttribute('oValue');
      const previousInput = e.target.previousElementSibling;
      const nextElem = e.target.nextElementSibling;

      if (previousInput) {
        previousInput.value = value;
      }
      if (nextElem) {
        nextElem.innerHTML = oValue.substring(0, 60);
      }

      e.target.classList.toggle('z-highlight-error', !value);

      const checkbox = e.target.closest('tr').querySelector('input[type=checkbox]');
      if (checkbox) {
        checkbox.checked = true;
      }
    }

    // Attribute step function change event
    document.querySelectorAll('.f-functionise-attrstepfunction').forEach(select => {
      select.removeEventListener('change', handleAttributeStepFunctionChange);
      select.addEventListener('change', handleAttributeStepFunctionChange);
    });

    function handleAttributeStepFunctionChange(e) {
      const functionValue = e.target.value;
      const functionValueElem = e.target.nextElementSibling;

      if (functionValueElem) {
        functionValueElem.classList.toggle('hideitem', functionValue !== 'substring');
      }
    }
  };

  this.addClickAttributeEditor = function(selfObj) {
    const maxValChars = 1000;
    let attrString = `<div id="${window.fUniqPrefix}_attribute_table"><table style="width: 100%">
        <tr><th>&nbsp;</th><th>Attribute</th><th class="f-functionise_attributeOperators">Operator</th><th>Value</th></tr>`;

    let operatorString = "<select class='operatorselect'>";
    operatorString += "<option value=''>Select Option</option>";
    clickattroperators.forEach((attr, index) => {
      operatorString += `<option value='${index}' #${index}_SELECTEDAREA#>${attr}</option>`;
    });
    if (selfObj.currentElement.xpath.includes('brace-editor')) {
      operatorString += "<option value='SI' #si_SELECTEDAREA#>Special Input</option>";
    }
    operatorString += '</select>';

    const tagName = selfObj.currentElement.element.toLowerCase();

    // Build the attribute table rows
    for (let [index, attr] of Object.entries(selfObj.currentElement)) {
      if (index !== 'value') {
        if (index === 'attr_value') index = '';
        if (index === 'value') index = 'attr_' + index;

        if (index.startsWith('attr_') && !index.startsWith('attr_parent') && !index.startsWith('attr_child') && !index.startsWith('attr_sibling')) {
          let attrName = index.slice(5);
          let attrValue = attr + '';
          let attrOpr = '';

          if (attrValue.includes('z-highlighted')) {
            attrValue = attrValue.replace('z-highlighted', '').trim();
          }
          if (attrValue.length > maxValChars) attrValue = attrValue.slice(0, maxValChars) + '...';

          let checked = '';
          if (selfObj.attributeValues && selfObj.attributeValues[attrName]) {
            checked = 'checked="checked"';
            attrValue = selfObj.attributeValues[attrName];
          }

          let operatorStringTemp = operatorString;
          if (selfObj.attributeOperators && selfObj.attributeOperators[attrName]) {
            attrOpr = selfObj.attributeOperators[attrName];
            operatorStringTemp = operatorStringTemp.replace(`#${attrOpr}_SELECTEDAREA#`, 'selected="selected"');
          }
          const attrstepvalueoptions = selfObj.attrClickActionStepValue(attrName);

          attrString += `<tr><td><input type="checkbox" name="attrChecked" value="1" id="${attrName}" ${checked}></td><td><label>${attrName.toLowerCase()}</label></td><td>${operatorStringTemp}</td><td>${attrstepvalueoptions}</td></tr>`;
        }
        if (index === 'text') {
          const attrstepvalueoptions = selfObj.attrClickActionStepValue(index);
          if (selfObj.currentElement.element !== 'img') {
            let textareaValue = attr;
            if (selfObj.attributeValues && selfObj.attributeValues['text']) {
              textareaValue = selfObj.attributeValues['text'];
            }

            let operatorStringTemp = operatorString;
            let attrOpr = '';
            if (selfObj.attributeOperators && selfObj.attributeOperators['text']) {
              attrOpr = selfObj.attributeOperators['text'];
              operatorStringTemp = operatorStringTemp.replace(`#${attrOpr}_SELECTEDAREA#`, 'selected="selected"');
            }

            attrString += `<tr><td><input type="checkbox" name="attrChecked" value="1" id="${attr}"></td><td><label>text</label></td><td>${operatorStringTemp}</td><td>${attrstepvalueoptions}</td></tr>`;
          }

          let attrValue = 'true';
          if (selfObj.attributeValues && selfObj.attributeValues['visibility']) {
            attrValue = selfObj.attributeValues['visibility'];
          }

          let operatorStringTemp = operatorString;
          let attrOpr = '';
          if (selfObj.attributeOperators && selfObj.attributeOperators['visibility']) {
            attrOpr = selfObj.attributeOperators['visibility'];
            operatorStringTemp = operatorStringTemp.replace(`#${attrOpr}_SELECTEDAREA#`, 'selected="selected"');
          }
        }
      }
    }
    attrString += '</table></div>';

    // Append the attribute table to the body
    document.body.insertAdjacentHTML('beforeend', attrString);

    document.querySelectorAll(`.${window.fUniqPrefix}_multipleoptions`).forEach(element => {
      element.addEventListener('click', function() {
        const rel = this.getAttribute('rel');
        let multipleoptionsrelValArr = [];
        const multipleoptionsrelVal = document.querySelector(`.withmultipleoptions[name="${rel}"]`).value;
        if (multipleoptionsrelVal) {
          multipleoptionsrelValArr = multipleoptionsrelVal.split('|FUNCOPR|');
        }

        let multipleoptionsrelValInputArr = [];
        if (multipleoptionsrelValArr[1]) {
          multipleoptionsrelValInputArr = multipleoptionsrelValArr[1].split('|FUNCVAL|');
        }

        let dialogHtml = `<div class='${window.fUniqPrefix}_multipleoptionDiv ${window.fUniqPrefix}' style='text-align:left;padding:4px;height: 400px;'>
            <div class='${window.fUniqPrefix}_multipleOptionTitle'>Multiple Options</div>
            <div class='myWebsites' style='overflow: auto; height: auto; max-height: 400px;'>`;

        dialogHtml += `<div class='${window.fUniqPrefix}_multipleoptionsOperator ${window.fUniqPrefix}'>
            <div class='${window.fUniqPrefix}_dialogHeading'>Select Operator</div>
            <select name='operatortype' id='${window.fUniqPrefix}_operatortype'>`;
        dialogHtml += `<option value='AND' ${multipleoptionsrelValArr[0] === 'AND' ? 'selected' : ''}>AND</option>`;
        dialogHtml += `<option value='OR' ${multipleoptionsrelValArr[0] === 'OR' ? 'selected' : ''}>OR</option>`;
        dialogHtml += '</select></div>';

        if (multipleoptionsrelValInputArr.length === 0) {
          multipleoptionsrelValInputArr[0] = multipleoptionsrelVal;
        }

        dialogHtml += `<div class='${window.fUniqPrefix}_multipleoptionsOption'>
            <div class='${window.fUniqPrefix}_dialogHeading'>Enter options</div>`;
        for (let i = 0; i < 10; i++) {
          dialogHtml += `<input type='text' name='multipleoptionsinput' class='${window.fUniqPrefix}_multipleoptionsinput inputbox' value='${multipleoptionsrelValInputArr[i] ||
            ''}'>`;
        }
        dialogHtml += '</div></div>';
        dialogHtml += `<div class='${window.fUniqPrefix}_submitbuttons'>
            <a type='button' class='${window.fUniqPrefix}_continuemultipleoption' href='#'>Continue</a>
            <a class='${window.fUniqPrefix}_cancelmultipleoption' href='#'>Cancel</a></div></div>`;

        document.body.insertAdjacentHTML('beforeend', dialogHtml);

        document.querySelector(`.${window.fUniqPrefix}_continuemultipleoption`).addEventListener('click', function(e) {
          e.preventDefault();
          const multipleoptionsinput = [];
          document.querySelectorAll(`.${window.fUniqPrefix}_multipleoptionsinput`).forEach(input => {
            if (input.value) multipleoptionsinput.push(input.value);
          });

          const multipleoptionsinputT =
            multipleoptionsinput.length <= 1
              ? multipleoptionsinput.join('')
              : `${document.getElementById(`${window.fUniqPrefix}_operatortype`).value}|FUNCOPR|${multipleoptionsinput.join('|FUNCVAL|')}`;

          const inputTrr = document.querySelector(`.withmultipleoptions[name="${rel}"]`).closest('tr');
          inputTrr.querySelector('input[type=checkbox]').checked = true;
          document.querySelector(`.withmultipleoptions[name="${rel}"]`).value = multipleoptionsinputT;

          document.querySelector(`.${window.fUniqPrefix}_multipleoptionDiv`).remove();
        });

        document.querySelector(`.${window.fUniqPrefix}_cancelmultipleoption`).addEventListener('click', function(e) {
          e.preventDefault();
          document.querySelector(`.${window.fUniqPrefix}_multipleoptionDiv`).remove();
        });
      });
    });

    document.querySelectorAll(`#${window.fUniqPrefix}_attribute_table input[type=text],#${window.fUniqPrefix}_attribute_table textarea`).forEach(input => {
      input.addEventListener('keyup', function() {
        this.closest('tr').querySelector('input[type=checkbox]').checked = true;
      });
    });

    if (typeof attrKendo !== 'undefined') attrKendo.center();

    document.querySelectorAll('.operatorselect').forEach(select => {
      select.addEventListener('change', function() {
        const inputTr = this.closest('tr');
        inputTr.querySelector('input[type=checkbox]').checked = true;

        const attrOpr = this.value;
        const stepValueElem = inputTr.querySelector('td:last [id*="attrstepvalue"]');
        const textBoxValueElem = inputTr.querySelector('td:last [id*="attrtextboxvalue"]');
        const textAreaValueElem = inputTr.querySelector('td:last [id*="attrtextareavalue"]');

        stepValueElem.classList.add('hideitem');
        textBoxValueElem.classList.add('hideitem');
        textAreaValueElem.classList.add('hideitem');

        if (attrOpr === 'SV') {
          textBoxValueElem.classList.remove('hideitem');
        } else if (attrOpr === 'SI') {
          textAreaValueElem.classList.remove('hideitem');
        } else if (['RS', 'RT', 'RTS', 'RTU', 'RN', 'FD'].includes(attrOpr)) {
          textBoxValueElem.classList.remove('hideitem');
          let filledValue = '';
          switch (attrOpr) {
            case 'RS':
              filledValue = '[randomString]';
              break;
            case 'RT':
              filledValue = '[randomText]';
              break;
            case 'RTS':
              filledValue = '[randomTextSmall]';
              break;
            case 'RTU':
              filledValue = '[randomTextUpper]';
              break;
            case 'RN':
              filledValue = '[randomNumber]';
              break;
            case 'FD':
              filledValue = '[functionizeDate]';
              break;
          }
          textBoxValueElem.value = filledValue;
        }
      });
    });

    document.querySelectorAll('.f-functionise-attrstepvalue').forEach(select => {
      select.addEventListener('change', function() {
        const value = this.value;
        const oValue = this.selectedOptions[0].getAttribute('oValue');
        const attt = selfObj.globalStepAttribute[oValue];
        let atttOptions = '<option>Select Attribute</option>';
        for (const [index, value] of Object.entries(attt)) {
          atttOptions += `<option value="${index}" oValue="${value}">${index}</option>`;
        }
        this.parentElement.querySelector('.f-functionise-attrstepattribute').innerHTML = atttOptions;

        this.closest('tr').querySelector('input[type=checkbox]').checked = true;
      });
    });

    document.querySelectorAll('.f-functionise-attrstepattribute').forEach(select => {
      select.addEventListener('change', function() {
        const oValue = this.selectedOptions[0].getAttribute('oValue');
        this.closest('table').querySelector('.f-functionise-attrstepvaluelabel').innerHTML = oValue;
      });
    });

    document.querySelectorAll('.f-functionise-attrstepfunction').forEach(select => {
      select.addEventListener('change', function() {
        const functionValueDiv = this.nextElementSibling;
        if (this.value === 'substring') {
          functionValueDiv.classList.remove('hideitem');
        } else {
          functionValueDiv.classList.add('hideitem');
        }
      });
    });

    document.querySelectorAll('.f-functionise-attrstepfunctionvalue').forEach(input => {
      input.addEventListener('keyup', function() {
        const oValue = document.querySelector('.f-functionise-attrstepattribute').selectedOptions[0].getAttribute('oValue');
        let rValue = '';
        try {
          const substrval = this.value;
          const [start, length] = substrval.split(',').map(Number);
          rValue = oValue.substr(start, length);
        } catch (err) {
          rValue = '';
        }
        this.closest('table').querySelector('.f-functionise-attrstepvaluelabel').innerHTML = rValue;
      });
    });
  };

  this.attrClickActionStepValue = function(attribute) {
    let optionExist = false;
    let selectboxstr = '';

    const objSelfA = this;

    if (attribute) {
      selectboxstr += `<select class='f-functionise-attrstepvalue hideitem' id='attrstepvalue_${attribute}'>`;
      selectboxstr += "<option value='' oValue=''>Select Step</option>";

      const WSRecordedData = window.WS.recordedData;
      WSRecordedData.forEach((value, index) => {
        if (value.action === 'verify' || value.action === 'input') {
          selectboxstr += `<option value="${value.actionId}" oValue="${parseInt(index)}">Step ${parseInt(index) + 1}</option>`;
          try {
            objSelfA.globalStepAttribute[index] = {};
          } catch (err) {}

          Object.keys(value).forEach(index1 => {
            if (value[index1] && index1 !== 'actionId') {
              objSelfA.globalStepAttribute[index][index1] = value[index1];
            }
          });
        }
      });

      selectboxstr += '</select>';
      selectboxstr += `<select class='f-functionise-attrstepattribute hideitem' id='attrstepvalue_${attribute}_attr'></select>`;

      // Add Functions
      selectboxstr += `<select class='f-functionise-attrstepfunction hideitem' id='attrstepvalue_${attribute}'>`;
      selectboxstr += "<option value=''>Select Function</option>";
      attributeFunctions.forEach(attr1 => {
        selectboxstr += `<option value='${attr1}'>${attr1}</option>`;
      });
      selectboxstr += `</select>`;
      selectboxstr += `<input type='text' class='f-functionise-attrstepfunctionvalue hideitem' placeholder='start,end'>`;
      selectboxstr += `<label class='f-functionise-attrstepvaluelabel hideitem' id='attrstepvaluelabel_${attribute}'>`;
      selectboxstr += `<input type='text' id='attrtextboxvalue_${attribute}' class='f-functionise-attrtextboxvalue hideitem'>`;
      selectboxstr += `<textarea id='attrtextareavalue_${attribute}' class='f-functionise-attrtextareavalue hideitem' style='height:100px'></textarea>`;
      selectboxstr += `<label class='f-functionise-attrstepvaluelabel hideitem' id='attrstepvaluelabel_${attribute}'></label>`;
    }

    return selectboxstr;
  };

  this.insertStringIntoEditor = function(editor, str) {
    var selection = editor.getSelection();
    if (selection.length > 0) {
      editor.replaceSelection(str);
    } else {
      var doc = editor.getDoc();
      var cursor = doc.getCursor();

      var pos = {
        line: cursor.line,
        ch: cursor.ch,
      };
      doc.replaceRange(str, pos);
    }
  };

  this.orderKeys = function(obj, expected) {
    var keys = Object.keys(obj).sort(function keyOrder(k1, k2) {
      if (k1 < k2) return -1;
      else if (k1 > k2) return +1;
      else return 0;
    });

    var i = null;
    var after = {};

    for (i = 0; i < keys.length; i++) {
      after[keys[i]] = obj[keys[i]];
      delete obj[keys[i]];
    }

    for (i = 0; i < keys.length; i++) {
      obj[keys[i]] = after[keys[i]];
    }
    return obj;
  };

  // Helper function to get the selector path for an element
  function getSelectorPath(elements) {
    var paths = [];

    elements.forEach(function(element) {
      var path = '';
      var node = element;

      while (node) {
        var name = node.nodeName.toLowerCase();
        if (!name) {
          break;
        }

        var parent = node.parentElement;
        var sameTagSiblings = parent ? Array.from(parent.children).filter(child => child.nodeName.toLowerCase() === name) : [];

        if (sameTagSiblings.length > 1) {
          var index = Array.from(parent.children).indexOf(node) + 1;
          if (index > 0) {
            name += ':nth-child(' + index + ')';
          }
        }

        path = name + (path ? ' > ' + path : '');
        node = parent;
      }

      paths.push(path);
    });

    return paths.join(',');
  }

  this.elementImmediateChildren = function(mainEl, fullpath) {
    try {
      const jE = [];

      const mainElSelector = getSelectorPath(mainEl);
      const lElem = mainEl.querySelectorAll(':scope > *');
      let remainingSelector;

      lElem.forEach(el => {
        const CJESelector = getSelectorPath(el);
        const CJESelectorF = CJESelector.split(',');
        remainingSelector = !fullpath
          ? CJESelectorF[0]
              .replace(mainElSelector, '')
              .replace('>', '')
              .trim()
          : CJESelectorF[0].trim();
        if (remainingSelector) jE.push(remainingSelector);
      });

      if (jE.length === 0) {
        const CJESelector = getSelectorPath(mainEl);
        const CJESelectorF = CJESelector.split(',');
        remainingSelector = !fullpath
          ? CJESelectorF[0]
              .replace(mainElSelector, '')
              .replace('>', '')
              .trim()
          : CJESelectorF[0].trim();
        if (remainingSelector) jE.push(remainingSelector);
      }

      return jE;
    } catch (err) {
      console.error(err.message);
    }
  };

  this.elementAllSiblings = function(mainEl) {
    try {
      const jE = [];
      const mainElSelector = getSelectorPath(mainEl);

      // Get all siblings of mainEl
      const siblings = Array.from(mainEl.parentNode.children).filter(child => child !== mainEl);

      siblings.forEach(sibling => {
        const CJESelector = getSelectorPath(sibling);
        const CJESelectorF = CJESelector.split(',');
        const remainingSelector = CJESelectorF[0]
          .replace(mainElSelector, '')
          .replace('>', '')
          .trim();
        if (remainingSelector) jE.push(remainingSelector);
      });

      return jE;
    } catch (err) {
      console.error(err.message);
    }
  };

  this.elementParents = function(mainEl, withtag) {
    try {
      const jE = withtag ? {} : [];
      let lElem = mainEl;
      const mainElSelector = getSelectorPath(mainEl);

      let done = false;
      let i = 0;

      while (!done && lElem.parentNode) {
        lElem = lElem.parentNode;

        const CJESelector = getSelectorPath(lElem);
        const CJESelectorF = CJESelector.split(',');
        let remainingSelector = CJESelectorF[0]
          .replace(mainElSelector, '')
          .replace('>', '')
          .trim();

        if (withtag) {
          jE[remainingSelector] = lElem.tagName.toLowerCase();
        } else {
          jE.push(remainingSelector);
        }

        i++;
        if (i >= 100) {
          done = true;
        }
      }

      return jE;
    } catch (err) {
      console.error(err.message);
      return withtag ? {} : [];
    }
  };

  this.addNextLevels = function(selectEl) {
    try {
      const selfObj = this;
      const levelelementsvalue = selectEl.value;

      // Remove all rows after the parent row of selectEl
      let row = selectEl.closest('tr');
      while (row.nextElementSibling) {
        row.nextElementSibling.remove();
      }

      // Build levelSelector path
      let levelSelector = '';
      document.querySelectorAll('.f-functionise_related_element_levels tr').forEach(row => {
        if (levelSelector) levelSelector += ' > ';
        const selectedOption = row.querySelector('option:checked');
        if (selectedOption) {
          levelSelector += selectedOption.getAttribute('oValue');
        } else {
          const select = row.querySelector('select');
          levelSelector += select ? select.value : '';
        }
      });

      // Update text of .f-functionise_related_element_levels_value
      const levelElement = document.querySelector('.f-functionise_related_element_levels_value');
      const selectedElement = document.querySelector(levelSelector);
      levelElement.textContent = selectedElement ? selectedElement.textContent : '';

      if (!levelelementsvalue) {
        return false;
      }

      const levelSelectorElement = document.querySelector(levelSelector);
      const vavelements = selfObj.elementImmediateChildren(levelSelectorElement);

      if (vavelements.length === 0) {
        return false;
      }

      // Generate new level row
      const levelCellText = row.querySelector('td').textContent;
      const levelNumber = parseInt(levelCellText.replace('Level', '').trim()) + 1;
      let level1String = `<tr><td>Level ${levelNumber}</td>`;
      level1String += '<td><select class="levelelements"><option value="">Select Element</option>';

      vavelements.forEach(value => {
        if (value) level1String += `<option value="${value}">${value}</option>`;
      });

      level1String += '</select></td></tr>';

      // Append new level row to the table
      const table = document.querySelector('.f-functionise_related_element_levels table');
      table.insertAdjacentHTML('beforeend', level1String);

      // Attach event listener to new select elements
      document.querySelectorAll('.levelelements').forEach(element => {
        element.removeEventListener('change', handleLevelChange);
        element.addEventListener('change', handleLevelChange);
      });

      function handleLevelChange(e) {
        selfObj.addNextLevels(e.target);
      }
    } catch (err) {
      console.error(err.message);
    }
  };

  this.validateDomWalkArrow = function(arrowElement, elementSelector) {
    try {
      let changeSelector = false;
      let selector = this.domWalkElement;
      if (arrowElement) {
        const rel = arrowElement.getAttribute('rel');
        switch (rel) {
          case 'up':
            const parentSelector = selector.parentElement;
            if (parentSelector) {
              this.domWalkElement = parentSelector;
              changeSelector = true;
            }
            break;
          case 'down':
            const childs = this.elementImmediateChildren(selector, true);
            if (childs.length > 0) {
              this.domWalkElement = document.querySelector(childs[0]);
              changeSelector = true;
            }
            break;
          case 'left':
            const leftSelector = selector.previousElementSibling;
            if (leftSelector) {
              this.domWalkElement = leftSelector;
              changeSelector = true;
            }
            break;
          case 'right':
            const rightSelector = selector.nextElementSibling;
            if (rightSelector) {
              this.domWalkElement = rightSelector;
              changeSelector = true;
            }
            break;
        }
        if (changeSelector) {
          document.querySelectorAll('.f-domWalkSelector').forEach(el => el.classList.remove('f-domWalkSelector'));
          this.domWalkElement.classList.add('f-domWalkSelector');
        }
      }
      if (elementSelector) {
        this.domWalkElement = elementSelector;
        document.querySelectorAll('.f-domWalkSelector').forEach(el => el.classList.remove('f-domWalkSelector'));
        this.domWalkElement.classList.add('f-domWalkSelector');
      }

      let domSelectorStr = '';
      changeSelector = window.WS.targetElement(this.domWalkElement);

      domSelectorStr += `<b>Element:</b>&nbsp;${changeSelector.element}<br/>`;

      const id = this.domWalkElement.id;
      if (id) domSelectorStr += `<b>Id:</b>&nbsp;${id}<br/>`;

      const domClass = this.domWalkElement.className.replace('f-domWalkSelector', '').trim();
      if (domClass) domSelectorStr += `<b>Class:</b>&nbsp;${domClass}<br/>`;

      domSelectorStr += `<b>Xpath:</b>&nbsp;${changeSelector.xpath}<br/>`;

      document.querySelector('.domSelector').innerHTML = domSelectorStr;
    } catch (err) {
      console.error(err.message);
    }
  };

  this.processWindowVariables = function(windowVariables) {
    for (var prop in windowVariables) {
      try {
        windowVariables[prop] = JSON.parse(windowVariables[prop]);
      } catch (err) {
        window.fconsole.log(windowVariables[prop]);
      }
    }
    return windowVariables;
  };

  this.continueOnAttributeEditor = function() {
    var selfObj = this;
    selfObj.origAttributeValues = {};
    if (selfObj.attributeValues) {
      selfObj.origAttributeValues = JSON.parse(JSON.stringify(selfObj.attributeValues));
    }

    selfObj.attributeValues = {};
    selfObj.attributeOperators = {};
    var lastAction = window.WS.getLastRecordedDataSegment();
    if (lastAction.action !== 'verify') {
      alert('Unable to update verify action. Please try again.');
      return;
    }

    document.querySelectorAll('#' + window.fUniqPrefix + '_attribute_table tr').forEach(function(row) {
      if (row.querySelector('td:eq(0) input') === null) return;

      var attrKey = row.querySelector('td:eq(1) label')?.textContent;
      if (!attrKey) {
        window.fconsole.log('Attribute key is undefined');
        return;
      }
      attrKey = attrKey.trim();

      var attrVal = row.querySelector('td:eq(3) input:not(.f-functionise-attrstepfunctionvalue)')?.value;
      if (typeof attrVal === 'undefined') {
        attrVal = row.querySelector('td:eq(3) textarea')?.value;

        if (typeof attrVal === 'undefined') {
          window.fconsole.log('Attribute value is undefined for key: ' + attrKey);
          return;
        }
      }
      attrVal = attrVal.trim();

      var attrFunc = row.querySelector('td:eq(3) .f-functionise-attrstepfunction')?.value || '';

      var attrFuncVal = row.querySelector('td:eq(3) .f-functionise-attrstepfunctionvalue')?.value;
      if (typeof attrFuncVal === 'undefined' || attrFunc !== 'substring') {
        attrFuncVal = '';
      }

      var attrOpr = row.querySelector('td:eq(2) select')?.value;
      if (!attrOpr) {
        window.fconsole.log('Attribute value is undefined for key: ' + attrKey);
        return;
      }
      attrOpr = attrOpr.trim();

      if (attrOpr === 'rangei' || attrOpr === 'rangef') {
        var attrValSplit = attrVal.split('-');
        var invalidRange = false;
        if (attrValSplit[0]) {
          var firstVal = attrValSplit[0].trim();
          if (Number(firstVal) !== +firstVal) {
            invalidRange = true;
          }
        } else {
          invalidRange = true;
        }
        if (attrValSplit[1]) {
          var secondVal = attrValSplit[1].trim();
          if (Number(secondVal) !== +secondVal) {
            invalidRange = true;
          }
        } else {
          invalidRange = true;
        }
        if (invalidRange) {
          alert('Invalid Range');
          return;
        }
      }

      if (row.querySelector('td:eq(0) input').checked) {
        var attrData = {};
        attrData['verifyattr_' + attrKey] = attrOpr + '#func#' + attrVal;
        if (attrFunc) attrData['verifyattr_' + attrKey] += '|FUNCSTEP|' + attrFunc;
        if (attrFuncVal) attrData['verifyattr_' + attrKey] += '|FUNCSTEP|' + attrFuncVal;
        window.fconsole.log('Adding ' + attrKey + ' ' + attrVal);
        window.WS.appendToRecordedData(attrData);
      } else {
        window.fconsole.log('Checking orig key ' + attrKey + ': ' + selfObj.origAttributeValues[attrKey]);
        if (selfObj.origAttributeValues[attrKey] !== undefined) {
          window.WS.removeFromRecordedData('verifyattr_' + attrKey);
        }
      }
    });

    document.querySelectorAll('#' + window.fUniqPrefix + '_cattribute_table tr').forEach(function(row) {
      if (row.querySelector('td:eq(0) input') === null) return;

      var attrKey = row.querySelector('td:eq(1) select')?.value;
      if (!attrKey) {
        window.fconsole.log('Attribute key is undefined');
        return;
      }
      attrKey = attrKey.trim();

      var attrVal = row.querySelector('td:eq(3) input')?.value;
      if (typeof attrVal === 'undefined') {
        attrVal = row.querySelector('td:eq(3) textarea')?.value;

        if (typeof attrVal === 'undefined') {
          window.fconsole.log('Attribute value is undefined for key: ' + attrKey);
          return;
        }
      }
      attrVal = attrVal.trim();

      var attrOpr = row.querySelector('td:eq(2) select')?.value;
      if (!attrOpr) {
        window.fconsole.log('Attribute value is undefined for key: ' + attrKey);
        return;
      }
      attrOpr = attrOpr.trim();

      if (attrOpr === 'rangei' || attrOpr === 'rangef') {
        var attrValSplit = attrVal.split('-');
        var invalidRange = false;
        if (attrValSplit[0]) {
          var firstVal = attrValSplit[0].trim();
          if (Number(firstVal) !== +firstVal) {
            invalidRange = true;
          }
        } else {
          invalidRange = true;
        }
        if (attrValSplit[1]) {
          var secondVal = attrValSplit[1].trim();
          if (Number(secondVal) !== +secondVal) {
            invalidRange = true;
          }
        } else {
          invalidRange = true;
        }
        if (invalidRange) {
          alert('Invalid Range');
          return;
        }
      }

      if (row.querySelector('td:eq(0) input').checked) {
        var attrData = {};
        attrData['verifyattr_c_' + attrKey] = attrOpr + '#func#' + attrVal;
        window.WS.appendToRecordedData(attrData);
      } else {
        window.fconsole.log('Checking orig key ' + attrKey + ': ' + selfObj.origAttributeValues[attrKey]);
        if (selfObj.origAttributeValues[attrKey] !== undefined) {
          window.WS.removeFromRecordedData('verifycattr_' + attrKey);
        }
      }
    });
  };

  this.continueOnClickAttributeEditor = function() {
    var selfObj = this;
    selfObj.origAttributeValues = {};
    if (selfObj.attributeValues !== undefined) {
      selfObj.origAttributeValues = JSON.parse(JSON.stringify(selfObj.attributeValues));
    }

    selfObj.attributeValues = {};
    selfObj.attributeOperators = {};
    var lastAction = window.WS.getLastRecordedDataSegment();

    document.querySelectorAll('#' + window.fUniqPrefix + '_attribute_table tr').forEach(function(row) {
      var attrKeyElem = row.querySelector('td:nth-child(2) label');
      var attrKey = attrKeyElem ? attrKeyElem.textContent.trim() : '';

      var attrValElem = row.querySelector('td:nth-child(4) input:not(.f-functionise-attrstepfunctionvalue)');
      var attrVal = attrValElem ? attrValElem.value.trim() : '';

      if (!attrVal) {
        var attrValTextareaElem = row.querySelector('td:nth-child(4) textarea');
        attrVal = attrValTextareaElem ? attrValTextareaElem.value.trim() : '';
      }

      var attrFuncElem = row.querySelector('td:nth-child(4) .f-functionise-attrstepfunction');
      var attrFunc = attrFuncElem ? attrFuncElem.value : '';

      if (attrFunc !== 'substring') {
        attrFunc = '';
      }

      var attrFuncValElem = row.querySelector('td:nth-child(4) .f-functionise-attrstepfunctionvalue');
      var attrFuncVal = attrFuncValElem ? attrFuncValElem.value : '';

      if (attrFunc !== 'substring') {
        attrFuncVal = '';
      }

      var attrOprElem = row.querySelector('td:nth-child(3) select');
      var attrOpr = attrOprElem ? attrOprElem.value.trim() : '';

      var attrStepAttrElem = row.querySelector('td:nth-child(4) .f-functionise-attrstepattribute');
      var attrStepAttr = attrStepAttrElem ? attrStepAttrElem.value : '';

      var attrStepValueElem = row.querySelector('td:nth-child(4) .f-functionise-attrstepvalue');
      var attrStepValue = attrStepValueElem ? attrStepValueElem.value : '';

      var attrtextboxvalueElem = row.querySelector('td:nth-child(4) .f-functionise-attrtextboxvalue');
      var attrtextboxvalue = attrtextboxvalueElem ? attrtextboxvalueElem.value : '';

      var attrtextareavalueElem = row.querySelector('td:nth-child(4) .f-functionise-attrtextareavalue');
      var attrtextareavalue = attrtextareavalueElem ? attrtextareavalueElem.value : '';

      var checkboxElem = row.querySelector('td:nth-child(1) input');
      if (checkboxElem && checkboxElem.checked && attrOpr) {
        var filledValue = '';
        switch (attrOpr) {
          case 'FAE':
            filledValue = '[functionizeappEmail]';
            break;
          case 'RS':
            filledValue = attrtextboxvalue; // "[randomString]";
            break;
          case 'RT':
            filledValue = attrtextboxvalue; // "[randomText]";
            break;
          case 'RTS':
            filledValue = attrtextboxvalue; // "[randomTextSmall]";
            break;
          case 'RTU':
            filledValue = attrtextboxvalue; // "[randomTextUpper]";
            break;
          case 'RN':
            filledValue = attrtextboxvalue; // "[randomNumber]";
            break;
          case 'FD':
            filledValue = attrtextboxvalue; // "[randomNumber]";
            break;
          case 'SV':
            if (attrStepValue) {
              filledValue = '[functionizeVariable::' + attrStepValue;
              if (attrStepAttr) filledValue += '::' + attrStepAttr;
              if (attrFunc) filledValue += '::' + attrFunc;
              if (attrFuncVal) filledValue += '::' + attrFuncVal;
              filledValue += ']';
            }
            break;
          case 'SI':
            filledValue = attrtextareavalue;
            break;
        }
        if (filledValue) {
          if (attrKey === 'value') {
            window.TCM.clickAttributeEditorValue['actualstring'] = filledValue;

            var filledValueLabelElem = document.querySelector('.f-functionise-attrstepvaluelabel');
            if (attrOpr === 'SV') {
              window.TCM.clickAttributeEditorValue['filledValue'] = filledValueLabelElem ? filledValueLabelElem.innerHTML : '';
            } else {
              window.TCM.clickAttributeEditorValue['filledValue'] = filledValue;
            }

            window.TCM.clickAttributeEditorValue['filledOpr'] = attrOpr;
            window.TCM.flagshiftclickinput = true;
          }
        }
      }
    });
  };

  this.changeByOeratorForVerify = function(thisObj) {
    var inputTr = thisObj.closest('tr');

    inputTr.querySelectorAll('input[type=checkbox]').forEach(function(checkbox) {
      checkbox.checked = true;
    });

    var lastTd = inputTr.querySelector('td:last-child');
    if (lastTd) {
      var attrStepValueElems = lastTd.querySelectorAll('[id*="attrstepvalue"]');
      var attrStepFunctionElems = lastTd.querySelectorAll('[id*="attrstepfunction"]');
      var multipleOptionsElems = lastTd.querySelectorAll('.' + window.fUniqPrefix + '_multipleoptions');

      attrStepValueElems.forEach(function(elem) {
        elem.classList.remove('hideitem');
      });
      lastTd.querySelectorAll('textarea').forEach(function(elem) {
        elem.classList.remove('hideitem');
      });
      lastTd.querySelectorAll('input').forEach(function(elem) {
        elem.classList.remove('hideitem');
      });
      attrStepFunctionElems.forEach(function(elem) {
        elem.classList.remove('hideitem');
      });

      var soperatorForInp = thisObj.value;
      if (soperatorForInp.indexOf('stepval') > 0) {
        lastTd.querySelectorAll('textarea').forEach(function(elem) {
          elem.classList.add('hideitem');
        });
        lastTd.querySelectorAll('input').forEach(function(elem) {
          elem.classList.add('hideitem');
        });
        attrStepValueElems.forEach(function(elem) {
          elem.classList.remove('hideitem');
        });
        multipleOptionsElems.forEach(function(elem) {
          elem.classList.add('hideitem');
        });
      } else {
        lastTd.querySelectorAll('textarea').forEach(function(elem) {
          elem.classList.remove('hideitem');
        });
        lastTd.querySelectorAll('input').forEach(function(elem) {
          elem.classList.remove('hideitem');
        });
        attrStepValueElems.forEach(function(elem) {
          elem.classList.add('hideitem');
        });
        attrStepFunctionElems.forEach(function(elem) {
          elem.classList.add('hideitem');
        });
        multipleOptionsElems.forEach(function(elem) {
          elem.classList.remove('hideitem');
        });
      }
    }
  };

  this.formatActionLogForListView = function(actionLog) {
    var recordedData = [];

    actionLog.forEach(function(value) {
      recordedData.push({
        action: value.action,
        element: value.element,
        actionId: value.actionId,
        url: value.url,
        time: value.time,
        verifyattr_text: value.verifyattr_text,
        verifyattr_value: value.verifyattr_value,
        text: value.text,
        value: value.value,
      });
    });

    return recordedData;
  };

  this.checkForEditorFault = function() {
    // Remove the error class from all select elements with the specific class
    document.querySelectorAll('select.f-functionise-attrstepvalue').forEach(el => {
      el.classList.remove('z-highlight-error');
    });

    let faultInEditor = false;

    // Get the table rows
    document.querySelectorAll('#' + window.fUniqPrefix + '_attribute_table tr').forEach(row => {
      // Get the operator value from the select element in the second cell
      const operatorSelect = row.querySelector('td:nth-child(3) select');
      const soperator = operatorSelect ? operatorSelect.value : undefined;

      if (soperator && soperator.indexOf('stepval') > 0) {
        // Get the step value from the select element in the fourth cell
        const stepValueSelect = row.querySelector('td:nth-child(4) select.f-functionise-attrstepvalue');
        const stepValue = stepValueSelect ? stepValueSelect.value : '';

        if (stepValue === '') {
          // Add error class and set faultInEditor flag
          if (stepValueSelect) {
            stepValueSelect.classList.add('z-highlight-error');
          }
          faultInEditor = true;
        }
      }
    });

    return faultInEditor;
  };

  this.keywordSearchButtonEvent = function(thisObj, selfObj, editorObj) {
    // Handle page variable change events
    document.querySelectorAll('.f-functionise-page-variable').forEach(el => {
      el.removeEventListener('change', handlePageVariableChange);
      el.addEventListener('change', handlePageVariableChange);
    });

    function handlePageVariableChange(e) {
      const vav = document.querySelector('.f-functionise-page-variable:checked')?.value;
      document.querySelector('.' + window.fUniqPrefix + '_page_variable_keyword').value = '';
      document.querySelectorAll('.f-functionise-pv-notfound').forEach(el => el.remove());
      document.querySelectorAll('.f-functionise-pv').forEach(el => (el.style.display = 'none'));
      document.querySelector('.' + window.fUniqPrefix + '-resourcevariablefullstring').innerHTML = '';

      if (vav === 'PV') {
        document.querySelector('.f-functionise-pv-selection').style.display = 'none';
        document.querySelectorAll('.f-functionise-pv').forEach(el => (el.style.display = 'block'));
        document.querySelectorAll('.f-functionise-rv').forEach(el => (el.style.display = 'none'));
      } else {
        document.querySelectorAll('.f-functionise-pv').forEach(el => (el.style.display = 'none'));
        document.querySelectorAll('.f-functionise-rv').forEach(el => (el.style.display = 'block'));
        document.querySelector('.f-functionise_page_variable_loader').style.display = 'block';
        document.querySelector('.f-functionise-pv-selection').style.display = 'none';
        window.TCM.loadResourceData();

        let r = 0;
        const myVar = setInterval(() => {
          window.fconsole.log('Interval function called to process pageVariabled ' + r);
          r++;
          if (r >= 2) {
            clearInterval(myVar);
            document.querySelector('.f-functionise_page_variable_loader').style.display = 'none';
            document
              .querySelector('.f-functionise_page_variable_loader')
              .insertAdjacentHTML('afterend', "<tr class='f-functionise-pv-notfound'><td colspan='2'>No Data Found.</td></tr>");
          }
          if (window.TCM.resourceData === 'BLANK') {
            document.querySelector('.f-functionise_page_variable_loader').style.display = 'none';
            document
              .querySelector('.f-functionise_page_variable_loader')
              .insertAdjacentHTML('afterend', "<tr class='f-functionise-pv-notfound'><td colspan='2'>No Data Found.</td></tr>");
            clearInterval(myVar);
          } else if (Object.keys(window.TCM.resourceData).length > 0) {
            const windowFzVariables = {};
            Object.entries(window.TCM.resourceData).forEach(([key, value]) => {
              if (!windowFzVariables.window) {
                windowFzVariables.window = {};
              }
              const fzVariablesT = `functionizeResourceVariables['${key}']`;
              if (!windowFzVariables.window[fzVariablesT]) {
                windowFzVariables.window[fzVariablesT] = {};
              }
              Object.entries(value).forEach(([key1, value1]) => {
                windowFzVariables.window[fzVariablesT][key1] = value1;
              });
            });
            window.TCM.windowVariables = windowFzVariables;

            try {
              const autoCompleteChoices = [];
              Object.entries(window.TCM.resourceData).forEach(([key, value]) => {
                if (Object.keys(value).length > 0) {
                  autoCompleteChoices.push(key);
                }
              });

              const autoCompleteInput = document.querySelector('.f-functionise_resource_variable_url');
              if (autoCompleteInput) {
                const autoComplete = new AutoComplete(autoCompleteInput, {
                  minChars: 2,
                  source: function(term, suggest) {
                    term = term.toLowerCase();
                    const suggestions = autoCompleteChoices.filter(choice => choice.toLowerCase().includes(term));
                    suggest(suggestions);
                  },
                  onSelect: function(e, term, item) {
                    document.querySelector('.autocomplete-suggestions').style.display = 'none';
                    selfObj.processPageVariables(
                      thisObj,
                      selfObj.processWindowVariables(window.TCM.windowVariables['window'][`functionizeResourceVariables['${term}']`]),
                      selfObj,
                      editorObj,
                      'RV'
                    );
                  },
                });
              }
            } catch (err) {}

            document.querySelectorAll('.f-functionise-rv').forEach(el => (el.style.display = 'block'));
            document.querySelector('.f-functionise_page_variable_loader').style.display = 'none';
            clearInterval(myVar);
          }
        }, 500);
      }
    }

    // Handle resource variable URL change events
    document.querySelectorAll('.f-functionise_resource_variable_url').forEach(el => {
      el.removeEventListener('change', handleResourceVariableUrlChange);
      el.addEventListener('change', handleResourceVariableUrlChange);
    });

    function handleResourceVariableUrlChange(e) {
      selfObj.processPageVariables(
        thisObj,
        selfObj.processWindowVariables(window.TCM.windowVariables['window'][`functionizeResourceVariables['${e.target.value}']`]),
        selfObj,
        editorObj,
        'RV'
      );
    }

    // Handle keyword search button click events
    const keywordSearchButton = document.querySelector('#keywordSearchButton');
    if (keywordSearchButton) {
      keywordSearchButton.removeEventListener('click', handleKeywordSearchButtonClick);
      keywordSearchButton.addEventListener('click', handleKeywordSearchButtonClick);
    }

    function handleKeywordSearchButtonClick(e) {
      document.querySelectorAll('.f-functionise_formError').forEach(el => {
        el.classList.add('f-hide_event');
        el.innerHTML = '';
      });
      document.querySelectorAll('.f-functionise-pv-notfound').forEach(el => el.remove());
      const pageVariableKeyword = document.querySelector('.' + window.fUniqPrefix + '_page_variable_keyword').value;

      if (!pageVariableKeyword) {
        document.querySelectorAll('.f-functionise_formError').forEach(el => {
          el.classList.remove('f-hide_event');
          el.innerHTML = 'Please enter keyword name.';
        });
        return false;
      } else if (pageVariableKeyword.length === 1) {
        document.querySelectorAll('.f-functionise_formError').forEach(el => {
          el.classList.remove('f-hide_event');
          el.innerHTML = 'Please enter keyword name with atleast 2 characters.';
        });
        return false;
      } else {
        document.querySelector('.f-functionise_page_variable_loader').style.display = 'block';
        document.querySelector('.f-functionise-pv-selection').style.display = 'none';
        window.postMessage({ call: 'getRelatedPageVariables', pageVariableKeyword: pageVariableKeyword }, '*');

        let r = 0;
        const myVar = setInterval(() => {
          r++;
          if (r >= 5) {
            clearInterval(myVar);
            document.querySelector('.f-functionise_page_variable_loader').style.display = 'none';
            document
              .querySelector('.f-functionise_page_variable_loader')
              .insertAdjacentHTML('afterend', "<tr class='f-functionise-pv-notfound'><td colspan='2'>No Data Found.</td></tr>");
          }
          window.fconsole.log('Interval function called to process page related Variables ' + r + ' ' + window.WS.searchedPageVariables);
          if (window.WS.searchedPageVariables === 'BLANK' && (!window.FzPageVariable || typeof window.FzPageVariable === 'undefined')) {
            document.querySelector('.f-functionise_page_variable_loader').style.display = 'none';
            document
              .querySelector('.f-functionise_page_variable_loader')
              .insertAdjacentHTML('afterend', "<tr class='f-functionise-pv-notfound'><td colspan='2'>No Data Found.</td></tr>");
            clearInterval(myVar);
          } else if (Object.keys(window.WS.searchedPageVariables).length > 0 || typeof window.FzPageVariable !== 'undefined') {
            let windowVariables = selfObj.processWindowVariables(window.WS.searchedPageVariables);

            try {
              if (typeof window.FzPageVariable !== 'undefined') {
                Object.entries(window.FzPageVariable).forEach(([key, value]) => {
                  if (key.indexOf(pageVariableKeyword) === 0) {
                    if (windowVariables === 'BLANK') windowVariables = [];

                    windowVariables[`window.FzPageVariable.${key}`] = value;
                  }
                });
              }
            } catch (err) {}

            if (windowVariables === 'BLANK') {
              document.querySelector('.f-functionise_page_variable_loader').style.display = 'none';
              document
                .querySelector('.f-functionise_page_variable_loader')
                .insertAdjacentHTML('afterend', "<tr class='f-functionise-pv-notfound'><td colspan='2'>No Data Found.</td></tr>");
              clearInterval(myVar);
            }
            clearInterval(myVar);
            selfObj.processPageVariables(thisObj, windowVariables, selfObj, editorObj, 'PV');
          }
        }, 500);
      }
    }
  };

  this.formatResourceString = function(string, fullurl) {
    var stringArr = string.split('.');
    var stringArrLen = stringArr.length;
    var val = stringArr[stringArrLen - 1];
    stringArr = string.split("['");
    var stringArrSt1 = stringArr[1];
    stringArr = stringArrSt1.split("']");
    stringArrSt1 = stringArr[0];
    var filename = stringArrSt1.split('/').pop();
    if (fullurl) filename = stringArrSt1;
    var rStr = filename + '.' + val;
    return rStr;
  };

  this.getactionloghumanized = function() {
    try {
      // Show loader
      document.querySelector('.f-functionise-actions_description').innerHTML = '<div class="f-funcitonise-loader-image">&nbsp;</div>';

      const selfObj = this;

      // Send POST request
      fetch('https://' + window.WS.wbHost + '/ajax/getactionloghumanized', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action_log: selfObj.formatActionLogForListView(window.WS.recordedData) }),
      })
        .then(response => response.json())
        .then(data => {
          if (data) {
            let humanizedData = '<ul>';
            let i = 1;

            data.forEach((value, index) => {
              humanizedData += `<li><div class='f-functionise-action_srno'>${i}</div><div class='f-functionise-action_description'>${value}</div><div class='f-functionise-action_delete'>x</div></li>`;
              i++;
            });

            humanizedData += '</ul>';
            document.querySelector('.f-functionise-actions_description').innerHTML = humanizedData;

            // Add click event to delete buttons
            document.querySelectorAll('.f-functionise-action_delete').forEach(button => {
              button.removeEventListener('click', handleDeleteClick);
              button.addEventListener('click', handleDeleteClick);
            });

            function handleDeleteClick(e) {
              const srno = parseInt(this.closest('li').querySelector('.f-functionise-action_srno').textContent);

              if (srno === 1) {
                alert('You cannot delete first pageinit.');
              } else {
                this.closest('li').remove();
                window.WS.recordedData.splice(srno - 1, 1);
                window.WS.recordWbData();
                window.WS.decrementActionCount();
                selfObj.getactionloghumanized();
              }
            }
          }
        })
        .catch(err => {
          alert(err.message);
        });
    } catch (err) {
      alert(err.message);
    }
  };
}

// This file build and controls the actual HTML for the panel container.

export function fBottomPanel(options) {
  var defaults = {};
  options = Object.assign({}, defaults, options);

  this.objPanel = null;
  var objTabs = null;
  this.currentElement = null;

  this.options = options;

  //Set the tabs container to be displayed within the open mbExtruder Panel
  this.setTabsContainer = function(oTabs) {
    objTabs = oTabs;
  };

  this.setCurrentElement = function(ce) {
    this.currentElement = ce;
  };

  //action to be executed when the panel is opened - this is linked to the panel as the onExtOpen callback
  this.openPanelAction = function() {
    objTabs.buildTabs();
  };

  //Initialize the mbExtruder panel with the specified options
  this.buildPanel = function() {
    // Build the panel using the MB Extruder library
    var panelElement = document.querySelector(options.panelContainer);
    if (panelElement) {
      this.objPanel = panelElement.fzeBuildMbExtruder({
        position: options.panelPosition,
        extruderOpacity: 1,
        width: options.panelWidth,
        closeOnExternalClick: false,
        closeOnClick: false,
        autoMatchParens: true,
        saveFunction: true,
        slideTimer: 200,
        onExtOpen: this.openPanelAction,
        onExtContentLoad: function() {},
        onExtClose: this.hidePanel,
      });
    }
  };

  // This function is called to open the mbExtruder panel (which in turn calls the onExtOpen callback to build the tabs)
  // and then sets the action log data in the specific tab

  this.openPanel = function(element, callerIframe, callerPopup, source, recordedData, urlActionNotCompatible = false) {
    self.port.emit('message', {
      obj: 'TCM',
      call: 'advancedEditor',
      arguments: {
        element: element,
        callerIframe: callerIframe,
        callerPopup: callerPopup,
        source: source,
        recordedData: recordedData,
        urlActionNotCompatible: urlActionNotCompatible,
      },
      forMaster: true,
    });
    /*
    console.log('f.bottompanel.js openPanel');
    // Helper function to check if an element has a specific class
    function hasClass(element, className) {
      return element.classList.contains(className);
    }

    // Helper function to add a class to an element
    function addClass(element, className) {
      element.classList.add(className);
    }

    // Helper function to remove a class from an element
    function removeClass(element, className) {
      element.classList.remove(className);
    }

    // Main code
    var settingButton = document.querySelector('#setting-button');
    var verifyButton = document.querySelector('#verify-button');
    var codeAttributeLinks = document.querySelectorAll('.f-functionise-code_attribute_link');
    var codeWaitLinks = document.querySelectorAll('.f-functionise-code_wait_link');
    var codeEmailLinks = document.querySelectorAll('.f-functionise-code_email_link');
    var codeSmsLinks = document.querySelectorAll('.f-functionise-code_sms_link');
    var codeNavigateLinks = document.querySelectorAll('.f-functionise-code_navigate_link');
    var hoverActions = document.querySelectorAll('.f-functionise-hoverAction');

    if (hasClass(settingButton, 'active-bottompanel')) {
      codeAttributeLinks.forEach(link => addClass(link, 'f-disableLink'));
      codeWaitLinks.forEach(link => removeClass(link, 'f-disableLink'));
      codeEmailLinks.forEach(link => removeClass(link, 'f-disableLink'));
      codeSmsLinks.forEach(link => removeClass(link, 'f-disableLink'));
      codeNavigateLinks.forEach(link => removeClass(link, 'f-disableLink'));
      hoverActions.forEach(action => addClass(action, 'f-disableLink'));
    } else {
      codeWaitLinks.forEach(link => addClass(link, 'f-disableLink'));
      codeEmailLinks.forEach(link => addClass(link, 'f-disableLink'));
      codeSmsLinks.forEach(link => addClass(link, 'f-disableLink'));
      codeNavigateLinks.forEach(link => addClass(link, 'f-disableLink'));
      codeAttributeLinks.forEach(link => removeClass(link, 'f-disableLink'));
      hoverActions.forEach(action => removeClass(action, 'f-disableLink'));

      if (hasClass(verifyButton, 'rec-buttons-active')) {
        var tagname = this.currentElement.element.toLowerCase();
        if (tagname != 'input' && tagname != 'textarea') {
          codeAttributeLinks.forEach(link => addClass(link, 'f-disableLink'));
        }
      }
    }
    this.objPanel.openMbExtruder();
    */
  };

  // This function is called to close the mbExtruder panel and calls the onExtClose callback.
  this.closePanel = function() {
    window.fconsole.log('close panel called');
    var validateLinks = document.querySelectorAll('.f-functionise-code_validate_link');
    validateLinks.forEach(function(element) {
      element.classList.add('f-hide_event');
    });
    this.objPanel.closeMbExtruder();
  };

  //This is called on the onExtClose callback
  this.hidePanel = function(time) {
    if (typeof time == 'undefined') time = 500;
    if (typeof window.TCM.advancedEditor != 'undefined' && window.TCM.advancedEditor != null) {
      setTimeout(
        `var panelContainer = document.querySelector(TCM.advancedEditor.oPanel.options.panelContainer);
        if (panelContainer) { panelContainer.style.zIndex = -1; }`,
        time
      );
    }
  };
}

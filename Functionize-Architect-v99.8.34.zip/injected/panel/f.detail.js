import { randomString } from './f.prepend';
// This file build and controls the left hand details panel component

export function fDetail(options) {
  var defaults = {};
  options = Object.assign({}, defaults, options);

  this.objMainEditor = null;
  this.currentFElement = null; // current

  this.setCurrentElement = function (ce) {
    this.currentFElement = ce;
    this.updateDetailPanel();
  };

  // Update the left details panel with the data from the current selected element.
  this.updateDetailPanel = function () {
    var maxValChars = 25;
    // Get the tag name (INPUT, SELECT) etc from the current selected functionise element
    var tagName = null;
    if (typeof this.currentFElement !== 'undefined' && this.currentFElement && this.currentFElement.element) {
      tagName = this.currentFElement.element.toLowerCase();
    } else {
      tagName = '';
    }

    var attrStr = '';

    if (typeof this.currentFElement !== 'undefined' && this.currentFElement) {
      // Display the tag name as the first element
      attrStr +=
        '<ul><li><label>Tag Name: </label><label class="' +
        window.fUniqPrefix +
        '-css-contentarea-details-label ' +
        randomString +
        '" id="' +
        window.fUniqPrefix +
        '_details_etagname">' +
        tagName +
        '</label></li>';

      // Display the other elements from the JSON data for the currently selected functionise element
      for (var index in this.currentFElement) {
        if (this.currentFElement.hasOwnProperty(index)) {
          var attr = this.currentFElement[index];
          var attrName = null;
          var attrValue = null;

          if (index.startsWith('attr_') && !index.startsWith('attr_parent') && !index.startsWith('attr_child') && !index.startsWith('attr_sibling')) {
            attrName = index.substring(5);
            attrValue = attr;

            var attrValueT = attrValue.toString();

            if (attrValueT.indexOf('z-highlighted') > -1) {
              attrValue = attrValue.replace('z-highlighted', '').trim();
              if (attrValue === '') continue;
            }
            if (attrValue.length > maxValChars) attrValue = attrValue.substring(0, maxValChars) + '...';

            attrStr +=
              '<li><label>' +
              attrName +
              ': </label><label class="' +
              window.fUniqPrefix +
              '-css-contentarea-details-label ' +
              randomString +
              '" id="' +
              window.fUniqPrefix +
              '_details_e' +
              attrName +
              '">' +
              attrValue +
              '</label></li>';
          }
          if (index === 'text') {
            attrName = index;
            attrValue = attr;

            attrStr +=
              '<li><label>' +
              attrName +
              ': </label><label class="' +
              window.fUniqPrefix +
              '-css-contentarea-details-label ' +
              randomString +
              '" id="' +
              window.fUniqPrefix +
              '_details_e' +
              attrName +
              '">' +
              attrValue +
              '</label></li>';
          }
        }
      }
      attrStr += '</ul>';
    }

    // Update the HTML content
    var element = document.querySelector('.' + window.fUniqPrefix + '-cElement');
    if (element) {
      element.innerHTML = attrStr;
    }
  };
}

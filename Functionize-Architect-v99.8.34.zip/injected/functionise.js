import './lib/panel/mbExtruder.js';
import './lib/simplestorage.min.js';

import * as common from './modeler/common';
import * as sender from './modeler/sender';
import * as tester from './tester/tester';

window.fUniqPrefix = 'f-functionise';

if (typeof window.functionizeJsInjected === 'undefined') {
  window.functionizeJsInjected = true;
  common.initCommon();
  sender.initSender();
  tester.initTester();
}

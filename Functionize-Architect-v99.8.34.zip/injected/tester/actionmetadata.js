//Action's Metadata
export function actionmetadata() {
  this.elementPreviousState = {};
  this.elementPostState = {};
  this.possibleElementsIds = {};
  this.elementfocusData = {};
  this.functionizeAjaxLogRequestForMeta = {};
  this.cxpath5 = '';
  this.targetElementCachesData = {};
  this.actionDataForAjax = {};

  //Set Meta Data for action based on its position
  this.addMetadata = function(metaKey, key, value, position) {
    try {
      var WSRecordedData = window.WS.recordedData;
      if (WSRecordedData.length == 0 || !WSRecordedData) return false;

      if (typeof position == 'undefined' || position == 'undefined') {
        position = WSRecordedData.length;
      }
      if (position < 0 || WSRecordedData.length < position) {
        return false;
      }
      position--;
      var WSRecordedSingleData = WSRecordedData[position];

      if (typeof WSRecordedSingleData.meta == 'undefined') {
        WSRecordedSingleData['meta'] = {};
      }

      if (key == 'undefined' || key == '') {
        WSRecordedSingleData['meta'][metaKey] = value;
      } else {
        if (typeof WSRecordedSingleData.meta[metaKey] == 'undefined') {
          WSRecordedSingleData['meta'][metaKey] = {};
        }
        WSRecordedSingleData['meta'][metaKey][key] = value;
      }

      if (position >= 0) {
        window.WS.appendToRecordedDataByIndex(WSRecordedSingleData, position);
      }
    } catch (err) {
      alert('1 - ' + err.message);
    }
  };

  //get Meta Data for action based on its position
  this.getMetadata = function(metaKey, key, position) {
    try {
      var WSRecordedData = window.WS.recordedData;
      if (WSRecordedData.length == 0 || !WSRecordedData) return false;

      if (typeof position == 'undefined' || position == 'undefined') {
        position = WSRecordedData.length;
      }
      if (position < 0 || WSRecordedData.length < position) {
        return false;
      }
      position--;
      var WSRecordedSingleData = WSRecordedData[position];

      if (typeof WSRecordedSingleData.meta == 'undefined') {
        return false;
      } else if (metaKey == 'undefined' || metaKey == '') {
        return WSRecordedSingleData['meta'];
      } else if (key == 'undefined' || key == '') {
        return WSRecordedSingleData['meta'][metaKey];
      } else {
        return WSRecordedSingleData['meta'][metaKey][key];
      }
    } catch (err) {}
  };

  //Add Element Previous State for action meta data
  this.addElementPreviousState = function(e, listner, elementData) {
    try {
      if (!window.WS.on) return;
      if (!window.WS.shiftDown) {
        if (!elementData) {
          window.fconsole.log('taregtting element on previous state');
          elementData = this.targetElementCache(e.target);
        }

        if (listner == 'mouseup' || listner == 'mouseover' || listner == 'focus') {
          elementData = this.getUseableData(elementData);
          elementData = this.addExtraAttributes(e, elementData);
          var xpath5 = elementData.xpath5;
          if (typeof this.elementPreviousState[xpath5] == 'undefined') {
            // && this.elementPreviousState[xpath5])
            this.elementPreviousState[xpath5] = elementData;
          } else {
            this.elementPreviousState[xpath5] = this.mergeJSON(this.elementPreviousState[xpath5], elementData);
          }

          if (
            elementData.type != 'checkbox' &&
            elementData.type != 'radio' &&
            (elementData.element == 'input' || elementData.element == 'textarea' || elementData.element == 'select')
          ) {
            if (typeof this.elementfocusData[xpath5] == 'undefined') {
              this.elementfocusData[xpath5] = elementData;
            } else {
              this.elementfocusData[xpath5] = this.mergeJSON(this.elementfocusData[xpath5], elementData);
            }
          }
        }
      }
    } catch (err) {}
  };

  //Add Element Post State for action meta data
  this.addElementPostState = function(e, listner, elementData) {
    try {
      if (!window.WS.on) return;
      if (!window.WS.shiftDown) {
        if (!elementData) {
          window.fconsole.log('taregtting element on post state');
          elementData = this.targetElementCache(e.target);
        }
        if (listner == 'click' || listner == 'mouseover' || listner == 'blur') {
          elementData = this.getUseableData(elementData);
          elementData = this.addExtraAttributes(e, elementData);
          var xpath5 = elementData.xpath5;
          if (typeof this.elementPostState[xpath5] == 'undefined') {
            // && this.elementPostState[xpath5])
            this.elementPostState[xpath5] = elementData;
          } else {
            this.elementPostState[xpath5] = this.mergeJSON(this.elementPostState[xpath5], elementData);
          }
        }
      }
    } catch (err) {}
  };

  //set meta data in action log for given position
  this.buildMetaDataForLastAction = function(e, listner, position, elementData) {
    try {
      if (window.WS.disableExtendedData) return;
      if (!window.WS.on) return;
      if (!window.WS.shiftDown) {
        if (!elementData) {
          window.fconsole.log('taregtting element on building meta data');
          elementData = this.targetElementCache(e.target);
        }
        var xpath5 = elementData.xpath5;

        var existingElementData = window.WS.recordedData[position - 1];

        if (typeof this.elementPreviousState[xpath5] != 'undefined' && this.elementPreviousState[xpath5] && existingElementData['xpath5'] == xpath5) {
          this.addMetadata('preActionData', '', this.elementPreviousState[xpath5], position);

          this.elementPreviousState[xpath5] = '';
        }

        if (typeof this.elementPostState[xpath5] != 'undefined' && this.elementPostState[xpath5] && existingElementData['xpath5'] == xpath5) {
          this.addMetadata('postActionData', '', this.elementPostState[xpath5], position);

          this.elementPostState[xpath5] = '';
        }

        if (typeof this.possibleElementsIds[xpath5] != 'undefined' && this.possibleElementsIds[xpath5] && existingElementData['xpath5'] == xpath5) {
          var allElementData = [];
          for (var i = 0; i < this.possibleElementsIds[xpath5].length; i++) {
            window.fconsole.log('taregtting element in possible elements...');
            var element = document.querySelector('[data-functionize-id="' + this.possibleElementsIds[xpath5][i] + '"]');
            elementData = this.targetElementCache(element);
            if (typeof elementData.xpath5 != 'undefined' && elementData.xpath5) {
              allElementData.push(elementData);
            }
          }
          if (allElementData.length) this.addMetadata('possibleElements', '', allElementData, position);

          this.possibleElementsIds[xpath5] = '';
        }
      }
    } catch (err) {}
  };

  //Merge JSON
  this.mergeJSON = function(pData, nData) {
    Object.entries(nData).forEach(function([key, value]) {
      pData[key] = value;
    });

    //TODO: this is broken. this.limitObject doesn't return anything
    //pData = this.limitObject(pData);

    return pData;
  };

  //Add Extra Fields for meta data
  this.addExtraAttributes = function(e, elementData) {
    switch (elementData['type']) {
      case 'checkbox':
      case 'radio':
        elementData['checked'] = e.target.checked;
        break;
    }
    return elementData;
  };

  this.addElementPossibleElements = function(e, listner) {
    try {
      var timeDiff = 50;
      if (!window.WS.on) return;
      if (listner == 'click') {
        var limit = 10;
        var start = 0;
        var cTarget = e.target;
        var done = false;

        var eventdata = window.WU.getEventElements('mouseover');
        var functionizeElementIds = [];
        while (!done) {
          var functionizeElementId = cTarget.attr('data-functionize-id');

          if (typeof functionizeElementId !== 'undefined' && functionizeElementId !== false) {
            var meta = window.WS.generateMetaDataFromMutationStorage(functionizeElementId);

            var mutationEvents = meta.mutationEvents;
            var mutationEventsCount = Object.keys(mutationEvents).length;

            if (mutationEventsCount > 1) {
              var keys = [];
              for (let i in mutationEvents) {
                keys.push(i);
              }
              keys.reverse();
              var mutationEventsReverse = {};
              for (var i = 0; i < keys.length; i++) {
                var mutationEventTime = parseInt(keys[i]);

                var mutationEventTimeEx = mutationEventTime - timeDiff;

                Object.values(eventdata).forEach(function(value) {
                  if (typeof value.element !== 'undefined' && value.element && typeof value.time !== 'undefined' && value.time) {
                    if (mutationEventTimeEx <= parseFloat(value.time) && mutationEventTime >= parseFloat(value.time)) {
                      functionizeElementIds.push(value.element);
                      done = true;
                    }
                  }
                });
              }
            }
          }
          cTarget = cTarget.parent();
          if (cTarget.length == 0) {
            done = true;
          }
          start++;
        }
        window.fconsole.log('taregtting element on possible elements...');
        var elementData = this.targetElementCache(e.target);

        var xpath5 = elementData.xpath5;
        if (typeof this.possibleElementsIds[xpath5] == 'undefined') {
          // && this.elementPreviousState[xpath5])
          this.possibleElementsIds[xpath5] = functionizeElementIds;
        } else {
          this.possibleElementsIds[xpath5] = this.mergeJSON(this.possibleElementsIds[xpath5], functionizeElementIds);
        }
      }
    } catch (err) {
      //alert("6 - "+err.message);
    }
  };
  this.prepareMetaDataForLastAction = function(e, listner, elementData) {
    try {
      if (window.WS.disableExtendedData) return;
      if (!window.WS.on) return;
      if (!window.WS.shiftDown) {
        this.addElementPreviousState(e, listner);
        this.addElementPostState(e, listner, elementData);
        this.addElementPossibleElements(e, listner);
        this.addElementRelatedAjaxCalls(e, listner);
        this.addElementOldMutation(e, listner, elementData);
      }
    } catch (err) {
      //alert("13 - "+err.message);
    }
  };
  this.waitAndUpdateAction = function(actionData) {
    try {
      if (window.WS.disableExtendedData) return;
      this.addClickAjaxCalls(actionData);
      this.addClickMutation(actionData);
      this.addElementOldMutation('', actionData.action, actionData);

      this.addElementHistory(actionData);
    } catch (err) {
      //alert("12 - "+err.message);
    }
  };
  this.addClickMutation = function(actionData) {
    var selfObj = this;
    var affectedElements = {};
    try {
      if (actionData.action == 'click') {
        setTimeout(function() {
          if (typeof window.functionizeElementMutationStorage != 'undefined') {
            Object.keys(window.functionizeElementMutationStorage).forEach(function(index) {
              var value = window.functionizeElementMutationStorage[index];
              var mutationEvents = value.mutationEvents;
              var mutationEventsCount = Object.keys(mutationEvents).length;
              if (mutationEventsCount > 1) {
                var keys = Object.keys(mutationEvents);
                keys.reverse();

                var mutationEventsReverse = {};
                keys.forEach(function(key, i) {
                  var mutationEventTime = parseInt(key);

                  if (parseInt(actionData.epoch) < mutationEventTime) {
                    console.log('targetting element on click mutation');

                    var elementData = selfObj.targetElementCache(document.querySelector('[data-functionize-id="' + index + '"]'));
                    var actionDataSelectorType = selfObj.getSelectorType(elementData);

                    if (typeof elementData[actionDataSelectorType] !== 'undefined' && elementData[actionDataSelectorType]) {
                      if (typeof affectedElements[elementData[actionDataSelectorType]] === 'undefined') {
                        affectedElements[elementData[actionDataSelectorType]] = elementData;
                      } else {
                        // This part seems to be empty in your original code
                      }

                      var mutationEventTimeOld = null;
                      if (typeof affectedElements[elementData[actionDataSelectorType]]['changeset'] === 'undefined') {
                        affectedElements[elementData[actionDataSelectorType]]['changeset'] = mutationEvents[mutationEventTime];
                        affectedElements[elementData[actionDataSelectorType]]['changeset_timestamp'] = mutationEventTime;

                        try {
                          mutationEventTimeOld = parseInt(keys[i + 1]);
                          affectedElements[elementData[actionDataSelectorType]]['changeset_old'] = mutationEvents[mutationEventTimeOld];
                        } catch (err) {
                          // Handle error if needed
                        }
                      } else {
                        affectedElements[elementData[actionDataSelectorType]]['changeset'] = selfObj.mergeJSON(
                          affectedElements[elementData[actionDataSelectorType]]['changeset'],
                          mutationEvents[mutationEventTime]
                        );

                        try {
                          mutationEventTimeOld = parseInt(keys[i + 1]);
                          affectedElements[elementData[actionDataSelectorType]]['changeset_old'] = selfObj.mergeJSON(
                            affectedElements[elementData[actionDataSelectorType]]['changeset_old'],
                            mutationEvents[mutationEventTimeOld]
                          );
                        } catch (err) {
                          // Handle error if needed
                        }
                      }
                    }
                  }
                });
              }
            });
            if (Object.keys(affectedElements).length) {
              selfObj.addMetadata('affectedElements', '', affectedElements, window.WS.getActionIndexByActionId(actionData.actionId) + 1);
            }
          }
        }, 200);
      }
    } catch (err) {}
  };
  this.addClickAjaxCallsForAjaxPageVariables = function(windowVariables) {
    var selfObj = this;
    var ajaxLogRequests = {};
    var actionData = window.AMD.actionDataForAjax;
    var actionDataSelectorType = this.getSelectorType(actionData);

    try {
      if (typeof windowVariables != 'undefined') {
        var functionizeAjaxLogRequest = windowVariables;

        var cTime = new Date().getTime();
        Object.entries(functionizeAjaxLogRequest).forEach(function([index, value]) {
          if (parseInt(actionData.epoch) < parseInt(value)) {
            try {
              if (typeof ajaxLogRequests[actionData[actionDataSelectorType]] === 'undefined') {
                ajaxLogRequests[actionData[actionDataSelectorType]] = {};
              }
              ajaxLogRequests[actionData[actionDataSelectorType]]['ajax_url'] = index;
              ajaxLogRequests[actionData[actionDataSelectorType]]['ajax_url_ts'] = value;
            } catch (err) {
              // Handle error if needed
            }
          }
        });
        if (Object.keys(ajaxLogRequests).length) {
          selfObj.addMetadata('ajaxActionData', '', ajaxLogRequests, window.WS.getActionIndexByActionId(actionData.actionId) + 1);
        }
      }
    } catch (err) {}
  };
  this.addClickAjaxCalls = function(actionData) {
    if (actionData.action == 'click') {
      setTimeout(function() {
        window.AMD.actionDataForAjax = actionData;
        window.postMessage({ call: 'getPageAjaxVariablesForMutation' }, '*');
      }, 200);
    }
  };
  this.addElementOldMutation = function(e, listner, actoinData) {
    try {
      var WSRecordedDataForPreviousAction = null;
      var WSRecordedDataForCurrentAction = null;
      if (listner == 'select') {
        if (typeof this.elementfocusData[actoinData.xpath5] != 'undefined' && this.elementfocusData[actoinData.xpath5] && actoinData.action == 'select') {
          WSRecordedDataForPreviousAction = this.getUseableData(this.elementfocusData[actoinData.xpath5]);
          WSRecordedDataForCurrentAction = this.getUseableData(actoinData);
          this.addMetadata('preActionData', '', WSRecordedDataForPreviousAction, window.WS.getActionIndexByActionId(actoinData.actionId) + 1);
          this.addMetadata('postActionData', '', WSRecordedDataForCurrentAction, window.WS.getActionIndexByActionId(actoinData.actionId) + 1);

          this.elementfocusData[actoinData.xpath5] = '';
        }
      }

      if (listner == 'blur') {
        var WSRecordedData = window.WS.recordedData;
        var position = WSRecordedData.length;

        if (position > 2) {
          WSRecordedDataForCurrentAction = window.WS.recordedData[position - 1];
          WSRecordedDataForPreviousAction = window.WS.recordedData[position - 2];

          if (
            WSRecordedDataForCurrentAction.xpath5 == WSRecordedDataForPreviousAction.xpath5 &&
            WSRecordedDataForCurrentAction.type != 'checkbox' &&
            WSRecordedDataForCurrentAction.type != 'radio' &&
            (WSRecordedDataForCurrentAction.element == 'input' || WSRecordedDataForCurrentAction.element == 'textarea' || WSRecordedDataForCurrentAction.element == 'select') &&
            WSRecordedDataForCurrentAction.action != 'click'
          ) {
            WSRecordedDataForPreviousAction = this.getUseableData(WSRecordedDataForPreviousAction);
            WSRecordedDataForCurrentAction = this.getUseableData(WSRecordedDataForCurrentAction);
            this.addMetadata('preActionData', '', WSRecordedDataForPreviousAction, position);
            this.addMetadata('postActionData', '', WSRecordedDataForCurrentAction, position);
          } else if (
            typeof this.elementfocusData[WSRecordedDataForCurrentAction.xpath5] != 'undefined' &&
            this.elementfocusData[WSRecordedDataForCurrentAction.xpath5] &&
            WSRecordedDataForCurrentAction.type != 'checkbox' &&
            WSRecordedDataForCurrentAction.type != 'radio' &&
            (WSRecordedDataForCurrentAction.element == 'input' || WSRecordedDataForCurrentAction.element == 'textarea' || WSRecordedDataForCurrentAction.element == 'select') &&
            WSRecordedDataForCurrentAction.action != 'click'
          ) {
            WSRecordedDataForPreviousAction = this.getUseableData(this.elementfocusData[WSRecordedDataForCurrentAction.xpath5]);
            WSRecordedDataForCurrentAction = this.getUseableData(WSRecordedDataForCurrentAction);
            this.addMetadata('preActionData', '', WSRecordedDataForPreviousAction, position);
            this.addMetadata('postActionData', '', WSRecordedDataForCurrentAction, position);

            this.elementfocusData[WSRecordedDataForCurrentAction.xpath5] = '';
          }

          if (typeof this.elementfocusData[WSRecordedDataForCurrentAction.xpath5] != 'undefined') this.elementfocusData[WSRecordedDataForCurrentAction.xpath5] = '';
        }
      }
    } catch (err) {
      //alert("11 - "+err.message);
    }
  };
  this.addElementHistory = function(actoinData) {
    try {
      var WSRecordedData = window.WS.recordedData;
      var position = WSRecordedData.length;

      if (position > 2) {
        var elementHistory = {};
        var actionDataSelectorType = this.getSelectorType(actoinData);

        var actoinDataSelector = actoinData[actionDataSelectorType];

        var actionDataCssSelector = window.WS.xPathToCss(actoinDataSelector);

        var element = document.querySelector(actionDataCssSelector);

        var dataFunctionizeId = element ? element.getAttribute('data-functionize-id') : null;

        if (typeof window.functionizeElementMutationStorage != 'undefined') {
          if (typeof window.functionizeElementMutationStorage[dataFunctionizeId]['mutationEvents'] != 'undefined') {
            elementHistory = window.functionizeElementMutationStorage[dataFunctionizeId]['mutationEvents'];

            var mutationEventsKeys = Object.keys(window.functionizeElementMutationStorage[dataFunctionizeId]['mutationEvents']);
            var mutationEventsCount = mutationEventsKeys.length;

            if (mutationEventsCount >= 1) {
              elementHistory['changeset'] = window.functionizeElementMutationStorage[dataFunctionizeId]['mutationEvents'][mutationEventsKeys[0]];
            }
          }

          if (elementHistory) {
            this.addMetadata('elementHistory', '', elementHistory, window.WS.getActionIndexByActionId(actoinData.actionId) + 1);
          }
        }
      }
    } catch (err) {}
  };
  this.getUseableData = function(elementRawData) {
    var returnData = {};
    Object.entries(elementRawData).forEach(function([index, value]) {
      if (['element', 'type', 'text', 'value', 'x', 'y', 'width', 'height'].includes(index)) {
        returnData[index] = value;
      }
      if (index.includes('xpath') || index.includes('cssSelector') || index.includes('uniqueSelectors') || index.includes('secondarySelectors')) {
        returnData[index] = value;
      }
    });
    return returnData;
  };
  this.targetElementCache = function(e) {
    try {
      var element = e;
      var functionizeElementId = element.getAttribute('data-functionize-id');
      if (!functionizeElementId) {
        functionizeElementId = window.WU.randomString(10);
        element.setAttribute('data-functionize-id', functionizeElementId);
      }
      if (typeof this.targetElementCachesData[functionizeElementId] == 'undefined' || !this.targetElementCachesData[functionizeElementId]) {
        this.targetElementCachesData[functionizeElementId] = window.WS.targetElement(e);
      }

      // this.limitObject never returns objectData.
      //selfObj.targetElementCachesData = selfObj.limitObject(selfObj.targetElementCachesData);

      return this.getUseableData(this.targetElementCachesData[functionizeElementId]);
    } catch (err) {
      console.log(err);
    }
  };
  this.getSelectorType = function(actionData) {
    var returnSelectorType = '';
    var selectors = ['xpath', 'xpath2', 'xpath3', 'xpath4', 'xpath5', 'cssSelector', 'cssSelector2', 'uniqueSelectors', 'uniqueSelectorsMulti', 'secondarySelectors'];
    selectors.some(function(value) {
      if (typeof actionData[value] !== 'undefined' && actionData[value]) {
        returnSelectorType = value;
        return true; // Stop iteration
      }
      return false; // Continue iteration
    });
    return returnSelectorType;
  };
  //TODO: fix this because it's broken. It doesn't return anything and all data passed through becomes undefined.
  this.limitObject = function(objectData) {
    var arrLimit = 30;
    if (Object.keys(objectData).length > arrLimit) {
      var isDeleted = false;
      for (var index in objectData) {
        if (objectData.hasOwnProperty(index)) {
          if (isDeleted) {
            break; // Stop iteration
          }
          delete objectData[index];
          isDeleted = true;
        }
      }
    }
  };
}

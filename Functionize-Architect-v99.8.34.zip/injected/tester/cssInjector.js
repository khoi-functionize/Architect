export function injectCSS(cssFile) {
  if (typeof window.chromePort != 'undefined') {
    let command = {
      call: 'injectCSS',
      file: cssFile,
    };
    window.chromePort.postMessage(command);
  }
}

export function injectCSSVariables() {
  if (typeof window.chromePort != 'undefined') {
    let command = {
      call: 'injectCSSVars',
    };
    window.chromePort.postMessage(command);
  }
}

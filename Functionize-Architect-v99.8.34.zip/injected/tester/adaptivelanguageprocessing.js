export class AdaptiveLanguageProcessing {
  constructor() {
    window.ALP = this;
    /** Establish if the correctionEnabled mode is set or not */
    this.correctionEnabled = false;
    this.alp = false;
  }

  setALP(state) {
    this.alp = state;
    if (window.TCM.isMaster) {
      this.sendCallToDescendants('setALP', state);
    }
  }

  toggleALPCorrectionMode() {
    return (this.correctionEnabled = !this.correctionEnabled);
  }

  clear() {
    window.WS.removeHighlights();
    window.TH.clearAll();
    window.WU.fShowAllElements();
  }

  triggerALPResponse(results) {
    if (results && results.length) {
      var action = results[0].action;
      var data = results[0].data;
      var firstResult = results[0];
      var element = this.getElement(firstResult);
      if (element) {
        console.log(element);
        this.scrollTo(element);
        element.classList.add('z-highlighted');
        this.performAction(action, element, data);
      }
      results.shift();
      results.forEach(result => {
        var element = this.getElement(result);
        if (element) {
          element.classList.add('z-highlighted');
        }
      });
    }
    return results;
  }

  getElement(result) {
    if (result.id) {
      return document.getElementById(result.id);
    } else {
      return document.elementFromPoint(result.left + 1, result.top + 1);
    }
  }

  /**
   * Trigger an animation to scroll to element.
   * @param {HTMLElment} element
   */
  scrollTo(element) {
    if (element && element.offsetTop) {
      window.scroll({
        behavior: 'smooth',
        left: 0,
        top: element.offsetTop,
      });
    }
  }

  /**
   * Trigger an event over an HTMLElement.
   * @param {string} action
   * @param {HTMLElement} element
   * @param {string} input
   */
  performAction(action, element, input = '') {
    if (element) {
      switch (action) {
        case 'click':
          {
            this.click(element);
          }
          break;
        case 'select':
          {
            this.click(element);
          }
          break;
        case 'input':
          {
            this.input(element, input);
          }
          break;
        case 'enter':
          {
            this.input(element, input);
          }
          break;
        case 'type':
          {
            this.input(element, input);
          }
          break;
        default:
          break;
      }
    }
  }

  /**
   * Perform a click in a element.
   * @param {HTMLElement} element
   */
  click(element) {
    // FIXME: Remove timeout after demo.
    setTimeout(() => {
      element.click();
    }, 3000);
  }

  /**
   * Perform a click in a element.
   * @param {HTMLElement} element
   * @param {string} input
   */
  input(element, data) {
    switch (element.tagName.toLowerCase()) {
      case 'input':
        element.value += data;
        break;
      case 'textarea':
        element.value += data;
        break;
      default:
        if (element.isContentEditable) {
          element.innerHTML = data;
        }
        break;
    }
    element.focus();
  }

  /**
   * Gets the route to make the call then trigger that call.
   */
  sendPredictRequest(data) {
    if (data.phrase && data.phrase.length) {
      this.apiCall(
        data.url,
        {
          url: data.documentURL,
          phrase: data.phrase,
          top_k: data.top_k,
          html: document.documentElement.outerHTML,
          uniqueAttr: data.uniqueAttr,
        },
        data.actionId
      );
    }
  }

  /**
   * Send a Ajax request.
   * @param {string} url Full url to request.
   * @param {object} data Object with the data
   */
  apiCall(url, data, actionId) {
    console.log(url, JSON.stringify(data));
    const xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-type', 'application/json');
    xhr.onreadystatechange = () => {
      if (xhr.readyState == 4) {
        try {
          const results = JSON.parse(xhr.responseText);
          console.log('results', results);
          if (actionId) {
            if (this.alp) {
              this.triggerALPResponse(results);
            }
            self.port.emit('message', {
              obj: 'f-vue',
              call: 'processALPResponse',
              arguments: {
                results: results,
                actionId: actionId,
              },
              forMaster: true,
            });
          }
        } catch (error) {
          console.error(xhr.responseText);
          console.error(error);
        }
      }
    };
    xhr.send(JSON.stringify(data));
  }

  sendCallToDescendants(method, param, meta) {
    window.fconsole.log('Send Descendants call ' + method + ' ' + window.WU.stringify(param));
    var command = { obj: 'ALP', call: method, arguments: param };
    if (typeof meta != 'undefined') command.meta = meta;
    this.sendCommandToDescendants(command);
  }

  sendCommandToDescendants(command) {
    window.fconsole.log('Send Command to Descendants ' + command.call);
    if (typeof self != 'undefined' && self.port != 'undefined') {
      window.fconsole.log('Sending relay to child: ' + command.call);
      self.port.emit('relay', command);
      return;
    }
  }
}

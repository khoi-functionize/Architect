import { _functionizeEvaluator_ } from './variablesemanager';
import { TestCaseManager } from './testcasemanager';
import { AdaptiveLanguageProcessing } from './adaptivelanguageprocessing';
import { actionmetadata } from './actionmetadata';
import { WebionageSender } from './webionagesender';
import { functioniseStyles, functioniseCss } from '../modeler/common';

export function initTester() {
  console.log('initTester');
  if (window.functionisePreinitReady || window.initTesterAdded) return;
  window.initTesterAdded = true;

  // this will authenticate the session we have
  if (window.functionisePreinitReady) {
    // if loaded traditionally we call preInit right away.  From the plugin this gets called directly
    preInitFunctionise();
  }
}

export function preInitFunctionise() {
  window.TCM = new TestCaseManager();
  window._functionizeEvaluator_ = new _functionizeEvaluator_();
  window.ALP = new AdaptiveLanguageProcessing();
  window.TCM.debug = true;
  // authenticate this session??
  var session = window.WU.storeAndCookie('functioniseSession');
  window.TCM.session = session;
  if (typeof window.TCM.session == 'undefined') window.TCM.session = window.functioniseSession;

  initFunctionise();

  console.log('preInitFunctionise functionisePluginSettings');

  if (typeof window.functionisePluginSettings != 'undefined' && typeof window.functionisePluginSettings.actionLimit != 'undefined')
    window.WS.actionLimit = parseInt(window.functionisePluginSettings.actionLimit);

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.nlp_live != 'undefined'
  )
    window.WS.nlp_live = window.functionisePluginSettings.recorderSettings.nlp_live;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.userId != 'undefined'
  )
    window.WS.userId = window.functionisePluginSettings.recorderSettings.userId;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.teamId != 'undefined'
  )
    window.WS.teamId = window.functionisePluginSettings.recorderSettings.teamId;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.recorderLiteVersion != 'undefined'
  )
    window.WS.recorderLiteVersion = window.functionisePluginSettings.recorderSettings.recorderLiteVersion;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.recorderTurkVersion != 'undefined'
  )
    window.WS.recorderTurkVersion = window.functionisePluginSettings.recorderSettings.recorderTurkVersion;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.do_not_use_css_offset != 'undefined'
  )
    window.WS.do_not_use_css_offset = window.functionisePluginSettings.recorderSettings.do_not_use_css_offset;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.enable_ad_tracking != 'undefined'
  )
    window.WS.enable_ad_tracking = window.functionisePluginSettings.recorderSettings.enable_ad_tracking;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.start_url != 'undefined'
  )
    window.WS.start_url = window.functionisePluginSettings.recorderSettings.start_url;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.start_recording_automatically != 'undefined'
  )
    window.WS.start_recording_automatically = window.functionisePluginSettings.recorderSettings.start_recording_automatically;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.disable_data_functionize_disabled_element_flag != 'undefined'
  )
    window.WS.disable_data_functionize_disabled_element_flag = window.functionisePluginSettings.recorderSettings.disable_data_functionize_disabled_element_flag;

  if (typeof window.functionisePluginSettings != 'undefined' && typeof window.functionisePluginSettings.recorderSettings != 'undefined') {
    for (var set in window.functionisePluginSettings.recorderSettings) window.WS.setSettings(set, window.functionisePluginSettings.recorderSettings[set], false);
  }

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.captureCompleteUrl != 'undefined'
  )
    window.WS.captureCompleteUrl = window.functionisePluginSettings.recorderSettings.captureCompleteUrl;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.liveEditPlanStep != 'undefined'
  )
    window.WS.liveEditPlanStep = window.functionisePluginSettings.recorderSettings.liveEditPlanStep;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.disableIframeCapture != 'undefined'
  )
    window.WS.disableIframeCapture = window.functionisePluginSettings.recorderSettings.disableIframeCapture;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.limitDataCapture != 'undefined'
  )
    window.WS.limitDataCapture = window.functionisePluginSettings.recorderSettings.limitDataCapture;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.disableExtendedData != 'undefined'
  )
    window.WS.disableExtendedData = window.functionisePluginSettings.recorderSettings.disableExtendedData;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.keep_recorder_on_top != 'undefined'
  )
    window.WS.keep_recorder_on_top = window.functionisePluginSettings.recorderSettings.keep_recorder_on_top;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.enable_browser_navigation_buttons != 'undefined'
  )
    window.WS.enable_browser_navigation_buttons = window.functionisePluginSettings.recorderSettings.enable_browser_navigation_buttons;

  try {
    if (
      typeof window.functionisePluginSettings != 'undefined' &&
      typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
      typeof window.functionisePluginSettings.recorderSettings.testing_urls != 'undefined'
    )
      window.WS.testing_urls = window.functionisePluginSettings.recorderSettings.testing_urls;
  } catch (e) {}

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.test_job_id != 'undefined'
  )
    window.WS.testJobId = window.functionisePluginSettings.recorderSettings.test_job_id;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.mturk_worker_id != 'undefined'
  )
    window.WS.mturkWorkerId = window.functionisePluginSettings.recorderSettings.mturk_worker_id;

  if (
    typeof window.functionisePluginSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings != 'undefined' &&
    typeof window.functionisePluginSettings.recorderSettings.device_data != 'undefined'
  )
    window.WS.deviceData = window.functionisePluginSettings.recorderSettings.device_data;
}

export function initFunctionise() {
  console.log('initFunctionise called');
  window.AMD = new actionmetadata();
  // window.TH = new tooltipHelper();
  window.WS = new WebionageSender();
  window.WS.init();
  window.WS.preinitInput();
  window.ZStyles = new functioniseStyles();
  window.ZDealCss = new functioniseCss();
  window.fconsole.log('Initing functionise3…');
  if (window.functioniseJsErrors != '') {
    // page init js errors
    window.WS.showJsError(window.functioniseJsErrors);
    if (window.canAddHTML) {
      var body = document.querySelector('body');
      body.setAttribute('functionisejserror', window.functioniseJsErrors);
    }
    window.functioniseJsErrors = '';
  }

  // reg mutation observer on desktop version
  if (!window.functioniseApp) functioniseMutationObserve();

  // re bind this function directly to the attr
  window.onerror = function (msg) {
    var curMsg = '';
    var body = document.querySelector('body');
    var currentFunctioniseJserror = body.getAttribute('functionisejserror');

    // Check if the attribute exists and update curMsg
    if (currentFunctioniseJserror !== null) {
      curMsg = '|' + currentFunctioniseJserror;
    }

    // Update the attribute if canAddHTML is true
    if (window.canAddHTML) {
      body.setAttribute('functionisejserror', msg + curMsg);
    }

    window.WS.showJsError(
      'Functionize detected the following script error: \n\n' +
        msg +
        '\n\nPlease try to correct front end script issues before completing a recording as it can effect Functionize as well.  Thank you.'
    );
  };

  // return on incompatible browsers…
  // TO DO ********MORE BROWSER checking here…
  if (!window.isFunctioniseCompatible) {
    window.TCM.removeCoverer(); // just to be sure
    return;
  }

  // Below code determins window type and role
  console.log(window.opener, self == top, window.name, window.functioniseControlEnabled, window.isPopup);
  if ((window.opener != null && self == top && window.name != 'FTestWindow') || (window.name.indexOf('Functionise') > -1 && !window.functioniseControlEnabled) || window.isPopup) {
    // popup window
    // now we try to access the opener to see what if we have access
    var namep = window.name.trim().split(' ');
    var name = window.name.trim();
    if (namep.length > 1) {
      for (let i = 0; i < namep.length; i++) {
        if (namep[i].indexOf('Functionise') > -1) name = namep[i].replace('Functionise', '');
      }
    } else {
      name = name.replace('Functionise', '');
    }
    window.WS.popupUID = name;
    // we will be getting this passed back to us
    window.WS.isPopup = true;

    if (window.isPopup && window.popupUID) {
      // chrome version here...
      window.WS.popupUID = window.popupUID;
    }

    let command = {
      obj: 'TCM',
      call: 'requestRegistration',
      arguments: {
        UID: window.WS.popupUID,
        windowType: 'popup',
      },
      meta: {
        fromUID: window.WS.popupUID,
        windowWidth: window.innerWidth,
        windowHeight: window.innerHeight,
        scrollLeft: window.scrollX,
        scrollTop: window.scrollY,
      },
    };

    // set registration send call to true;
    window.TCM.hasSentRegistration = true;

    // window.TCM.sendCommand(command,window.opener);

    console.log('requestRegistration from here', command);
    self.port.emit('relay', command);
  } else if (((window.opener != null && window == top && window.name != 'FTestWindow') || window == top) && !window.functioniseControlEnabled) {
    // main win but no control is allowed from the plugin
    // framesets -- we can ignore most of the time...
    return;
  } else if ((window.opener != null && self == top && window.name != 'FTestWindow') || self == top) {
    console.log('requestRegistration this is where we need to be');
    // top window or F Tester Window found we assume a recorder
    // set registration send call to true;
    window.TCM.hasSentRegistration = true;
    window.TCM.addMaster();
    // window.TCM.isController = true; // we are at the top of the chain
  } else {
    // this has to be an iframe
    if (window.functioniseControlEnabled) {
      // this only works in content scripts from plugin
      // this has floating window
      // we'll get the start call from the plugin….
      window.TCM.addMaster();
    } else {
      // this is iframe...
      window.WS.iframeUID = window.iframeUID; // we are getting this from the plugin now...
      window.WS.isIframe = true;

      var generateQuerySelector = function (el) {
        if (el.tagName.toLowerCase() == 'html') return 'HTML';
        var str = el.tagName;
        str += el.id != '' && el.id.indexOf(':') === -1 ? '#' + el.id : '';
        if (el.className) {
          var classes = el.className.split(/\s/);
          for (var i = 0; i < classes.length; i++) {
            if (classes[i].indexOf('.') === -1 && classes[i] !== '' && /^\d/.test(classes[i]) === false && classes[i].indexOf(':') === -1) {
              str += '.' + classes[i];
            }
          }
        }
        return generateQuerySelector(el.parentNode) + ' > ' + str;
      };
      // TODO -- why is the call not in window.TCM??
      var frameName = '';
      var frameId = '';
      var frameHash = '';
      var frameURL = document.URL;
      var frameSelector = '';
      var frameTitle = document?.head ? document.head.getAttribute('title') : document.title || '';
      try {
        // this can throw errors on cross domain calls...  We can set CORS headers if we need to override this
        if (window.frameElement) {
          try {
            frameName = window.frameElement.getAttribute('name');
            frameId = window.frameElement.getAttribute('id');
            frameTitle = window.frameElement.getAttribute('title');
          } catch (e) {}

          try {
            frameSelector = generateQuerySelector(window.frameElement);
          } catch (e) {}
          /*
          try {
            document.querySelector(frameSelector);
          } catch (e) {
            console.error('Iframe selector is not valid', e);
          }

 */
        }
      } catch (e) {
        console.error('Frame attr err:' + e.message);
      }
      try {
        // this can throw errors on cross domain calls...  We can set CORS headers if we need to override this
        frameHash = window.location.hash;
      } catch (e) {}
      // we add frameName and frameURL
      if (window.name != '') frameName = window.name;

      let command = {
        obj: 'TCM',
        call: 'requestRegistration',
        arguments: { UID: window.WS.iframeUID, windowType: 'iframe' },
        meta: {
          UID: window.parentUID,
          fromUID: window.WS.iframeUID,
          windowWidth: window.innerWidth,
          windowHeight: window.innerHeight,
          scrollLeft: window.scrollX,
          scrollTop: window.scrollY,
          frameName: frameName,
          frameURL: frameURL,
          frameHash: frameHash,
          frameId: frameId,
          frameSelector: frameSelector,
          frameTitle: frameTitle,
        },
      };

      window.TCM.registrationCommand = command;
      window.TCM.hasSentRegistration = false;

      // WHY WAS THIS MOVED???
      window.TCM.hasSentRegistration = true;
      // moving this down to the iframe mouse move listener
      if (typeof self != 'undefined' && self.port != 'undefined') {
        window.console.log('Sending relay to plugin: ' + command.call + ' parent: ' + window.parentUID);
        self.port.emit('relay', command);
      } else {
        window.TCM.sendCommand(command, window.parent);
      }
    }
  }
  // TO DO timer to remove coverer in case no callback is received
  // now we run queued messages we got before we were ready
  for (let i = 0; i < window.functionisePreInitMessages.length; i++) {
    window.console.log('Evaluating pre init messages');
    window.functioniseMessageListener(window.functionisePreInitMessages[i]);
  }
}

// This gets called upon registration received
// parent or control window will call this when....
export function registered(data) {
  console.log('registered', data);
  if (window.TCM.isRegistered) {
    window.fconsole.log('window.TCM already registered', data);
    return;
  }

  window.fconsole.log('Registered has been called', data);
  if (typeof data != 'undefined' && typeof data.isController != 'undefined') {
    window.TCM.isController = data.isController;

    window.fconsole.log('Registered as controller: ' + data.isController);
    if (typeof data.isMaster != 'undefined') {
      window.TCM.isMaster = data.isMaster;
      window.fconsole.log('Registered as master: ' + data.isMaster);
    }
  }

  if (typeof data.path != 'undefined') window.WS.path = data.path;

  // we get this call if we are valid and are set to go…
  window.TCM.isRegistered = true;
  if (window.TCM.isController && window.WS.doRecording > 0) {
    // set appropriate cookies in case we have a domain change
    window.WU.cookie('functioniseTesting', 'on');
    window.WU.cookie('functionise', 'true');
  }

  window.fconsole.log('Registration succeeded for page at : ' + document.URL + ' ' + window.WS.on + ' ' + window.WS.doRecording);
  // mark cookie that this person has recording access for fake window

  window.WU.store('hasFunctionise', true);
  // get current url

  window.WS.locUrl = document.location.href;

  // take out anchors as we do not need them
  // var ancor = window.WS.locUrl.lastIndexOf('#');
  // if (ancor != -1 && !window.WS.captureCompleteUrl) window.WS.locUrl = window.WS.locUrl.substr(0, ancor);

  if (window.WU.storeAndCookie('functioniseDemo') == 'true') window.WS.isDemo = true;

  var isSubWindow = true;
  if (window.WS.on && window.WS.doRecording > 0) {
    window.fconsole.log('Recording is on.');
    // we call it start with a different param if the recording has already started to retain the session
    isSubWindow = window.WS.isIframe;
    if (!window.WS.isIframe) isSubWindow = window.WS.isPopup;

    window.TCM.init(window.WS.startTestRunning, window.WS.stopTest, isSubWindow);
    window.fze.init();
    window.TCM.setRecording(true);
    // iframes and popups
    // init Page
    setTimeout(() => {
      window.WS.initPage(data);
    }, 200);
    setTimeout(function () {
      window.TCM.removeCoverer();
    }, 350);
  } else if (window.WS.on && (window.TCM.isVerifying || window.WS.collecting)) {
    // do recording is off in this case but bc we are verifying...
    isSubWindow = window.WS.isIframe;
    if (!window.WS.isIframe) isSubWindow = window.WS.isPopup;

    window.TCM.init(window.WS.startTestRunning, window.WS.stopTest, isSubWindow);
    window.fze.init();
    // iframes and popups
    // init Page
    setTimeout(() => {
      window.WS.initPage(data);
    }, 200);
    setTimeout(function () {
      window.TCM.removeCoverer();
    }, 350);
  } else {
    // if (getParameterByName('functioniseDemo') == '1')
    //	window.WS.isDemo = window.sessionStorage.functioniseDemo = true;
    window.fconsole.log('window.TCM init is called…' + window.WS.isIframe + ' ' + window.WS.isPopup);
    isSubWindow = window.WS.isIframe;
    if (!window.WS.isIframe) isSubWindow = window.WS.isPopup;

    window.TCM.init(window.WS.startTest, window.WS.stopTest, isSubWindow);
    window.fze.init();
    if (window.WS.isIframe) {
      // this only happens during recording now...   we run pageinit...
      window.WS.initPage(data);
    }

    setTimeout(function () {
      window.TCM.removeCoverer();
    }, 250);
    if (
      window.WS.recordedData.length < 1 &&
      window.WS.start_recording_automatically &&
      window.functionizeEditMode != 'liveEdit' &&
      window.functionizeEditMode != 'liveEditPageObject'
    ) {
      window.WS.automaticallyStartTest();
      window.functionisePluginSettings.recorderSettings.start_recording_automatically = false;
    }
  }

  // register event handlers

  window.addEventListener('beforeunload', function (event) {
    window.WS.doWbUnload();
  });

  window.addEventListener('unload', function (event) {
    window.fconsole.log('window unload has been called');
    self.port.emit('unload', {});
    window.WS.unload = true;
  });
  if (window.WS.enable_browser_navigation_buttons) {
    window.addEventListener('popstate', function (event) {
      window.WS.checkWindowNavigateState();
    });
  }

  window.addEventListener('resize', function () {
    // TO DO test this
    if (!window.WS.on) return;
    window.WS.disableExternalIframes(); // Disabled third-party iframes -- should not
    window.WS.resized();
  });

  // custom alert
  window.customAlert = function (args) {
    return window.WS.customAlert(args);
  };

  // custom confirm
  window.customConfirm = function (choice, args) {
    return window.WS.customConfirm(choice, args);
  };

  // custom ajax
  window.customAjax = function (method, url, timestamp) {
    // return window.WS.customConfirm(choice,arguments);
    if (!window.WS.on || window.WS.doRecording < 1) return;
    window.WS.evaluateAjaxCall(method, url, timestamp);
  };

  window.fconsole.log('Installed: ' + window.functionizePluginInstalled);

  (function () {
    var proxied = window.confirm;
    window.confirm = function (txt) {
      // do something here
      var choice = null;
      if (typeof proxied.apply == 'function') {
        choice = proxied.apply(this, arguments);
      } else {
        choice = proxied(txt);
      }
      if (window.WS.on) {
        window.WS.customConfirm(choice, arguments);
      }
      return choice;
    };
  })();

  console.log(' window.WS.isIframe', window.WS.isIframe);
  if (document.readyState !== 'complete' && !window.WS.isIframe) {
    console.log('is not ready and is not iframe');
    document.addEventListener('readystatechange', (event) => {
      if (event.target.readyState === 'complete') {
        (async () => {
          let elementStatistics = {};
          let counter = 0;
          while (!window.WS.pageInitId && counter < 30) {
            counter++;
            console.log('waiting...');
            await new Promise((resolve) => setTimeout(resolve, 1000));
          }

          console.log('readyState is not complete - waiting');

          let data = {};

          if (counter === 30) {
            elementStatistics = 'readyState timed out';
          } else {
            console.time('elementStatisticsReadyState');
            elementStatistics = window.WS.collectMlData(
              document.body && document.body.childElementCount > 0 ? document.body : document.children[0],
              'pageinit',
              window.WS.pageInitId
            );
            console.timeEnd('elementStatisticsReadyState');
          }

          if (window.innerHeight !== window.WS.coreData.windowHeight) {
            data.windowHeight = window.innerHeight;
          }
          new Promise((resolve, reject) => {
            window.WS.updateActionByActionId(data, window.WS.pageInitId || 0);
            self.port.emit('message', {
              obj: 'TCM',
              call: 'addMLDataToContextSwitch',
              arguments: { data: { result: elementStatistics, actionId: window.WS.pageInitId || 0, forAction: true } },
              forMaster: true,
            });
            resolve();
          }).then(() => {
            window.WS.initTraverseIframes();
          });
        })();
      }
    });
  } else {
    if (!window.WS.isIframe) {
      (async () => {
        let counter = 0;
        while ((!window.WS.pageInitId || !window.WS.initTraverseIframes) && counter < 30) {
          counter++;
          console.log('waiting...');
          await new Promise((resolve) => setTimeout(resolve, 1000));
        }

        new Promise((resolve, reject) => {
          self.port.emit('message', {
            obj: 'TCM',
            call: 'addMLDataToContextSwitch',
            arguments: {
              data: {
                result:
                  counter < 30
                    ? window.WS.collectMlData(document.body && document.body.childElementCount > 0 ? document.body : document.children[0], 'pageinit', window.WS.pageInitId)
                    : 'readyState timed out',
                actionId: window.WS.pageInitId || 0,
                forAction: true,
              },
            },
            forMaster: true,
          });
          resolve();
        }).then(() => {
          window.WS.initTraverseIframes();
        });
      })();
    }
  }
}

export function setFunctionizeIframeData(el) {
  el.setAttribute('data-functionize-index', window.functionizeIframeIndex);
  var nameAttr = el.getAttribute('name');
  if (typeof nameAttr == 'undefined' || nameAttr == null || !nameAttr || nameAttr == '') el.setAttribute('name', 'data-functionize-index-' + window.functionizeIframeIndex);

  window.functionizeIframeIndex++;
  if (typeof chromePort != 'undefined') {
    // var command = { call: 'iframeAddedEvent' };
    // window.chromePort.postMessage(command);
  }
}

function functioniseMutationObserve() {
  MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
  // create an observer instance
  var observer = new MutationObserver(function (mutations) {
    for (var a = 0; a < mutations.length; a++) {
      var mutation = mutations[a];
      if (mutation == null) return;

      if (typeof mutation.addedNodes != 'undefined') {
        for (var j = 0; j < mutation.addedNodes.length; ++j) {
          if (mutation.addedNodes[j].childNodes.length > 0) {
            for (var k = 0; k < mutation.addedNodes[j].childNodes.length; ++k) {
              if (typeof mutation.addedNodes[j].childNodes[k].tagName != 'undefined' && mutation.addedNodes[j].childNodes[k].tagName.toLowerCase() == 'iframe') {
                setFunctionizeIframeData(mutation.addedNodes[j].childNodes[k]);
              }
            }
          }

          if (typeof mutation.addedNodes[j].tagName != 'undefined' && mutation.addedNodes[j].tagName.toLowerCase() == 'iframe') {
            // TODO: this has never been defined. What is it supposed to do?
            // setFunctionizeData(mutation.addedNodes[j]);

            let node = mutation.addedNodes[j];
            // Set the 'data-functionize-index' attribute
            node.setAttribute('data-functionize-index', window.functionizeIframeIndex);
            // Increment the index
            window.functionizeIframeIndex++;
            // Log the index and outerHTML of the node
            console.log('Set index on iframe: ' + node.getAttribute('data-functionize-index') + ' ' + node.outerHTML);

            // if (typeof window.chromePort != 'undefined') {
            // var command = { call: 'iframeAddedEvent' };
            // window.fconsole.log('Sending chrome message here' + JSON.stringify(command));
            // window.chromePort.postMessage(command);
            // }
          }

          // add added timestamp to the element...
          let node = mutation.addedNodes[j];

          if (node.tagName === undefined) {
            try {
              // Set the attribute on the parent node
              let parentNode = node.parentNode;
              if (parentNode) {
                parentNode.setAttribute('data-functionize-added', new Date().getTime());
              }
            } catch (e) {
              // Handle potential errors
              console.error('Error setting attribute on parent node:', e);
            }
          } else {
            try {
              // Set the attribute on the node itself
              node.setAttribute('data-functionize-added', new Date().getTime());
            } catch (e) {
              // Handle potential errors
              console.error('Error setting attribute on node:', e);
            }
          }
        }
      }
      if (!window.functioniseWindowLoadedEvent) return;

      var mutTime = new Date().getTime();
      if (mutation.type == 'attributes') {
        if (window.WS.isFunctioniseElement(mutation.target)) return;

        if (typeof chromePort != 'undefined') {
          var targetElement = mutation.target;

          // Get the value of the 'data-functionize-id' attribute
          var functionizeElementId = targetElement.getAttribute('data-functionize-id');

          if (functionizeElementId !== null && functionizeElementId !== false) {
            // If the attribute exists and is not false, use its value
            functionizeElementId = targetElement.getAttribute('data-functionize-id');
          } else {
            // Generate a new ID and set it on the element
            functionizeElementId = window.WU.randomString(10);
            targetElement.setAttribute('data-functionize-id', functionizeElementId);
          }

          var styles = new Array();
          try {
            styles = window.getComputedStyle(mutation.target);
          } catch (e) {
            window.fconsole.log(e);
          }
          var cssObjProp;
          var props = new Array('z-index', 'visibility', 'display', 'x', 'y', 'margin-left', 'margin-right', 'top', 'left');
          for (let ii = 0; ii < props; ii++) {
            cssObjProp = props[ii];
            var cssObjPropVal = styles.getPropertyValue(cssObjProp); // styles.item(ii);
            if (typeof cssObjPropVal != 'undefined') {
              if (typeof window.functionizeElementMutationStorage[functionizeElementId] == 'undefined') window.functionizeElementMutationStorage[functionizeElementId] = {};
              var storageObj = window.functionizeElementMutationStorage[functionizeElementId];
              if (typeof storageObj[cssObjProp] == 'undefined') storageObj[cssObjProp] = new Array();

              if (typeof storageObj['mutationEvents'] == 'undefined') storageObj['mutationEvents'] = {};

              var oldStyle = { value: '' };
              if (storageObj[cssObjProp].length > 0) oldStyle = storageObj[cssObjProp][storageObj[cssObjProp].length - 1]; // take the latest value

              var newVal = cssObjPropVal; // styles.getPropertyValue(cssObjProp);
              if (newVal != oldStyle.value) {
                if (typeof storageObj['mutationEvents'][mutTime] == 'undefined') storageObj['mutationEvents'][mutTime] = {};

                storageObj[cssObjProp].push({ value: newVal, timestamp: mutTime });
                storageObj['mutationEvents'][mutTime][cssObjProp] = newVal;
              }
              if (storageObj[cssObjProp].length > 20) {
                // control obj size....
                var oldObj = storageObj[cssObjProp].shift(); // take oldest
                delete storageObj['mutationEvents'][oldObj.timestamp]; // delete related event mutation event.
              }
            }
          }
        }
      }

      if (mutation.type == 'attributes' && mutation.attributeName == 'class') {
        if (window.WS.isFunctioniseElement(mutation.target)) return;
        var newValue = mutation.target.getAttribute('class');
        var oldValue = mutation.oldValue;
        if (mutation.oldValue == null || typeof mutation.oldValue == 'undefined') oldValue = '';
        if (newValue == null || typeof newValue == 'undefined') newValue = '';

        var oldClasses = oldValue.trim().split(' ');
        var newClasses = newValue.trim().split(' ');
        for (var i = newClasses.length - 1; i > -1; i--) {
          var found = false;
          for (var ii = oldClasses.length - 1; ii > -1; ii--) {
            if (newClasses[i] == oldClasses[ii]) {
              found = true;
              oldClasses.splice(ii, 1);
              break;
            }
          }
          if (!found) {
            if (typeof window.WU.hoverClasses == 'undefined') window.WU.hoverClasses = new Array();

            if (window.WU.hoverClasses != '' && window.WU.hoverClasses.indexOf(newClasses[i]) < -1) {
              // window.fconsole.log("Adding new class = " + newClasses[i]);
              window.WU.hoverClasses.push(newClasses[i]);
            }
          }
        }
      }
    }
  });
  // configuration of the observer:
  // var config = { attributes: true, childList: true, characterData: false, subtree: true, attributeOldValue: true };
  // pass in the target node, as well as the observer options
  // it's off now...
  // observer.observe(document, config);
}

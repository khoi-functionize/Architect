import { registered } from './tester';
import { fAdvanceEditor } from '../panel/f.advancededitor';
import { functioniseDocumentReady } from '../modeler/sender';
import { functioniseChangeListener } from '../modeler/listeners/functioniseChangeListener';

///this is version 1
//this is our slave acting as controller or subview TC manager
export function TestCaseManager() {
  window.TCM = this;

  this.maxZIndex = 2147483647;

  //state flags
  this.isEdit = false; //is this an edit of an existing case...
  this.isCachedEdit = false;
  this.isRegistered = false;
  this.recording = false;
  this.isPaused = false;
  this.isVerifying = false;
  this.isScrolling = false;
  this.captureElementScrolls = true;
  this.isHoveringAction = false;
  this.isStopping = false;
  this.editing = false;
  this.isFullscreen = false;
  this.lastKeyDown = null;
  //we default to true now to be sure...
  this.isSubWindow = true; //false;
  this.hasAllowedController = false;
  this.allowedControllerFramePath = '';
  this.initialize = false;
  this.initCalled = false;
  this.debug = false;
  this.liveEdit = false;
  this.isMaster = false;
  this.startTime = 0;
  this.currentZIndex = 10000000;
  this.hasSentRegistration = false;
  this.registrationCommand = null;
  this.requestRegistrationSent = false;
  //timeout is handled in the recorder iframe
  //this.testTimeout = 1*60*60*1000; //timeout is 2 hours

  //button states
  this.startstopEnabled = false;
  this.verifyEnabled = false;
  this.cancelEnabled = false;

  this.highlighted = null;
  this.highlighting = false;

  this.verify = '';
  this.cloudStorage = null;
  this.obj = this;

  this.scripts = new Array();
  this._tcTitle = '';
  this.windowTop = 30; //

  //in case we get calls from frames and we do not have init yet
  this.queuedActionCounter = 0;
  this.advancedEditor = null;
  this.editElementClone = null;
  this.editElement = null;
  //this.channel = new MessageChannel();

  this.checkfunctionisepanel = '';
  this.checkfunctionisepanelcount = 0;

  this.iframe = null;

  this.blankElement = false; //

  //session to auth calls from
  this.session = null;

  //holds swap variables like functionizeapp email
  this.runtimeVariables = {};

  this.resourceData = {};

  //runtime replace strings
  this.runtimeReplacementStrings = [];

  //runtime replace strings
  this.suggestVerificationsInput = [];

  //runtime replace strings
  this.variablePreviousSelection = '';

  //runtime replace strings
  this.flagCVAreaSelection = false;

  //runtime replace strings
  this.flagRelatedElement = false;

  //runtime replace strings
  this.flagshiftclickinput = false;

  this.clickAttributeEditorValue = {};

  this.currentElementForRelated = {};

  //reg requests are queued here
  this.registrationQueue = new Array();

  //call back functions
  this._startCallback = function () {};
  this._stopCallback = function () {};

  this.windowVariables = {};
  this.windowInnerWidth = window.innerWidth;

  this.submitCheckSubmitted = false;
  this.formSubmitSubmitted = false;
  this.simpleFormSubmit = false;
  this.isCSP = false;
  this.isCancelCalled = false;

  this.generatedDataTargetingElement = false;
  this.projectVariableTargetingElement = false;
  this.generatedDataFunction = '';
  this.localGeneratedDataResult = '';
  this.projectVariableValue = '';
  this.projectVariableDisplay = '';
  this.projectVariableLoad_name = '';
  this.projectVariableLoad_attribute = '';
  this.projectVariableLoad_operation = '';
  this.calledAction = null;

  this.modelerIframeHasDraged = false;
  this.modelerIframeLastStyle = '';
  this.isCollapsed = false;
  this.panelOpen = false;
  this.elementTargeting = false;
  this.keyValuesGlobal = [];
  this.searchedPageVariables = {};
  this.searchedPageVariablesKeyword = '';
  window.TCM.domWalkElement = '';
  this.globalStepAttribute = [];
  this.createAttempt = 1;

  this.isLoading = false;

  this.modelerResizeIframe = function (data) {
    if (this.isCollapsed) {
      this.unCollapse();
    }
    var div = document.getElementById('f-functionise-tc-manager');
    var isMobile = this.isMobileAndTablet();
    if (div) {
      if (data.x && data.x !== div.style.width) {
        var bounds = window.WU.zoomBoundingRect(div);
        if (data.x === '700px') {
          this.panelOpen = true;
          window.TCM.sendValueToDescendants('TCM', 'panelOpen', true);
          window.WU.setPauseCoverer();
          window.TCM.ensureVisibility();
          div.style.left = (isMobile ? bounds.left : div.offsetLeft) - (isMobile ? 345 : 340) + 'px';
        } else {
          this.panelOpen = false;
          window.TCM.sendValueToDescendants('TCM', 'panelOpen', false);
          window.WU.removePauseCoverer();
          div.style.left = (isMobile ? bounds.left : div.offsetLeft) + (isMobile ? 80 : 340) + 'px';
        }
        div.style.width = data.x;
      }
      if (data.y) {
        div.style.height = data.y;
      }
      if (!isMobile && parseInt(div.style.top) < 10) {
        div.style.top = '10px';
      }
      if (!isMobile && parseInt(div.style.left) < 10) {
        div.style.left = '10px';
      }
      return { x: div.style.width, y: div.style.height };
    }
  };

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    switch (request.path) {
      case '/functionize/resizeIframe':
        sendResponse(this.modelerResizeIframe(request.data));
        break;
    }
  });

  this.setCalledAction = function (action) {
    window.TCM.calledAction = action;
    if (window.TCM.isMaster) window.TCM.sendValueToDescendants('TCM', 'calledAction', action);
    return action;
  };
  this.emptyCalledAction = function () {
    self.port.emit('message', {
      obj: 'f-vue',
      call: 'setCalledAction',
      arguments: null,
      forMaster: true,
    });
  };
  /**
   * Calls an action by its ID and waits for a response
   * @param {string|number} actionId - The ID of the action to call
   * @returns {Promise<any>} - Resolves with the called action or false if timeout
   */
  this.callActionByActionId = function (actionId) {
    return new Promise(async (resolve) => {
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setCalledAction',
        arguments: actionId,
        forMaster: true,
      });

      // Wait for response with timeout
      const maxAttempts = 5;
      const delayMs = 500;

      for (let attempt = 0; attempt < maxAttempts; attempt++) {
        if (window.TCM.calledAction) {
          return resolve(window.TCM.calledAction);
        }

        // Wait before checking again
        await new Promise((r) => setTimeout(r, delayMs));
      }

      // If we reach here, we've timed out
      resolve(false);
    });
  };
  this.setShiftDown = function (state) {
    self.port.emit('message', {
      obj: 'TCM',
      call: 'setShiftDown',
      arguments: state,
      forMaster: true,
    });
    window.WS.shiftDown = state;
    if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'shiftDown', state);
    return state;
  };
  this.setVisualVerifyDown = function (state) {
    self.port.emit('message', {
      obj: 'TCM',
      call: 'setShiftDown',
      arguments: state,
      forMaster: true,
    });
    window.WS.shiftDown = state;
    window.TCM.sendValueToDescendants('WS', 'shiftDown', state);
    return state;
  };
  /**
   * Refreshes the Functionize event listeners by removing and re-adding them
   */
  this.refreshListeners = function () {
    try {
      window.removeFunctioniseListeners();
    } catch (e) {
      window.fconsole.log('Error removing Functionize listeners: ' + e.message);
    }
    try {
      window.addFunctioniseListeners();
    } catch (e) {
      window.fconsole.log('Error adding Functionize listeners: ' + e.message);
    }
  };
  this.create = function () {
    console.log('tcm create');
    function insertAfter(el, referenceNode) {
      try {
        window.TCM.createAttempt = 1;
        referenceNode.parentNode.insertBefore(el, referenceNode.nextSibling);
      } catch (e) {
        if (window.TCM.createAttempt < 60) {
          window.TCM.createAttempt = window.TCM.createAttempt + 1;
          (async () => {
            console.log('waiting...');
            await new Promise((resolve) => setTimeout(resolve, 1000));
            window.TCM.refreshListeners();
            window.TCM.init();
          })();
        } else {
          console.error('Could not add Architect to this page', e.message);
        }
      }
      window.TCM.createAttempt = 1;
    }

    // keep ARC from restarting if we've cancelled it during live debug
    if (window.WS.runtimeDebugCancel) {
      return;
    }

    // Prevent execute inside iframe
    if (!window.WS.isIframe) {
      // don't recreate the iframe if it's already on the page
      if (document.getElementById('f-functionise-tc-manager')) return;

      (async () => {
        while (typeof window.customElements == 'undefined' || !window.customElements || typeof window.customElements.get !== 'function') {
          console.log('waiting...');
          await new Promise((resolve) => setTimeout(resolve, 100));
        }
        if (typeof window.customElements.get('functionize-architect') === 'undefined') {
          class FunctionizeArchitect extends HTMLElement {
            // eslint-disable-next-line no-useless-constructor
            constructor() {
              super();
            }
            connectedCallback() {
              // Create a shadow root
              const shadow = this.attachShadow({ mode: 'closed' });

              const head = document.createElement('div');
              head.style.cssText =
                'position:static;width:100%;background: transparent;height: 35px;color: #fff;display: flex;justify-content: flex-end;pointer-events: none;font-weight: 300;font-family:"Rubik", sans-serif;';
              head.className = 'f-functionise';

              const headStyle = document.createElement('style');
              headStyle.textContent = `
                .f-functionise-css-rotate-transition-down {
                  transform: rotate(180deg);
                 }
               `;

              head.appendChild(headStyle);

              var container = document.createElement('div');
              container.style.cssText =
                'position:static;box-sizing: border-box;pointer-events: all;cursor: grab;min-width: 360px;width: 360px;height: 100%;background: rgb(56, 47, 78);padding: 0 5px;border-radius: 5px 5px 0 0;display: flex;align-items: center;justify-content: space-between;';

              const logo = document.createElement('div');
              logo.style.cssText = 'display: flex;position: static;';

              logo.innerHTML =
                '<svg xmlns="http://www.w3.org/2000/svg" width="148.026" height="18.526" style="position: relative;"><g data-name="Group 1991"><path style="fill: #fff !important;" data-name="Path 2877" d="M.76,0A.365.365,0,0,1,.494-.114.365.365,0,0,1,.38-.38.765.765,0,0,1,.4-.589L5.111-12.882a.591.591,0,0,1,.608-.418H7.011a.591.591,0,0,1,.608.418L12.312-.589l.038.209a.365.365,0,0,1-.114.266A.365.365,0,0,1,11.97,0H11a.461.461,0,0,1-.323-.1.529.529,0,0,1-.152-.219l-1.045-2.7H3.249L2.2-.323A.5.5,0,0,1,2.043-.1a.469.469,0,0,1-.313.1ZM8.93-4.655,6.365-11.4,3.8-4.655ZM14.82,0a.425.425,0,0,1-.314-.124.425.425,0,0,1-.123-.314V-12.844a.449.449,0,0,1,.123-.332.425.425,0,0,1,.314-.124h4.636a5.2,5.2,0,0,1,3.42,1.026A3.634,3.634,0,0,1,24.111-9.31,3.8,3.8,0,0,1,23.4-6.935a3.68,3.68,0,0,1-2,1.292L24.32-.589a.473.473,0,0,1,.057.209.352.352,0,0,1-.123.266A.4.4,0,0,1,23.978,0h-.912a.683.683,0,0,1-.447-.133,1.256,1.256,0,0,1-.294-.38L19.57-5.339H16.245v4.9a.409.409,0,0,1-.133.314A.457.457,0,0,1,15.789,0Zm4.56-6.954q2.831,0,2.831-2.375T19.38-11.7H16.245v4.75ZM31.6.19A5.131,5.131,0,0,1,27.73-1.178a5.549,5.549,0,0,1-1.416-3.781Q26.3-5.472,26.3-6.631q0-1.178.019-1.71a5.535,5.535,0,0,1,1.425-3.772A5.117,5.117,0,0,1,31.6-13.49a6.279,6.279,0,0,1,2.869.6,4.39,4.39,0,0,1,1.786,1.568,4.255,4.255,0,0,1,.665,2.071v.038a.324.324,0,0,1-.124.257.416.416,0,0,1-.276.1H35.473q-.38,0-.475-.437a3.169,3.169,0,0,0-1.159-2,3.87,3.87,0,0,0-2.242-.58q-3.268,0-3.382,3.629-.019.513-.019,1.577t.019,1.615q.114,3.629,3.382,3.629A3.916,3.916,0,0,0,33.848-2a3.082,3.082,0,0,0,1.149-2,.617.617,0,0,1,.171-.342.46.46,0,0,1,.3-.095h1.045a.441.441,0,0,1,.295.1.3.3,0,0,1,.1.275,4.282,4.282,0,0,1-.665,2.09A4.39,4.39,0,0,1,34.466-.409,6.279,6.279,0,0,1,31.6.19ZM39.9,0a.425.425,0,0,1-.313-.124.425.425,0,0,1-.124-.314V-12.844a.449.449,0,0,1,.124-.332A.425.425,0,0,1,39.9-13.3h.969a.449.449,0,0,1,.332.124.449.449,0,0,1,.124.332V-7.6h6.536v-5.244a.449.449,0,0,1,.123-.332A.425.425,0,0,1,48.3-13.3h.969a.449.449,0,0,1,.333.124.449.449,0,0,1,.124.332V-.437a.409.409,0,0,1-.133.314A.457.457,0,0,1,49.267,0H48.3a.425.425,0,0,1-.313-.124.425.425,0,0,1-.123-.314V-5.89H41.325V-.437a.409.409,0,0,1-.133.314A.457.457,0,0,1,40.869,0ZM53.466,0a.425.425,0,0,1-.313-.124.425.425,0,0,1-.124-.314V-12.863a.425.425,0,0,1,.124-.313.425.425,0,0,1,.313-.124h1.007a.425.425,0,0,1,.313.124.425.425,0,0,1,.124.313V-.437a.425.425,0,0,1-.124.314A.425.425,0,0,1,54.473,0ZM61.56,0a.425.425,0,0,1-.314-.124.425.425,0,0,1-.123-.314V-11.609H57.475a.425.425,0,0,1-.313-.123.425.425,0,0,1-.124-.314v-.8a.457.457,0,0,1,.124-.323.409.409,0,0,1,.313-.133h9.158a.449.449,0,0,1,.332.124.449.449,0,0,1,.123.332v.8a.409.409,0,0,1-.133.314.457.457,0,0,1-.323.123H63V-.437a.409.409,0,0,1-.133.314A.457.457,0,0,1,62.548,0Zm8.094,0a.425.425,0,0,1-.313-.124.425.425,0,0,1-.123-.314V-12.844a.449.449,0,0,1,.123-.332.425.425,0,0,1,.313-.124H77.5a.425.425,0,0,1,.314.124.449.449,0,0,1,.123.332v.722a.444.444,0,0,1-.114.313.418.418,0,0,1-.323.123h-6.46v4.161h6.042A.425.425,0,0,1,77.4-7.4a.449.449,0,0,1,.123.332v.7a.425.425,0,0,1-.123.313.425.425,0,0,1-.314.124H71.041v4.313h6.612a.437.437,0,0,1,.323.114.437.437,0,0,1,.114.323v.741a.425.425,0,0,1-.124.314A.425.425,0,0,1,77.653,0ZM85.386.19a5.131,5.131,0,0,1-3.867-1.368A5.549,5.549,0,0,1,80.1-4.959q-.019-.513-.019-1.672,0-1.178.019-1.71a5.535,5.535,0,0,1,1.425-3.772,5.117,5.117,0,0,1,3.857-1.377,6.279,6.279,0,0,1,2.869.6,4.39,4.39,0,0,1,1.786,1.568,4.255,4.255,0,0,1,.665,2.071v.038a.324.324,0,0,1-.124.257.416.416,0,0,1-.275.1H89.262q-.38,0-.475-.437a3.169,3.169,0,0,0-1.159-2,3.87,3.87,0,0,0-2.242-.58q-3.268,0-3.382,3.629-.019.513-.019,1.577T82-5.054q.114,3.629,3.382,3.629A3.916,3.916,0,0,0,87.637-2a3.082,3.082,0,0,0,1.15-2,.617.617,0,0,1,.171-.342.46.46,0,0,1,.3-.095h1.045a.441.441,0,0,1,.295.1.3.3,0,0,1,.1.275,4.282,4.282,0,0,1-.665,2.09A4.39,4.39,0,0,1,88.255-.409,6.279,6.279,0,0,1,85.386.19ZM96.6,0a.425.425,0,0,1-.313-.124.425.425,0,0,1-.124-.314V-11.609H92.511a.425.425,0,0,1-.313-.123.425.425,0,0,1-.124-.314v-.8a.457.457,0,0,1,.124-.323.409.409,0,0,1,.313-.133h9.158a.449.449,0,0,1,.333.124.449.449,0,0,1,.123.332v.8a.409.409,0,0,1-.133.314.457.457,0,0,1-.323.123H98.04V-.437a.409.409,0,0,1-.133.314A.457.457,0,0,1,97.584,0Z" transform="translate(22.526 15.49)" fill="#fff" opacity=".5"/><g data-name="Group 1831"><path style="fill: rgb(0, 178, 255) !important;" data-name="Path 2458" d="M79.545,240.023l3.491,2.654,1.359-1.788-2.736-2.081,1.276-1.678,2.737,2.081,2.292-3.015a9.261,9.261,0,0,0-14.292,11.56Z" fill="#00b2ff" transform="translate(-72.272 -233.599)"/><path style="fill: rgb(34, 232, 179) !important;" data-name="Path 2459" d="M96.9,249.521l-5.874,7.733L87.531,254.6l-1.359,1.788,2.737,2.08-1.276,1.678L84.9,258.066,82.6,261.081A9.261,9.261,0,0,0,96.9,249.521Z" transform="translate(-79.769 -245.152)" fill="#22e8b3"/></g></g></svg>';
              logo.style.cssText = 'position:static;display: flex;align-items: center;user-select: none;color: #9c98a7;font-size: 15px;font-weight: 400;';

              var logoText = document.createElement('div');

              var collapse = document.createElement('div');
              collapse.style.cssText = 'position:static;display: flex; width: 30px; height: 100%;';

              var collapseButton = document.createElement('button');
              collapseButton.style.cssText =
                'background: transparent; border: 0px; padding: 0px; width: 30px; cursor: pointer; outline: none; margin: 0 !important; box-shadow: none !important;';
              collapseButton.className = 'f-functionise-css-rotate-transition';
              collapseButton.id = 'f-functionise-tc-manager-collapse-button';
              collapseButton.innerHTML =
                '<svg style="fill:#fff;height: 35px;width:30px;transform: scale(.75);" xmlns="http://www.w3.org/2000/svg" class="icon fill-current"><defs><clipPath id="a"><path d="M0 0h32v32H0z"></path></clipPath></defs><g clip-path="url(#a)"><path style="fill: #fff !important;" data-v-2416fd8f="" d="M11.41 20.41L16 15.83l4.59 4.58L22 19l-6-6-6 6z"></path></g></svg>';

              var loading = document.createElement('div');
              loading.id = 'loading';
              loading.style.cssText = 'z-index: 9999;position: absolute;top: 0;left: 0;right: 0;bottom: 0;background: #272239;animation: fadeOutFromNone 0.7s ease-out;';
              loading.innerHTML =
                '<svg version="1.1" class="loading-icon" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="40px" height="40px" viewBox="0 0 50 50" style="position: absolute;top: 50%;left: 50%;transform: translate(-50%, calc(-50% - 50px));enable-background:new 0 0 50 50;" xml:space="preserve"><path fill="#00b2ff" d="M25.251,6.461c-10.318,0-18.683,8.365-18.683,18.683h4.068c0-8.071,6.543-14.615,14.615-14.615V6.461z" transform="rotate(154.721 25 25)"><animateTransform attributeType="xml" attributeName="transform" type="rotate" from="0 25 25" to="360 25 25" dur="0.6s" repeatCount="indefinite"></animateTransform></path></svg>';

              var iframe = document.createElement('iframe');
              // Must be declared at web_accessible_resources in manifest.json
              iframe.src = chrome.runtime.getURL('popup/popup.html');
              iframe.setAttribute('allow', 'clipboard-read; clipboard-write');
              iframe.className = 'f-functionise';
              iframe.onload = function () {
                loading.remove();
              };
              // Some styles for a fancy sidebar
              iframe.style.cssText =
                'position:relative !important;top:0;left:0;width:100%;height:100%; min-width: 100%; max-width: 100%; border:0;pointer-events: all;max-height: 515px; min-height: 515px; display: block !important;';

              var dragCover = document.createElement('div');
              dragCover.id = 'f-functionise-drag-coverer';
              dragCover.className = window.fUniqPrefix;
              dragCover.style.cssText = 'position:absolute;top:35px;left:0px;z-index:2147483547;width:360px;height:530px; display:none; opacity:0.0; pointer-events: auto;';

              var steps = document.createElement('div');
              steps.id = 'functionize_steps_counter';
              steps.style.cssText =
                'position:static;background: #272339;font-size: 14px;border-radius: 10px;padding: 2px 7px;display: flex;color: #93909c;text-align: center;margin-left: 13px;font-weight: 300;font-family:"Rubik", sans-serif;';
              steps.innerHTML = 'actions';

              var modelerControls = document.createElement('div');
              modelerControls.style.cssText = 'position:static;display: flex;justify-content: space-between;width: 44px;height: 100%;margin-left: auto;margin-right: 20px;';

              collapse.appendChild(collapseButton);
              logo.appendChild(logoText);
              container.appendChild(logo);
              container.appendChild(steps);
              container.appendChild(modelerControls);
              container.appendChild(collapse);
              head.appendChild(container);
              head.appendChild(dragCover);
              shadow.appendChild(head);
              shadow.appendChild(loading);
              shadow.appendChild(iframe);

              window.TCM.setDraggableElement(container, this);
              window.TCM.setCollapsibleElement(collapseButton, this);

              window.addEventListener(
                'message',
                (event) => {
                  try {
                    if (event.data.target && event.data.target === 'functionize-architect') {
                      if (event.data.hasOwnProperty('call')) {
                        let collapsible = this;
                        switch (event.data.call) {
                          case 'updateSteps':
                            steps.innerHTML = `${event.data.data} ${event.data.data == 1 ? 'step' : 'actions'}`;
                            break;
                          case 'collapse':
                            if (collapsible && shadow) {
                              let bounds = window.WU.zoomBoundingRect(collapsible);
                              let childs = shadow.childNodes;
                              window.TCM.modelerIframeLastStyle = JSON.parse(
                                JSON.stringify({
                                  element: {
                                    width: collapsible.style.width,
                                    height: collapsible.style.height,
                                  },
                                  child: {
                                    width: childs[0].style.width,
                                    height: childs[0].style.height,
                                  },
                                })
                              );
                              collapsible.style.width = '359px';
                              collapsible.style.height = '35px';
                              childs[0].style.width = '359px';
                              childs[0].style.height = '35px';
                              childs[1].style.setProperty('display', 'none', 'important');
                              if (window.TCM.isMobileAndTablet()) {
                                collapsible.style.top = bounds.top - window.WU.zoomBoundingRect(collapsible).height / 2 + 'px';
                              }
                              collapseButton.classList.add('f-functionise-css-rotate-transition-down');
                            }
                            break;
                          case 'uncollapse':
                            if (collapsible && shadow) {
                              let bounds = window.WU.zoomBoundingRect(collapsible);
                              let childs = shadow.childNodes;
                              if (closed) {
                                collapsible.style.width = '360px';
                                collapsible.style.height = window.TCM.modelerIframeLastStyle.element.height;
                                childs[0].style.width = window.TCM.modelerIframeLastStyle.child.width;
                                childs[0].style.height = window.TCM.modelerIframeLastStyle.child.height;
                              } else {
                                collapsible.style.width = window.TCM.modelerIframeLastStyle.element.width;
                                collapsible.style.height = window.TCM.modelerIframeLastStyle.element.height;
                                childs[0].style.width = window.TCM.modelerIframeLastStyle.child.width;
                                childs[0].style.height = window.TCM.modelerIframeLastStyle.child.height;
                              }
                              if (window.TCM.isMobileAndTablet()) {
                                collapsible.style.top = bounds.top - window.WU.zoomBoundingRect(collapsible).height / 2 + 'px';
                              }
                              childs[1].style.setProperty('display', 'block', 'important');
                              collapseButton.classList.remove('f-functionise-css-rotate-transition-down');
                            }
                            break;
                        }
                      }
                    }
                  } catch (e) {}
                },
                false
              );
            }
          }

          window.customElements.define('functionize-architect', FunctionizeArchitect);
        }

        var div = document.createElement('functionize-architect');
        div.id = 'f-functionise-tc-manager';
        div.className = window.fUniqPrefix;

        div.style.cssText =
          'position:fixed;top:30px;right:30px;z-index:9999999999;width:360px;height:550px;border-top-right-radius:5px;border-top-left-radius:5px;background: transparent;pointer-events: none;opacity: 1;display:block;';

        if (!document.getElementById('f-functionise-tc-manager')) {
          insertAfter(div, document.body || document.children[0]);
        }
      })();
    }

    this.showActionCounter();

    if (!window.WS.collectStatistics) {
      var zi = window.WU.getTopZindex();
      var that = this;
      setTimeout(function () {
        that.adjustTop(zi);
      }, 750);
    }

    this.initialize = true;
    window.TCM.isStopping = false;

    var tcmself = this;
    clearInterval(tcmself.checkfunctionisepanel);
    if (!window.WS.isIframe && !window.WS.isPopup) {
      console.log('calling tcmself.checkfunctionisepanel');
      tcmself.checkfunctionisepanel = setInterval(function () {
        if (document.getElementById('f-functionise-tc-manager') === null && (!window.WS.isIframe || !window.WS.isPopup)) {
          console.log('calling TCM.create()', tcmself.create);
          tcmself.create();
          functioniseDocumentReady();
        }
        tcmself.checkfunctionisepanelcount++;
      }, 3000);
    }

    setTimeout(() => {
      if (!window.functioniseListenersAdded) {
        window.addFunctioniseListeners();
      }
    }, 600);
  };
  this.updateSteps = function (steps) {
    window.postMessage({ call: 'updateSteps', target: 'functionize-architect', data: steps }, '*');
  };
  this.setDraggableElement = function (element, parent) {
    const that = this;
    that.modelerIframeHasDraged = false;
    // element.addEventListener('pointerdown', dragMouseDown);
    element.addEventListener('pointerdown', enableDrag);
    document.addEventListener('pointerup', stopDrag);

    var offsetX;
    var offsetY;
    var coordX;
    var coordY;
    var isMobile;
    that.modelerIframeHasDraged = false;

    function enableDrag() {
      document.onpointerdown = startDrag;
      document.onpointerup = stopDrag;
      document.addEventListener('touchmove', touchMove, { passive: false });
      let element = document.getElementById('f-functionise-drag-coverer');
      if (element) {
        element.style.display = 'block';
      }
    }

    function touchMove(e) {
      if (e.preventDefault) {
        e.preventDefault();
      }
    }

    function offset(el) {
      var rect = window.WU.zoomBoundingRect(el);
      var scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
      var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      return {
        top: rect.top + scrollTop,
        left: rect.left + scrollLeft,
        width: rect.width,
        height: rect.height,
      };
    }

    function startDrag(e) {
      // determine event object
      if (!e) {
        e = window.event;
      }
      if (!e.target.classList.contains('f-functionise') && !e.target.closest('.f-functionise')) {
        stopDrag();
        return;
      }
      var targ = parent;
      var divOffset = offset(targ);
      // calculate event X, Y coordinates
      offsetX = e.clientX;
      offsetY = e.clientY;
      isMobile = that.isMobileAndTablet();
      // assign default values for top and left properties
      if (!targ.style.left) {
        // we're setting the right position now. since the left position was not set initially, the iframe was jumping to 0px left on dragstart
        targ.style.left = divOffset.left + 'px';
      }
      if (!targ.style.top) {
        targ.style.top = divOffset.top + 'px';
      }
      // calculate integer values for top and left
      // properties
      coordX = parseInt(targ.style.left);
      coordY = parseInt(targ.style.top);
      that.movedX = 0;
      that.movedY = 0;
      // move div modeler window
      that.modelerIframeHasDraged = false;
      document.onpointermove = doDrag;
    }

    function doDrag(e) {
      if (!e) {
        e = window.event;
      }
      that.modelerIframeHasDraged = false;
      var targ = parent;
      // move div element
      targ.style.left = coordX + e.clientX - offsetX + 'px';
      targ.style.top = coordY + e.clientY - offsetY + 'px';

      that.movedX += e.clientX - offsetX;
      that.movedY += e.clientY - offsetY;
      return false;
    }

    function stopDrag() {
      var element = document.getElementById('f-functionise-drag-coverer');
      if (element) {
        element.style.display = 'none';
      }
      that.modelerIframeHasDraged = false;
      document.onpointerdown = null;
      document.onpointerup = null;
      document.onpointermove = null;
      document.removeEventListener('touchmove', touchMove);
      coordX = parseInt(parent.style.left);
      coordY = parseInt(parent.style.top);
      var divOffset = offset(parent);
      if (!isMobile && coordX < 0) parent.style.left = '0px';
      if (coordX > window.innerWidth - 50) {
        parent.style.left = window.innerWidth - 50 + 'px';
      }
      if (isMobile && coordX + divOffset.width > window.innerWidth - 70) {
        parent.style.left = window.innerWidth - divOffset.width - 70 + 'px';
      }
      if (!isMobile && coordY < 0) parent.style.top = '0px';
      if (!isMobile && coordY > window.innerHeight - 70) {
        parent.style.top = window.innerHeight - 70 + 'px';
      }
      that.modelerIframeHasDraged = that.movedX > 15 || that.movedX < -15 || that.movedY > 15 || that.movedY < -15;
    }
  };
  this.isMobileAndTablet = function () {
    let check = false;
    (function (a) {
      if (
        /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(
          a
        ) ||
        /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(
          a.substr(0, 4)
        )
      )
        check = true;
    })(navigator.userAgent || navigator.vendor || window.opera);
    return check;
  };
  this.triggerMouseup = function () {
    var evt = document.createEvent('MouseEvents');
    evt.initEvent('mouseup', true, true);
    document.body.dispatchEvent(evt);
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('triggerMouse');
  };
  this.setNlpToggle = function (element) {
    element.addEventListener('change', (event) => {
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setNlpToggleValue',
        arguments: event.target.checked,
      });
    });
  };
  this.setNlpToggleValue = function (value) {
    if (window.TCM.isMaster) {
      self.port.emit('message', {
        obj: 'TCM',
        call: 'setNlpToggle',
        arguments: value,
        forMaster: true,
      });
      window.TCM.sendCallToDescendants('setNlpToggleValue', value);
    }
    document.getElementById('myonoffswitch').checked = value;
  };
  this.setCollapsibleElement = function (element, collapsible) {
    element.addEventListener('click', () => {
      if (!this.modelerIframeHasDraged) {
        if (this.isCollapsed) {
          this.unCollapse();
        } else {
          this.collapse();
        }
      }
    });
  };
  this.collapse = function () {
    if (!this.isCollapsed) {
      this.isCollapsed = true;
      window.postMessage({ call: 'collapse', target: 'functionize-architect' }, '*');
    }
  };
  this.unCollapse = function (closed) {
    if (this.isCollapsed) {
      this.isCollapsed = false;
      window.postMessage({ call: 'uncollapse', target: 'functionize-architect' }, '*');
    }
  };
  this.setElementTarget = function (elementTargeting) {
    this.collapse();
    if (!window.TCM.isMaster && this.elementTargeting != elementTargeting) {
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setElementTarget',
        arguments: elementTargeting,
        forMaster: true,
      });
    }
    this.elementTargeting = elementTargeting;
    if (this.elementTargeting) {
      window.TCM.collapse();
    } else {
      window.TCM.unCollapse();
    }
    if (window.TCM.isMaster) {
      window.TCM.sendCallToDescendants('setElementTarget', elementTargeting);
      window.WS.removeHighlights();
      // window.TH.clearAll();
      window.WU.fShowAllElements();
    }
  };
  this.saveElementTarget = function (element) {
    self.port.emit('message', {
      obj: 'f-vue',
      call: 'saveElementTarget',
      arguments: element,
      forMaster: true,
    });
  };

  this.init = function (startCallback, stopCallback, isSubWindow) {
    console.log('Init is executing ' + isSubWindow + ' with runtime vars: ' + JSON.stringify(window.TCM.runtimeVariables));

    if (window.location.href.indexOf('previews.functionize.com') > -1) this.isCachedEdit = true;

    if (this.initCalled) return;

    //we clean the action data from unnecessary iframe page inits….
    if (this.isController) this.cleanRecordedData(false, true);

    this.initCalled = true;
    this.cloudStorage = window.WS.cloudStorage;
    window.TCM.lastAdjusted = 0;
    if (typeof window.WS.settings.managerBoxTop != 'undefined') this.windowTop = window.WS.settings.managerBoxTop;

    if (!(startCallback instanceof Function)) {
      throw new Error("startCallback type isn't a Function!");
    } else {
      this._startCallback = startCallback;
    }

    if (!(stopCallback instanceof Function)) {
      throw new Error("stopCallback type isn't a Function!");
    } else {
      this._stopCallback = stopCallback;
    }
    window.fconsole.log('Setting wbProt');
    var wbProt = window.location.protocol;

    if (this.isController || (this.isSubWindow && !window.WS.isIframe)) {
      window.advancedPanelInjected = true;
    }

    // injectCSS('styles/qtip.css');

    this.isSubWindow = isSubWindow;

    //create floating window...
    if (this.isSubWindow && !this.isController) {
      setTimeout(() => {
        this.create();
        this.initEditor();
      }, 1000);
    } else {
      if (this.isController) {
        setTimeout(() => {
          this.create();
          this.initEditor();
        }, 1000);
      } else {
        console.log('something went wrong creating Architect');
      }
    }

    //reg all pending children
    window.fconsole.log('Registering children');
    this.registerQueuedChildren();

    if (!window.WS.isIframe) {
      if (!window.WS.collectStatistics) {
        setInterval(function () {
          window.TCM.ensureVisibility();
        }, 5000);
      }
    }

    if (typeof window.functionizeRuntimeVariables != 'undefined') this.setRuntimeVariables(window.functionizeRuntimeVariables);

    //  window.WS.setSettings('coverElementOnActionRec', true); // force true, reverting previous change
    // window.WS.saveSettings();
    window.TCM.setShiftDown(false);
  };

  this.incrementPageCount = function () {
    window.fconsole.log('Increase page count call: ' + window.TCM.isMaster + ' ' + window.TCM.isController);
    if (window.TCM.isMaster) {
      var command = { obj: 'TCM', call: 'incrementPageCount' };
      window.TCM.sendCommandToMaster(command);
      window.WS.pageCount++;
    } else if (window.TCM.isController) {
    }
  };

  this.removeCoverer = function () {
    //this timout is set in the plugin upon injection in case the body is not yet ready.
    //we clear this just in case...
    if (typeof window.covererTimer != 'undefined') clearTimeout(window.covererTimer);
    //take loader window off
    window.fconsole.log('Remove coverer is called');
    var loadingElementId = window.fUniqPrefix + '-loading';
    var loadingElement = document.getElementById(loadingElementId);

    if (loadingElement) {
      loadingElement.parentNode.removeChild(loadingElement);
    }
  };

  //just the loader bar.     For suppressed domains we remove just the bar
  this.removeCovererBar = function () {
    //take loader window off
    var loadingBarElementId = window.fUniqPrefix + '-loading-bar';
    var loadingBarElement = document.getElementById(loadingBarElementId);

    if (loadingBarElement) {
      loadingBarElement.parentNode.removeChild(loadingBarElement);
    }
  };

  this.resetStates = function () {
    window.TCM.isVerifying = false;
    window.TCM.isScrolling = false;
    window.TCM.isStopping = false;
    window.TCM.isHoveringAction = false;
    window.TCM.setShiftDown(false);
    window.TCM.editing = false;
    window.TCM.recording = false;
    window.TCM.runtimeVariables = {};
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('resetStates');
  };

  this.clearTooltips = function () {
    // window.TH.clearAll();
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('clearTooltips');
  };

  //****** Advanced editor tools here **************************/
  this.initEditor = function () {
    console.log('Initing editor');
    var tabOptions = {};
    tabOptions = {
      overview: {
        label: 'Selected Element',
        container: '#' + window.fUniqPrefix + '-overview',
        type: 'buttons',
        show: '1',
        blankelementshow: '0',
      },
      element: {
        label: 'Selector Override',
        container: '#' + window.fUniqPrefix + '-element',
        type: 'editor',
        show: '1',
        blankelementshow: '0',
      },
      code: {
        label: 'Outcome Override',
        container: '#' + window.fUniqPrefix + '-code',
        type: 'editor',
        show: '1',
        blankelementshow: '0',
      },
      advanced: {
        label: 'Advanced',
        container: '#' + window.fUniqPrefix + '-advanced',
        type: 'advancebuttons',
        show: '1',
        blankelementshow: '0',
      },
    };
    var options = {
      target: 'body',
      panelContainer: '#' + window.fUniqPrefix + '-css-advance-editor-wrapper',
      panelPosition: 'bottom',
      tabContainer: '#' + window.fUniqPrefix + '-tab-container',
      tabs: tabOptions,
      triggerAction: 'click',
      panelWidth: window.innerWidth - 20,
      saveCallBack: function (element, actionId) {
        // var command = {
        //  obj: 'WS',
        //  call: 'saveAdvancedCoderData',
        //  arguments: new Array(element, actionId),
        // };
        // window.TCM.sendCommand(command, window.parent);
        // this is a hack because the above isn't working for some reason
        // TODO: fix this
        window.WS.saveAdvancedCoderData(element, actionId);
      }, //advaced coder save will call stop edit
      cancelCallBack: function (element) {
        var command = {
          obj: 'WS',
          call: 'saveAdvancedCoderData',
          arguments: element,
        };
        window.TCM.sendCommand(command, window.parent);
      },
    };
    var wbProt = window.location.protocol;

    window.WS.setCollectStatistics();
    window.WS.setPreferDomsnapshot();
    window.WS.setCollectFormData();
    window.WS.setForceZoom();
    /*
    if (!window.advancedPanelInjected) {
      var element = document.querySelector('#f-functionise-tc-manager');
      if (element) {
        var parent = element.parentNode;
        if (parent) {
          parent.remove();
        }
      }
      preInitFunctionise();
      functioniseDocumentReady();
    }
    */
    //add css to advanced editor
    this.advancedEditor = new fAdvanceEditor(options);
    this.advancedEditor.initialize();
  };

  this.setEditState = function (state) {
    window.TCM.editing = state;
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('setEditState', state);
  };

  this.setVerifyState = function (state) {
    window.TCM.isVerifying = state;
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('setVerifyState', state);
  };

  this.setScrolling = function (state) {
    window.TCM.isScrolling = state;
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('setScrolling', state);
  };

  this.setStopState = function (state) {
    window.TCM.isStopping = state;
    if (window.TCM.isMaster) {
      window.TCM.sendCallToDescendants('setStopState', state);
    }
  };

  this.cancelCancel = function () {
    //window.TCM.sendCallToDescendants("cancelCancel", true);
  };

  // SETTINGS

  /**
   * Calls the function to toggle coverer in the injected script.
   * @param {boolean} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.coverElementOnActionRec = function (data) {
    if (window.WS.recordedData.length > 0 && window.TCM.recording) {
      var set = data;
      window.WS.setSettings('coverElementOnActionRec', set);
      window.WS.saveSettings();
      if (!set) {
        //
      } else {
        //
      }
    }
  };

  this.usePageInitActions = function (data) {
    if (window.WS.recordedData.length > 0 && window.TCM.recording) {
      var set = data || false;
      window.WS.setSettings('usePageInitActions', set);
      window.WS.saveSettings();
      if (!set) {
        //
      } else {
        //
      }
    }
  };

  this.keepTooltipsOnVerification = function (data) {
    if (window.WS.recordedData.length > 0 && window.TCM.recording) {
      var set = data;
      window.WS.setSettings('keepTooltipsOnVerification', set);
      window.WS.saveSettings();
      if (!set) {
        //
      } else {
        //
      }
    }
  };

  /**
   * Calls the function to toggle coverer in the injected script.
   * @param {boolean} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.toggleMouseover = function (data) {
    if (window.WS.recordedData.length > 0 && window.TCM.recording) {
      var set = data;
      if (window.WS.settings['disableMouseover']) set = false;
      window.WS.setSettings('disableMouseover', set);
      window.WS.saveSettings();
      if (!set) {
        //
      } else {
        //
      }
    }
  };

  /**
   * Calls the function to toggle mouseout in the injected script.
   * @param {boolean} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.toggleMouseout = function (data) {
    var set = data;
    if (typeof window.WS.settings['disableMouseout'] === 'undefined') window.WS.settings['disableMouseout'] = false;
    if (typeof window.WS.settings['disableMouseoutAction'] === 'undefined') window.WS.settings['disableMouseoutAction'] = false;
    if (!window.WS.settings['disableMouseout']) window.WS.settings['disableMouseoutAction'] = true;
    window.WS.setSettings('disableMouseout', set);
    window.WS.saveSettings();
  };

  /**
   * Calls the function to toggle focus in the injected script.
   * @param {boolean} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.toggleFocus = function (data) {
    if (typeof data !== 'undefined' && typeof data === 'boolean') {
      // set data from vuex
      self.port.emit('message', {
        obj: 'TCM',
        call: 'toggleFocus',
        arguments: data,
        forMaster: true,
      });
      window.WS.focusOnElementFlag = data;
      window.postMessage({ call: 'setFocus', args: data }, '*');
      if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'focusOnElementFlag', data);
    }
  };

  /**
   * Calls the function to toggle long text in the injected script.
   * @param {boolean} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.toggleLongText = function (data) {
    if (window.WS.recordedData.length > 0 && window.TCM.recording) {
      if (typeof data !== 'undefined' && typeof data === 'boolean') {
        // set data from vuex
        self.port.emit('message', {
          obj: 'TCM',
          call: 'toggleLongText',
          arguments: data,
          forMaster: true,
        });
        window.WS.captureLargeData = data;
        if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'captureLargeData', data);
      }
    }
  };

  this.toggleCaptureElementScrolls = function (data) {
    console.log('toggleCaptureElementScrolls', data, window.TCM.captureElementScrolls);
    if (window.WS.recordedData.length > 0 && window.TCM.recording) {
      if (typeof data !== 'undefined' && typeof data === 'boolean') {
        // set data from vuex
        self.port.emit('message', {
          obj: 'TCM',
          call: 'toggleCaptureElementScrolls',
          arguments: data,
          forMaster: true,
        });
        window.TCM.captureElementScrolls = data;
        if (window.TCM.isMaster) window.TCM.sendValueToDescendants('TCM', 'captureElementScrolls', data);
      }
    }
    console.log(window.TCM.captureElementScrolls);
  };

  this.toggleEnableSVGChildren = function (data) {
    console.log('toggleEnableSVGChildren', data, window.WS.enableSVGChildren);
    if (window.WS.recordedData.length > 0 && window.TCM.recording) {
      if (typeof data !== 'undefined' && typeof data === 'boolean') {
        // set data from vuex
        self.port.emit('message', {
          obj: 'TCM',
          call: 'toggleEnableSVGChildren',
          arguments: data,
          forMaster: true,
        });
        window.WS.enableSVGChildren = data;
        if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'enableSVGChildren', data);
      }
    }
    console.log(window.WS.enableSVGChildren);
  };

  this.toggleAllowBodyTargetElement = function (data) {
    console.log('toggleAllowBodyTargetElement', data, window.WS.allowBodyTargetElement);
    if (window.WS.recordedData.length > 0 && window.TCM.recording) {
      if (typeof data !== 'undefined' && typeof data === 'boolean') {
        // set data from vuex
        self.port.emit('message', {
          obj: 'TCM',
          call: 'toggleAllowBodyTargetElement',
          arguments: data,
          forMaster: true,
        });
        window.WS.allowBodyTargetElement = data;
        if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'allowBodyTargetElement', data);
      }
    }
    console.log(window.WS.allowBodyTargetElement);
  };

  this.toggleEnableMLonkeydown = function (data) {
    console.log('toggleEnableMLonkeydown', data, window.WS.enableSVGChildren);
    if (window.WS.recordedData.length > 0 && window.TCM.recording) {
      if (typeof data !== 'undefined' && typeof data === 'boolean') {
        // set data from vuex
        self.port.emit('message', {
          obj: 'TCM',
          call: 'toggleEnableMLonkeydown',
          arguments: data,
          forMaster: true,
        });
        window.WS.collectMlDataOnKeydown = data;
        if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'collectMlDataOnKeydown', data);
      }
    }
    console.log(window.WS.enableSVGChildren);
  };

  //this gets called recursively until we reach the controller window
  this.startEdit = function (element, callerIframe, callerPopup, source, recordedData) {
    if (!source || typeof source === 'undefined') source = 'self';

    if (source == 'self') {
      window.TCM.setEditDomWalkElement(element);
    }
    // this.validateDomWalkArrow();
    console.log('startEdit recordedData', recordedData);
    if (typeof recordedData === 'undefined') {
      recordedData = new Array();
    } else {
      window.WS.recordedData = JSON.parse(recordedData);
    }
    if (window.TCM.isMaster && !window.TCM.isController) {
      // when we are the master and not the controller paths are already set...
    } else {
      // if its not from the master we set path
      if (typeof callerIframe !== 'undefined' && callerIframe != null && source != 'master') element = window.WS.setPathOnData(element, callerIframe, 'iframe');

      if (typeof callerPopup !== 'undefined' && callerPopup != null && source != 'master') element = window.WS.setPathOnData(element, callerPopup, 'popup');
    }

    var command = {};
    var args = null;

    if ((window.WS.isIframe || window.WS.isPopup) && source != 'master') {
      console.log(window.WS.isIframe + ' ' + window.WS.isPopup + ' ' + source);
      command = { obj: 'TCM', call: 'startEdit', arguments: null };
      var target = window.parent;
      args = new Array(element, window.WS.iframeUID, null, 'iframe');
      if (window.WS.isPopup) {
        target = window.opener;
        args = new Array(element, null, window.WS.popupUID, 'popup');
      }
      command.arguments = args;
      window.TCM.sendCommand(command, target);
      return;
    }

    if (window.TCM.isMaster && !window.TCM.isController) {
      // sending it back down if the master is not the controller...
      console.log('//sending it back down if the master is not the controller...');
      command = { obj: 'TCM', call: 'startEdit', arguments: null };
      args = new Array(element, null, null, 'master', JSON.stringify(window.WS.recordedData));
      command.arguments = args;
      window.TCM.sendCommand(command, target);
      return;
    }

    window.TCM.setEditState(true);

    if (window.TCM.isController && (window.TCM.isMaster || source == 'master')) {
      window.TCM.setElements(element);
      var elementString = '';
      if (typeof element !== 'undefined') elementString = JSON.stringify(element);

      window.fconsole.log('Opening panel call made with element' + elementString);

      window.TCM.setShiftDown(false);
      window.TCM.advancedEditor.getObject('panel').openPanel(element, callerIframe, callerPopup, source, recordedData, window.location.href != element.url);
    }
  };

  this.stopEdit = function (source) {
    if (typeof source == 'undefined') source = 'self';

    window.fconsole.log('Stop edit is called');
    window.TCM.setShiftDown(false);
    if (source == 'master' || window.TCM.isMaster) {
      window.WS.removeHighlights();
      // window.TH.clearAll();
      window.WU.fShowAllElements();
      window.TCM.cancelVerify();
      //reset shiftDown state now...
      window.TCM.sendValueToDescendants('WS', 'shiftDown', false);
      window.TCM.setEditState(false);
    }

    if (window.TCM.isController && source == 'self') {
      window.TCM.advancedEditor.getObject('panel').closePanel();
    }
    //verify is done...

    if (!window.TCM.isMaster && window.TCM.isController && source == 'self') {
      //we need to clear the rec data
      window.WS.recordedData = new Array();
    }
    if (window.TCM.isStopping && window.TCM.isController && source == 'master') {
      // this is the last step in the creation process
      ///recording is done we create final form
      window.TCM.createFormWindow();
    }

    if (window.TCM.isController && !window.TCM.isMaster && source == 'self') {
      //frameset
      let command = { obj: 'TCM', call: 'stopEdit', arguments: new Array('iframe') };
      window.TCM.sendCommand(command, window.parent);
    }

    if (window.TCM.isMaster) {
      let command = { obj: 'TCM', call: 'stopEdit', arguments: new Array('master') };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  this.setEditDomWalkElement = function (element) {
    var selector = window.WS.getUniqueSelector(element);
    window.TCM.domWalkElement = document.querySelector(selector);

    document.querySelectorAll('.f-domWalkSelector').forEach((el) => {
      el.classList.remove('f-domWalkSelector');
    });

    if (window.TCM.domWalkElement) {
      window.TCM.domWalkElement.classList.add('f-domWalkSelector');

      // remove focus from the element after a delay
      setTimeout(function () {
        window.TCM.domWalkElement.blur();
      }, 50);
    }
  };

  this.setElements = function (element) {
    if (element != null) {
      window.TCM.editElement = element; // window.WU.cloneNodeWithEvents(element);
      window.TCM.advancedEditor.setBlankElement(false);
      window.TCM.advancedEditor.setCurrentElement(element);
      window.TCM.advancedEditor.setElementDetails(element);
    } else {
      window.TCM.advancedEditor.setBlankElement(true);
    }
    if (window.TCM.isMaster) {
      var command = { obj: 'TCM', call: 'setElements', arguments: element };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  this.cancelAdvancedPanel = function () {
    window.TCM.advancedEditor.oTabs.attributeValues = {};
    if (!window.TCM.advancedEditor.blnFlagBlankElement || window.TCM.advancedEditor.blnFlagBlankElement == false) {
      // we do not save user code on close click….
      window.TCM.advancedEditor.oEditor.processSubmit(false, false);
    } else {
      // we do not have an element - close without saving
      window.TCM.advancedEditor.setBlankElement(false);
      window.TCM.stopEdit();
    }
    document.querySelectorAll('.f-domWalkSelector').forEach(function (element) {
      element.classList.remove('f-domWalkSelector');
    });
  };

  this.cancelAdvancedPanelClick = function (data) {
    setTimeout(function () {
      var element = document.querySelector(data.cssSelector);
      if (element) {
        element.click();
      }
    }, 300);
  };

  this.saveAdvancedPanel = function (data) {
    window.TCM.advancedEditor.oTabs.attributeOperators = {};
    window.TCM.advancedEditor.setCurrentFunctioniseElement(window.TCM.advancedEditor.oEditor.currentElement);
    window.TCM.advancedEditor.triggerCallBack();
  };

  this.elementImmediateChildren = function (mainEl, fullpath) {
    return Array.from(mainEl.children).filter((el) => el.nodeName !== 'SCRIPT' && el.nodeName !== 'STYLE' && !window.WS.isFunctioniseElement(el));
  };

  this.validateDomWalkArrow = function (data, elementSelector) {
    var direction = data.direction;
    try {
      var changeSelector = false;
      var element = window.TCM.domWalkElement;

      if (direction && element) {
        var tryCount = 0;
        switch (direction) {
          case 'up':
            var parentElement = element.parentElement;
            if (parentElement) {
              window.TCM.domWalkElement = parentElement;
              changeSelector = true;
            }
            break;
          case 'down':
            var childs = this.elementImmediateChildren(element, true);
            if (childs && childs[0]) {
              window.TCM.domWalkElement = childs[0];
              changeSelector = true;
            }
            break;
          case 'left':
            var leftElement = element.previousElementSibling;
            tryCount = 0;
            while (window.WS.isFunctioniseElement(leftElement) && tryCount < 5) {
              leftElement = leftElement.previousElementSibling;
              tryCount++;
            }
            if (leftElement) {
              window.TCM.domWalkElement = leftElement;
              changeSelector = true;
            }
            break;
          case 'right':
            var rightElement = element.nextElementSibling;
            tryCount = 0;
            while (window.WS.isFunctioniseElement(rightElement) && tryCount < 5) {
              rightElement = rightElement.nextElementSibling;
              tryCount++;
            }
            if (rightElement) {
              window.TCM.domWalkElement = rightElement;
              changeSelector = true;
            }
            break;
        }

        if (changeSelector) {
          document.querySelectorAll('.f-domWalkSelector').forEach((el) => el.classList.remove('f-domWalkSelector'));
          window.TCM.domWalkElement.classList.add('f-domWalkSelector');
        }
      }

      if (elementSelector) {
        window.TCM.domWalkElement = elementSelector;
        document.querySelectorAll('.f-domWalkSelector').forEach((el) => el.classList.remove('f-domWalkSelector'));
        window.TCM.domWalkElement.classList.add('f-domWalkSelector');
      }

      self.port.emit('message', {
        obj: 'TCM',
        call: 'domWalkElement',
        arguments: window.WS.targetElement(window.TCM.domWalkElement, data.action),
        forVue: true,
      });
    } catch (err) {
      console.error(err);
    }
  };

  this.searchQuerySelector = function (data) {
    let elements = [];

    try {
      elements = document.querySelectorAll(data.data.selector);
    } catch (e) {
      console.log(e);
      try {
        let cssSelector = window.WS.xPathToCss(data.data.selector);
        elements = document.querySelectorAll(cssSelector);
      } catch (e) {
        console.log(e);
      }
    }

    if (elements.length === 0) {
      self.port.emit('message', {
        obj: 'TCM',
        call: 'showDialog',
        arguments: 'No elements matching your query',
        forVue: true,
      });
      return;
    }

    if (elements.length > 1) {
      // too many elements selected but use first and continue
      self.port.emit('message', {
        obj: 'TCM',
        call: 'showDialog',
        arguments: 'Using the first matching element because more than one element matched your query.',
        forVue: true,
      });
    }

    window.TCM.domWalkElement = elements[0];

    document.querySelectorAll('.f-domWalkSelector').forEach((el) => {
      el.classList.remove('f-domWalkSelector');
    });

    window.TCM.domWalkElement.classList.add('f-domWalkSelector');

    self.port.emit('message', {
      obj: 'TCM',
      call: 'domWalkElement',
      arguments: window.WS.targetElement(window.TCM.domWalkElement, data.data.action),
      forVue: true,
    });
  };

  this.setDomWalkElement = function (data) {
    console.log('setDomWalkElement', data);
    window.WS.dKeyDown = false;
    document.querySelectorAll('.f-domWalkSelector').forEach((element) => {
      element.classList.remove('f-domWalkSelector');
    });
    var changedElement = window.WS.targetElement(window.TCM.domWalkElement, data.action, undefined, false, undefined, false, true, data.actionId);
    changedElement.action = data.action;
    changedElement.selection_method = data.selection_method;
    changedElement.force_selector = data.force_selector;
    changedElement.selector = data.selector;
    changedElement.elementSelect = data.selectorCode;
    if (typeof data.isVisualCheck !== 'undefined') {
      changedElement.isVisualCheck = data.isVisualCheck;
      changedElement.visual_comparison_type = data.visual_comparison_type;
      changedElement.visual_comparison_match = data.visual_comparison_match;
      changedElement.computed_vision_based_validation = data.computed_vision_based_validation;
      changedElement.change_percentage_allowed = data.change_percentage_allowed;
    }
    console.log('changedElement', changedElement, changedElement.actionId, data.hasOwnProperty('actionId'), data.actionId);
    if (data.hasOwnProperty('actionId')) {
      changedElement.actionId = data.actionId;
    }
    if (!changedElement.eventX && data.eventX) {
      changedElement.eventX = data.eventX;
    }
    if (!changedElement.eventY && data.eventY) {
      changedElement.eventY = data.eventY;
    }
    setTimeout(() => {
      window.WS.overloadActionByActionId(Object.assign(changedElement, { skipVerifications: true }), true, data.actionId);
    }, 50);
  };

  this.userQuerySelector = function (querySelector) {
    if (querySelector) {
      try {
        window.TCM.advancedEditor.oTabs.domWalkElementSearch = true;
        window.TCM.advancedEditor.oTabs.domWalkElementSearchSelector = querySelector;
        this.validateDomWalkArrow({ data: false }, document.querySelector(querySelector));
      } catch (err) {
        alert('Invalid Selector');
        console.error(err);
      }
      // alert(querySelector);
    }
  };

  this.processTestCode = function (data) {
    console.log('processTestCode', data);
    let strCode = data.strCode;
    let elementSelect = data.elementSelect;
    let tab = 'code';

    if (window.TCM.advancedEditor.oEditor.getCleanedCode(strCode).trim() == '') {
      window.TCM.advancedEditor.oEditor.validateUserCodesCallback(true, '');
      return;
    }

    if (!data.code) {
      tab = 'element';
      strCode = this.prepareUserSelectorCodeForExecution(strCode, data.save);
    } else {
      strCode = this.prepareUserCodeForExecution(strCode, elementSelect, data.action, data.save);
    }

    // window.TCM.advancedEditor.oEditor.testCodeTimer = setTimeout(function() {
    //   window.TCM.advancedEditor.oEditor.validateUserCodeTimeout();
    // }, 4000);
    var path = data.path;
    if (!window.TCM.advancedEditor.oEditor.blnFlagBlankElement && window.TCM.advancedEditor.oEditor.currentElement != null && !path)
      path = window.TCM.advancedEditor.oEditor.currentElement.path;

    if (!data.save) {
      console.log('code', strCode, tab, path);
      window.WS.testUserCode(strCode, tab, path);
    }

    if (data.save) {
      if (!window.TCM.advancedEditor.oEditor.blnFlagBlankElement || window.TCM.advancedEditor.oEditor.blnFlagBlankElement == false) {
        window.TCM.advancedEditor.setCurrentFunctioniseElement(window.TCM.advancedEditor.oEditor.currentElement);
      } else {
        window.TCM.advancedEditor.setCurrentFunctioniseElement(null);
      }

      if (strCode.trim() != '') {
        window.TCM.advancedEditor.setElementData(tab, strCode, data.actionId);
      }

      if (window.WS.settings['disableMouseoutAction']) window.WS.settings['disableMouseoutAction'] = false;

      // TODO: Check if triggerCallBack is needed for ADV selector in non Verify
      window.TCM.advancedEditor.triggerCallBack(data.actionId);
    }

    return false;
  };

  this.prepareUserSelectorCodeForExecution = function (selectorCode, save) {
    console.log('selectorCode', selectorCode);
    if (!save) {
      selectorCode = 'function elementanon(){\n ' + selectorCode + '\n}';
    }
    return window.TCM.advancedEditor.oEditor.getCleanedCode(selectorCode);
  };

  this.prepareUserCodeForExecution = function (userCode, elementSelect, action, save) {
    var tagname;
    var index;
    var selector;

    if (window.TCM.advancedEditor.oEditor.currentElement && window.TCM.advancedEditor.oEditor.currentElement.element) {
      tagname = window.TCM.advancedEditor.oEditor.currentElement.element.toLowerCase();
      index = window.TCM.advancedEditor.oEditor.currentElement.index;
      selector = window.TCM.advancedEditor.oEditor.currentElement.cssSelector;
    } else if (Object.keys(action).length > 0) {
      if (action.element) {
        tagname = action.element.toLowerCase();
      }
      index = action.index;
      selector = action.cssSelector;
    }

    if (index < 0) index = 0;
    let selectorCode = '';
    if (selector || elementSelect) {
      selectorCode = 'var fElement = ' + `document.querySelector("${selector || elementSelect}")` + '\n';
    } else {
      console.info('prepareUserCodeForExecution selectorCode is undefined', selectorCode);
    }

    if (!save) {
      userCode = `(function(){
        ${selectorCode || elementSelect}
        ${userCode}
      })();`;
    } else {
      // eslint-disable-next-line no-self-assign
      userCode = userCode;
    }

    return window.TCM.advancedEditor.oEditor.getCleanedCode(userCode);
  };

  this.setIsHoveringAction = function (state) {
    if (window.TCM.isHoveringAction != state) {
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setIsHoveringAction',
        arguments: state,
        forMaster: true,
      });
    }
    window.TCM.isHoveringAction = state;
    if (window.TCM.isMaster) {
      if (!window.TCM.isHoveringAction) {
        window.WS.removeHighlights();
        // window.TH.clearAll();
        window.WU.fShowAllElements();
      }
      window.TCM.sendCallToDescendants('setIsHoveringAction', state);
    }
  };

  this.setIsScrollToElementAction = function (state) {
    if (window.TCM.isScrollToElementAction != state) {
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setIsScrollToElementAction',
        arguments: state,
        forMaster: true,
      });
    }
    window.TCM.isScrollToElementAction = state;
    if (window.TCM.isMaster) {
      if (!window.TCM.isScrollToElementAction) {
        window.WS.removeHighlights();
        // window.TH.clearAll();
        window.WU.fShowAllElements();
      }
      window.TCM.sendCallToDescendants('setIsScrollToElementAction', state);
    }
  };

  this.hideForBaselineScreenshot = function (scroll) {
    if (document.querySelector('#f-functionise-pause-coverer')) {
      document.querySelector('#f-functionise-pause-coverer').style.display = 'none';
    }
    if (document.getElementById('f-functionise-tc-manager')) {
      document.getElementById('f-functionise-tc-manager').style.display = 'none';
      if (scroll.scrollLeft || scroll.scrollTop) {
        window.scrollTo(scroll.scrollLeft || 0, scroll.scrollTop || 0);
      }
    }
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('hideForBaselineScreenshot', scroll);
  };

  this.showForBaselineScreenshot = function () {
    if (document.getElementById('f-functionise-tc-manager')) {
      document.getElementById('f-functionise-tc-manager').style.display = 'block';
    }
    if (document.querySelector('#f-functionise-pause-coverer')) {
      document.querySelector('#f-functionise-pause-coverer').style.display = 'block';
    }
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('showForBaselineScreenshot');
  };

  this.initShadowChangeListener = function (path) {
    let element = null;
    path
      .split('::')
      .filter((selector, index, arr) => index > 0 && index < arr.length - 1)
      .forEach((selector) => {
        if (element === null) {
          element = document.querySelector(selector);
          element.shadowRoot.removeEventListener('change', function (e) {
            return functioniseChangeListener(e);
          });
          element.shadowRoot.addEventListener('change', function (e) {
            return functioniseChangeListener(e);
          });
        } else {
          element = element.shadowRoot.querySelector(selector);
          element.shadowRoot.removeEventListener('change', function (e) {
            return functioniseChangeListener(e);
          });
          element.shadowRoot.addEventListener('change', function (e) {
            return functioniseChangeListener(e);
          });
        }
      });
  };

  this.selectShadowDomElement = function (path) {
    let element = null;
    path
      .split('::')
      .filter((item, index) => index > 0)
      .forEach((selector) => {
        if (element === null) {
          element = document.querySelector(selector);
        } else {
          element = element.shadowRoot.querySelector(selector);
        }
      });
    return element;
  };

  this.countChildren = function (parent, getChildrensChildren) {
    var relevantChildren = 0;
    var children = parent.childNodes.length;
    for (var i = 0; i < children; i++) {
      if (parent.childNodes[i].nodeType != 3) {
        if (getChildrensChildren) {
          relevantChildren += this.countChildren(parent.childNodes[i], true);
        }
        relevantChildren++;
      }
    }
    return relevantChildren;
  };

  this.getVerificationIsTooLong = function (cssSelector, xpath) {
    console.log('getVerificationIsTooLong', cssSelector, xpath);
    try {
      let element = null;
      if (xpath && xpath.indexOf('functionize-shadow') > -1) {
        element = this.selectShadowDomElement(xpath);
      }
      if (!element) {
        try {
          element = document.querySelector(cssSelector) || document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        } catch (e) {
          element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        }
      }
      if (element) {
        var count = this.countChildren(element, true);
        return count > 10;
      } else {
        return null;
      }
    } catch (error) {
      console.warn('getVerificationIsTooLong', error);
      return null;
    }
  };

  this.getComputedStyle = function (cssSelector, xpath) {
    console.trace('getComputedStyle');
    try {
      let element = null;
      if (xpath && xpath.indexOf('functionize-shadow') > -1) {
        element = this.selectShadowDomElement(xpath);
      }
      if (!element) {
        try {
          element = document.querySelector(cssSelector) || document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        } catch (e) {
          element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        }
      }
      if (!element) return null;
      let haveDomWalkSelector = false;
      if (element.classList.contains('f-domWalkSelector')) {
        haveDomWalkSelector = true;
        element.classList.remove('f-domWalkSelector');
      }
      console.log('getting computed styles');
      let computedStyle = JSON.stringify(window.getComputedStyle(element, null));
      if (haveDomWalkSelector) {
        element.classList.add('f-domWalkSelector');
      }
      return computedStyle;
    } catch (error) {
      console.warn('getComputedStyle', error);
      return null;
    }
  };

  this.completeAdvancedEditor = function (data) {
    /*
    this.setDomWalkElement({ action: data.action });

    if (window.TCM.advancedEditor.oEditor.getCleanedCode(data.selectorCode).trim() !== '') {
      this.processTestCode({ save: true, strCode: data.selectorCode, target: data.target, path: data.action.path, action: data.action });
    }

    if (window.TCM.advancedEditor.oEditor.getCleanedCode(data.customCode).trim() !== '') {
      window.TCM.advancedEditor.setElementData('code', data.customCode);
      this.processTestCode({ save: true, code: true, strCode: data.selectorCode, target: data.target, path: data.action.path, action: data.action });
    }
    */
    if (data.action.action != 'verify' && data.action.action != 'hover' && data.action.action != 'scroll') {
      if (data.action.action == 'click') {
        setTimeout(function () {
          // Select the element using the CSS selector
          var element = document.querySelector(data.action.cssSelector);

          // Check if the element exists
          if (element) {
            // Trigger a click event on the element
            element.click();
          }
        }, 300);
      }
      return;
    }

    data.origAttributeValues = {};
    if (typeof data.attributeValues !== 'undefined') {
      data.origAttributeValues = JSON.parse(JSON.stringify(data.attributeValues));
    }

    data.attributeValues = {};
    data.attributeOperators = {};

    data.attributes.forEach((attribute) => {
      this.saveAttributeOnAdvanceVerify(attribute, data);
    });

    data.computedAttributes.forEach((attribute) => {
      this.saveComputedOnAdvanceVerify(attribute, data);
    });

    if (!data.attributes.length && !data.computedAttributes.length) {
      window.WS.appendToRecordedData({}, data.action);
    }
  };

  this.saveAttributeOnAdvanceVerify = function (attribute, data) {
    if (typeof attribute.attrKey === 'undefined' || !attribute.attrKey) {
      window.fconsole.log('Attribute key is undefined');
      return;
    }
    attribute.attrKey = attribute.attrKey.toString().trim();
    if (typeof attribute.attrVal === 'undefined') {
      window.fconsole.log('Attribute value is undefined for key: ' + attribute.attrKey);
      return;
    }
    attribute.attrVal = attribute.attrVal.toString().trim();
    if (typeof attribute.attrFunc === 'undefined') {
      attribute.attrFunc = '';
    }
    if (typeof attribute.attrFuncVal === 'undefined' || attribute.attrFunc != 'substring') {
      attribute.attrFuncVal = '';
    }
    if (typeof attribute.attrOpr === 'undefined') {
      window.fconsole.log('Attribute value is undefined for key: ' + attribute.attrKey);
      return;
    }
    attribute.attrOpr = attribute.attrOpr.trim();

    if (attribute.attrOpr == 'rangei' || attribute.attrOpr == 'rangef') {
      // alert(attrVal);
      var attrValSplit = attribute.attrVal.split('-');
      var invalidRange = false;
      if (typeof attrValSplit[0] !== 'undefined') {
        var firstVal = attrValSplit[0].trim();
        if (Number(firstVal) != firstVal) {
          invalidRange = true;
        }
      } else {
        invalidRange = true;
      }
      if (typeof attrValSplit[1] !== 'undefined') {
        var secondVal = attrValSplit[1].trim();
        if (Number(secondVal) != secondVal) {
          invalidRange = true;
        }
      } else {
        invalidRange = true;
      }
      if (invalidRange) {
        alert('Invalid Range');
        return;
      }
    }

    // if (attribute.checked) {
    var attrData = {};
    attrData['verifyattr_' + attribute.attrKey] = attribute.attrOpr + '#func#' + attribute.attrVal;
    if (attribute.step) {
      attrData['verifyattr_' + attribute.attrKey] = attribute.attrOpr + '#func#' + attribute.step;
    }
    if (attribute.attrFunc) {
      attrData['verifyattr_' + attribute.attrKey] += '|FUNCSTEP|' + attribute.attrFunc;
    }
    if (attribute.attrFuncVal) {
      attrData['verifyattr_' + attribute.attrKey] += '|FUNCSTEP|' + attribute.attrFuncVal;
    }
    window.fconsole.log('Adding ' + attribute.attrKey + ' ' + attribute.attrVal);
    try {
      for (const [key, value] of Object.entries(attrData)) {
        attrData[key] = encodeURIComponent(value);
      }
    } catch (e) {}
    window.WS.appendToRecordedData(attrData, data.action);
    // } else {
    // we need to check if it has been checked before….
    // window.fconsole.log('Checking orig key ' + attribute.attrKey + ': ' + data.origAttributeValues[attribute.attrKey]);
    // if (typeof data.origAttributeValues[attribute.attrKey] != 'undefined') {
    //  window.WS.removeFromRecordedData('verifyattr_' + attribute.attrKey);
    // }
    // }
  };

  this.saveComputedOnAdvanceVerify = function (attribute, data) {
    if (typeof attribute.attrKey === 'undefined' || !attribute.attrKey) {
      window.fconsole.log('Attribute key is undefined');
      return;
    }
    attribute.attrKey = attribute.attrKey.trim();
    if (typeof attribute.attrVal === 'undefined') {
      window.fconsole.log('Attribute value is undefined for key: ' + attribute.attrKey);
      return;
    }
    attribute.attrVal = attribute.attrVal.trim();
    if (typeof attribute.attrOpr === 'undefined') {
      window.fconsole.log('Attribute value is undefined for key: ' + attribute.attrKey);
      return;
    }
    attribute.attrOpr = attribute.attrOpr.trim();

    if (attribute.attrOpr == 'rangei' || attribute.attrOpr == 'rangef') {
      var attrValSplit = attribute.attrVal.split('-');
      var invalidRange = false;
      if (typeof attrValSplit[0] !== 'undefined') {
        var firstVal = attrValSplit[0].trim();
        if (Number(firstVal) != firstVal) {
          invalidRange = true;
        }
      } else {
        invalidRange = true;
      }
      if (typeof attrValSplit[1] !== 'undefined') {
        var secondVal = attrValSplit[1].trim();
        if (Number(secondVal) != secondVal) {
          invalidRange = true;
        }
      } else {
        invalidRange = true;
      }
      if (invalidRange) {
        alert('Invalid Range');
        return;
      }
    }

    // if (attribute.checked) {
    var attrData = {};
    attrData['verifyattr_c_' + attribute.attrKey] = attribute.attrOpr + '#func#' + attribute.attrVal;
    if (attribute.step) {
      attrData['verifyattr_c_' + attribute.attrKey] = attribute.attrOpr + '#func#' + attribute.step;
    }
    if (attribute.attrFunc) {
      attrData['verifyattr_c_' + attribute.attrKey] += '|FUNCSTEP|' + attribute.attrFunc;
    }
    if (attribute.attrFuncVal) {
      attrData['verifyattr_c_' + attribute.attrKey] += '|FUNCSTEP|' + attribute.attrFuncVal;
    }
    window.fconsole.log('Adding ' + attribute.attrKey + ' ' + attribute.attrVal);
    try {
      for (const [key, value] of Object.entries(attrData)) {
        attrData[key] = encodeURIComponent(value);
      }
    } catch (e) {}
    window.WS.appendToRecordedData(attrData, data.action);
  };

  this.getRelatedElement = function () {
    window.TCM.setRelatedElementFlag(true);
    this.collapse();
    return true;
  };

  this.stopRelatedElement = function () {
    window.TCM.setRelatedElementFlag(false);
    // window.TH.clearAll(true);
    window.WS.removeHighlights();
  };

  this.setRelatedElement = function (data) {
    var currentElementForRelated = this.currentElementForRelated;
    var functioniseAttrstepvalue = data.functionise_attrstepvalue;
    var functioniseAttrstepattribute = data.functionise_attrstepattribute;
    var functioniseAttrstepfunction = data.functionise_attrstepfunction;
    var functioniseAttrstepoValue = data.functionise_attrstepoValue;

    if (!functioniseAttrstepvalue || !functioniseAttrstepattribute) {
      return false;
    }

    var changeSelector = null;

    try {
      // Assuming window.WU.getElementTreeXPath and window.WS.targetElement are available and work correctly
      var element = document.querySelector(currentElementForRelated);
      var lastActionxpath5 = window.WU.getElementTreeXPath(element, false, false).split('/');
      console.log('targetting in related element'); // Replace with window.fconsole.log if needed

      changeSelector = window.WS.targetElement(e.target); // TODO: check this event isn't set
      var changeSelectorxpath5 = changeSelector.xpath5.split('/');
      var commonTag = '';
      var findStr = '';
      var closestSelecter = '';

      lastActionxpath5.forEach((value, index) => {
        if (commonTag) {
          if (findStr) findStr += ' > ';
          findStr += this.formatSelectorElement(value);
        } else {
          if (value) {
            if (closestSelecter) closestSelecter += ' > ';
            closestSelecter += this.formatSelectorElement(value);
          }
        }
        if (value !== changeSelectorxpath5[index] && !commonTag) {
          commonTag = this.formatSelectorElement(changeSelectorxpath5[index - 1], true);

          findStr += ' > ';
          findStr += this.formatSelectorElement(value);
        }
      });
    } catch (err) {
      // Handle error
    }

    var insText = '[functionizeVariable::' + (parseInt(functioniseAttrstepoValue) + 1) + '::' + functioniseAttrstepattribute;
    if (functioniseAttrstepfunction) {
      insText += '::' + functioniseAttrstepfunction;
    }
    insText += ']';

    var actionElement = document.querySelector(currentElementForRelated).tagName.toLowerCase();

    // Find the first matching element
    function findElementContainingText(selector, text) {
      var elements = document.querySelectorAll(selector);
      for (var i = 0; i < elements.length; i++) {
        if (elements[i].textContent.includes(text)) {
          return elements[i];
        }
      }
      return null;
    }

    var jSelector = findElementContainingText(actionElement, insText);

    if (commonTag) {
      jSelector = jSelector.closest(commonTag);
    }

    if (findStr) {
      jSelector = jSelector.querySelector(findStr);
    }

    var jString = "var fElement = document.querySelector('" + actionElement + ":contains('" + insText + "')')";
    if (commonTag) {
      jString += ".closest('" + commonTag + "')";
    }
    if (findStr) {
      jString += ".querySelector('" + findStr + "')";
    }

    jString += ';\nreturn fElement;';

    try {
      changeSelector = window.WS.targetElement(jSelector);
    } catch (err) {
      // Handle error
    }

    return jString;
  };

  this.getElementAttributesSteps = function (data) {
    var attributesSteps = {};
    if (data.attributes) {
      var WSRecordedData = data.recordedData;

      data.attributes.forEach((attribute) => {
        attributesSteps[attribute] = [];

        WSRecordedData.forEach((value, index) => {
          data.attributeotheroperators.forEach((value1, index1) => {
            if (index1 == 'src') {
              index1 = 'attr_src';
            }
            if (index1 == 'href') {
              index1 = 'attr_href';
            }
            if (index1 == 'style') {
              index1 = 'attr_style';
            }
            if ((attribute != 'href' && index1 != 'attr_href') || (attribute == 'href' && index1 != 'text')) {
              if (value[index1]) {
                if (attribute == 'style' && index1 == 'text') {
                } else {
                  var substroValue = null;
                  if (
                    typeof window.TCM.runtimeReplacementStrings[value.actionId] !== 'undefined' &&
                    typeof window.TCM.runtimeReplacementStrings[value.actionId][index1] !== 'undefined' &&
                    window.TCM.runtimeReplacementStrings[value.actionId][index1]
                  ) {
                    substroValue = window.TCM.runtimeReplacementStrings[value.actionId][index1];
                    substroValue = substroValue.substr(0, 60);
                    attributesSteps[attribute].push({
                      value: value.actionId + '|FUNCSTEP|' + index1,
                      oValue: window.TCM.runtimeReplacementStrings[value.actionId][index1],
                      name: 'Step ' + (parseInt(index) + 1) + ' - ' + substroValue,
                    });
                  } else if (typeof value.actualstring !== 'undefined' && value.actualstring && index1 == 'value') {
                    substroValue = value.actualstring;
                    substroValue = substroValue.substr(0, 60);
                    attributesSteps[attribute].push({
                      value: value.actionId + '|FUNCSTEP|' + index1,
                      oValue: value.actualstring,
                      name: 'Step ' + (parseInt(index) + 1) + ' - ' + substroValue,
                    });
                  } else {
                    substroValue = value[index1];
                    substroValue = substroValue.substr(0, 60);
                    attributesSteps[attribute].push({
                      value: value.actionId + '|FUNCSTEP|' + index1,
                      oValue: value[index1],
                      name: 'Step ' + (parseInt(index) + 1) + ' - ' + substroValue,
                    });
                  }
                }
              }
            }
          });
        });
      });
    }
    return attributesSteps;
  };

  this.getAttributeSteps = function (attrName) {
    var attributeSteps = [];
    if (!attrName) {
      var lastAction = window.WS.recordedData[window.WS.recordedData.length - 1];
      attrName = '';
      if (lastAction.text) {
        attrName = 'text';
      }
      if (lastAction.value) {
        attrName = 'value';
      }
      if (!attrName) {
        attrName = lastAction.element;
      }
    }
    if (attrName) {
      var WSRecordedData = window.WS.recordedData;
      WSRecordedData.forEach((value, index) => {
        if (value.action == 'verify' || value.action == 'input') {
          attributeSteps.push({
            value: value.actionId,
            oValue: parseInt(index),
            name: `Step ${parseInt(index) + 1} - ${value.action}`,
          });
          try {
            this.globalStepAttribute[index] = {};
          } catch (err) {}
          for (const index1 in value) {
            if (value1 && index1 != 'actionId') {
              this.globalStepAttribute[index][index1] = value1;
            }
          }
        }
      });
    }
    return attributeSteps;
  };

  this.getAttributeOptions = function (data) {
    var attt = window.WS.recordedData[data.oValue];
    var attributeOptions = [];
    this.orderKeys(attt);
    Object.keys(attt).forEach(function (index) {
      var selectedText = '';
      var value = attt[index];
      var oValue = value;

      if (
        typeof window.TCM.runtimeReplacementStrings[data.value] !== 'undefined' &&
        typeof window.TCM.runtimeReplacementStrings[data.value][index] !== 'undefined' &&
        window.TCM.runtimeReplacementStrings[data.value][index] != null
      ) {
        oValue = window.TCM.runtimeReplacementStrings[data.value][index];
      }

      if (typeof window.TCM.variablePreviousSelection[1] !== 'undefined' && window.TCM.variablePreviousSelection[1] && window.TCM.variablePreviousSelection[1] == index) {
        selectedText = 'selected';
      }

      if (typeof attt.actualstring !== 'undefined' && attt.actualstring && index == 'value') {
        oValue = attt.actualstring;
      }

      attributeOptions.push({
        value: index,
        oValue: oValue,
        selectedText: selectedText,
        name: index,
      });
    });
    return attributeOptions;
  };

  this.orderKeys = function (obj, expected) {
    var keys = Object.keys(obj).sort(function keyOrder(k1, k2) {
      if (k1 < k2) return -1;
      else if (k1 > k2) return +1;
      else return 0;
    });
    var i;
    var after = {};
    for (i = 0; i < keys.length; i++) {
      after[keys[i]] = obj[keys[i]];
      delete obj[keys[i]];
    }
    for (i = 0; i < keys.length; i++) {
      obj[keys[i]] = after[keys[i]];
    }
    return obj;
  };

  // TODO: this can probably be removed.
  this.addVisualCheck = function (data) {
    var attrData = {};
    attrData['computed_vision_based_validation'] = 1;
    var comparisonType = data.visual_comparison_type;
    attrData['visual_comparison_type'] = comparisonType;
    attrData['change_percentage_allowed'] = data.visual_check_comparison_stepnumber_variance || 0;
    if (comparisonType == 'stepcomparison') {
      var visualCheckComparisonStepnumberOperator = data.visual_check_comparison_stepnumber_operator;
      var visualCheckComparisonStepnumber = data.visual_check_comparison_stepnumber;
      var visualCheckComparisonStepnumberVariance = data.visual_check_comparison_stepnumber_variance;

      if (visualCheckComparisonStepnumberVariance) {
        visualCheckComparisonStepnumberVariance = '|FUNCSTEP|' + data.visual_check_comparison_stepnumber_variance;
      } else {
        visualCheckComparisonStepnumberVariance = '';
      }
      attrData['visual_comparison_match'] =
        visualCheckComparisonStepnumberOperator + '|FUNCSTEP|' + visualCheckComparisonStepnumber + visualCheckComparisonStepnumberVariance ||
        'undefined' + '|FUNCSTEP|' + data.visual_check_comparison_stepnumber_variance;
    }

    window.WS.appendToRecordedData(attrData);
  };

  this.addNote = function (data) {
    var functioniseNotepadArea = data.functionise_notepad_area;
    if (functioniseNotepadArea) {
      var attrData = {};
      attrData['custom_description'] = functioniseNotepadArea;
      window.WS.appendToRecordedData(attrData);
      return true;
    } else {
      return false;
    }
  };

  this.backForward = function (type) {
    try {
      var navigateStateType = type || 'forward';
      var elementCode = 'window.history.' + navigateStateType + '();';
      var data = {
        action: 'customcode',
        url: window.WS.locUrl,
        timestamp: window.WU.getTime(),
        elementCode: elementCode,
        custom_description: 'Browser ' + navigateStateType + ' button clicked.',
      };
      window.focus();
      self.port.emit('message', {
        obj: 'TCM',
        call: type == 'back' ? 'goBackward' : 'goForward',
        forMaster: true,
      });
      window.WS.getRecordingData(data);
      setTimeout(elementCode, 1);
      // editorObj.processSubmit();
    } catch (err) {}
  };

  this.checkForAMissingSelector = function (type) {
    var currentInstructionStep = window.WU.store('currentInstructionStep');
    return !!(typeof currentInstructionStep !== 'undefined' && currentInstructionStep != 'undefined' && currentInstructionStep);
  };

  this.missingSelector = function () {
    var currentInstructionStep = window.WU.store('currentInstructionStep');
    if (typeof currentInstructionStep !== 'undefined' && currentInstructionStep != 'undefined' && currentInstructionStep) {
      if (typeof window.WS.recordedData[0]['missingSelector'] === 'undefined') {
        window.WS.recordedData[0]['missingSelector'] = [];
      }
      window.WS.recordedData[0]['missingSelector'].push(currentInstructionStep);
    }
    // editorObj.processSubmit();
  };

  this.wrongSelector = function () {
    var currentInstructionStep = window.WU.store('currentInstructionStep');
    if (typeof currentInstructionStep !== 'undefined' && currentInstructionStep != 'undefined' && currentInstructionStep) {
      if (typeof window.WS.recordedData[0]['wrongSelector'] === 'undefined') {
        window.WS.recordedData[0]['wrongSelector'] = [];
      }
      window.WS.recordedData[0]['wrongSelector'].push(currentInstructionStep);
    }
    // editorObj.processSubmit();
  };

  this.pauseRecording = function (pause) {
    if (window.WS.isIframe) {
      window.TCM.isPaused = pause;
      return;
    }
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('pauseRecording', pause);
    window.TCM.setPauseCoverer(pause);
    window.TCM.isPaused = pause;
  };

  this.navigateToUrl = function (url) {
    window.location.replace(url);
  };

  this.setPauseCoverer = function (on) {
    if (typeof on === 'undefined') on = true;
    if (on) {
      // window.WU.setPauseCoverer();
      window.TCM.ensureVisibility();
    } else {
      window.WU.removePauseCoverer();
    }
  };

  this.setPendingActionCover = function () {
    console.trace('setPendingActionCover');
    if (!window.WS.isIframe) {
      window.WU.setPendingActionCoverer();
      window.TCM.ensureVisibility();
    }
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('setPendingActionCover');
  };

  this.removePendingActionCover = function () {
    console.trace('removePendingActionCover');
    if (!window.WS.isIframe) {
      window.WU.removePendingActionCoverer();
    }
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('removePendingActionCover');
  };

  this.setLoading = function (state) {
    self.port.emit('message', {
      obj: 'f-vue',
      call: 'setLoadingValue',
      arguments: state,
      forMaster: true,
    });
  };

  this.setLoadingValue = function (state) {
    this.isLoading = state;
    if (state) {
      document.body.style.cursor = 'wait';
    } else {
      document.body.style.cursor = 'default';
    }
    if (window.TCM.isMaster) {
      var command = { obj: 'TCM', call: 'setLoadingValue', arguments: state };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  this.saveSettings = function () {
    window.WS.saveSettings();
  };

  //****** Advanced editor tools end here **************************/
  this.checkAccess = function () {
    // Construct the URL
    var checkUrl = 'https://' + window.WS.wbHost + '/sites/admin/hasaccesstestcase';

    // Perform the fetch request
    fetch(checkUrl + '?id=' + encodeURIComponent(window.wbDid))
      .then((response) => {
        // Check if the response is OK
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        // Handle the JSON data
        if (data.actionResult === 'SUCCESS') {
          window.TCM.enable('startstop');
          if (typeof data.actionLimit !== 'undefined') {
            window.WS.actionLimit = parseInt(data.actionLimit);
          }
        } else {
          window.functionizeVex.dialog.alert(data.actionMsg);
        }
      })
      .catch((error) => {
        // Handle errors
        window.functionizeVex.dialog.alert('Unexpected error occurred: ' + error.message);
      });
  };

  this.placeTop = function () {
    //we now hard code for top level z-index...
  };

  this.adjustTop = function (zi) {
    // Return a very high number if needed
    // return 2147483647;

    // Get the current time
    var d = new Date();
    var now = d.getTime();
    // Allow running this no more than every 1500 milliseconds
    // if (window.TCM.lastAdjusted > now - 1500) return;

    // Get the z-index of the top element
    var topElement = document.querySelector('#f-functionise-tc-manager');
    var parentElement = topElement ? topElement.parentElement : null;
    var topZ = parentElement ? parseInt(window.getComputedStyle(parentElement).zIndex, 10) : 0;
    if (isNaN(topZ)) topZ = 0;

    // Get the z-index of the message box
    var messageBox = document.querySelector('.f-functionise-messagebox');
    var topZ1 = messageBox ? parseInt(window.getComputedStyle(messageBox).zIndex, 10) : 0;
    if (isNaN(topZ1)) topZ1 = 0;

    if (zi >= topZ || zi >= topZ1) {
      this.currentZIndex = zi + 2;

      // Select all relevant elements
      var elements = document.querySelectorAll('.' + window.fUniqPrefix + ', .' + window.fUniqPrefix + '-panel, .' + window.fUniqPrefix + '-panel *');

      // Convert NodeList to Array for easier manipulation
      elements = Array.from(elements);

      // Filter out elements with specific classes or IDs
      elements = elements.filter((element) => !element.classList.contains(window.fUniqPrefix + '-coverer') && !element.id.includes(window.fUniqPrefix + '-drag-coverer'));

      // Set styles for each element
      elements.forEach((element) => {
        element.style.zIndex = this.currentZIndex;
        element.style.visibility = 'visible';

        // Set visibility for hidden children
        Array.from(element.children).forEach((child) => {
          if (child.style.display === 'none') {
            child.style.visibility = 'visible';
          }
        });
      });
      zi++;
    } else {
      zi = topZ;
      if (topZ1 > topZ) {
        zi = topZ1;
      }
    }

    window.TCM.lastAdjusted = now;
  };

  //Mouseovers stigger this call to see if the recorder is covered by any chance…
  this.checkTopZIndex = function (e) {
    if (this.currentZIndex === 1) {
      this.currentZIndex = this.maxZIndex - 10; // Safety setting
    }

    var element = e instanceof Element ? e : document.querySelector(e);
    var currentZIndex = parseInt(window.getComputedStyle(element).zIndex, 10);

    if (this.currentZIndex > this.maxZIndex - 100) {
      // We will lower the zIndex
      if (currentZIndex >= this.currentZIndex - 10) {
        if (window.WS.isFunctioniseElement(element)) return;

        if (this.currentZIndex < 10) {
          this.currentZIndex = 10;
        }

        window.fconsole.log('Lowering z-index to: ' + (this.currentZIndex - 10));
        element.style.zIndex = this.currentZIndex - 10;
      }
    } else {
      this.adjustTop();
    }
  };

  this.close = function () {
    if (window.TCM.recording) {
      window.TCM.cancelTask();
    }

    if (window.WS.settings.hideWindowOnClose) {
      //we hide the tool all together
      window.WU.cookie('functioniseTesting', 'off', { expires: 0, path: '/' });
      window.WU.cookie('functionise', '', { expires: 0, path: '/' });
    }
  };

  //makes sure nothing set's our window to display none
  this.ensureVisibility = function () {
    this.adjustTop(window.WU.getTopZindex());
  };

  /**
   * Updates the action counter display in the UI
   * @param {number} actionCount - The current action count to display
   */
  this.showActionCounter = function (actionCount) {
    window.fconsole.log('Showing Action counter is called: ' + window.TCM.isController + ' with action count: ' + actionCount);
    if (!window.TCM.isMaster && !window.TCM.isController) return;

    if (window.TCM.isMaster && !window.TCM.isController) {
      //we need to pass this down...
      var method = 'showActionCounter';
      var param = window.WS.recordedData.length;
      window.TCM.sendCallToDescendants(method, param);
      return;
    }

    window.fconsole.log('Showing Action counter ' + window.WS.doRecording + ' ' + actionCount);

    if (typeof actionCount == 'undefined') actionCount = window.WS.recordedData.length;
  };

  /**
   * Resets the action counter display
   * This is an alias for showActionCounter() without parameters
   */
  this.hideActionCounter = function () {
    this.showActionCounter();
  };

  /**
   * Checks if the document has a doctype and shows a warning if it doesn't
   * @private
   */
  this.checkDoctype = function () {
    if (window.document.doctype == null && !window.functionizeIsSeleniumTest) {
      // no doctype declared, so we need to warn the user about it...
      self.port.emit('message', {
        obj: 'TCM',
        call: 'showDialog',
        arguments:
          'You do not have a doctype declared on your page. This may lead to unpredictable results during your modeling and during runtime.\n\nWe recommend that you add a valid doctype to your site before trying to record your test cases.',
        forVue: true,
      });
    }
  };

  /**
   * Initializes a task after checking doctype
   */
  this.preinitTask = function () {
    this.checkDoctype();
    this.initTask();
  };

  /**
   * Initializes a task with optional data parameters
   * @param {Object} data - Configuration data for the task
   */
  this.initTask = function (data = {}) {
    window.fconsole.log('new inittask');
    let withReload = false;
    if (data.clearStorage || data.clearCookies) {
      withReload = true;
    }

    this.checkDoctype();
    this.startTask(withReload);
  };

  this.removeCookie = function (cookieHost, cookieName, cookiePath) {
    window.fconsole.log('fApp ' + window.functioniseApp);
    if (window.functioniseApp) {
      this.removeCookieInJs(cookieHost, cookieName, cookiePath);
      return;
    }

    window.fconsole.log('Remove Cookie called : ' + cookieName);
    var data = {
      call: 'deleteCookie',
      name: cookieName,
      url: cookieHost,
      path: cookiePath,
      all: false,
    };
    window.TCM.sendCommandToMaster(data);
  };

  this.removeCookieInJs = function (cookieHost, cookieName) {
    window.fconsole.log('Remove Cookie called : ' + cookieName);
    window.WU.cookie(cookieName, '', { expires: 0, path: '/' });
  };

  //starts the test
  this.startTask = function (withReload) {
    if (window.WS.locUrl.indexOf('agvancesky') > 0) {
      if (!window.WS.isIframe) {
        if (window.WS.locUrl != document.location.href) {
          window.WS.locUrl = document.location.href;
        }
      }
    }

    if (typeof withReload == 'undefined')
      //if cookies were deleted we reload the page
      withReload = false;

    if (!window.TCM.initialize) {
      throw new Error('Please call init first');
    }
    window.fconsole.log('startTask is called');
    //we have accepted cookies feature off now…   This looks like a smart thing to have at all times as a reminder...

    //set testing cookie for coverers
    if (window.TCM.isMaster) window.WU.cookie('functioniseTesting', 'on');

    window.TCM.setRecording(true);
    if (!withReload) window.TCM._startCallback();
    var command = {};
    if (window.TCM.isMaster) {
      command = { obj: 'TCM', call: 'startTask' };
      window.TCM.sendCommandToMaster(command);
    } else {
      window.fconsole.log('Start Task is sent to Master window');
      command = { obj: 'TCM', call: 'startTask' };
      window.TCM.sendCommand(command, window.parent);
    }

    if (withReload) {
      window.fconsole.log('Page reload called...');
      window.WU.setSaveCoverer();
      location.reload();
    }
  };

  this.stopTask = function (data) {
    window.fconsole.log('new stopTask');
    window.fconsole.log(data);
    let doStop = data.stop;

    window.fconsole.log(doStop);

    if (!this.initialize) {
      throw new Error('Please call init first');
    }

    if (doStop && window.TCM.isStopping)
      // we are already stopping...
      return;

    // window.TH.clearAll();
    window.TCM.setStopState(doStop);
    window.TCM.disable('startstop');
    // we no longer force verify at the end of the case...
    if (!doStop) window.TCM.startVerifying();

    window.TCM.setRecording(false);
    if (window.TCM.isStopping) {
      // we no longer force the verification actions below…
      window.TCM.createFormWindow();
    }
  };

  this.startSettings = function () {
    // window.TH.clearAll();
    window.TCM.setStopState(false);
    window.TCM.disable('startstop');

    window.TCM.setRecording(false);
    //open the advanced panel
    window.TCM.startEdit(null);
  };

  this.triggerTimeout = function () {
    window.fconsole.log('Timeout is triggered');
    if (window.WS.doRecording > 0) window.functionizeVex.dialog.alert('Ooops.   Looks like your test has timed out...');
  };

  this.confirmCancelTask = function () {
    var confirmCancelTaskStr = '';
    if (typeof window.WS.mturkWorkerId != 'undefined' && window.WS.mturkWorkerId) {
      //|| (typeof window.WS.testJobId != 'undefined' && window.WS.testJobId)) {
      confirmCancelTaskStr = '<div style="line-height:22px">Are you sure you want to cancel this modeling? You will have to restart this modeling from the hit details page.</div>';
    } else {
      if (typeof window.functionizeEditMode != 'undefined' && typeof functionizeEditTestId != 'undefined') {
        confirmCancelTaskStr = 'Are you sure you want to cancel the Live Edit?<br/><br/>Caution: Your work will be lost if you cancel this Live Edit.';
        confirmCancelTaskStr += "<div class='cancelRecordingConfirmation'><input type='radio' name='confirmAction' value='dashboard'><span>Return to the dashboard</span><br/>";
        confirmCancelTaskStr += "<input type='radio' name='confirmAction' checked='checked' value='beginning'><span>Restart this Live Edit from the beginning</span><br/>";

        confirmCancelTaskStr += "<input type='radio' name='confirmAction' value='stay'><span>Do not cancel the Live Edit and continue modeling</span><br/>";
        confirmCancelTaskStr += "<input type='radio' name='confirmAction' value='returnbacktotestcase'><span>Return back to test case</span></div>";
      } else {
        confirmCancelTaskStr = 'Are you sure you want to cancel this test case?<br/><br/>Caution: Your work will be lost if you cancel this test case.';
        if (typeof window.WS.testJobId != 'undefined' && window.WS.testJobId) {
          confirmCancelTaskStr +=
            "<div class='cancelRecordingConfirmation'><input type='radio' name='confirmAction' value='dashboardturk'><span>Return to Test Creation Wizard</span><br/>";
        } else {
          confirmCancelTaskStr += "<div class='cancelRecordingConfirmation'><input type='radio' name='confirmAction' value='dashboard'><span>Return to the dashboard</span><br/>";
        }
        confirmCancelTaskStr += "<input type='radio' name='confirmAction' checked='checked' value='beginning'><span>Restart this test case from the beginning</span><br/>";

        if (typeof window.WS.testJobId != 'undefined' && window.WS.testJobId) {
        } else {
          confirmCancelTaskStr += "<input type='radio' name='confirmAction' value='stay'><span>Do not cancel and continue modeling</span><br/>";
          confirmCancelTaskStr += "<input type='radio' name='confirmAction' value='stophere'><span>Start a new test case from this page</span>";
        }
        if (typeof window.functionizeEditMode != 'undefined' && typeof functionizeEditTestId != 'undefined') {
          confirmCancelTaskStr += "<br/><input type='radio' name='confirmAction' value='returnbacktotestcase'><span>Return back to test case</span></div>";
        }
      }
    }
    confirmCancelTaskStr += '</div>';
  };

  this.cancelTask = function (source, removeCancelMsg) {
    if (typeof source === 'undefined') source = 'self';
    if (!window.TCM.initialize) {
      throw Error('Please call init first');
    }

    window.TCM.setRecording(false);

    if (window.TCM.isMaster)
      // we call this on the master level...
      window.WS.cancelTest();

    window.TCM.finalizeTest();
    var command = { obj: 'TCM', call: 'cancelTask' };
    if (window.TCM.isMaster) {
      window.fconsole.log('sending cancel task to master');
      window.TCM.sendCommandToMaster(command);
    } else if (window.TCM.isController && source == 'self') {
      // control sub window...
      window.fconsole.log('Start Task is sent to Master window');
      command = { obj: 'TCM', call: 'cancelTask' };
      window.TCM.sendCommand(command, window.parent);
    }
  };

  /**
   * Calls the function to open db explorer action in the injected script.
   * @param {Boolean} functionise_dbexplorer_confirm Open in new page.
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.createApiAction = function (data) {
    window.fconsole.log('Creating api call action');
    if (data.functionise_apicall_confirm) {
      window.WS.createApiAction(true, data.url);
    } else {
      window.WS.createApiAction(false, data.url);
    }
    // editorObj.processSubmit();
  };

  /**
   * Calls the function to open db explorer action in the injected script.
   * @param {Boolean} functionise_dbexplorer_confirm Open in new page.
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.createDBExplorerAction = function (data) {
    window.fconsole.log('Creating DB explorer action');
    if (data.functionise_dbexplorer_confirm) {
      window.WS.createDBExplorerAction(true, data.url);
    } else {
      window.WS.createDBExplorerAction(false, data.url);
    }
    // editorObj.processSubmit();
  };

  /**
   * Calls the function to open email action in the injected script.
   * @param {Boolean} functionise_emailreader_confirm Open in new page.
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.createEmailreceiveAction = function (data) {
    console.log('createEmailreceiveAction', data);
    window.fconsole.log('Creating email recive action');
    if (data.functionise_emailreader_confirm) {
      window.WS.createEmailreceiveAction(true, data.url);
    } else {
      window.WS.createEmailreceiveAction(false, data.url);
    }
    // editorObj.processSubmit();
  };

  /**
   * Calls the function to open file viewer in the injected script.
   * @param {Boolean} functionise_fileviewer_confirm Open in new page.
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.createFileViewerAction = function (data) {
    window.fconsole.log('Creating email recive action');
    if (data.functionise_fileviewer_confirm) {
      window.WS.createFileViewerAction(true, data.url);
    } else {
      window.WS.createFileViewerAction(false, data.url);
    }
    // editorObj.processSubmit();
  };

  /**
   * Calls the function to navigate action in the injected script.
   * @param {String} functionise_navigate_action_url Url to navigate.
   * @param {Boolean} functionise_navigate_confirm Open in new page.
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.createOpenAction = function (data) {
    window.fconsole.log('Creating navigate action');
    if (data.functionise_navigate_confirm) {
      window.WS.createOpenAction(data.functionise_navigate_action_url, true);
    } else {
      window.WS.createOpenAction(data.functionise_navigate_action_url);
    }
    // editorObj.processSubmit();
  };

  /**
   * Calls the function to add sms action in the injected script.
   * @param {*} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.createSMSreceiveAction = function (data) {
    console.log('createSMSreceiveAction', data);
    if (data.functionise_smsreceive_confirm) {
      window.WS.createSMSreceiveAction(true, data.url);
    } else {
      window.WS.createSMSreceiveAction(false, data.url);
    }
    // editorObj.processSubmit();
  };

  /**
   * Calls the function to add not on page action in the injected script.
   * @param {*} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.createNotOnPageAction = function (data) {
    window.fconsole.log('Creating not on page action');
    var notOnPage = {
      action: 'notonpage',
      url: window.WS.locUrl,
      timestamp: window.WU.getTime(),
      element: data.notonthePageelement,
      attribute: data.notonthePageattribute,
      operator: data.notonthePageoperator,
      value: data.notonthePagevalue,
      selector: data.notonthePageselector,
    };
    window.WS.getRecordingData(notOnPage);
    // editorObj.processSubmit();
    return true;
  };

  this.openSaveVariable = function () {
    if (window.TCM.isVerifying) {
      self.port.emit('message', {
        obj: 'TCM',
        call: 'openSaveVariable',
        arguments: {
          text: window.TCM.advancedEditor.oEditor.currentElement.text,
          value: window.TCM.advancedEditor.oEditor.currentElement.value,
          html: window.TCM.advancedEditor.oEditor.currentElement.html,
        },
        forVue: true,
      });
    }
  };

  /**
   * Calls the function to save variable action in the injected script.
   * @param {*} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.saveVariable = function (data) {
    var isVerifying = window.TCM.isVerifying;
    var attrData = {};
    if (isVerifying) {
      attrData['projectVariableSave_name'] = data.saveVariableName;
      attrData['projectVariableSave_attribute'] = data.saveVariableAttribute;
      window.WS.appendToRecordedData(attrData);
      // if (typeof window.WS.currentElement[data.saveVariableAttribute] != 'undefined') {
      // self.port.emit('message', {
      //  obj: 'TCM',
      //  call: 'saveVariable',
      //   arguments: data,
      //  forVue: true,
      // });
      // var projectVariableSaveCookieVariable = 'projectVariableSave_' + window.projectId + '_' + data.saveVariableName; // +"_"+saveVariableAttribute;
      // var projectVariableSaveCookieVariableValue = window.WS.currentElement[data.saveVariableAttribute];
      // window.WU.store(projectVariableSaveCookieVariable, projectVariableSaveCookieVariableValue);
      // window.WU.cookie(projectVariableSaveCookieVariable, projectVariableSaveCookieVariableValue);
      // }
    } else {
      window.fconsole.log('Creating save variable action');
      attrData['action'] = 'projectVariable';
      attrData['timestamp'] = window.WU.getTime();
      attrData['url'] = window.WS.locUrl;
      attrData['projectVariableSave_name'] = data.saveVariableName;
      // attrData['projectVariableSave_attribute'] = data.saveVariableAttribute;
      attrData['projectVariableSave_value'] = data.saveVariableValue;
      attrData['projectVariableSave_operation'] = 'save';
      window.WS.getRecordingData(attrData);
      // editorObj.processSubmit();
    }
  };

  /**
   * Calls the function to add page variable action in the injected script.
   * @param {*} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.loadVariable = function (data) {
    var attrData = {};
    attrData['projectVariableLoad_name'] = data.loadVariableName;
    attrData['projectVariableLoad_attribute'] = data.loadVariableAttribute;
    attrData['projectVariableLoad_operation'] = data.loadVariableOperation;
    attrData['action'] = 'input';

    /* if we're not verifying, we dont have an element or action
     attrData['action'] = 'projectVariable';
     attrData['timestamp'] = window.WU.getTime();
     attrData['url'] = window.WS.locUrl;
     window.WS.getRecordingData(attrData);
     return;
    */

    var isVerifying = window.TCM.isVerifying;
    if (isVerifying) {
      window.WS.appendToRecordedData(attrData);
    } else {
      try {
        attrData['action'] = 'projectVariable';
        if (data.loadVariableOperation == 'load' && data.loadVariableValue) {
          window.TCM.clickAttributeEditorValue['actualstring'] = data.loadVariableValue;
          window.TCM.clickAttributeEditorValue['filledValue'] = data.loadVariableValue;

          window.TCM.clickAttributeEditorValue['filledOpr'] = 'LOAD';
          window.TCM.flagshiftclickinput = true;
        }
      } catch (err) {}
    }

    if (data.loadVariableOperation == 'load') {
      try {
        if (data.loadVariableValue) {
          var element = document.querySelector(window.TCM.advancedEditor.oEditor.currentElement.cssSelector);

          if (element) {
            switch (data.loadVariableAttribute) {
              case 'text':
                element.textContent = data.loadVariableValue;
                break;
              case 'value':
                if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
                  element.value = data.loadVariableValue;
                }
                break;
              case 'html':
                element.innerHTML = data.loadVariableValue;
                break;
            }
          }
        }
      } catch (err) {
        // Handle or log the error as needed
      }
    }
    // editorObj.processSubmit();
  };

  this.createWaitAction = function (data) {
    window.fconsole.log('Creating wait action');
    window.WS.createWaitAction(data);
    // editorObj.processSubmit();
  };

  /**
   * Calls the function to add page variable action in the injected script.
   * @param {*} data
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.createpageVariableAction = function (data) {
    window.fconsole.log('Creating page variable action');
    window.WS.createpageVariableAction(data.inputvar, data.customDescription, data.outcomeOverride);
    // editorObj.processSubmit();
    return true;
  };

  this.createResourceVariableAction = function (data) {
    window.WS.createResourceVariableAction(data.inputvar);
    // editorObj.processSubmit();
    return true;
  };

  /**
   * Calls the function to add page variable action in the injected script.
   * @param {*} pageVariableKeyword
   * @see {@link src/background/woker/uiMessageHandler/actions.js} Previous step in the flow.
   */
  this.getRelatedPageVariables = function (pageVariableKeyword) {
    console.log('getRelatedPageVariables', pageVariableKeyword);
    window.postMessage({ call: 'getRelatedPageVariables', pageVariableKeyword: pageVariableKeyword }, '*');
    /*
    this.keyValuesGlobal = [];
    this.searchedPageVariables = {};
    // send to content scripts
    var pageVariables = [];
    if (pageVariableKeyword == 'window') {
      pageVariables = this.getRelatedPageVariablesByLevel(window, pageVariableKeyword);
    } else {
      pageVariables = this.getRelatedPageVariablesByKeyword(window, pageVariableKeyword);
    }
    if (pageVariables.length == 0) {
      pageVariables = this.getRelatedPageVariablesByLevel(window, pageVariableKeyword);
    }
    window.postMessage({ call: 'setRelatedPageVariables', pageVariables: pageVariables }, '*');
    return pageVariables;
     */
  };

  this.executeCustomJS = function (code) {
    try {
      if (code) {
        var returnArrTemp = 'window.WS.functionizeValidateCustomJSResult = null; window.WS.functionizeValidateCustomJSResult = ' + code;
        setTimeout(returnArrTemp, 1);
        setTimeout(() => {
          console.log('Custom JS executed', window.WS.functionizeValidateCustomJSResult);
          self.port.emit('message', {
            obj: 'TCM',
            call: 'setExecutedCustomJS',
            arguments: window.WS.functionizeValidateCustomJSResult,
            forVue: true,
          });
        }, 200);
      }
    } catch (e) {}
  };

  this.getRelatedPageVariablesByLevel = function (windowd, pageVariableKeyword) {
    var fWindow = {};
    for (var p in windowd) {
      if (p.indexOf(pageVariableKeyword) == 0) {
        try {
          fWindow[p] = JSON.stringify(windowd[p]);
        } catch (e) {
          fWindow[p] = this.circularStringify(windowd[p], 1);
        }
      }
    }
    return fWindow;
  };

  this.circularStringify = function (object, depth) {
    var fWindow = {};
    for (var p in object) {
      try {
        fWindow[p] = JSON.stringify(object[p]);
      } catch (e) {
        if (depth > 2) {
          fWindow[p] = '[CIRCULAR]';
        } else {
          fWindow[p] = this.circularStringify(object[p], depth + 1);
        }
      }
    }
    return fWindow;
  };

  this.getRelatedPageVariablesByKeyword = function (windowd, pageVariableKeyword) {
    if (pageVariableKeyword.indexOf('window.') == 0) pageVariableKeyword = pageVariableKeyword.replace('window.', '');

    var fWindow = {};
    var pageVariableKeywordArr = null;
    if (pageVariableKeyword.indexOf('.') > 0) {
      try {
        pageVariableKeywordArr = pageVariableKeyword.split('.');
        var newVar = 'pageVariableKeywordValue = windowd';
        for (let i = 0; i < pageVariableKeywordArr.length; i++) {
          newVar += "['" + pageVariableKeywordArr[i] + "']";
        }
        newVar += ';';
        setTimeout(newVar, 1);

        if (pageVariableKeywordValue) {
          var returnArrTemp = 'var fWindow = {};';
          var returnArrTempVarName = 'fWindow';
          for (let i = 0; i < pageVariableKeywordArr.length; i++) {
            returnArrTempVarName += "['" + pageVariableKeywordArr[i] + "']";
            returnArrTemp += returnArrTempVarName + ' = {};';
          }
          returnArrTemp += returnArrTempVarName + " = '" + pageVariableKeywordValue + "';";
          setTimeout(returnArrTemp, 1);
          return fWindow;
        }
      } catch (e) {}
    }
    if (pageVariableKeyword.indexOf('.') > 0) {
      pageVariableKeywordArr = pageVariableKeyword.split('.');

      for (let p in windowd) {
        if (p == pageVariableKeywordArr[0]) {
          try {
            let windowdp = windowd[p];
            if (typeof windowdp !== 'string' && windowdp.length > 0) {
              fWindow = this.getRelatedPageVariablesArray(fWindow, p, windowdp);
            } else if (typeof windowdp === 'object' && Object.keys(windowdp).length > 0) {
              fWindow[p] = this.getRelatedPageVariablesByKeyword(windowdp);
            } else {
              fWindow[p] = JSON.stringify(windowdp);
            }
          } catch (e) {
            fWindow[p] = this.circularStringify(windowdp, 1);
          }
        }
      }
    } else {
      for (let p in windowd) {
        if (p.indexOf(pageVariableKeyword) == 0 || !pageVariableKeyword) {
          try {
            let windowdp = windowd[p];
            if (typeof windowdp !== 'string' && windowdp.length > 0) {
              fWindow = this.getRelatedPageVariablesArray(fWindow, p, windowdp);
            } else if (typeof windowdp === 'object' && Object.keys(windowdp).length > 0) {
              fWindow[p] = this.getRelatedPageVariablesByKeyword(windowdp);
            } else {
              fWindow[p] = JSON.stringify(windowdp);
            }
          } catch (e) {
            fWindow[p] = this.circularStringify(windowdp, 1);
          }
        }
      }
    }
    return fWindow;
  };

  this.getRelatedPageVariablesArray = function (fWindow, key, val) {
    val.forEach(function (value, index) {
      if (typeof value !== 'string' && value.length > 0) {
        fWindow[key + '[' + index + ']'] = JSON.stringify(value);
      } else {
        fWindow[key + '[' + index + ']'] = this.getRelatedPageVariablesByKeyword(value);
      }
    });
    return fWindow;
  };

  this.processWindowVariables = function (windowVariables) {
    for (var prop in windowVariables) {
      try {
        windowVariables[prop] = JSON.parse(windowVariables[prop]);
      } catch (err) {
        window.fconsole.log(windowVariables[prop]);
      }
    }
    return windowVariables;
  };

  this.processPageVariables = function (windowVariables) {
    try {
      window.TCM.searchedPageVariables = {};
      this.setKeyValuesGlobal(windowVariables, window.TCM.searchedPageVariablesKeyword || '', 0);
      self.port.emit('message', {
        obj: 'TCM',
        call: 'processPageVariables',
        arguments: window.TCM.searchedPageVariables,
        forVue: true,
      });
    } catch (err) {}
  };

  this.setKeyValuesGlobal = function (cVariable, keyname, level, vav = 'PV') {
    var nLevel = level + 1;
    var kVal;
    if (nLevel <= 4) {
      for (var prop in cVariable) {
        if (typeof cVariable[prop] !== 'function') {
          try {
            cVariable[prop] = JSON.parse(cVariable[prop]);
          } catch (err) {}
          if (typeof cVariable[prop] === 'object') {
            var windowvariable = 'window121212';
            if (vav == 'PV') windowvariable = 'window';
            if (
              prop != 'self' &&
              prop != '$' &&
              prop != 'window.WS' &&
              prop != 'TH' &&
              prop != 'TCM' &&
              prop != 'applicationCache' &&
              keyname != 'document' &&
              keyname != 'content' &&
              keyname != 'frames' &&
              keyname != 'parent' &&
              keyname != '_pa' &&
              keyname != windowvariable &&
              keyname != 'top' &&
              isNaN(prop) &&
              prop.indexOf('$') != 0
            ) {
              if (keyname) {
                kVal = String(keyname + '.' + prop);
              } else {
                kVal = String(prop);
              }
              this.setKeyValuesGlobal(cVariable[prop], kVal, nLevel);
            }
          } else {
            if (prop != 'self' && prop != '$' && prop != 'WS' && prop != 'TH' && prop != 'TCM') {
              var validEntry = true;
              if (keyname == 'content' || keyname == 'frames' || keyname == 'parent' || keyname == 'top' || keyname == 'window') {
                if (this.searchedPageVariables[prop]) {
                  validEntry = false;
                } else {
                  this.searchedPageVariables[prop] = String(cVariable[prop]);
                }
              }
              if (validEntry) {
                if (keyname) {
                  kVal = String(keyname + '.' + prop);
                } else {
                  kVal = String(prop);
                }
                this.keyValuesGlobal.push(kVal);
                this.searchedPageVariables[kVal] = String(cVariable[prop]);
              }
            }
          }
        }
      }
    }
  };

  this.setRecording = function (on) {
    if (on) {
      this.enable('cancel');
      this.enable('verify');
      this.enable('startstop');
      this.enable('setting');

      this.showActionCounter();
      this.recording = true;
      window.WS.doRecording = 1;
    } else {
      this.disable('verify');
      console.log('window.WS.stopTestRecording was called in window.TCM');
      window.WS.stopTestRecording();
    }
  };

  this.startVerifying = function () {
    window.TCM.setVerifyState(true);
    window.WS.startCollecting();
  };

  this.cancelVerify = function () {
    if (!this.isStopping) {
      window.WS.continueTestRecording();
    }
    this.setVerifyState(false);

    // TODO: it feels like this should be here
    if (window.WS.collecting) window.WS.stopCollecting();
  };

  //finish the test case
  this.finalizeTest = function (source) {
    window.fconsole.log('Finalize test is called.');
    if (typeof source == 'undefined') source = 'self';
    if (this.isController && source == 'self') {
      //called locally
      //var startstopButton = document.getElementById('startstop-button');
      //if (startstopButton && typeof startstopButton.removeTooltip === 'function') {
      //  startstopButton.removeTooltip(); // Call the custom method to remove the tooltip
      //}
      // window.TH.create('#startstop-button', '#startstop-button', 'Start Modeling', 0, 'top middle', 'bottom middle', true);
      if (!this.isMaster) {
        // control sub window...
        window.fconsole.log('finalizeTest is sent to Master window');
        var command = { obj: 'TCM', call: 'finalizeTest' };
        window.TCM.sendCommand(command, window.parent);
        //we'll receive the call again from the master....
        return;
      }
    }
    // window.TH.clearAll();
    window.WS.removeHighlights();
    window.WU.fShowAllElements();
    window.WS.on = false;
    window.TCM.setVerifyState(false);
    window.TCM.setStopState(false);
    window.TCM.resetStates();
    window.WU.enableAllElements();

    if (window.TCM.isController) {
      window.WU.cookie('functioniseTesting', 'off');
      window.TCM.enable('startstop');
      window.TCM.disable('cancel');
      window.TCM.disable('setting');
      window.TCM.hideActionCounter();
      // window.TCM.advancedEditor.getObject('panel').closePanel();
    }

    if (window.TCM.isMaster) {
      window.TCM.sendCallToDescendants('finalizeTest', 'master');
    }

    if (window.WS.isPopup) {
      //we close ourselves at the end of a test if popup
      //give it time to propagate before closing
      setTimeout(function () {
        window.close();
      }, 1000);
    }
  };

  //this returns at the end of a verify action
  this.setTestResult = function (source) {
    if (this.isVerifying) {
      //we go to editing here
      window.WS.verify = this.verify;
      //record the last action so its available for the panel
      if (source == 'master' || (window.TCM.isMaster && window.TCM.isController)) window.WS.getRecordingData(null, null, true);
      //open advanced panel for editing
      if (window.WS.shiftDown) {
        window.fconsole.log('Shift down detected…  opening panel with data:' + JSON.stringify(this.verify.data));
        window.TCM.startEdit(this.verify.data);
      } else {
        window.fconsole.log('Shift down is not detected…');
        window.WS.removeHighlights();
        // window.TH.clearAll();
        window.WU.fShowAllElements();
        //verify is done...
        window.TCM.cancelVerify();
        if (window.TCM.isStopping) {
          // this is the last step in the creation process
          ///recording is done we create final form
          window.TCM.createFormWindow();
        }
      }
    }
  };

  this.CheckAndAddSuggestionWindow = function () {
    var lastAction = window.WS.recordedData[window.WS.recordedData.length - 1];
    var verifyString = '';
    if (typeof lastAction.value != 'undefined' && lastAction.value) {
      verifyString = lastAction.value;
    }
    if (typeof lastAction.text != 'undefined' && lastAction.text) {
      verifyString = lastAction.text;
    }
    if (verifyString) {
      var WSRecordedData = window.WS.recordedData;
      var foundSuggestions = new Array();
      if (WSRecordedData.length > 0) {
        WSRecordedData.forEach(function (attr, index) {
          if (attr.actionId != lastAction.actionId) {
            var singleAc = {};
            if (
              typeof window.TCM.suggestVerificationsInput[attr.actionId] != 'undefined' &&
              typeof window.TCM.suggestVerificationsInput[attr.actionId].text &&
              window.TCM.suggestVerificationsInput[attr.actionId].text == verifyString
            ) {
              singleAc = {};
              singleAc['actionId'] = attr.actionId;
              singleAc['attribute'] = 'text';
              singleAc['action'] = attr.action;
              singleAc['step'] = index + 1;
              singleAc['value'] = window.TCM.suggestVerificationsInput[attr.actionId].text;
              foundSuggestions.push(singleAc);
            }
            if (
              typeof window.TCM.suggestVerificationsInput[attr.actionId] != 'undefined' &&
              typeof window.TCM.suggestVerificationsInput[attr.actionId].value &&
              window.TCM.suggestVerificationsInput[attr.actionId].value == verifyString
            ) {
              singleAc = {};
              singleAc['actionId'] = attr.actionId;
              singleAc['attribute'] = 'value';
              singleAc['action'] = attr.action;
              singleAc['step'] = index + 1;
              singleAc['value'] = window.TCM.suggestVerificationsInput[attr.actionId].value;
              foundSuggestions.push(singleAc);
            }
          }
        });
      }
      if (foundSuggestions.length > 0) {
        var waitString = '<div id="' + window.fUniqPrefix + '_verify_match_suggestion"><table>';
        waitString += '<tr><td colspan="2"><label>Do you want to attach this verification to a previous step based on the selected value?</label></td></tr>';

        foundSuggestions.forEach(function (attr, index) {
          waitString +=
            '<tr><td style="width: 20px"><input type="radio" name="f-functionise_action_match_suggestion" value="eqstepval#func#' +
            attr.actionId +
            '|FUNCSTEP|' +
            attr.attribute +
            '" attributefor="' +
            attr.attribute +
            '" class="f-functionise_action_match_suggestion"></td><td><label>Step ' +
            attr.step +
            ' (' +
            attr.action +
            ') - ' +
            attr.value +
            '</label></td></tr>';
        });
        waitString += '</table></div>';
      }
    }
  };

  this.cleanRecordedData = function (doEncode, doDrop) {
    if (typeof doEncode == 'undefined') doEncode = false;

    if (typeof doDrop == 'undefined') doDrop = true;

    if (window.WS.enable_ad_tracking) {
      doDrop = false;
    }

    var actionsToDrop = new Array();
    var pathToDrop = new Array();
    for (var i = 0; i < window.WS.recordedData.length; i++) {
      if (typeof window.WS.recordedData[i].path != 'undefined' && window.WS.recordedData[i].path != '' && pathToDrop.indexOf(window.WS.recordedData[i].path) > -1) {
        actionsToDrop.push(i);
        continue;
      }
      //filter out unnecessary page init codes
      if (window.WS.recordedData[i].action == 'pageinit' && typeof window.WS.recordedData[i].path != 'undefined' && window.WS.recordedData[i].path != '') {
        var hasInteraction = false;
        for (var x = i + 1; x < window.WS.recordedData.length; x++) {
          if (
            window.WS.recordedData[x].action != 'pageinit' &&
            window.WS.recordedData[x].action != 'contextswitch' &&
            (typeof window.WS.recordedData[x].actionType == 'undefined' || window.WS.recordedData[x].actionType != 'init') &&
            window.WS.recordedData[i].path == window.WS.recordedData[x].path
          ) {
            hasInteraction = true;
            break;
          }
        }
        if (!hasInteraction) {
          //check to be sure its not a popup
          var pp = window.WS.recordedData[i].path.split('_');
          var lastPath = pp.pop();
          if (lastPath.indexOf('popup') < 0) {
            pathToDrop.push(window.WS.recordedData[i].path);
            if (window.WS.recordedData[i - 1].action == 'contextswitch') {
              actionsToDrop.push(i - 1);
            }
            actionsToDrop.push(i);
          }
        }
      }
      if (doEncode) {
        for (var p in window.WS.recordedData[i]) {
          //we urlencode to manage non UTF-8 strings -- on other end de urldecode to get the conversion finished :)
          if (typeof window.WS.recordedData[i][p] == 'undefined' || window.WS.recordedData[i][p] == null) {
            window.WS.recordedData[i][p] = '';
          } else if (window.WS.recordedData[i][p] == '' || p == 'meta' || p == 'elementData') {
            //if action key is meta, skip encode functionality
          } else {
            try {
              var dv = decodeURIComponent(window.WS.recordedData[i][p]);
              if (dv && dv != '') window.WS.recordedData[i][p] = encodeURIComponent(dv);
              else window.WS.recordedData[i][p] = encodeURIComponent(window.WS.recordedData[i][p]);
            } catch (e) {
              window.WS.recordedData[i][p] = encodeURIComponent(window.WS.recordedData[i][p]);
            }
          }
        }
      }
    }
    //make sure it is ordered asc
    actionsToDrop.sort((a, b) => b + a);
    if (doDrop) {
      for (let i = actionsToDrop.length - 1; i > -1; i--) {
        window.WS.recordedData.splice(actionsToDrop[i], 1);
      }
    }
    if (doEncode) {
      //this is the end.    We search for potential duplicate clicks….
      for (let i = 0; i < window.WS.recordedData.length; i++) {
        if (window.WS.recordedData[i].action == 'pageinit' && i > 0) {
          if (
            (window.WS.recordedData[i - 1].action == 'click' || window.WS.recordedData[i - 1].action == 'doubleclick') &&
            (window.WS.recordedData[i - 2].action == 'click' || window.WS.recordedData[i - 2].action == 'doubleclick')
          ) {
            if (window.WS.recordedData[i - 1].xpath == window.WS.recordedData[i - 2].xpath) {
              //this is a likely duplicate
              window.WS.recordedData[i - 1].potentialDuplicate = 'true';
            }
          }
        }
      }
    }
  };

  this.requestFormData = function () {
    if (window.TCM.isController) {
      window.fconsole.log('requesting form data');
      var command = { obj: 'TCM', call: 'requestFormData' };
      window.TCM.sendCommand(command, window.parent);
    } else if (window.TCM.isMaster) {
      //we send the data
      var data = {};
      data.did = window.WS.did;
      data.pageCount = window.WS.pageCount;
      data.locUrl = window.WS.locUrl;
      window.TCM.sendCallToDescendants('setFormData', new Array(JSON.stringify(window.WS.recordedData), JSON.stringify(data)));
    }
  };

  this.setFormDataFinal = function (tcTitle) {
    this._tcTitle = tcTitle;
    this._stopCallback(tcTitle, this.verify);
    //send finalize command to master
    var command = { obj: 'TCM', call: 'finalizeTest' };
    this.sendCommandToMaster(command);
    this.finalizeTest();
    //try to finish correctly..
    window.WS.cancelTest();
    this.finalizeTest();
  };

  //final form to submit to the back end

  this.createFormWindow = function () {
    window.fconsole.log('new create form window');
    let st = 'false';
    if (window.functionizeStandalone) st = 'true';

    window.postMessage({ call: 'getPageAjaxVariablesResponseForMutation' }, '*');

    var command = { obj: 'TCM', call: 'getCSPFlag' };
    this.sendCommandToMaster(command);

    if (
      (typeof window.WS.testJobId !== 'undefined' && window.WS.testJobId) ||
      (typeof window.WS.mturkWorkerId !== 'undefined' && window.WS.mturkWorkerId) ||
      (typeof window.functionizeEditTestId !== 'undefined' && window.functionizeEditTestId)
    ) {
      // TODO: why are we changing the title?
      // var elem = "<div id='f-functionise-tc-manager-form' style='text-indent: 11111px !important'>";
    } else {
      // TODO: no html form needed
      // var elem = "<div id='f-functionise-tc-manager-form'>";
    }

    // TODO: keeing this here to remember the name attribute
    // let input = "<input type='text' name='title' id='f-functionise-tc-manager-form-title' style='position: relative;' />";

    window.TCM.isEdit = false;

    if (typeof window.functionizeEditMode !== 'undefined' && typeof window.functionizeEditTestId !== 'undefined') {
      window.TCM.isEdit = true;
    }

    if (typeof window.WS.mturkWorkerId !== 'undefined' && window.WS.mturkWorkerId) {
      window.WU.store('mTurkJobDescriptionScroll', '');
      window.WU.store('jsTemplateTurkJobDescriptionData', '');
      window.TCM.isEdit = true;
    }
    if (typeof window.WS.testJobId !== 'undefined' && window.WS.testJobId) {
      window.WU.store('mTurkJobDescriptionScroll', '');
      window.WU.store('jsTemplateTurkJobDescriptionData', '');
      window.TCM.isEdit = true;
    }

    window.fconsole.log(window.TCM.isEdit);
    this.setFormData(undefined, undefined, st);
  };

  this.setFormData = function (data, additionalData, st) {
    window.fconsole.log('new setformdata');
    if (!window.TCM.isController) return;

    if (window.WS.recordedData.length == 0 && typeof data === 'undefined' && !window.TCM.isMaster) {
      this.requestFormData();
      return;
    }

    window.TCM.cleanRecordedData(true, true);

    // force collect data
    this.collectFormData(st);
  };

  this.collectFormData = function (st) {
    window.fconsole.log('new collectformdata');
    // TODO: change modeler/listeners.js message to send ajaxResponse to the extension instead of setting form data

    let data = {
      data: window.WS.recordedData,
      did: window.WS.did,
      demo: window.WS.isDemo,
      pageCount: window.WS.pageCount,
      locUrl: window.WS.locUrl,
      version: chrome.runtime.getManifest().version,
      redirect: window.WS.locUrl,
      projectId: window.projectId,
      standalone: st,
      host: window.WS.wbHost,
    };

    if (typeof window.functionizeSimulatedDevice !== 'undefined') {
      data.simulatedDevice = window.functionizeSimulatedDevice;
      data.simulatedDeviceWidth = window.functionizeSimulatedDeviceWidth;
      data.simulatedDeviceHeight = window.functionizeSimulatedDeviceHeight;
    }

    if (typeof window.functionizeEditMode !== 'undefined' && typeof window.functionizeEditTestId !== 'undefined') {
      data.functionizeEditTestId = window.functionizeEditTestId;
      data.functionizeEditActionId = window.functionizeEditActionId;
      data.functionizeEditMode = window.functionizeEditMode;
      data.functionizeBranch = window.functionizeBranch;
    }

    if (typeof window.functionizeIsSeleniumTest !== 'undefined' && window.functionizeIsSeleniumTest) {
      data.chromeDriverRunning = 1;
    }

    self.port.emit('message', {
      obj: 'TCM',
      call: 'submissionData',
      arguments: data,
      forMaster: true,
    });

    // this.sendCommandToMaster(command);
  };

  this.ajaxSubmit = function () {
    var xhr = new XMLHttpRequest();
    var url = 'https://' + window.WS.wbHost + '/ajax/addrecordlog';
    var params = new URLSearchParams({
      projectId: window.projectId,
      data: JSON.stringify(window.WS.recordedData),
      title: document.querySelector('#f-functionise-tc-manager-form-title').value,
    });

    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        var logId = xhr.responseText;
        this.submitCheckSubmitted = false;

        if (logId && logId !== 'undefined') {
          window.TCM.finalizeTest();
          var command = { obj: 'TCM', call: 'cancelTask' };
          window.TCM.sendCommandToMaster(command);

          document.querySelector('#f-functionise-tc-manager-form-data').value = '';
          var hiddenInput = document.createElement('input');
          hiddenInput.type = 'hidden';
          hiddenInput.id = 'f-functionise-tc-manager-form-log_id';
          hiddenInput.name = 'log_id';
          hiddenInput.value = logId;
          document.querySelector('#f-functionise-tc-manager-form-projectId').insertAdjacentElement('afterend', hiddenInput);

          document.querySelector('.testsaveloader').style.display = 'none';

          var form = document.querySelector('#f-functionise-tc-manager-form-form');
          var queryString = new URLSearchParams(new FormData(form)).toString();
          var redUrl = 'https://' + window.WS.wbHost + '/record?' + queryString;
          window.location.href = redUrl;
          return true;
        }
      }
    }.bind(this);

    xhr.send(params.toString());
  };

  this.createActionWithData = function (data) {
    console.log('createActionWithData', data, data.value ? typeof data.value : 'no value');
    try {
      window.WS.getRecordingData(data, false);
    } catch (e) {
      console.error(e);
    }
  };

  this.cancelSubmit = function () {
    window.TCM.setStopState(false);
    window.TCM.enable('startstop');
    window.TCM.cancelCancel();
    window.TCM.setRecording(true);

    if (window.TCM.isMaster) {
      var command = { obj: 'TCM', call: 'cancelSubmit', arguments: {} };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  this.initCancel = function () {
    window.TCM.isCancelCalled = true;
    setTimeout(function () {
      window.TCM.isCancelCalled = false;
    }, 2000);
  };

  this.getTestCaseTitle = function () {
    return this._tcTitle;
  };

  this.retrieveFormValues = function (e) {
    var post = {};
    var elem = e.elements;
    for (var i = 0; i < elem.length; i++) {
      post[elem[i].name] = elem[i].value;
    }
    window.fconsole.log('setting post data : ' + JSON.stringify(post));
    window.functionizeRecordingPostData = JSON.stringify(post);
  };

  //turn on/off buttons
  this.enable = function (button) {
    console.log('Enable called for ' + button);

    // Get the button element by its ID
    var buttonElement = document.getElementById(button + '-button');

    if (buttonElement) {
      // Add the 'rec-buttons-active' class to the button element
      buttonElement.classList.add('rec-buttons-active');
    }

    // Set the corresponding property to true
    this[button + 'Enabled'] = true;
  };

  this.disable = function (button) {
    // Get the button element by its ID
    var buttonElement = document.getElementById(button + '-button');

    if (buttonElement) {
      // Remove the 'rec-buttons-active' class from the button element
      buttonElement.classList.remove('rec-buttons-active');
    }

    // Set the corresponding property to false
    this[button + 'Enabled'] = false;
  };

  //load scripts functionality
  this.loadScripts = function () {
    console.log('loadScripts');
    var cu = this.scripts.shift();
    if (this.scripts.length >= 0 && cu !== undefined) {
      this.loadScript(cu);
    } else {
      this.create();
    }
  };

  this.loadScript = function (url) {
    var script = document.createElement('script');
    var done = false;
    var head = document.head;
    script.src = url;
    script.onload = script.onreadystatechange = function () {
      if (!done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete')) {
        done = true;
        window.TCM.loadScripts();

        // IE memory leak
        script.onload = script.onreadystatechange = null;
      }
    };
    head.appendChild(script);
  };

  this.addSessionToCommand = function (command) {
    return command;
  };

  this.setResourceData = function (data) {
    if (Object.keys(data).length > 0) {
      this.resourceData = data;
    } else {
      this.resourceData = 'BLANK';
    }
  };

  this.setCSPFlag = function (data) {
    window.TCM.isCSP = data;
  };

  this.getResourceData = function (data) {
    return this.resourceData;
  };

  this.setLocalVariables = function (variables) {
    Object.keys(variables.local).forEach((variable) => {
      window.fze.setVariablesByType({ type: 'local', name: variable, value: variables.local[variable] });
    });
  };

  this.receiveMultiMessage = function (data) {
    window.fconsole.log('Messages : ' + JSON.stringify(data));
    for (var i in data) {
      var message = data[i];
      if (message.obj == 'window') window[message.obj] = window;
      window.fconsole.log('Message: ' + JSON.stringify(message));
      window.fconsole.log('Executing call to obj' + message.obj + ' ' + message.call);
      try {
        if (typeof message.arguments != 'undefined') {
          if (!Array.isArray(message.arguments)) {
            window[message.obj][message.call].apply(null, new Array(message.arguments));
          } else {
            window[message.obj][message.call].apply(null, message.arguments);
          }
        } else {
          window[message.obj][message.call]();
        }
      } catch (e) {
        window.fconsole.log(e);
      }
    }
  };

  this.sendCommand = function (command, target, meta) {
    window.fconsole.log('Send Command called with call:' + command.call + ' ' + JSON.stringify(meta));
    if (typeof command == 'undefined') return;
    if (target == null || typeof target == 'undefined') target = window.parent;

    if (typeof meta != 'undefined') {
      command.meta = {};
      window.fconsole.log('Adding UID to child call ' + meta.UID);
      command.meta.UID = meta.UID;
      if (typeof meta.fromUID != 'undefined') command.meta.fromUID = meta.fromUID;

      window.fconsole.log('Adding winType to child call ' + meta.windowType);
      if (typeof meta.windowType != 'undefined') command.meta.windowType = meta.windowType;

      if (typeof meta.selector != 'undefined') command.meta.selector = meta.selector;

      if (typeof meta.targetElement != 'undefined') command.meta.targetElement = meta.targetElement;

      if (typeof meta.iframeOffsetX != 'undefined') command.meta.iframeOffsetX = meta.iframeOffsetX;

      if (typeof meta.iframeOffsetY != 'undefined') command.meta.iframeOffsetY = meta.iframeOffsetY;

      if (typeof meta.traverseIframeComp != 'undefined') command.meta.traverseIframeComp = meta.traverseIframeComp;

      if (typeof meta.functionizeid != 'undefined') command.meta.functionizeid = meta.functionizeid;

      if (typeof meta.traverseIframenextNodeId != 'undefined') command.meta.traverseIframenextNodeId = meta.traverseIframenextNodeId;

      if (typeof meta.attributes !== 'undefined') {
        command.meta.attributes = meta.attributes;
      }

      // if (typeof meta.elementStatistics != 'undefined') command.meta.elementStatistics = meta.elementStatistics;

      window.fconsole.log('Final meta in call ' + JSON.stringify(command.meta));
      command.meta.index = meta.index;
      return this.sendCommandToDescendants(command);
    }
    if (typeof targetData != 'undefined') {
      //send to popup or all iframes...
    } else {
      this.executeSendCommand(command, target);
    }
  };

  this.executeSendCommand = function (command, target) {
    //window.fconsole.log("Posting message to target: " + window.WU.stringify(target) + " with message " + window.WU.stringify(command).substring(0,150));
    window.fconsole.log('Sending relay command call');
    if (typeof self != 'undefined' && self.port != 'undefined') {
      var UID = window.WS.iframeUID;
      if (window.WS.popupUID != '') UID = window.WS.popupUID;
      if (UID != '') {
        if (typeof command.meta == 'undefined') command.meta = {};

        command.meta.fromUID = UID;
      }
      window.fconsole.log('Sending relay to master: ' + command.call + ' ' + UID);

      self.port.emit('relay', command);

      return;
    }

    try {
      if (window.MessageChannel) {
        var m = new MessageChannel();
        target.postMessage(command, '*', [m.port2]);
      } else {
        target.postMessage(command, '*');
      }
      return true;
    } catch (e) {
      //window.fconsole.log("Unable to send message to target:" + window.WU.stringify(command)+ " with error:" + e);
    }
    return false;
  };

  this.sendCommandToMaster = function (command) {
    window.fconsole.log('Master command called');
    if (typeof self != 'undefined' && self.port != 'undefined') {
      window.fconsole.log('Sending message to master: ' + command.call);
      command.forMaster = true;
      self.port.emit('message', command);
      return;
    }
    // Access the iframe element directly
    var iframe = window.TCM.iframe;

    // Check if the iframe exists and has a contentWindow
    if (iframe && iframe.contentWindow) {
      return this.sendCommand(command, iframe.contentWindow);
    }
  };

  this.sendCommandToParent = function (command) {
    if (window.WS.isIframe || window.WS.isPopup) {
      var target = window.parent;
      if (window.WS.isPopup) target = window.opener;

      if (typeof self != 'undefined' && self.port != 'undefined') {
        window.fconsole.log('Sending relay to parent: ' + command.call);
        self.port.emit('relay', command);
      } else {
        window.fconsole.log('Sending relay to parent: ' + command.call + ', ' + JSON.stringify(target));
        this.sendCommand(command, target);
      }
    }
  };

  this.sendCallToDescendants = function (method, param, meta) {
    window.fconsole.log('Send Descendants call ' + method + ' ' + window.WU.stringify(param));
    var command = { obj: 'TCM', call: method, arguments: param };
    if (typeof meta != 'undefined') command.meta = meta;
    this.sendCommandToDescendants(command);
  };

  this.sendCommandToDescendants = function (command) {
    window.fconsole.log('Send Command to Descendants ' + command.call);
    if (typeof self != 'undefined' && self.port != 'undefined') {
      window.fconsole.log('Sending relay to child: ' + command.call);
      try {
        self.port.emit('relay', command);
      } catch (e) {}
    }
  };

  this.loadData = function (data) {
    window.fconsole.log('Loading data ' + data);
    var command = { obj: 'TCM', call: 'dataRequest', arguments: data };
    this.sendCommandToMaster(command);
  };

  this.setter = function (data) {
    for (var p in data) {
      //called from window object  can not use this...
      // window.fconsole.log('setting data ' + p + ' ' + window.WU.stringify(data[p]));
      window.TCM[p] = data[p];
      if (p == 'isPaused' && data[p]) window.TCM.setPauseCoverer(true);

      if (p == 'recording' && !data[p]) window.functionizeNavigationTypeString = '';
    }
  };

  this.sendCurrentStates = function (UID) {
    //than set up the correct recording states
    var commands = new Array();

    commands.push({ obj: 'TCM', call: 'setter', arguments: { recording: window.TCM.recording } });
    commands.push({ obj: 'TCM', call: 'setter', arguments: { isVerifying: window.TCM.isVerifying } });
    commands.push({ obj: 'TCM', call: 'setter', arguments: { isScrollToElementAction: window.TCM.isScrollToElementAction } });
    commands.push({ obj: 'TCM', call: 'setter', arguments: { isHoveringAction: window.TCM.isHoveringAction } });
    commands.push({ obj: 'TCM', call: 'setter', arguments: { isStopping: window.TCM.isStopping } });
    commands.push({ obj: 'TCM', call: 'setter', arguments: { editing: window.TCM.editing } });
    commands.push({ obj: 'TCM', call: 'setter', arguments: { debug: window.TCM.debug } });
    commands.push({ obj: 'TCM', call: 'setter', arguments: { liveEdit: window.TCM.liveEdit } });
    commands.push({ obj: 'WS', call: 'setter', arguments: { doRecording: window.WS.doRecording } });
    commands.push({ obj: 'WS', call: 'setter', arguments: { on: window.WS.on } });
    commands.push({ obj: 'WS', call: 'setter', arguments: { shiftDown: window.WS.shiftDown } });

    commands.push({ obj: 'TCM', call: 'setLocalVariables', arguments: { local: fze.local } });

    //we do not need to recurse any more...
    //commands.push({obj: 'TCM',call: 'sendCurrentStates', arguments: {}});
    if (typeof UID != 'undefined') {
      var meta = {};
      window.fconsole.log('Adding UID to child call ' + UID);
      meta.UID = UID;
      window.TCM.sendCallToDescendants('receiveMultiMessage', commands, meta);
    } else {
      window.TCM.sendCallToDescendants('receiveMultiMessage', commands);
    }
  };

  this.sendValueToDescendants = function (obj, property, value) {
    window.fconsole.log('Send value to Descendants call');
    var data = {};
    data[property] = value;
    var command = { obj: obj, call: 'setter', arguments: data };
    this.sendCommandToDescendants(command);
  };

  this.sendValueToParent = function (obj, property, value) {
    window.fconsole.log('Send value to Parent call');
    var data = {};
    data[property] = value;
    var command = { obj: obj, call: 'setter', arguments: data };
    this.sendCommandToParent(command);
  };

  this.addMaster = function () {
    console.log('requestRegistration addMaster');
    //we include the iframe… we'l expect a callback to get this window registered
    this.isMaster = true;
    this.isController = true;

    if (typeof self != 'undefined' && self.port != 'undefined') {
      this.sendRequestRegistration(true);
    }
  };

  this.disableFunctionise = function () {
    //set cookie not to check again
    window.fconsole.log('Disabling functionise');
    window.WU.cookie('functioniseTesting', 'off');
    window.WU.cookie('functionise', 'false', { expires: 3650, path: '/' });
    //remove cover
    this.removeCoverer();
  };

  this.enableFunctionise = function () {
    window.WU.cookie('functionise', 'true', { expires: 0, path: '/' });
  };

  this.registered = function (data) {
    console.log('registered', data);
    let element = document.getElementById(window.fUniqPrefix + '-iframe-coverer');
    let style = document.getElementById(window.fUniqPrefix + '-iframe-coverer-style');
    if (element) {
      element.remove();
    }
    if (style) {
      style.remove();
    }
    if (data.meta.hasOwnProperty('functionizeid')) {
      window.WS.functionizeid = parseInt(data.meta.functionizeid);
    }
    registered(data);
  };

  //requesting reg for this frame/window
  this.sendRequestRegistration = function (forMaster) {
    console.trace('sendRequestRegistration registered');
    if (typeof forMaster == 'undefined') forMaster = false;

    var frameName = '';
    var frameId = '';
    var frameURL = window.WS.locUrl;
    var frameTitle = '';
    this.requestRegistrationSent = true;
    try {
      //this can throw errors on cross domain calls...  We can set CORS headers if we need to override this
      frameName = window.frameElement.getAttribute('name');
      frameId = window.frameElement.getAttribute('id');
      frameTitle = document.head.getAttribute('title') || document.title || '';
    } catch (e) {}
    //we add frameName and frameURL
    if (!forMaster) {
      if (window.name != '') frameName = window.name;
    }
    if (window.TCM.isMaster) forMaster = true;

    self.port.emit('message', {
      obj: 'TCM',
      call: 'requestRegistration',
      meta: {
        windowWidth: window.innerWidth,
        windowHeight: window.innerHeight,
        scrollLeft: window.scrollX || window.pageXOffset,
        scrollTop: window.scrollY || window.pageYOffSet,
        frameName: frameName,
        frameURL: frameURL,
        frameTitle: frameTitle,
        frameId: frameId,
        path: window.WS.path,
      },
      forMaster: forMaster,
    });
  };

  //popups and iframes will be sending this call
  this.requestRegistration = async function (data) {
    console.log('requestRegistration registered', JSON.parse(JSON.stringify(data)), window.TCM.initialize || this.initialize, window);
    if (!data) {
      console.error('no data', data);
      return;
    }

    if (!window.TCM.initialize && !this.initialize) {
      await new Promise((resolve) => setTimeout(resolve, 2000));
    }

    //this is likely a frame registering to the system.
    //we log its ID and continue from there
    if (window.TCM.initialize || this.initialize) {
      // we are ready to do regs
      window.TCM.sendCurrentStates(data.UID);

      var frameFound = false;
      var iframe;

      try {
        if (data.hasOwnProperty('windowType') && data.windowType === 'iframe' && typeof data.meta.UID !== 'undefined' && data.meta.UID !== '') {
          iframe = document.querySelectorAll('iframe');
          iframe.forEach((frame) => {
            try {
              if (frame.contentWindow.WS && frame.contentWindow.WS.iframeUID == data.meta.fromUID) {
                frameFound = true;
                iframe = frame;
              }
            } catch (e) {}
          });

          if (!frameFound) {
            window.WS.siteStatistics.iframeList.forEach((frame) => {
              try {
                if (frame.contentWindow.WS && frame.contentWindow.WS.iframeUID == data.meta.fromUID) {
                  frameFound = true;
                  iframe = frame;
                }
              } catch (e) {}
            });
          }
        }

        //we start IDs based on multiple logics
        if (
          typeof data.meta.frameName != 'undefined' &&
          data.meta.frameName != null &&
          data.meta.frameName != '' &&
          data.meta.frameName.length > 0 &&
          data.meta.frameName.length < 1000 &&
          !frameFound
        ) {
          iframe = document.querySelectorAll("iframe[name='" + data.meta.frameName + "']:not([data-functionise-uid])");
          if (iframe.length == 1) {
            frameFound = true;
          }

          if (!frameFound) {
            iframe = document.querySelectorAll("frame[name='" + data.meta.frameName + "']:not([data-functionise-uid])");

            if (iframe.length == 1) {
              frameFound = true;
            }
          }
        }

        if (
          typeof data.meta.frameName != 'undefined' &&
          data.meta.frameName != null &&
          data.meta.frameName != '' &&
          data.meta.frameName.length > 0 &&
          data.meta.frameName.length > 1000 &&
          !frameFound
        ) {
          iframe = document.querySelectorAll("iframe[name^='" + data.meta.frameName.substring(0, 999) + "']:not([data-functionise-uid])");
          if (iframe.length == 1) {
            frameFound = true;
          }

          if (!frameFound) {
            iframe = document.querySelectorAll("frame[name^='" + data.meta.frameName.substring(0, 999) + "']:not([data-functionise-uid])");

            if (iframe.length == 1) {
              frameFound = true;
            }
          }
        }

        if (!frameFound && typeof data.meta.frameId != 'undefined' && data.meta.frameId != null && data.meta.frameId != '') {
          iframe = document.querySelectorAll("iframe[id='" + data.meta.frameId + "']:not([data-functionise-uid])");
          if (iframe.length == 1) {
            frameFound = true;
          }

          if (!frameFound) {
            iframe = document.querySelectorAll("frame[id='" + data.meta.frameId + "']:not([data-functionise-uid])");
            if (iframe.length === 1) {
              frameFound = true;
            }
          }
        }

        if (!frameFound && typeof data.meta.frameURL != 'undefined' && data.meta.frameURL != null && data.meta.frameURL != '') {
          if (data.meta.frameURL !== 'about:blank') {
            iframe = document.querySelectorAll("iframe[src='" + data.meta.frameURL + "']:not([data-functionise-uid])");
          } else {
            // use this selector for about:blank urls that includes iframes with no src attribute
            iframe = document.querySelectorAll('iframe:not([src]), iframe[src="about:blank"]');
          }

          if (iframe.length > 1) {
            iframe.forEach((frame) => {
              if (typeof data.meta.windowWidth !== 'undefined' && data.meta.windowWidth !== '') {
                if (Math.abs(frame.getBoundingClientRect().width - Number(data.meta.windowWidth)) <= 1) {
                  frameFound = true;
                }
                if (!frameFound) {
                  if (typeof data.meta.windowHeight !== 'undefined' && data.meta.windowHeight !== '') {
                    if (Math.abs(frame.getBoundingClientRect().height - Number(data.meta.windowHeight)) <= 1) {
                      frameFound = true;
                    }
                  }
                }
              }
            });
          } else if (iframe.length === 1) {
            frameFound = true;
          }

          if (!frameFound) {
            iframe = document.querySelectorAll("frame[src='" + data.meta.frameURL + "']:not([data-functionise-uid])");
            if (iframe.length === 1) {
              frameFound = true;
            }
          }
        }

        // fallback to frame url ends with selector if it still hasn't been found
        if (!frameFound && typeof data.meta.frameURL != 'undefined' && data.meta.frameURL != null && data.meta.frameURL != '') {
          if (data.meta.frameURL !== 'about:blank') {
            iframe = document.querySelectorAll("iframe[src$='" + data.meta.frameURL.substring(data.meta.frameURL.length - 10) + "']:not([data-functionise-uid])");
          } else {
            // use this selector for about:blank urls that includes iframes with no src attribute
            iframe = document.querySelectorAll('iframe:not([src]), iframe[src="about:blank"]');
          }
          if (iframe.length === 1) {
            frameFound = true;
          }

          if (!frameFound) {
            iframe = document.querySelectorAll("frame[src$='" + data.meta.frameURL.substring(data.meta.frameURL.length - 10) + "']:not([data-functionise-uid])");
            if (iframe.length === 1) {
              frameFound = true;
            }
          }
        }

        if (!frameFound && typeof data.meta.frameSelector != 'undefined' && data.meta.frameSelector != null && data.meta.frameSelector != '') {
          iframe = document.querySelector(data.meta.frameSelector);
          if (iframe) {
            frameFound = true;
          }
        }

        if (typeof data.meta.frameTitle != 'undefined' && data.meta.frameTitle != null && data.meta.frameTitle != '' && !frameFound) {
          iframe = document.querySelectorAll("iframe[title='" + data.meta.frameTitle + "']:not([data-functionise-uid])");
          if (iframe.length === 1) {
            frameFound = true;
          }

          if (!frameFound) {
            iframe = document.querySelectorAll("frame[title='" + data.meta.frameTitle + "']:not([data-functionise-uid])");

            if (iframe.length === 1) {
              frameFound = true;
            }
          }
        }

        // fallback fallback to frame url starts with selector if it still hasn't been found
        if (!frameFound && typeof data.meta.frameURL != 'undefined' && data.meta.frameURL != null && data.meta.frameURL != '') {
          if (data.meta.frameURL !== 'about:blank') {
            // iframe = document.querySelectorAll("iframe[src^='" + data.meta.frameURL.substring(0, 20) + "']");
            iframe = document.querySelectorAll("iframe[src^='" + data.meta.frameURL.substring(0, 20) + "']:not([data-functionise-uid])");
          } else {
            // use this selector for about:blank urls that includes iframes with no src attribute
            iframe = document.querySelectorAll('iframe:not([src]), iframe[src="about:blank"]');
          }
          // iframe is a NodeList from previous querySelectorAll
          if (iframe.length === 1) {
            frameFound = true;
          }

          if (!frameFound) {
            iframe = document.querySelectorAll("frame[src^='" + data.meta.frameURL.substring(0, 20) + "']:not([data-functionise-uid])");
            if (iframe.length === 1) {
              frameFound = true;
            }
          }

          if (!frameFound) {
            if (data.meta.hasOwnProperty('windowWidth')) {
              iframe = window.WS.siteStatistics.iframeList.find(
                (iframe) =>
                  iframe.src === data.meta.frameURL && parseInt(data.meta.windowWidth) === parseInt(getComputedStyle(iframe).width && !iframe.hasAttribute('data-functionise-uid'))
              );
            }
            if (!iframe) {
              iframe = window.WS.siteStatistics.iframeList.find((iframe) => iframe.src === data.meta.frameURL && !iframe.hasAttribute('data-functionise-uid'));
            }

            if (iframe) {
              frameFound = true;
            }
          }
        }

        if (!frameFound && typeof data.meta.frameURL != 'undefined' && data.meta.frameURL != null && data.meta.frameURL != '') {
          if (data.meta.frameURL !== 'about:blank') {
            iframe = document.querySelectorAll("iframe[src='" + data.meta.frameURL + "']:not([data-functionise-uid])");
          } else {
            // use this selector for about:blank urls that includes iframes with no src attribute
            iframe = document.querySelectorAll('iframe:not([src]), iframe[src="about:blank"]');
          }

          if (iframe.length === 1) {
            frameFound = true;
            iframe = iframe[0];
          }

          if (iframe.length > 1) {
            if (typeof data.meta.windowHeight !== 'undefined' && data.meta.windowHeight !== '') {
              iframe = [...iframe].filter((iframe) => Math.abs(iframe.getBoundingClientRect().height - Number(data.meta.windowHeight)) <= 1);
            }

            if (iframe.length === 1) {
              frameFound = true;
              iframe = iframe[0];
            }
          }

          if (iframe.length > 1) {
            if (typeof data.meta.windowWidth !== 'undefined' && data.meta.windowWidth !== '') {
              iframe = [...iframe].filter((iframe) => Math.abs(iframe.getBoundingClientRect().width - Number(data.meta.windowWidth)) <= 1);
            }

            if (iframe.length === 1) {
              frameFound = true;
              iframe = iframe[0];
            }
          }

          if (!frameFound) {
            iframe = document.querySelectorAll("frame[src='" + data.meta.frameURL + "']:not([data-functionise-uid])");

            if (iframe.length > 0) {
              frameFound = true;
              iframe = iframe[0];
            }
          }
        }
      } catch (e) {
        console.log(e);
      }

      // find the frame by size if we still haven't been able to locate
      if (!frameFound) {
        if (data.meta.hasOwnProperty('windowWidth') && parseInt(data.meta.windowWidth) > 0) {
          document.querySelectorAll('frame:not([data-functionise-uid])').forEach((f) => {
            let width = parseInt(getComputedStyle(f).width) - parseInt(getComputedStyle(f).borderWidth) * 2;
            if (Math.round(parseInt(data.meta.windowWidth) / parseInt(width)) === 1) {
              if (data.meta.hasOwnProperty('windowHeight')) {
                let height = parseInt(getComputedStyle(f).height) - parseInt(getComputedStyle(f).borderWidth) * 2;
                if (Math.round(parseInt(data.meta.windowHeight) / parseInt(height)) === 1) {
                  iframe = f;
                  frameFound = true;
                }
              } else {
                iframe = f;
                frameFound = true;
              }
            }
          });
          if (!frameFound) {
            document.querySelectorAll('iframe:not([data-functionise-uid])').forEach((f) => {
              let width = parseInt(getComputedStyle(f).width) - parseInt(getComputedStyle(f).borderWidth) * 2;
              if (Math.round(parseInt(data.meta.windowWidth) / parseInt(width)) === 1) {
                if (data.meta.hasOwnProperty('windowHeight')) {
                  let height = parseInt(getComputedStyle(f).height) - parseInt(getComputedStyle(f).borderWidth) * 2;
                  if (Math.round(parseInt(data.meta.windowHeight) / parseInt(height)) === 1) {
                    iframe = f;
                    frameFound = true;
                  }
                } else {
                  iframe = f;
                  frameFound = true;
                }
              }
            });
          }
        }
      }

      if (frameFound) {
        if (iframe.length > 1 || iframe.length === 1) {
          iframe = iframe[0];
        }
        // Assuming `iframe` is a reference to the iframe element(s)
        iframe.setAttribute('data-functionise-UID', data.UID);

        // Find the iframe with the specific data-functionize-index and remove the attribute
        const indexedIframe = document.querySelector("iframe[data-functionize-index='" + data.functionizeIframeIndex + "']");
        if (indexedIframe) {
          indexedIframe.removeAttribute('data-functionize-index');
        }

        // Set the new data-functionize-index on the current iframe
        iframe.setAttribute('data-functionize-index', data.functionizeIframeIndex);
      }

      if (typeof data.functionizeIframeIndex !== 'undefined' && !frameFound) {
        let iframeElement = document.querySelector("iframe[data-functionize-index='" + data.functionizeIframeIndex + "']");
        if (iframeElement) {
          console.log('Setting UID data on functionizeIframeIndex ' + data.functionizeIframeIndex);
          iframeElement.setAttribute('data-functionise-UID', data.UID);
          console.log('functionizeIframeIndex is set to: ' + iframeElement.getAttribute('data-functionise-UID'));
        } else {
          let frameElement = document.querySelector("frame[data-functionize-index='" + data.functionizeIframeIndex + "']");
          if (frameElement) {
            console.log('Setting UID data on functionizeIframeIndex ' + data.functionizeIframeIndex);
            frameElement.setAttribute('data-functionise-UID', data.UID);
            console.log('functionizeIframeIndex is set to: ' + frameElement.getAttribute('data-functionise-UID'));
          } else {
            console.log('iframe index has not returned an iframe: ' + data.functionizeIframeIndex);
            let iframes = document.querySelectorAll('iframe');
            let frames = document.querySelectorAll('frame');
            let i = 0;

            iframes.forEach((iframe) => {
              if (i === data.functionizeIframeIndex) {
                iframe.setAttribute('data-functionize-index', data.functionizeIframeIndex);
                iframe.setAttribute('data-functionise-UID', data.UID);
                console.log('iframe index is set now...');
              }
              i++;
            });

            frames.forEach((frame) => {
              if (i === data.functionizeIframeIndex) {
                frame.setAttribute('data-functionize-index', data.functionizeIframeIndex);
                frame.setAttribute('data-functionise-UID', data.UID);
                console.log('frame index is set now...');
              }
              i++;
            });
          }
        }
      }

      window.TCM.registerChild(data);
      if (window.TCM.isVerifying) {
        var command = { obj: 'WS', call: 'startCollecting', arguments: 'master' };

        var targetIframe = window.WS.getIframeByUID(data.UID, data.frameURL);

        if (targetIframe === null) {
          return;
        }
        command.meta = { UID: data.UID };
        window.TCM.sendCommand(command, targetIframe.contentWindow);
      }
    } else {
      //we are not ready ourselves yet.   We'll be adding regs now
      if (!window.TCM.requestRegistrationSent) window.TCM.sendRequestRegistration();

      window.TCM.registrationQueue.push(data);
    }
  };

  this.registerChild = function (data) {
    console.log('registerChild registered', data);
    if (data.windowType === 'popup') {
      data.selector = '';
      data.index = window.WS.popups.length;
      window.WS.popups.push(data.UID);
      this.registerChildAccept(data, undefined, data.windowType + data.UID);
      // let newpopup = { newpopup: data.UID };
      // if (data.meta.hasOwnProperty('openerUID')) {
      //   newpopup = { newpopup: data.UID, openerUID: data.meta.openerUID };
      // }
      // window.WS.appendToRecordedData(newpopup, 'click|emailreceive|smsreceive|navigate|apicall');
      return;
    }
    var needControllerFrame = false;
    if (!window.TCM.isController && window.TCM.isMaster) needControllerFrame = true;

    window.WS.registerIframe(data, needControllerFrame);
  };

  this.registerChildAccept = function (data, allowController, path) {
    console.log('registerChildAccept registered', data, allowController, path);
    if (typeof allowController == 'undefined') allowController = false;

    if (typeof path == 'undefined') path = '';

    var isController = null;
    if (allowController && !window.TCM.hasAllowedController) {
      window.TCM.hasAllowedController = true;
      isController = true;
      window.TCM.allowedControllerFramePath = path;
    } else {
      isController = false;
    }

    var isMaster = false;
    var command = {
      obj: 'TCM',
      call: 'registered',
      arguments: { isMaster: false, isController: isController, path: path },
    };
    var meta = {
      windowType: data.windowType,
      UID: data.UID,
      index: data.index,
      selector: data.selector,
      targetElement: JSON.stringify(data.targetElement),
      iframeOffsetX: data.iframeOffsetX,
      iframeOffsetY: data.iframeOffsetY,
      traverseIframeComp: data.traverseIframeComp,
      functionizeid: data.functionizeid,
      traverseIframenextNodeId: data.traverseIframenextNodeId,
    };

    if (data.hasOwnProperty('attributes') && Object.keys(data.attributes).length > 0) {
      meta.attributes = data.attributes;
    }

    window.TCM.sendCommand(command, null, meta);
    //send runtime vars to child...
    var rv = JSON.stringify(this.runtimeVariables);
    command = { obj: 'TCM', call: 'setRuntimeVariables', arguments: rv };
    window.TCM.sendCommandToDescendants(command);
  };

  //we loop through the queue and send the registration call
  this.registerQueuedChildren = function () {
    console.log('registerQueuedChildren registered', this.registrationQueue);
    //this.sendCurrentStates();
    window.fconsole.log('Children queue size: ' + this.registrationQueue.length);
    for (var i = 0; i < this.registrationQueue.length; i++) {
      window.fconsole.log('Processing queued registration request at index ' + i);
      this.registerChild(this.registrationQueue[i]);
    }
  };

  this.setFramePropertiesInPlugin = function () {
    var height = window.innerHeight;
    if (height < window.WS.minWindowHeight) height = window.WS.minWindowHeight;

    var command = {
      obj: 'null',
      call: 'setFrameProperties',
      meta: {
        fromUID: window.WS.popupUID,
        windowWidth: window.innerWidth,
        windowHeight: height,
        scrollLeft: window.scrollX,
        scrollTop: window.scrollY,
      },
    };
    console.log('Sending frame properties:' + JSON.stringify(command));
    window.TCM.sendCommand(command);
  };

  this.triggerRecorderScreenshot = function (recData, delay) {
    if (typeof delay == 'undefined') delay = 0;

    if (delay < 1) {
      this.sendPluginScreenshotRequest(recData);
    } else {
      setTimeout(function () {
        window.TCM.sendPluginScreenshotRequest(recData);
      }, delay);
    }
  };

  this.sendPluginScreenshotRequest = function (recData) {
    //window.fconsole.log("SOUREV - sendPluginScreenshotRequest");
    var command = { obj: 'TCM', call: 'takeScreenshot', arguments: recData };
    window.chromePort.postMessage(command);
  };

  this.saveRuntimeVariables = function () {
    var rv = JSON.stringify(this.runtimeVariables);
    var command = { obj: 'TCM', call: 'saveRuntimeVariables', arguments: rv };
    this.sendCommandToMaster(command);
  };

  this.loadResourceData = function () {
    var rv = '';
    var command = { obj: 'TCM', call: 'loadResourceData', arguments: rv };
    this.sendCommandToMaster(command);
  };

  this.setRuntimeVariables = function (value) {
    window.fconsole.log("Setting runtime vars: '" + value + ' type ' + typeof value);
    if (typeof value != 'undefined' && value.trim() != '' && value != 'undefined') window.TCM.runtimeVariables = JSON.parse(value);
  };

  this.getProjectVariable = function (index) {
    return index;
  };

  this.getFunctionizeappEmail = function (index) {
    if (typeof index == 'undefined') index = '';
    if (typeof this.runtimeVariables['functionizeappEmail' + index] != 'undefined') {
      return this.runtimeVariables['functionizeappEmail' + index];
    }

    this.runtimeVariables['functionizeappEmail' + index] = window.WU.randomFunctionizeappEmail();
    this.saveRuntimeVariables();
    return this.runtimeVariables['functionizeappEmail' + index];
  };

  this.getFunctionizeappPhone = function (strVal) {
    this.runtimeVariables['functionizeappPhone'] = window.WU.getFunctionizeappPhone(strVal);
    this.saveRuntimeVariables();
    return this.runtimeVariables['functionizeappPhone'];
  };

  this.setStyleImp = function (obj, key, value) {
    obj.css(key, '');
    obj.style(key, value, 'important');
    var keyValue = obj.style(key);
    if (!keyValue) {
      obj.css(key, value + 'px');
    }
  };

  this.setRelatedElementFlag = function (state) {
    window.TCM.flagRelatedElement = state;
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('setRelatedElementFlag', state);
  };

  this.callSetTargetGenerateData2 = function (data) {
    self.port.emit('message', {
      obj: 'f-vue',
      call: 'setTargetGenerateData2',
      arguments: data,
      forMaster: true,
    });
  };

  this.setTargetGenerateData2 = function (data) {
    console.log('setTargetGenerateData2', data);
    this.projectVariableTargetingElement = data.projectVariableTargetingElement;
    this.projectVariableValue = data.projectVariableValue;
    this.projectVariableDisplay = data.projectVariableDisplay;

    if (data.hasOwnProperty('projectVariableLoad_name')) {
      this.projectVariableLoad_name = data.projectVariableLoad_name;
    }

    if (data.hasOwnProperty('projectVariableLoad_attribute')) {
      this.projectVariableLoad_attribute = data.projectVariableLoad_attribute;
    }

    if (data.hasOwnProperty('projectVariableLoad_operation')) {
      this.projectVariableLoad_operation = data.projectVariableLoad_operation;
    }

    if (this.projectVariableTargetingElement) {
      setTimeout(() => {
        window.TCM.collapse();
      }, 300);
    } else {
      window.TCM.unCollapse(true);
    }
    if (window.TCM.isMaster) {
      window.TCM.sendCallToDescendants('setTargetGenerateData2', data);
      window.WS.removeHighlights();
      // window.TH.clearAll();
      window.WU.fShowAllElements();
    }
  };

  this.callSetTargetGenerateData = function (data) {
    self.port.emit('message', {
      obj: 'f-vue',
      call: 'setTargetGenerateData',
      arguments: data,
      forMaster: true,
    });
  };

  this.setTargetGenerateData = function (data) {
    this.generatedDataTargetingElement = data.generatedDataTargetingElement;
    this.generatedDataFunction = data.generatedDataFunction;
    this.localGeneratedDataResult = data.localGeneratedDataResult;
    if (this.generatedDataTargetingElement) {
      setTimeout(() => {
        window.TCM.collapse();
      }, 300);
    } else {
      window.TCM.unCollapse(true);
    }
    if (window.TCM.isMaster) {
      window.TCM.sendCallToDescendants('setTargetGenerateData', data);
      window.WS.removeHighlights();
      // window.TH.clearAll();
      window.WU.fShowAllElements();
    }
  };

  this.addRelatedElement = function (target) {
    window.TCM.currentElementForRelated = target;
    window.TCM.setRelatedElementFlag(false);
    window.TCM.unCollapse();
    var command = {
      obj: 'f-vue',
      call: 'setSelectedRelatedElement',
      arguments: target,
    };
    this.sendCommand(command, window.parent);
    if (window.TCM.isMaster) window.TCM.sendCallToDescendants('addRelatedElement', target);
  };

  this.formatSelectorElement = function (se, removeindex) {
    var ses = se.split('[');

    if (ses[1]) {
      var sess = ses[1].split(']');
      if (sess[0]) {
        var eq = sess[0];

        if (removeindex) return ses[0];
        else {
          return ses[0] + ':eq(' + (parseInt(eq) - 1) + ')';
        }
      } else {
        if (removeindex) return se;
        else {
          return se + ':eq(0)';
        }
      }
    } else {
      if (removeindex) return se;
      else {
        return se + ':eq(0)';
      }
    }
  };
  this.submitCheck = function () {
    var selfObj = this;
    if (selfObj.submitCheckSubmitted) {
      return false;
    }

    selfObj.submitCheckSubmitted = true;
    //check for title
    var element = document.getElementById('f-functionise-tc-manager-form-title');

    // Check if the element exists and its value is empty
    if (element && element.value.trim() === '') {
      window.functionizeVex.dialog.alert('Please enter a title for this test case.');
      return;
    }
    if (window.functionizeStandalone) {
      //pass back to Java app

      var formElement = document.getElementById('f-functionise-tc-manager-form-form');
      // Call the method with the form element
      window.TCM.retrieveFormValues(formElement);
    } else {
      //normal submit to webapp
      // Create and append hidden input for submit_time
      var submitTimeInput = document.createElement('input');
      submitTimeInput.type = 'hidden';
      submitTimeInput.name = 'submit_time';
      submitTimeInput.value = new Date().getTime();
      document.querySelector('#f-functionise-tc-manager-form-projectId').insertAdjacentElement('afterend', submitTimeInput);

      if (typeof window.functionizeEditMode !== 'undefined') {
        // Submit the form
        document.querySelector('#f-functionise-tc-manager-form-form').submit();
      } else {
        // Show loader
        document.querySelectorAll('.testsaveloader').forEach((el) => (el.style.display = 'block'));

        // Prepare data to send
        var formData = new FormData();
        formData.append('projectId', document.querySelector('#f-functionise-tc-manager-form-projectId').value);
        formData.append('data', document.querySelector('#f-functionise-tc-manager-form-data').value);
        formData.append('title', document.querySelector('#f-functionise-tc-manager-form-title').value);

        // Send POST request
        fetch('https://' + window.WS.wbHost + '/ajax/addrecordlog', {
          method: 'POST',
          body: formData,
        })
          .then((response) => response.text())
          .then((logId) => {
            selfObj.submitCheckSubmitted = false;
            if (logId) {
              window.TCM.finalizeTest();
              var command = { obj: 'TCM', call: 'cancelTask' };
              window.TCM.sendCommandToMaster(command);

              // Create and append hidden input for logId
              var logIdInput = document.createElement('input');
              logIdInput.type = 'hidden';
              logIdInput.id = 'f-functionise-tc-manager-form-log_id';
              logIdInput.name = 'log_id';
              logIdInput.value = logId;
              document.querySelector('#f-functionise-tc-manager-form-projectId').insertAdjacentElement('afterend', logIdInput);

              // Clear data and hide loader
              document.querySelector('#f-functionise-tc-manager-form-data').value = '';
              document.querySelectorAll('.testsaveloader').forEach((el) => (el.style.display = 'none'));

              // Submit the form
              document.querySelector('#f-functionise-tc-manager-form-form').submit();
            }
          })
          .catch((error) => console.error('Error:', error));

        // Timeout to check for log_id
        setTimeout(function () {
          var logIdElement = document.querySelector('#f-functionise-tc-manager-form-log_id');
          if (!logIdElement || !logIdElement.value) {
            selfObj.submitCheckSubmitted = false;
            selfObj.simpleFormSubmit = true;
            window.TCM.finalizeTest();
            var command = { obj: 'TCM', call: 'cancelTask' };
            window.TCM.sendCommandToMaster(command);
            document.querySelectorAll('.testsaveloader').forEach((el) => (el.style.display = 'none'));
            document.querySelector('#f-functionise-tc-manager-form-form').submit();
          }
        }, 30000);
      }
    }
  };
}

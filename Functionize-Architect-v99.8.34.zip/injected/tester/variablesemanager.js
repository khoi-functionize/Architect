window.fze = new Proxy(
  {
    resource: [],
    system: {},
    local: {},
    project: {},
    actions: {},
    action: function (actionId) {
      return window?.WS?.recordedData.find((action) => action.actionId === actionId) || this.actions[actionId];
    },
    html: {},
    resourceVariable: {},
    init: function () {
      let cookies = window.WS.getOtherCookies();
      if (cookies) {
        cookies.forEach((cookie) => {
          this.cookie[cookie.name] = cookie;
        });
      }
      try {
        Object.keys(window.localStorage).forEach((htmlVariableName) => {
          this.html[htmlVariableName] = window.localStorage[htmlVariableName];
        });
      } catch (e) {
        console.log(e);
      }
    },
    setAction: function (action) {
      this.actions[action.actionId] = action;
      for (let prop in this.actions[action.actionId]) {
        if (prop.startsWith('attr_')) {
          // configure attributes data
          if (!this.actions[action.actionId].hasOwnProperty('attributes')) {
            this.actions[action.actionId].attributes = {};
          }
          this.actions[action.actionId].attributes[prop.replace('attr_', '')] = this.actions[action.actionId][prop];
        }
      }

      // replace variable expressions with generated values
      if (
        this.actions[action.actionId].hasOwnProperty('actualstring') ||
        this.actions[action.actionId].hasOwnProperty('generatedValue') ||
        this.actions[action.actionId].hasOwnProperty('selectText')
      ) {
        if (this.actions[action.actionId].value && this.actions[action.actionId].value !== '') {
          this.actions[action.actionId].value = action.actualstring || action.generatedValue || action.selectText;
        }
        if (this.actions[action.actionId].text && this.actions[action.actionId].text !== '') {
          this.actions[action.actionId].text = action.actualstring || action.generatedValue;
        }
      }
    },
    setVariablesByType: function (variable) {
      this[variable.type][variable.name] = variable.value;
      if (window.TCM.isMaster) {
        try {
          this.sendValueToDescendants('setVariablesByType', variable);
        } catch (e) {}
      }
    },
    removeVariablesByType: function (variable) {
      delete this[variable.type][variable.name];
      if (window.TCM.isMaster) {
        this.sendValueToDescendants('removeVariablesByType', variable);
      }
    },
    setVariables: function (variables) {
      console.log('setVariables', variables);
      Object.keys(variables).forEach((type) => {
        Object.keys(variables[type]).forEach((variable) => {
          this[type][variable] = variables[type][variable].value;
        });
      });
      if (window.TCM.isMaster) {
        this.sendValueToDescendants('setVariables', variables);
      }
    },
    setResourceVariables: function (resourceVariables) {
      Object.keys(resourceVariables).forEach((resourceVariableUrl) => {
        this.resource[resourceVariableUrl] = resourceVariables[resourceVariableUrl];
      });
    },
    sendValueToDescendants: function (call, data) {
      var command = { obj: 'WS', call: call, forMaster: true, arguments: data };
      window.TCM.sendCommandToDescendants(command);
    },
    getAsyncAction: function (actionId) {
      return (async () => {
        try {
          return await window.TCM.callActionByActionId(actionId);
        } catch (e) {
          return 0; // fallback value
        }
      })();
    },
    getCookie: function (cookieId) {
      let cookies = window.WS.getOtherCookies();
      let cookie = cookies.find((element) => {
        return element.name == cookieId;
      });
      return cookie;
    },
    date: new Date(),
    randomPhone: function (format = 'XXX-XXX-XXXX') {
      while (format.includes('X')) {
        format = format.replace('X', Math.floor(Math.random() * 10));
      }
      return format;
    },
    randomNumber: function (length = 3) {
      return Math.floor(Math.random() * 10 ** length);
    },
    randomText: function (length = 10) {
      var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
      var string = '';
      for (let i = 0; i < length; i++) {
        string += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return string;
    },
    randomString: function (length = 10, includeNumbers = false) {
      var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      var string = '';
      for (let i = 0; i < length; i++) {
        string += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return string;
    },
    randomEmail: function (domain = 'example.com') {
      return (
        (Math.random() + 1)
          .toString(36)
          .substring(2, Math.random() * (12 - 8) + 8)
          .toLowerCase() +
        '@' +
        domain
      );
    },
    randomDoB: function (min, max) {
      var nowDate = new Date();
      var minDate = new Date();
      minDate.setFullYear(nowDate.getFullYear() - min);
      var maxDate = new Date();
      maxDate.setFullYear(nowDate.getFullYear() - (max + 1));
      return new Date(Math.random() * (maxDate.getTime() - minDate.getTime()) + minDate.getTime());
    },
    extractNumbers: function (string) {
      return string.replace(/\\D/g, '');
    },
    extractFloat: function (string) {
      return string.match(/[+-]?\\d+(\\.\\d+)?/g).map(function (v) {
        return parseFloat(v).toString();
      })[0];
    },
    pageVariable: function (name) {
      let variable = window.TCM.getRelatedPageVariables(name);
      return variable[name];
    },
    cookie: (name) => ('; ' + document.cookie).split(`; ${name}=`).pop().split(';')[0],
    localStorage: (name) => localStorage[name] || '',
    pageVariables: (name) => {
      try {
        return eval(name) || '';
      } catch (e) {
        return '';
      }
    },
  },
  {
    set: function (event) {
      throw new Error('Cannot assign directly to fze.VAR');
    },
  }
);

export function _functionizeEvaluator_(exprFn) {
  var error = null;
  try {
    var result = exprFn(window._functionizeFzeObject_);
  } catch (e) {
    error = e;
  }
  return {
    result: result,
    error: error,
  };
}

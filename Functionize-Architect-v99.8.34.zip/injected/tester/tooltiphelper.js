export function tooltipHelper() {
  this.tooltips = new Array();
  this.coreTooltips = new Array();
  this.adjust = {
    screen: true,
  };

  this.doAnimation = true;

  this.setAdjust = function(data) {
    //this.adjust = data;
  };

  this.create = function(mouseTarget, elementTarget, text, autoHide, positionMy, positionAt, isCore, type) {
    try {
      // eslint-disable-next-line no-unused-expressions
      if (isCore == undefined) isCore == false;

      var tipClass = window.fUniqPrefix + '-panel-qtip-tipsy';

      if (type == undefined) {
        type = 'info';
      }

      if (type == 'error') tipClass = window.fUniqPrefix + '-panel-qtip-red';

      if (type == 'success') tipClass = window.fUniqPrefix + '-panel-qtip-green';

      if (type == 'warning')
        // default yellow
        tipClass = '';

      if (type == 'verify') tipClass = '';

      this.clearAll();
      var position = {
        my: positionMy, // Position my top left…
        at: positionAt, // at the bottom right of…
        target: elementTarget, // my target
        adjust: this.adjust,
        viewport: window,
      };

      var options = {
        content: text,
        position: position,
        style: {
          classes: 'qtip-rounded ' + window.fUniqPrefix + ' ' + tipClass,
        },
      };
      if (!this.doAnimation) {
        options.show = {
          effect: false,
        };
      }
      var tooltip = mouseTarget.qtip(options);

      if (!isCore) this.tooltips.push(tooltip);
      else this.coreTooltips.push(tooltip);

      return tooltip;
    } catch (e) {
      window.fconsole.log(e.message);
    }
  };

  this.destroy = function(tooltip) {
    try {
      tooltip.qtip('destroy', true);
    } catch (e) {
      window.fconsole.log('Unable to clear tooltip destroy…');
    }
  };

  this.hide = function(tooltip) {
    if (tooltip == undefined) return;
    try {
      tooltip.qtip('api').toggle(false); //Hide
    } catch (e) {
      window.fconsole.log('Unable to hide tooltip…' + e.message);
    }
  };

  this.show = function(tooltip) {
    if (typeof tooltip == 'undefined') return;
    try {
      tooltip.qtip('api').toggle(true); //Show
    } catch (e) {
      window.fconsole.log('Unable to show tooltip…' + e.message);
    }
  };

  this.clearAll = function(core) {
    try {
      if (typeof core == 'undefined') core = false;

      for (let i = 0; i < this.tooltips.length; i++) {
        window.fconsole.log('Clearing tooltip ' + i);
        this.destroy(this.tooltips[i]);
      }
      this.tooltips = new Array();
      if (core) {
        for (let i = 0; i < this.coreTooltips.length; i++) {
          this.destroy(this.coreTooltips[i]);
        }
        this.coreTooltips = new Array();
        try {
          document.querySelectorAll('.qtip').forEach(function(element) {
            element.remove();
          }); //remove all for sure
        } catch (e) {}
      }
    } catch (e) {}
  };

  this.createCore = function() {
    if (!window.WS.settings.helperOn) return;
    if (window.TCM.recording) {
      this.create('#startstop-button', '#startstop-button', 'Stop Modeling', 0, 'top middle', 'bottom middle', true);
    } else {
      this.create('#startstop-button', '#startstop-button', 'Start Modeling', 0, 'top middle', 'bottom middle', true);
    }
    this.create('#verify-button', '#verify-button', 'Drop Checkpoint', 0, 'top middle', 'bottom middle', true);
    this.create('#cancel-button', '#cancel-button', 'Cancel Test', 0, 'top middle', 'bottom middle', true);
    this.create('#settings-button', '#settings-button', 'Advanced Panel', 0, 'top middle', 'bottom middle', true);

    this.create('#notepad-button', '#notepad-button', 'Action Note', 0, 'top middle', 'bottom middle', true);
  };

  this.createTabTP = function() {
    //
  };
}

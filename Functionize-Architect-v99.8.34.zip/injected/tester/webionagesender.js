import { functioniseAssocVars, wsElement, functioniseTestResult, functioniseSettings } from '../modeler/common';
import { functionizeAddListener, functionizeRemoveListener, functioniseMouseoutListener, functioniseMouseleaveListener } from '../modeler/listeners/allListeners';
import xPathToCss from 'xpath-to-css';
import { injectCSS } from './cssInjector';
import SiteStatistics from 'site-statistics-js/src/SiteStatistics';
import tippy from 'tippy.js';

// Main Sender Object
export function WebionageSender() {
  this.maxDownloadInterval = 2000;
  this.mlDataElements = {};
  this.lastActionIsInstructionOrPO = false;
  this.lastAction = null;
  this.keyDownElement = null;
  this.nlp_live = false;
  this.userId = 0;
  this.teamId = 0;
  this.forceZoom = false;
  this.preferDomsnapshot = false;
  this.collectStatistics = true;
  this.collectFormData = false;
  this.enableTabKeypress = false;
  this.siteStatistics = new SiteStatistics(true);
  this.siteStatisticsMap = {};
  this.siteStatisticsInputMap = {};
  // this.siteStatistics.allElements2 = document;
  this.pageStats = {};
  this.on = true;
  this.unload = false;
  this.isDemo = false;
  this.testCaseTitle = '';
  this.verify = null;
  // this gets set on hover.	  Verify above gets set on mousedown
  this.verifyCurrentElement = null;
  this.verifyCurrentElementEvent = null;
  this.isClicking = false;
  this.isTest = 0;
  this.UID = '';
  this.sending = false;
  this.mousex = 0;
  this.mousey = 0;
  this.zoom = 1;
  this.lastZoom = 0;
  // xoffset is used for receiving data to place cursor on page
  this.xoffset = 0;
  this.lastMousex = 0;
  this.lastMousey = 0;
  this.mouseoverTraceX = new Array();
  this.mouseoverTraceY = new Array();
  this.scrollTop = 0;
  this.scrollLeft = 0;
  this.lastScrollTop = 0;
  this.lastScrollLeft = 0;
  this.inputVals = new Array();
  this.allInputVars = new Array();
  this.allSelectVars = new Array();
  this.allRadioVars = new Array();
  this.allCheckVars = new Array();
  this.inputToSend = {};
  this.lastInputToSend = {};
  this.selectToSend = {};
  this.lastSelectToSend = {};
  this.radioToSend = {};
  this.lastRadioToSend = {};
  this.checkToSend = {};
  this.lastCheckToSend = {};
  this.clickToSend = {};
  this.clickToSendCopy = {};
  this.lastClickToSend = {};
  this.currentElement = {};
  this.currentElementIndex = {};
  this.enterToSend = {};
  this.enterToSendUp = {};
  this.windowUnloading = false;
  this.lastEnterToSend = {};
  this.enterToSendElement = {};
  this.enterToSendIndex = {};
  this.enterToSendTs = -1;
  this.scrollToElementOnToSend = {};
  this.lastScrollToElementOnToSend = {};
  this.hoverOnToSend = {};
  this.lastHoverOnToSend = {};
  this.html5dragdropToSend = {};
  this.lastHtml5dragdropToSend = {};
  this.dragElement = false;
  this.html5dragstart = {};
  this.dropEventSent = false;
  this.noDealShowTimes = 0;
  this.noPromoShowTimes = 0;
  this.noDealHideTimes = 0;
  this.noPromoHideTimes = 0;
  this.checkStatusCounter = 0;
  this.checkInSpeed = 25;
  this.doSend = 0;
  this.doLogIn = true;
  this.isLoggedIn = false;
  this.browser = null;
  this.browserVersion = null;
  this.locUrl = '';
  this.hasLazyLoad = false;
  this.referrer = document.referrer;
  this.hasFocus = 1;
  this.lastHasFocus = 1;
  this.searchEngine = 'Unknown';
  this.lastData = '';
  this.coreData = '';
  this.isPdf = false;
  this.statusCounterThreshold = 30;
  this.hooksCalled = new Array();
  this.ipAddress = '';
  this.did = null;
  this.wbHost = 'app.functionize.com';
  this.cloudStorage = 'storage-download.googleapis.com/functionize-public';
  this.view_theme_path = 'views/themes/default/';
  this.wbServerPort = null;
  this.wbIsSSL = false;
  this.isTracking = false;
  this.refreshSpeed = 1000;
  this.animateSpeed = this.refreshSpeed - 100;
  this.isResizedWindow = false;
  this.useContextSwitchAction = false;
  this.processIframeMlDataCache = {};
  this.suppressChangeListener = false;

  // recording repeated stuff
  this.doRecording = 0;
  this.recordingId = null;
  this.recordedData = new Array();
  this.isNewRecordedPage = true;
  this.isIpRequested = false;
  this.origRecordedData = '';
  this.lastRecordTime = new Date().getTime();
  this.totalVisitLength = 0;

  this.deviceData = {};
  // this is a default
  // should be overridden by speedtest
  // about 1 meg // should be enough for at least 10 minutes of data
  this.WBdata = '';
  this.recordedDataLimit = 128000;
  this.startTime = new Date().getTime();
  this.justStarted = false;

  this.iframeCoordinates = {};

  this.recorded = -1;
  this.lastRecordedActionId = '';
  this.isUnload = false;

  // wb ajax stuff here
  this.callCounter = 0;
  this.request_script = new Array();
  // making sure that we do not request the same thing twice
  this.isWbajax = new Array(false, false);
  // is iframe instance
  this.isIframe = false;
  this.iframeIndex = 0;
  this.iframeUID = '';
  this.functionizeid = '';
  this.iframes = new Array();
  this.path = ''; // we store here the current windows, frames path -- for now used mainly in framesets when the controller is not the main win
  this.isNewpage = true;
  this.isPopup = false;
  this.popups = new Array();
  this.popupUID = '';
  this.collecting = false;
  this.alertWindow = null;
  this.dragevent = null;
  this.actionLimit = 40;
  this.actionCount = 0;
  this.maxWindowWidth = 1920;
  this.maxWindowHeight = 1080;
  this.minWindowHeight = 300;
  this.hasWindowSizeError = false;
  this.hasInputInit = false;
  this.settings = new functioniseSettings();
  this.shiftDown = false;
  this.dKeyDown = false;
  this.associatedKey = '';
  this.keyboardPaste = false;
  this.keyboardCopy = false;
  this.mkeyDownCounter = 0;
  this.ckeyDownCounter = 0;
  this.lastObservedElement = null;
  this.isFunctionised = false;
  this.recorderLiteVersion = false;
  this.recorderTurkVersion = false;
  this.do_not_use_css_offset = 0;
  this.enable_ad_tracking = false;
  this.start_url = '';
  this.start_recording_automatically = false;
  this.disable_data_functionize_disabled_element_flag = false;
  this.keep_recorder_on_top = false;
  this.ignore_hidden_elements = true;
  this.enable_browser_navigation_buttons = false;
  this.testing_urls = {};
  this.captureCompleteUrl = false;
  this.liveEditPlanStep = 1;
  this.disableIframeCapture = false;
  this.limitDataCapture = false;
  this.unsupportedTargetElements = new Array('object', 'applet', 'embed', 'frameset', 'keygen'); //, 'canvas','svg','iframe','frame'
  this.allowBodyTargetElement = false;
  this.unsupportedParentElements = new Array(); // new Array('svg');
  this.disableExtendedData = false;
  this.testJobId = '';
  this.mturkWorkerId = '';
  this.captureLargeData = false;
  this.enableSVGChildren = false;
  this.flashTimer = false;

  this.functionizeappEmailURL = 'https://www.functionizeapp.com/tools/emailreader';
  this.functionizeappSMSURL = 'https://www.functionizeapp.com/tools/textreader';
  this.functionizeappAPIURL = 'https://www.functionizeapp.com/tools/apiexplorer';
  this.functionizeappFileViewer = 'https://www.functionizeapp.com/tools/fileviewer';
  this.functionizeappDBExplorer = 'https://www.functionizeapp.com/tools/dbexplorer';

  this.iframeInitPathSelector = '';

  // this.focusOnElementFlag = true;

  this.resizeTimer = false;
  this.createDownloadTimer = false;

  this.isPointerDown = false;
  this.isMouseDown = false;
  this.enableCaptureSignature = false;
  this.canvasSignature = [];
  this.canvasSignatureSingle = {};
  this.canvasSignatureCount = 0;
  this.canvasSignatureEnabled = false;
  this.canvasSignatureElement = '';

  this.searchedPageVariables = {};
  this.recordedRandomVariables = {};
  this.clickEventCheck = {};

  this.hoverData = false;

  this.computedVariable = {};

  this.runtimeDebugCancel = false;
  this.lastMLAction = '';
  this.lastMLSelector = '';

  // removing this feature for preFocus and postFocus due to issues
  // this.activeElements = { pre: document.body, post: document.body };

  this.pageInitId = null;

  this.debounceTimer = false;
  this.keypressDebounce = false;
  this.scrollDebounceTimer = false;
  this.scrollElementDebounceTimer = false;
  this.scrollElements = [];

  this.pointerDownTrace = [];
  this.pointerDownTraceWait = false;
  this.pointerDownTracing = false;
  this.pointerDownDndTracing = false;
  this.pointerDownTracePerSecond = 10;
  this.pointerDownTraceOffset = { x: 0, y: 0 };
  this.pointerDownTraceTimestamp = null;
  this.pointerDownTraceTimestampOffset = null;

  this.hasScroll = false;

  this.traverseIframe = null;
  this.traverseIframeComp = null;
  // this.initTraverseIframes = false;
  this.functionizeValidateCustomJSActionID = null;
  this.functionizeValidateCustomJSProperty = null;
  this.functionizeValidateCustomJSTime = null;
  this.functionizeValidateCustomJSElement = null;
  this.functionizeValidateCustomJSResult = null;
  this.functionizeValidateCustomJSResultTimer = null;
  this.functionizeValidateCustomJSUpdateTimer = null;
  this.functionizeValidateCustomJSDisplay = null;
  this.functionizeValidateCustomJSError = null;
  this.generateNewVariableTimer = null;
  this.getPreviousActionDataTimer = null;
  this.removableNewPopup = ['DBExplorer', 'fileViewer', 'emailreceive', 'smsreceive', 'navigate', 'apicall'];

  this.collectMlDataOnKeydown = false;
  this.keyDownMlData = '';

  this.iframeIndex = 0;

  this.init = function () {
    this.wbHost = window.functioniseHttpHost; // 'www.functionise.com';
    this.cloudStorage = window.functionizeCloudStorage;

    // Check for lazy loading pages
    if (
      document.querySelector("[loading='lazy']") !== null ||
      document.querySelector('img[data-src]') !== null ||
      document.querySelector('.lazy-load') !== null ||
      document.querySelector('.lazyload') !== null
    ) {
      this.hasLazyLoad = true;
    }
  };

  this.resetData = function () {
    this.recordedData = new Array();
    this.pointerDownTrace = [];
    this.pointerDownTraceWait = false;
    this.pointerDownTraceOffset = { x: 0, y: 0 };
    this.pointerDownTraceTimestamp = null;
    this.pointerDownTracing = false;
    this.pointerDownDndTracing = false;
    this.pointerDownTraceTimestampOffset = null;
    this.coreData = null;
    this.isPdf = false;
    this.collecting = false;
    this.hasInputInit = false;
    this.actionCount = 0;
    this.testCaseTitle = '';
    this.mousex = 0;
    this.mousey = 0;
    // xoffset is used for receiving data to place cursor on page
    this.xoffset = 0;
    this.lastMousex = 0;
    this.lastMousey = 0;
    this.scrollTop = 0;
    this.scrollLeft = 0;
    this.lastScrollTop = 0;
    this.lastScrollLeft = 0;
    this.inputVals = new Array();
    this.allInputVars = new Array();
    this.allSelectVars = new Array();
    this.allRadioVars = new Array();
    this.allCheckVars = new Array();
    this.inputToSend = '';
    this.lastInputToSend = '';
    this.selectToSend = '';
    this.lastSelectToSend = '';
    this.radioToSend = '';
    this.lastRadioToSend = '';
    this.checkToSend = '';
    this.lastCheckToSend = '';
    this.clickToSend = '';
    this.clickToSendCopy = '';
    this.lastClickToSend = '';
    this.enterToSendElement = '';
    this.enterToSendIndex = '';
    this.enterToSendTs = -1;
    this.lastEnterToSend = '';
    this.lastScrollToElementOnToSend = {};
    this.lastHoverOnToSend = '';
    this.noDealShowTimes = 0;
    this.noPromoShowTimes = 0;
    this.noDealHideTimes = 0;
    this.noPromoHideTimes = 0;
    window.TCM.setShiftDown(false);
    this.pageInitId = null;
    this.hasScroll = false;
    this.traverseIframe = null;
    this.traverseIframenextNodeId = null;
    this.traverseIframeComp = null;
    this.processIframeMlDataCache = {};
    this.suppressChangeListener = false;
  };

  this.capturePointerPositions = function (data) {
    window.WS.pointerDownTracing = true;

    if (!window.WS.pointerDownTraceWait) {
      let x = Number(data.x) - Number(window.WS.pointerDownTraceOffset.x);
      let y = Number(data.y) - Number(window.WS.pointerDownTraceOffset.y);
      // don't add the same value multiple times
      if (
        window.WS.pointerDownTrace.length > 0 &&
        window.WS.pointerDownTrace[window.WS.pointerDownTrace.length - 1].x === x &&
        window.WS.pointerDownTrace[window.WS.pointerDownTrace.length - 1].y === y
      ) {
        return;
      }

      window.WS.pointerDownTrace.push({
        x: x,
        y: y,
        ms: Date.now() - window.WS.pointerDownTraceTimestamp,
      });

      // stop any further events
      window.WS.pointerDownTraceWait = true;

      setTimeout(function () {
        window.WS.pointerDownTraceWait = false;
      }, 1000 / window.WS.pointerDownTracePerSecond);
    }
  };

  this.collectMlDataDomsnapshot = function (element, actionId) {
    let result = 'domsnapshot placeholder';
    console.log('collectMlData domsnapshot');
    element.setAttribute('functi0nize-selected', true);
    chrome.runtime.sendMessage({ elementStatistics: actionId }, (response) => {
      console.log('collectMlData domsnapshot response', response);
      result = response;
      element.removeAttribute('functi0nize-selected');
    });
    return result;
  };

  this.collectMlData = function (element, actionType, actionId, attempt = false) {
    console.time('collectMlData');
    let result = 'ml data failed';
    let filter = false;
    this.siteStatistics.filterActivated = false;
    if (this.collectStatistics || window.functionizeFilterMlData) {
      if (
        this.preferDomsnapshot &&
        typeof actionType !== 'undefined' &&
        actionType !== 'click' &&
        actionType !== 'hover' &&
        actionType !== 'scroll' &&
        actionType.indexOf('html5') === -1
      ) {
        this.collectMlDataDomsnapshot(element, actionId);
        this.parseIframes();
        console.timeEnd('collectMlData');
        return 'domsnapshot placeholder';
      } else {
        this.siteStatistics.filterActivated = true;
        const classObj = {};
        if (element.attributes.hasOwnProperty('class') && element.attributes.class.value) {
          classObj['class'] = element.attributes.class.value.split(' ');
        }

        filter = {
          INCLUDE: [{ tagName: element.tagName }, classObj],
          EXCLUDE: [
            { tagName: ['LINK', 'OPTION'] },
            { cssStyle: { display: 'none' } },
            {
              viewport: {
                left: 0,
                right: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
                top: 0,
                bottom: window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight,
              },
            },
          ],
        };
        this.siteStatistics.setFilter(filter);
      }
    }

    result = this.siteStatistics.getSelection2(element);

    let hasFunctionizeSelected = false;
    result.comp.forEach((item, index) => {
      if (item[12] && item[12].hasOwnProperty('functi0nize-selected')) {
        hasFunctionizeSelected = true;
      }
    });

    if (filter !== false) {
      result.filter = filter;
    }

    if (!hasFunctionizeSelected && this.siteStatistics.filterActivated && !attempt) {
      this.setCollectStatistics(false);
      result = this.collectMlData(element, actionType, actionId, true);
      this.setCollectStatistics(true);
    }

    console.timeEnd('collectMlData');
    return result;
  };

  this.traversePreOrder = function* (node) {
    if (!node) return;

    yield node;
    for (let child of node.children) {
      if (
        child.matches('option') ||
        child.matches('defs') ||
        child.matches('optgroup') ||
        child.matches('style') ||
        child.matches('link') ||
        child.matches('script') ||
        child.matches('meta') ||
        child.matches('title') ||
        child.matches('head') ||
        child.classList.contains('f-functionise') ||
        (child.matches('input') && child.getAttribute('type') === 'hidden')
      )
        continue;
      if (child.shadowRoot) {
        for (let shadow of child.shadowRoot.children) {
          yield* this.traversePreOrder(shadow);
        }
      }
      yield* this.traversePreOrder(child);
    }
  };

  this.selectAll = function (selector, root) {
    let newTop = 0;
    for (let node of this.traversePreOrder(root)) {
      if (node.matches(selector)) {
        try {
          var zi = parseInt(getComputedStyle(node).zIndex);

          if (zi && !isNaN(zi) && zi >= newTop) {
            newTop = zi;
            var nZIndex = zi - 10;
            if (nZIndex < 0) nZIndex = 0;
            var functionizeId = node.getAttribute('data-functionize-id');
            if (typeof functionizeId != 'undefined' && functionizeId != 'undefined' && functionizeId) {
              if (typeof window.WU.adjustZIndexElements[functionizeId] == 'undefined' || !window.WU.adjustZIndexElements[functionizeId]) {
                window.WU.adjustZIndexElements[functionizeId] = 0;
              }
              window.WU.adjustZIndexElements[functionizeId]++;
              if (window.WU.adjustZIndexElements[functionizeId] > 4 && el.textContent == '') {
                var thisClass = node.getAttribute('class');
                if (typeof thisClass == 'undefined' || !thisClass) {
                  thisClass = node.getAttribute('id');
                }
                if (typeof thisClass == 'undefined' || !thisClass) {
                  thisClass = '';
                }
                if (thisClass.indexOf('f-functionise') < 0) {
                  // TODO: why are we removing elements? This is removing inputs from forms on southwest and allstate
                  // this.remove();
                }
              }
            }

            //this.style.setProperty('z-index', nZIndex, 'important');
          }
        } catch (e) {
          console.log(e.message);
        }
      }
    }
    return newTop;
  };

  this.getTopZindex = function (node = document.body) {
    let path = ['*'];
    let result = [];

    if (path.length === 0) return result;

    let root = node;
    const selector = path[0];

    if (path.length === 1) return window.WS.selectAll(selector, root);

    const newPath = root.matches(selector) ? path.slice(1) : path;

    for (let child of root.children) {
      result = [...result, ...window.WS.getTopZindex(newPath, child)];
    }

    return result;
  };

  //* ****************** Child setters *************************/
  this.setter = function (data) {
    for (var p in data) {
      // called from window object; cannot use this...
      // window.fconsole.log('setting data ' + p + ' ' + window.WU.stringify(data[p]));
      if (p === 'settings') {
        // This needs to merge now
        window.WS[p] = Object.assign(window.WS[p] || {}, data[p]);
      } else {
        window.WS[p] = data[p];
      }
    }
  };

  this.setFlashToElement = function (target) {
    // We set this via setTimeout to allow the recording to take place first...
    this.flashTimer = setTimeout(function () {
      target.classList.remove('z-highlighted');
      target.classList.add('z-flash-highlighted');
    }, 100);

    setTimeout(function () {
      target.classList.remove('z-flash-highlighted');
    }, 900);
  };

  this.liveEditResizeNotification = function () {
    if (window.functionizeEditMode === 'liveEdit') {
      window.hasShownFzeResizeMessage = true;
      alert('Resizing your browser window during a live edit recording can cause unexpected failures.');
    }
  };

  this.setFlash = function (target) {
    // clearTimeout(this.flashTimer);
    // send chrome to take screenshot...
    // var command = { obj: 'TCM', call: 'takeScreenshot', arguments: [this.recData] };
    // window.chromePort.postMessage(command);
    if (!target || target.length < 1) return;
    if (typeof target.getBoundingClientRect() === 'undefined') return;

    window.fconsole.log('FlashElement');

    const tagName = target.tagName.toLowerCase();
    const inputType = target.getAttribute('type') || '';

    if (tagName === 'textarea' || (tagName === 'input' && (!inputType || inputType === 'text' || inputType === 'password'))) {
      clearTimeout(this.flashTimer);
    }

    const boundingRect = window.WU.zoomBoundingRect(target);
    const top = boundingRect.top;
    const left = boundingRect.left;
    const width = boundingRect.width + 2;
    const height = boundingRect.height + 2;
    let zi = window.TCM.maxZIndex - 5;

    try {
      zi = parseInt(document.querySelector('#f-functionise-tc-manager').style.zIndex) - 1;
    } catch (e) {}

    if (this.settings['coverElementOnActionRec']) {
      const cover = document.createElement('div');
      cover.id = 'f-flasher';
      cover.className = 'f-functionise z-flash-highlighted';
      cover.style.display = 'block';
      cover.style.position = 'fixed';
      cover.style.width = width + 'px';
      cover.style.height = height + 'px';
      cover.style.top = top + 'px';
      cover.style.left = left + 'px';
      cover.style.zIndex = zi;

      this.flashTimer = setTimeout(function () {
        target.classList.remove('z-highlighted');
        document.body.appendChild(cover);
      }, 100);

      setTimeout(function () {
        cover.remove();
      }, 900);
    } else {
      setTimeout(function () {
        target.classList.add('z-flash-highlighted');
      }, 20);

      setTimeout(function () {
        target.classList.remove('z-flash-highlighted');
      }, 900);
    }
  };

  /** ****    dashboard settings      ******/
  this.saveSettings = function () {
    var command = { obj: 'TCM', call: 'saveSettings', arguments: this.settings };
    window.TCM.sendCommandToMaster(command);
  };

  this.setSettings = function (item, value, doSave) {
    if (typeof doSave === 'undefined') doSave = true;

    if (item == 'recorder_type') {
      this.settings.managerBoxRight = 30;
    }
    if (item == 'disableMouseout') {
      if (value) {
        functionizeAddListener('mouseout', functioniseMouseoutListener);
        functionizeAddListener('mouseleave', functioniseMouseleaveListener);
      } else {
        try {
          functionizeRemoveListener('mouseout', functioniseMouseoutListener);
          functionizeRemoveListener('mouseleave', functioniseMouseleaveListener);
        } catch (e) {}
      }
    }
    this.settings[item] = value;
  };

  this.toggleSettings = function (item) {
    if (this.settings[item]) this.settings[item] = false;
    else this.settings[item] = true;

    this.saveSettings();
    if (item == 'helperOn' && !this.settings[item]) {
      // window.TH.clearAll(true);
    } else {
      // window.TH.createCore();
    }
  };

  this.getSettingsHtml = function () {
    var items = new Array();
    items.push(new functioniseAssocVars('helperOn', 'Show Helper Bubbles'));
    items.push(new functioniseAssocVars('hideWindowOnClose', 'Auto Hide Panel'));
    items.push(new functioniseAssocVars('retainManagerBoxPosition', 'Remember Recorder Position'));
    items.push(new functioniseAssocVars('showRecordtimeErrors', 'Show Javascript Errors'));

    var html = '<table id="f-functionise-tc-settings-table"><tbody>';
    for (var i = 0; i < items.length; i++) {
      var checked = '';
      if (this.settings[items[i].index]) {
        checked = 'checked';
      }

      html +=
        '<tr><td width="50%">' +
        items[i].value +
        '</td><td width="25%" class="' +
        window.fUniqPrefix +
        'horizontal-divider"><hr></td><td><div class="' +
        window.fUniqPrefix +
        '-js-switch" data-name="human" data-checked="' +
        checked +
        '" data-value="true" onclick="window.WS.toggleSettings(\'' +
        items[i].index +
        '\')"><div class="' +
        window.fUniqPrefix +
        '-helper"></div></div></td></tr>';
    }
    html += '</tbody></table>';
    return html;
  };

  this.editSettings = function () {
    return false;
  };

  /** ****    dashboad settings end      ******/

  //* *****	cookie management *******/

  this.acceptCurrentCookies = function () {
    var cookies = this.getOtherCookies();
    var storedCookieString = window.WU.cookie('functioniseAcceptedCookies');
    var storedCookies = null;
    if (storedCookieString == null || typeof storedCookieString === 'undefined') {
      storedCookies = new Array();
    } else {
      storedCookies = storedCookieString.split('&');
    }
    for (var i = 0; i < cookies.length; i++) {
      storedCookies.push(encodeURIComponent(cookies[i]));
    }
    if (storedCookies.length > 0) window.WU.cookie('functioniseAcceptedCookies', storedCookies.join('&'), { expires: 365, path: '/' });
  };

  this.getOtherCookies = function () {
    if (!window.functioniseApp) {
      if (typeof functioniseCurrentCookiesAsString !== 'undefined') {
        try {
          return JSON.parse(decodeURIComponent(window.functioniseCurrentCookiesAsString));
        } catch (e) {
          window.fconsole.log(e.message);
        }
      }
      return window.functioniseCurrentCookies;
    }

    var cookies = [];
    var c = document.cookie.split(/; */);
    if (c.length < 1) return cookies;

    c.forEach(function (cookie) {
      var splitCookie = cookie.split('=');
      // skip Google Analytics cookies
      if (splitCookie[0].indexOf('functionise') < 0 && splitCookie[1] !== '' && splitCookie[0].indexOf('__utm') < 0) {
        cookies.push(splitCookie[0]);
      }
    });

    console.log('cookies', cookies);
    return cookies;
  };

  this.getAllCookies = function () {
    var cookies = [];
    var c = document.cookie.split(/; */);
    if (c.length < 1) return cookies;

    c.forEach(function (cookie) {
      var splitCookie = cookie.split('=');
      // Skip Google Analytics cookies
      if (splitCookie[0].indexOf('functionise') < 0 && splitCookie[1] !== '' && splitCookie[0].indexOf('__utm') < 0) {
        cookies.push({ name: splitCookie[0], value: splitCookie[1] });
      }
    });

    console.log('cookies', cookies);
    return cookies;
  };
  //* *****	cookie management end *******/

  this.getElementBubbleText = function (e) {
    let el = e; // Assuming `e` is a DOM element
    let identificator = '';

    // Get the element's ID
    if (el.id && el.id.length < 70) {
      identificator = `<span style="color: #1A1AA6;">#${el.id}</span>`;
    }

    // Get the element's class names
    if (el.className && el.className.length + identificator.length < 120) {
      let elements = el.className.split(' ');
      identificator += '<span style="color: #1A1AA6;">';
      elements.forEach((element) => {
        identificator += '.' + element;
      });
      identificator += '</span>';
    }

    // Define CSS properties to check
    let properties = ['color', 'font', 'background', 'margin', 'padding'];
    let propertiesText = '';

    // Get computed styles for the properties
    let computedStyle = window.getComputedStyle(el);
    properties.forEach((property) => {
      let value = computedStyle.getPropertyValue(property);
      if (value && value !== '0px') {
        if (property === 'background' && (value.includes('url') || value.length > 100)) {
          return;
        }
        propertiesText += `<p style="text-align: right;">
          <span style="float: left;">${property.charAt(0).toUpperCase() + property.slice(1)} </span>
          <span>${value}</span>
        </p>`;
      }
    });

    // Generate the tooltip HTML
    let tooltip = `
      <div style="display: flex;">
        <div style="word-break: break-all;">
          <strong style="color: #881280;">${el.tagName}${identificator}</strong>
        </div>
        <div style="margin-left: auto;">
          <p style="width: 70px; margin: 0; text-align: right;">
            ${el.offsetWidth.toFixed(2)} x ${el.offsetHeight.toFixed(2)}
          </p>
        </div>
      </div>
      ${propertiesText}
    `;

    return tooltip;
  };

  //* *****	custom promt boxes *******/

  this.customConfirm = function (choice, arg) {
    if (window.WS.doRecording > 0 && window.WS.on) {
      // we can not fake this….   We'll simply record it and record the slection
      window.WS.getRecordingData({
        action: 'confirm',
        selection: choice,
        value: arg,
        actionId: window.WU.getTime() + '_' + window.WU.randomString(),
        url: window.WS.locUrl,
      });
    }
  };

  this.customPrompt = function (value, arg) {
    if (window.WS.doRecording > 0 && window.WS.on) {
      // we can not fake this….   We'll simply record it and record the slection
      let data = {
        action: 'prompt',
        prompt: arg,
        value: value,
        actionId: window.WU.getTime() + '_' + window.WU.randomString(),
        url: window.WS.locUrl,
      };

      if (value === null) {
        data.selection = '0';
        delete data.value;
      }

      window.WS.getRecordingData(data);
    }
  };

  this.customAlert = function (arg) {
    if (window.WS.doRecording > 0 && window.WS.on && !window.TCM.editing) {
      if (typeof arg !== 'string') {
        try {
          arg = arg.toString();
        } catch (e) {}
      }

      window.functionizeVex.dialog.alert(arg);

      window.WS.getRecordingData({
        action: 'alert',
        value: arg,
        actionId: window.WU.getTime() + '_' + window.WU.randomString(),
        url: window.WS.locUrl,
      });
      return true;
    }
    return false;
  };

  //* *****	custom promt boxes	end *******/

  this.hasVerifyAction = function () {
    for (var i = 0; i < window.WS.recordedData.length; i++) {
      if (window.WS.recordedData[i].action == 'verify') return true;
    }
    return false;
  };

  /** ****   Test start/stop and additional control methods *******/

  this.startTest = function (UID) {
    if (!window.WS.isIframe && !window.WS.isPopup) {
      // anything to do here?
    } else {
      // in the iframes we can get the UID passed down from the top
      if (!window.TCM.hasSentRegistration) return;

      if (UID != null && UID != undefined) window.WS.UID = UID;

      window.fconsole.log('Iframe or popup found in startTest.  Setting recoding on');
      window.TCM.setRecording(true);
    }
    window.WS.resetData();
    window.WS.on = true;
    window.WS.justStarted = true;
    window.WS.doRecording = 1;
    window.WS.isTest = 1;
    window.WS.actionCount = 0;
    window.WS.initPage();

    window.fconsole.log('Sending startTest to descendants');
    if (window.TCM.isMaster) {
      var command = { obj: 'WS', call: 'startTest', arguments: window.WS.UID };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  this.startTestRunning = function () {
    // reset sessionID
    window.WS.on = true;
    window.WS.doRecording = 1;
    window.WS.isTest = 1;
    window.WU.cookie('functioniseTesting', 'on', { expires: 0, path: '/' });
    window.WU.cookie('functionise', 'true', { expires: 0, path: '/' });
    window.WS.initPage();
  };

  this.stopTest = function (title, result) {
    window.WS.testCaseTitle = title;
    window.WS.verify = result;
    window.WU.cookie('functioniseTesting', 'off', { expires: 0, path: '/' });
    window.WU.cookie('functionise', '', { expires: 0, path: '/' });
    window.WS.recordWbData(true);
    window.WS.doRecording = 0;
    window.WS.isTest = 0;
    window.WS.actionCount = 0;
    // reset the UID
    window.WS.setWindowSizeError(false);
  };

  this.cancelTest = function () {
    if (!this.isIframe && !this.isPopup) {
      window.WU.cookie('functioniseTesting', 'off', { expires: 0, path: '/' });
    }
    window.WS.resetData();
    window.WS.doRecording = 0;
    window.WS.isTest = 0;
    window.WS.on = false;
    window.WS.actionCount = 0;
    window.WS.setWindowSizeError(false);
    if (!window.TCM.isMaster) window.TCM.setRecording(false);

    if (window.TCM.isMaster) {
      var command = { obj: 'WS', call: 'cancelTest', arguments: 'master' };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  this.stopTestRecording = function () {
    // window.WS.on = false;
    window.WS.doRecording = 0;
    // clear last click that was the stop button
    window.WS.clickToSend = '';
    if ((this.isIframe || this.isPopup) && !window.TCM.isController) {
      // in iframes and popups we send the data up the chain
      // this.recordWbData();
      // window.TCM.setRecording(false);
      // if (this.runtimeDebugCancel) {
      // }
    } else if (window.TCM.isMaster) {
      var command = { obj: 'WS', call: 'stopTestRecording' };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  this.continueTestRecording = function (source) {
    if (typeof source === 'undefined') source = 'self';

    if (!window.WS.justStarted || (window.TCM.isController && source != 'self')) return;
    window.WS.collecting = false;
    window.WS.on = true;
    window.WS.doRecording = 1;
    window.TCM.editing = false;
    window.TCM.isVerifying = false;
    window.TCM.setRecording(true);
    var command = null;
    if (window.TCM.isMaster) {
      command = { obj: 'WS', call: 'continueTestRecording', arguments: 'master' };
      window.TCM.sendCommandToDescendants(command);
    } else if (window.TCM.isController) {
      window.fconsole.log('continue test recording is sent to master');
      command = { obj: 'WS', call: 'continueTestRecording' };
      window.TCM.sendCommand(command, window.parent);
    }
    // clear coverers here to be sure...
    window.WU.fShowAllElements();
    // window.TH.clearAll(true);
    window.WS.removeHighlights();
  };

  /** ****   Test start/stop and additional control methods end *******/

  /** ****   Test verification methods *******/

  this.startCollecting = function (source) {
    if (typeof source === 'undefined') source = 'self';

    // If chrome, we need to enable disabled elements...
    if (typeof window.chromePort !== 'undefined' && !window.WS.disable_data_functionize_disabled_element_flag) {
      window.fconsole.log('Enable everything disabled for verification...');
      document.querySelectorAll(':disabled').forEach(function (el) {
        el.removeAttribute('disabled');
        el.setAttribute('data-functionize-disabled', 'disabled');
      });
    }

    if (window.TCM.isController && source === 'master') return;

    this.collecting = true;
    this.verify = null;
    let command = null;

    if (window.TCM.isMaster) {
      command = { obj: 'WS', call: 'startCollecting', arguments: 'master' };
      window.TCM.sendCommandToDescendants(command);
    } else if (window.TCM.isController) {
      window.fconsole.log('startCollecting is sent to Master window');
      command = { obj: 'WS', call: 'startCollecting' };
      window.TCM.sendCommand(command, window.parent);
    }
  };

  this.stopCollecting = function (result, callerIframe, callerPopup, source) {
    console.log('!! stopCollecting', result, callerIframe, callerPopup, source);
    if (typeof source === 'undefined') source = 'self';
    if (result === null) {
      result = { data: { iframeUID: undefined, popupUID: undefined } };
    }

    if (source === 'self') {
      if (this.iframeUID && typeof result.data.iframeUID === 'undefined' && typeof this.iframeUID !== 'undefined') {
        console.log('!! adding iframeUID', this.iframeUID);
        result.data.iframeUID = this.iframeUID;
      }

      if (this.popupUID && typeof result.data.popupUID === 'undefined' && typeof this.popupUID !== 'undefined') {
        console.log('!! adding popupUID', this.popupUID);
        result.data.popupUID = this.popupUID;
      }
    }

    if (window.pageInitAction) {
      let command = {
        obj: 'WS',
        call: 'iframeRecordingData',
        arguments: [window.pageInitAction, this.iframeUID],
        meta: { suppressSetPath: false },
      };
      window.TCM.sendCommand(command, window.parent);
      window.pageInitAction = false;
    }

    window.fconsole.log('stopCollecting is called: ' + JSON.stringify(result) + ' ' + window.TCM.isMaster);
    window.fconsole.log(callerIframe);

    // If chrome, we need to enable disabled elements...
    if (typeof window.chromePort !== 'undefined') {
      window.fconsole.log('Disable all that was disabled for verification...');
      document.querySelectorAll('[data-functionize-disabled]').forEach(function (el) {
        el.setAttribute('disabled', 'disabled');
        el.removeAttribute('data-functionize-disabled');
      });
    }

    if (window.TCM.isController && result === null && source === 'master') {
      console.log('stopCollecting returning here');
      return;
    }

    let uniqueSelectors = window.WS.getUniqueSelector(result.data);
    if (!window.TCM.isMaster) {
      // Set DOM walk here
      window.TCM.domWalkElement = document.querySelector(uniqueSelectors);
      document.querySelectorAll('.f-domWalkSelector').forEach(function (el) {
        el.classList.remove('f-domWalkSelector');
      });
      if (window.TCM.domWalkElement) {
        window.TCM.domWalkElement.classList.add('f-domWalkSelector');
      }
    }

    window.WS.collecting = false;
    window.WS.removeHighlights();
    // window.TH.clearAll();
    window.WU.fShowAllElements();

    if (result !== null && result.data.path === '') {
      // Set highlight event...
      clearTimeout(window.setFlashTimer);
      window.setFlashTimer = setTimeout(() => {
        window.WS.setFlash(window.TCM.domWalkElement);
      }, 200);
    }

    let command = null;
    if (window.TCM.isMaster && window.TCM.isController) {
      console.log('!! stopCollecting here');
      command = {
        obj: 'WS',
        call: 'stopCollecting',
        arguments: [null, null, null, 'master'],
        meta: { ignoreIframeUID: callerIframe, ignorePopupUID: callerPopup },
      };
      window.TCM.sendCommandToDescendants(command);
    } else if (window.TCM.isMaster && !window.TCM.isController) {
      console.log('!! stopCollecting here');
      command = {
        obj: 'WS',
        call: 'stopCollecting',
        arguments: [result, null, null, 'master'],
        meta: { ignoreIframeUID: callerIframe, ignorePopupUID: callerPopup },
      };
      if (source === 'controller') {
        console.log('!! stopCollecting here');
        command = {
          obj: 'WS',
          call: 'stopCollecting',
          arguments: [result, null, null, 'master'],
          meta: { ignorePopupUID: callerPopup },
        };
      }
      window.fconsole.log('Sending stop collecting command to children');
      console.log('!! stopCollecting', command, result, callerIframe, callerPopup, source);
      window.TCM.sendCommandToDescendants(command);
    }

    if (window.TCM.isController) {
      window.TCM.verify = result;
      if (window.TCM.verify === '') {
        window.functionizeVex.dialog.alert('Please select an element with text as html only is only partially supported at this time.');
        window.TCM.startVerifying();
        return true;
      } else {
        if (window.TCM.verify.value !== undefined && window.TCM.verify.value !== '') {
          if (window.TCM.verify.value.length > 250 && !window.WS.captureLargeData) {
            self.port.emit('message', {
              obj: 'f-vue',
              call: 'showAiAssistLongText',
              arguments: undefined,
              forMaster: true,
            });
            window.TCM.startVerifying();
            return true;
          }
        }
        // Focus the window here
        if (window.WS.shiftDown) {
          // if shift is down we want the main window to take control
          // window.focus();
        }
        window.TCM.setTestResult(source);
      }
      return;
    }

    if (result !== null) {
      console.log('stopCollecting here');
      // Only send if this is chaining up
      // We need to send it up the chain too
      if (window.WS.isIframe && source !== 'master') {
        if (window.isIframe && window.parentUrl && this.iframeUID && !result.data.hasOwnProperty('url')) {
          result.data['url'] = this.locUrl;
          if (window.parentUrl) {
            result.data['topUrl'] = window.parentUrl;
          }
        }
        console.log('!! Sending call with iframeUID ' + window.WS.iframeUID);
        command = {
          obj: 'WS',
          call: 'stopCollecting',
          arguments: [result, window.WS.iframeUID, null, 'iframe'],
        };
        if (window.TCM.isController) {
          console.log('!! stopCollecting here', result);
          command = {
            obj: 'WS',
            call: 'stopCollecting',
            arguments: [result, window.WS.iframeUID, null, 'controller'],
          };
        }
        window.TCM.sendCommand(command, window.parent);
      }
      if (window.WS.isPopup && source !== 'master') {
        console.log('!! stopCollecting here', result);
        result.data.windowHeight = window.innerHeight;
        result.data.windowWidth = window.innerWidth;
        result.data.browserWindowHeight = window.outerHeight;
        result.data.browserWindowWidth = window.outerWidth;
        result.data.scrollLeft = window.scrollX;
        result.data.scrollTop = window.scrollY;
        result.data.url = window.WS.locUrl;
        command = {
          obj: 'WS',
          call: 'stopCollecting',
          arguments: [result, null, window.WS.popupUID, 'popup'],
        };
        window.TCM.sendCommand(command, window.opener);
      }
    }
  };

  /** ****   Test verification methods end *******/

  /** ****   Page initialization methods *******/

  this.initPage = function (data) {
    if (window.functionizePageinit === true) return;
    window.functionizePageinit = true;
    // we only count new pages if we are in the top frame
    window.WS.justStarted = true;
    var isPageinit = true;
    var isFirstCall = true;
    var resized = this.resized(isPageinit, isFirstCall);
    this.getCoreData(data);
    if (!resized) {
      // window size too large we set to maximum for page init for now until we get the resize action
      this.coreData.windowWidth = this.maxWindowWidth;
      this.coreData.windowHeight = this.maxWindowHeight;
    }

    var lastAction = this.recordedData[this.recordedData.length - 1];
    try {
      if (window.functionizeNavigationTypeString) {
        window.functionizeNavigationType = JSON.parse(window.functionizeNavigationTypeString);
      }
    } catch (e) {
      console.error(e);
    }

    if (typeof window.functionizeNavigationType !== 'undefined' && !window.WS.isIframe) {
      data = {
        action: 'navigate',
        epoch: Date.now(),
        url: window.WS.locUrl,
        timestamp: window.WU.getTime(),
        navigationType: window.functionizeNavigationType.transitionType,
        transitionQualifier: window.functionizeNavigationType.transitionQualifier,
      };
      this.getRecordingData(data);
      this.coreData.navigationType = window.functionizeNavigationType.transitionType;
      delete window.functionizeNavigationType;
    }

    this.getRecordingData(this.coreData);

    if (!this.isIframe && !this.isPopup) {
      window.TCM.incrementPageCount();
      // window.sessionStorage.functionisePageCount++;
    } else if (!window.TCM.isMaster && window.TCM.isController) {
      // we have a frame that is controlling the game...
      window.TCM.incrementPageCount();
    }

    // if (this.coreData == undefined || this.coreData == null || this.coreData == '')
    // var resized = this.resized();

    var liveEditMode = false;
    if (typeof window.functionizeEditMode !== 'undefined' && window.functionizeEditMode == 'liveEdit') liveEditMode = true;
    if (window.WS.recordedData.length > 1) liveEditMode = false;

    if (!this.hasInputInit && !liveEditMode && this.justStarted) this.initInput(); // if we have no Input init we call it here   once in the right range it should complet successfully
  };

  this.initInput = function () {
    if (window.TCM.isEdit) {
      this.hasInputInit = true;
      return;
    }

    if (typeof this.settings['usePageInitActions'] !== 'undefined' && !this.settings['usePageInitActions']) return;

    // If window size is off, we need to queue this for later init (for positions)
    if (this.hasWindowSizeError || this.hasInputInit || typeof this.recordedData !== 'object') return;

    // Get text they put into input field
    document.querySelectorAll('input[data-functionize-initvalue], input:-webkit-autofill').forEach(function (e) {
      if (e.offsetParent === null) return; // Skip hidden elements
      const type = e.getAttribute('type') || '';
      if (['checkbox', 'radio', 'hidden', 'submit', 'image', 'file', 'reset', 'button'].includes(type)) return;
      if (e.tagName.toLowerCase() === 'select') return;
      const value = e.value;
      if (value === '' || value === e.getAttribute('value') || value === e.getAttribute('data-functionize-initvalue')) return;
      window.WS.inputToSend = window.WS.targetElement(e, 'input', undefined, false, undefined, true);
      window.WS.getRecordingData();
    });

    window.fconsole.log('Select init is called');

    document.querySelectorAll('select').forEach(function (selectElement) {
      if (selectElement.offsetParent === null) return; // Skip hidden elements
      let defaultValue = '';
      let firstValue = '';
      selectElement.querySelectorAll('option').forEach(function (option, index) {
        if (index === 0) {
          const value = option.getAttribute('value');
          firstValue = value !== null ? value : option.textContent;
        }
        const isSelected = option.hasAttribute('selected');
        if (isSelected && selectElement.value === option.getAttribute('value')) {
          defaultValue = selectElement.value;
        } else if (isSelected) {
          const value = option.getAttribute('value');
          defaultValue = value !== null ? value : option.textContent;
        }
      });
      window.fconsole.log('Select values == ' + defaultValue + ' ' + selectElement.value);
      if (defaultValue === selectElement.value || selectElement.value === firstValue || selectElement.value === selectElement.getAttribute('data-functionize-initvalue')) {
        window.fconsole.log('Select default value found');
        return;
      }
      window.fconsole.log('Select values recorder');
      window.WS.selectToSend = window.WS.targetElement(selectElement, 'select', undefined, false, undefined, true);
      window.WS.getRecordingData();
    });

    document.querySelectorAll('input[type=radio]').forEach(function (radio) {
      if (radio.offsetParent === null) return; // Skip hidden elements
      if (radio.checked && radio.getAttribute('checked') !== 'checked' && radio.getAttribute('data-functionize-initvalue') !== 'true') {
        window.WS.radioToSend = window.WS.targetElement(radio, 'radio', undefined, false, undefined, true);
        window.WS.getRecordingData();
      }
    });

    document.querySelectorAll('input[type=checkbox]').forEach(function (checkbox) {
      if (checkbox.offsetParent === null || checkbox.classList.contains('f-functionise')) return; // Skip hidden or specific class elements
      if (checkbox.checked && checkbox.getAttribute('checked') !== 'checked' && checkbox.getAttribute('data-functionize-initvalue') !== 'true') {
        window.WS.checkToSend = window.WS.targetElement(checkbox, 'check', undefined, false, undefined, true);
        window.WS.checkToSend.element = 'checkbox';
        window.WS.checkToSend.index = Array.from(document.querySelectorAll('input[type=checkbox]'))
          .filter((el) => !el.classList.contains(window.fUniqPrefix) && !el.closest(`.${window.fUniqPrefix}`))
          .indexOf(checkbox);
        window.WS.checkToSend.value = checkbox.getAttribute('checked');
        window.WS.checkToSend.actionType = 'init';
        window.WS.getRecordingData();
      }
    });

    this.hasInputInit = true;
  };

  this.preinitInput = function () {
    window.fconsole.log('pre Initinput is called');
    if (typeof this.settings['usePageInitActions'] !== 'undefined' && !this.settings['usePageInitActions']) return;

    // Get text they put into input field
    document.querySelectorAll('input, :-webkit-autofill').forEach(function (e) {
      if (e.offsetParent === null) return; // Skip hidden elements
      const type = e.getAttribute('type') || '';
      if (['checkbox', 'radio', 'hidden', 'submit', 'image', 'file', 'reset', 'button'].includes(type)) return;
      if (e.tagName.toLowerCase() === 'select') return;
      const value = e.value;
      if (value === '' || value === e.getAttribute('value')) return;
      e.setAttribute('data-functionize-initvalue', value);
      e.setAttribute('data-initvalue', value);
    });

    document.querySelectorAll('select').forEach(function (selectElement) {
      if (selectElement.offsetParent === null) return; // Skip hidden elements
      let defaultValue = '';
      let firstValue = '';
      selectElement.querySelectorAll('option').forEach(function (option, index) {
        if (index === 0) {
          const value = option.getAttribute('value');
          firstValue = value !== null ? value : option.textContent;
        }
        const isSelected = option.hasAttribute('selected');
        if (isSelected && selectElement.value === option.getAttribute('value')) {
          defaultValue = selectElement.value;
        } else if (isSelected) {
          const value = option.getAttribute('value');
          defaultValue = value !== null ? value : option.textContent;
        }
      });
      if (defaultValue === selectElement.value || selectElement.value === firstValue) {
        window.fconsole.log('Select default value found');
        return;
      }
      selectElement.setAttribute('data-functionize-initvalue', selectElement.value);
      selectElement.setAttribute('data-initvalue', selectElement.value);
    });

    document.querySelectorAll('input[type=radio]').forEach(function (radio) {
      if (radio.offsetParent === null) return; // Skip hidden elements
      if (radio.checked && !radio.hasAttribute('checked')) {
        radio.setAttribute('data-functionize-initvalue', 'true');
        radio.setAttribute('data-initvalue', 'true');
      }
    });

    document.querySelectorAll('input[type=checkbox]').forEach(function (checkbox) {
      if (checkbox.offsetParent === null) return; // Skip hidden elements
      if (checkbox.checked && !checkbox.hasAttribute('checked')) {
        checkbox.setAttribute('data-functionize-initvalue', 'true');
        checkbox.setAttribute('data-initvalue', 'true');
      }
    });
  };

  this.resized = function (isPageinit, isFirstCall) {
    // this.settings['EnableMaxScreenResolution'] = false;
    if (typeof isPageinit === 'undefined') isPageinit = false;

    if (typeof isFirstCall === 'undefined') isFirstCall = false;

    if (window.WS.doRecording != 1) return;
    window.fconsole.log('resized called');

    if (window.document.doctype == null) {
      /// if no doctype we turn this feature off...
      this.settings['EnableMaxScreenResolution'] = false;
    }

    if (!this.isIframe) {
      // if mobile on chrome we ignore win size arguments...
      if (
        navigator.userAgent.indexOf('Mobile') < 0 &&
        (window.innerWidth > this.maxWindowWidth || window.innerHeight > this.maxWindowHeight) &&
        this.settings['EnableMaxScreenResolution']
      ) {
        this.setWindowSizeError(true);
        if (isPageinit) return false;
      } else {
        this.setWindowSizeError(false);
        if (!this.hasInputInit && !isFirstCall) this.initInput();
      }
    }

    if (isPageinit || this.isIframe) return true; // no resize action in start or iframe...
    var height = window.innerHeight;
    if (height < this.minWindowHeight) height = this.minWindowHeight;

    var first = document.querySelector('body *');
    var fleft = 0;
    var ftop = 0;

    if (first) {
      var rect = first.getBoundingClientRect();
      fleft = rect.left + window.scrollX;
      ftop = rect.top + window.scrollY;
    }

    var data = {
      action: 'resize',
      element: 'window',
      browserWindowWidth: window.outerWidth,
      browserWindowHeight: window.outerHeight,
      windowWidth: window.innerWidth,
      windowHeight: window.innerHeight, // Assuming height is meant to be window.innerHeight
      firstxOffset: fleft,
      firstyOffset: ftop,
    };

    this.getRecordingData(data);

    if (document.querySelectorAll('#f-functionise-tc-manager').length > 0) {
      try {
        window.WS.runtimeDebugCancel = true;
        document.querySelector('#f-functionise-tc-manager').remove();
        clearTimeout(window.functionizeArcResizeTimer);
        window.functionizeArcResizeTimer = setTimeout(() => {
          window.WS.runtimeDebugCancel = false;
          window.TCM.create();
        }, 1000);
      } catch (e) {
        console.error(e);
      }
    }

    // Now pageinit calls this
    // if (!this.hasInputInit) // if we have no Input init we call it here   once in the right range it should complet successfully
    //	this.initInput();
  };

  this.automaticallyStartTest = function () {
    if (window.TCM.isMaster) {
      setTimeout(() => {
        self.port.emit('message', {
          obj: 'f-vue',
          call: 'automaticallyStartTest',
          data: { storage: false, cookies: false },
          forMaster: true,
        });
      }, 1000);
    }
  };

  this.getCoreData = function (data) {
    console.log('getCoreData pageinit', data, this.locUrl);
    window.WS.encoding = window.WU.detectEncoding().toLowerCase();
    var height = window.innerHeight;
    if (height < this.minWindowHeight) height = this.minWindowHeight;

    this.coreData = {
      action: 'pageinit',
      uid: this.UID,
      did: this.did,
      url: this.locUrl,
      encoding: window.WS.encoding,
      windowWidth: window.innerWidth,
      browserWindowWidth: window.outerWidth,
      browserWindowHeight: window.outerHeight,
      windowHeight: height,
      scrollLeft: window.scrollX,
      scrollTop: window.scrollY,
      epoch: window.WU.getTime(),
    };

    if (window.TCM.isMaster && !window.WS.recordedData.length && window.WS.start_recording_automatically && window.WS.start_url && !window.TCM.liveEdit) {
      this.coreData.url = window.WS.start_url;
      this.coreData.initialPageinit = 'true';
    }

    self.port.emit('message', {
      obj: 'f-vue',
      call: 'checkIfIsLocalAccessOnly',
      arguments: { url: this.coreData.url },
      forMaster: true,
    });

    if (typeof data !== 'undefined' && data.hasOwnProperty('meta') && data.meta.hasOwnProperty('attributes') && Object.keys(data.meta.attributes).length > 0) {
      for (let attr in data.meta.attributes) {
        this.coreData[`iframe_attr_${attr}`] = data.meta.attributes[attr];
      }
    }

    if (data && data.hasOwnProperty('meta') && data.meta.hasOwnProperty('functionizeid')) {
      this.coreData.functionizeid = data.meta.functionizeid;
      window.WS.functionizeid = data.meta.functionizeid;
    }

    if (data && data.hasOwnProperty('meta') && data.meta.hasOwnProperty('traverseIframenextNodeId')) {
      (async () => {
        while (!window.WS.pageInitId) {
          console.log('waiting...');
          await new Promise((resolve) => setTimeout(resolve, 1000));
        }
        new Promise((resolve, reject) => {
          console.log('collecting ml data');
          window.WS.updateActionByActionId(
            {
              elementStatistics: window.WS.collectMlData(
                document.body && document.body.childElementCount > 0 ? document.body : document.children[0],
                'pageinit',
                window.WS.pageInitId
              ), // window.WS.siteStatistics.getSelection2(document.body && document.body.childElementCount > 0 ? document.body : document.children[0]),
            },
            window.WS.pageInitId
          );
          // console.log('elementCount', window.WS.siteStatistics.nodeId);
          resolve();
        }).then(() => {
          // console.log('iFunctionizeID', iframeUID ? iframeUID.match(/(.*)-(.*)/)[2] + 0 : '');

          // reset filter
          if (this.siteStatistics.filterActivated) {
            this.setIframeFilter();
          }

          window.WS.traverseIframe = window.WS.siteStatistics.traverseIframe(data.meta.functionizeid, 0, iframeUID ? iframeUID.match(/(.*)-(.*)/)[2] + 0 : '');
          window.WS.traverseIframenextNodeId = window.WS.traverseIframe.nextNodeId;
          window.WS.iFunctionizeID = data.meta.functionizeid;
          var localComp = JSON.stringify(JSON.parse(window.WS.traverseIframe.comp));
          window.WS.traverseIframeComp = [JSON.parse(localComp)];
        });
      })();
    }

    window.WS.start_recording_automatically = false;
  };

  this.sendProcessIframeMlData = function (data) {
    console.log('sendProcessIframeMlData', data);
    self.port.emit('message', {
      obj: 'WS',
      call: 'processIframeMlData',
      meta: {
        parentUID: window.parentUID,
        frameId: window.iframeUID,
        data: data,
      },
    });
  };

  this.contextSwitchProcessIframeMlData = function (data) {
    if (data.meta.iframeId !== iframeUID) return;
    console.log('contextSwitchProcessIframeMlData', iframeUID, data.meta.iframeId);
    if (data.functionizeid) {
      (async () => {
        while (!window.WS.traverseIframeComp) {
          console.log('waiting...');
          await new Promise((resolve) => setTimeout(resolve, 1000));
        }
        // for (let i = 0; i < window.WS.traverseIframeComp[0].length; i++) {
        // if (typeof window.WS.traverseIframeComp[0][i][12] !== 'undefined' && window.WS.traverseIframeComp[0][i][12].hasOwnProperty('functi0nize-selected')) {
        // console.log('DELETING functi0nize-selected', window.WS.traverseIframeComp[0][i][12], window.WS.traverseIframeComp, iframeUID, data.meta.iframeId);
        // delete window.WS.traverseIframeComp[0][i][12]['functi0nize-selected'];
        // }
        // }
        // need next node id data in here
        this.sendProcessIframeMlData({
          data: window.WS.traverseIframeComp,
          functionizeid: data.functionizeid,
          actionId: data.actionId,
          traverseIframenextNodeId: window.WS.traverseIframenextNodeId,
        });
      })();
    }
  };

  /** ****   Page initialization methods end *******/

  this.rightClick = function (e) {
    // Since right clicks are outside of JavaScript, we simply record this function and send it back
    // In case a JavaScript HTML-based custom menu comes up
    var value = this.targetElement(e, 'rightclick');

    value.scrollTop = window.scrollY;
    value.scrollLeft = window.scrollX;
    value.mouseX = parseInt(e.pageX - e.target.getBoundingClientRect().left);
    value.mouseY = parseInt(e.pageY - e.target.getBoundingClientRect().top);
    value.eventX = e.pageX;
    value.eventY = e.pageY;

    value.metaKey = e.metaKey || false;
    value.shiftKey = e.shiftKey || false;
    value.altKey = e.altKey || false;
    value.ctrlKey = e.ctrlKey || false;

    if (e.target.tagName.toLowerCase() === 'input' || e.target.tagName.toLowerCase() === 'textarea') {
      // Possible copy-paste… we need to think about
      this.preCopyPaste = e.target.value;
      console.log('setting preCopyPasteElement', e.target);
      this.preCopyPasteElement = e.target;
      window.fconsole.log('Logging possible copy paste: ' + this.preCopyPaste);
    }

    if (JSON.stringify(this.clickToSend) === JSON.stringify(value)) return; // Prevent further effects
    this.clickToSend = value;
    // And record it
    this.getRecordingData();
  };

  this.setIframeFilter = function () {
    console.log('setIframeFilter');

    let filter = {
      INCLUDE: [{ tagName: 'iframe' }],
      EXCLUDE: [{ tagName: ['LINK', 'OPTION'] }, { cssStyle: { display: 'none' } }],
    };
    this.siteStatistics.setFilter(filter);
  };

  this.initTraverseIframes = function () {
    // if (window.TCM.isMaster) {
    if (!window.isIframe) {
      // reset filter
      if (this.siteStatistics.filterActivated) {
        this.setIframeFilter();
      }

      window.WS.traverseIframe = window.WS.siteStatistics.traverseIframe(null, 0);
      window.WS.traverseIframenextNodeId = window.WS.traverseIframe.nextNodeId;
      window.WS.traverseIframeComp = [JSON.parse(window.WS.traverseIframe.comp)];
    }
  };
  this.registerIframe = async function (data, needControllerFrame) {
    console.trace('registerIframe registered');
    if (window.WS.disableIframeCapture || document.querySelectorAll('.' + window.fUniqPrefix + '-extruder-content').length > 0) {
      window.fconsole.log('Skipping Recorder Iframe Registration');
      return false;
    }

    var UID = data.UID;
    var index = window.WS.iframeIndex;
    var controlIndex = 0;
    var controlIndexWidth = 0;
    var controlIndexHeight = 0;
    var tag = 'iframe';

    if (document.querySelectorAll('iframe').length < 1 && (needControllerFrame || document.querySelectorAll('frame').length > 0)) {
      tag = 'frame';
    }

    var selfObj = this;

    var frameFound = false;

    function handleIframe(frame, index) {
      var frameFound = true;
      frame.dataset.UID = UID;

      selfObj.setFlashToElement(frame);

      var hash = window.WU.randomText(20);
      var notificationMessage = `
        <div class="${window.fUniqPrefix} f-functioniseme ${window.fUniqPrefix}-notification-window f_functionise_notification_window ${hash} f-hideTab1"
          id="${window.fUniqPrefix}-notification-window"
          style="z-index:99999;position:absolute;top:5px;left:5px;background:#00000054;color:#fff;border-radius:10px;padding:7px 15px;">
          New Iframe has been registered.
        </div>`;
      document.body.insertAdjacentHTML('beforeend', notificationMessage);
      setTimeout(() => {
        document.querySelector('.f_functionise_notification_window.' + hash).style.display = 'none';
      }, 2000);
      setTimeout(() => {
        var elem = document.querySelector('.f_functionise_notification_window.' + hash);
        if (elem) elem.remove();
      }, 3000);

      var selector = '';
      var useIds = true;
      var element = frame;

      if (
        (window.location.host.includes('cigna') && element.tagName.toLowerCase() === 'iframe') ||
        (window.location.host.includes('cigna') && element.tagName.toLowerCase() === 'frame') ||
        ((element.tagName.toLowerCase() === 'iframe' || element.tagName.toLowerCase() === 'frame') && frame.id && /\d/.test(frame.id))
      ) {
        useIds = false;
      }

      var skipDynamicAttributes = false;
      var isSkippable = false;
      if (
        window.location.host.includes('cpap') ||
        window.location.host.includes('stripe') ||
        ((element.tagName.toLowerCase() === 'iframe' || element.tagName.toLowerCase() === 'frame') && frame.id && /\d/.test(frame.id))
      ) {
        isSkippable = true;
      }
      if (isSkippable && frame.id) {
        skipDynamicAttributes = true;
      }

      if (frame.id && window.location.host.indexOf('cigna') === -1 && useIds) {
        selector = '//' + element.tagName + '[@id="' + frame.id + '"]';
      } else if (element.attributes.length > 0) {
        data.attributes = {};
        Array.from(element.attributes).forEach((attr) => {
          if (
            attr.name.includes('functionise') ||
            attr.name.includes('functionize') ||
            attr.value.includes('functionise') ||
            attr.value.includes('functionize') ||
            attr.value.includes('functi0nize') ||
            /\d/.test(attr.value)
          ) {
            return;
          }

          if (!useIds && (attr.name === 'id' || attr.name === 'src')) return;

          if (isSkippable && attr.value.length > 0 && /\d/.test(attr.value[attr.value.length - 1])) {
            return;
          }

          data.attributes[attr.name] = attr.value;

          if (attr.name === 'class') attr.value = attr.value.replace('z-highlighted', '').replace('z-flash-highlighted', '');

          var val = attr.value;
          if (val.length > 200 || val === '') return;

          var s = element.tagName + '[' + attr.name + '="' + val + '"]';

          var matches = [];

          try {
            matches = document.querySelectorAll(s);
          } catch (e) {
            console.log('Attribute generates invalid query selector', e);
          }

          if (matches.length === 1) {
            selector = '//' + element.tagName + '[@' + attr.name + '="' + val + '"]';
            return false;
          }
        });
      }
      if (selector === '') selector = window.WU.getElementXPath(element);

      window.WS.iframes.push({ UID: UID, index: index, selector: selector });

      data.index = index;
      data.selector = selector;
      data.targetElement = window.WS.targetElement(frame);
      data.iframeOffsetX = frame.getBoundingClientRect().left + window.scrollX;
      data.iframeOffsetY = frame.getBoundingClientRect().top + window.scrollY;
      data.functionizeid = frame.iFunctionizeID;
      data.traverseIframenextNodeId = window.WS.traverseIframenextNodeId;

      var allowController = false;
      if (window.TCM.isMaster && !window.TCM.isController)
        // we have a non-controlling master...
        allowController = true;

      window.TCM.registerChildAccept(data, allowController, 'iframe' + index);
      return frameFound;
    }

    document.querySelectorAll(tag).forEach((frame, i) => {
      var cuid = frame.getAttribute('data-functionise-UID');
      console.log('find iframe UID', frame, cuid, UID);
      if (cuid === UID) {
        window.WS.parseIframes();
        frameFound = handleIframe(frame, index);
        return false;
      }
      index++;
    });

    if (!frameFound) {
      let hider = document.createElement('div');
      hider.id = `${window.fUniqPrefix}-iframe-hider`;
      hider.style.cssText = 'opacity: 0.8; background-color: rgb(51, 51, 51); position: fixed; width: 100%; height: 100%; top: 0; left: 0; z-index: 42; visibility: visible;';
      if (!window.WS.traverseIframe || typeof window.WS.traverseIframe.cached === 'undefined') {
        document.body.append(hider);
        window.WS.parseIframes();
        console.log('waiting 2 seconds...');
        await new Promise((resolve) => setTimeout(resolve, 2000));
        document.body.removeChild(hider);
      }
      let iframe;
      try {
        iframe = Object.values(window.WS.traverseIframe.cached).find((iframe) => iframe.src === data.meta.frameURL);
        if (!iframe) {
          iframe = window.WS.siteStatistics.iframeList.find((iframe) => iframe.src === data.meta.frameURL);
        }
      } catch (e) {
        iframe = false;
      }

      if (iframe) {
        frameFound = true;
        handleIframe(iframe, index);
      } else {
        document.body.append(hider);
        window.WS.parseIframes();
        console.log('waiting 2 seconds...');
        await new Promise((resolve) => setTimeout(resolve, 2000));
        document.body.removeChild(hider);
        try {
          iframe = Object.values(window.WS.traverseIframe.cached).find((iframe) => iframe.src === data.meta.frameURL);
          if (!iframe) {
            iframe = window.WS.siteStatistics.iframeList.find((iframe) => iframe.src === data.meta.frameURL);
          }
        } catch (e) {
          iframe = false;
        }

        if (!iframe && data.meta?.frameName) {
          try {
            iframe = Object.values(window.WS.traverseIframe.cached).find((iframe) => iframe.getAttribute('name') === data.meta.frameName);
            if (!iframe) {
              iframe = window.WS.siteStatistics.iframeList.find((iframe) => iframe.getAttribute('name') === data.meta.frameName);
            }
          } catch (e) {
            iframe = false;
          }
        }

        if (!iframe && data.meta?.frameId) {
          try {
            iframe = Object.values(window.WS.traverseIframe.cached).find((iframe) => iframe.getAttribute('id') === data.meta.frameId);
            if (!iframe) {
              iframe = window.WS.siteStatistics.iframeList.find((iframe) => iframe.getAttribute('id') === data.meta.frameId);
            }
          } catch (e) {
            iframe = false;
          }
        }

        if (iframe) {
          frameFound = true;
          handleIframe(iframe, index);
        }
      }
    }

    if (!frameFound) {
      console.log('iframe is not found again', data);
      window.TCM.registerChildAccept(data, false, 'iframe' + data.index);
    }
  };

  this.disableExternalIframes = function () {
    window.WU.enableAllElements();
    if (window.functioniseAddOn) {
      window.fconsole.log('We have our add on present so no need to disable iframes…');
      return;
    }

    window.fconsole.log('Disabling iframes.');

    // Select all iframe elements excluding those with the specific class
    document.querySelectorAll('iframe:not(.' + window.fUniqPrefix + ')').forEach(function (frame) {
      // Check if the data UID attribute is undefined or empty
      if (frame.dataset.UID === undefined || frame.dataset.UID === '') {
        window.WS.disableElement(frame);
      }
    });

    var command = { obj: 'WS', call: 'disableExternalIframes' };
    window.TCM.sendCommandToDescendants(command);
  };

  this.disableElement = function (e) {
    window.WU.disableElement(e);
  };

  this.removeHighlights = function (currentContextOnly) {
    if (typeof currentContextOnly === 'undefined') {
      currentContextOnly = false;
    }

    window.WU.destroyTippyInstance();

    // Remove 'z-highlighted' class
    document.querySelectorAll('.z-highlighted').forEach(function (el) {
      el.classList.remove('z-highlighted');
    });

    // Remove 'f-domWalkSelector' class
    document.querySelectorAll('.f-domWalkSelector').forEach(function (el) {
      el.classList.remove('f-domWalkSelector');
    });

    // Remove elements with 'f-functionise-hider' class
    document.querySelectorAll('.f-functionise-hider').forEach(function (el) {
      el.remove();
    });

    if (window.TCM.isMaster && !currentContextOnly) {
      var command = { obj: 'WS', call: 'removeHighlights' };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  this.doWbUnload = function () {
    // document.cookie = `functionisemeUnload=${new Date().getTime()}; expires=0; path=/`;

    if (Object.keys(window.WS.enterToSendUp).length > 0) {
      try {
        window.localStorage.setItem('enterToSendUp', JSON.stringify(window.WS.enterToSendUp));
      } catch (e) {}
    }
    /*
    if (Object.keys(this.clickToSend).length > 0) {
      try {
        this.getRecordedData();
      } catch (e) {
        // Handle the error if necessary
      }
    }
    */
    window.WU.cookie('functionisemeUnload', new Date().getTime(), { expires: 0, path: '/' });
    this.isUnload = true;
  };

  this.incrementActionCount = function () {
    if (!window.TCM.initialize) return;

    this.actionCount++;
    window.TCM.showActionCounter();
    // action count is incremented automatically with the recordWbData call now...
    window.fconsole.log(this.actionCount + ' ' + this.actionLimit);
    if (this.actionCount >= this.actionLimit - 1) {
      window.TCM.stopTask(true);
    }
  };

  this.decrementActionCount = function () {
    if (!window.TCM.initialize) return;

    this.actionCount--;
    if (this.actionCount < 0) this.actionCount = 0;

    window.TCM.showActionCounter();
    var command = { obj: 'TCM', call: 'decrementActionCount' };
    window.TCM.sendCommandToMaster(command);
    window.fconsole.log(this.actionCount + ' ' + this.actionLimit);
  };

  /** ******* Element Targetting code ****************/

  this.getElementDetails = function (e, element) {
    console.trace('getElementDetails', e, element);

    if (typeof element === 'undefined') element = new wsElement();

    element.text = '';
    if (e.innerText) {
      element.text = window.WU.cleanValue(e.innerText);
    }

    if (e.hasAttribute('contenteditable') && e.innerHTML) {
      element.useHtml = '0';
      element.html = e.innerHTML;
    }

    // svg child elements do not have innerText, so we need to use textContent
    if ((element.text === '' || typeof element.text === 'undefined') && typeof e.tagName === 'string' && e.tagName.toLowerCase() !== 'svg' && e.closest('svg')) {
      element.text = window.WU.cleanValue(e.textContent);
    }

    element.value = window.WU.cleanValue(e.value || '', false, element);

    if (e.attributes) {
      Array.from(e.attributes).forEach(function (attr) {
        let attribute = { name: attr.name, value: attr.value };

        if (attribute.name == null || attribute.value == null) return;
        if (typeof attribute.value === 'function' || typeof attribute.name === 'function') return; // skip functions
        if (attribute.name.indexOf('functionize') > -1 || attribute.name.indexOf('functionise') > -1 || attribute.name.indexOf('functi0nize') > -1) return; // functionize data attr is skipped...

        if (attribute.value == null || typeof attribute.value === 'undefined') attribute.value = '';
        if (attribute.name === 'class' && typeof attribute.value.replace === 'function') {
          attribute.value = attribute.value.replace('z-highlighted', '').replace('z-flash-highlighted', '');
        }

        if (attribute.name === 'aria-describedby' && attribute.value.indexOf(window.fUniqPrefix) > -1) return;

        if (attribute.name === 'title' && attribute.value === '') return;
        if (attribute.name === 'oldtitle') {
          element['attr_title'] = window.WU.cleanValue(attribute.value);
          return;
        }

        if (typeof attribute.name === 'string' && attribute.name.indexOf('<') !== 0) {
          element['attr_' + attribute.name.replaceAll('{', '').replaceAll('}', '')] = window.WU.cleanValue(attribute.value.replaceAll('{', '').replaceAll('}', ''));
        }
      });
      element['attr_visibility'] = window.getComputedStyle(e).display !== 'none';
    }

    const offset = e.getBoundingClientRect();
    element.x = offset.left;
    element.y = offset.top;

    var rect = window.WU.zoomBoundingRect(e);
    element.width = rect.width;
    element.height = rect.height;

    if (!element.hasOwnProperty('elementStatistics')) {
      if (element.hasOwnProperty('action') && element.action === 'input' && element.hasOwnProperty('element') && element.hasOwnProperty('actionId') && e instanceof HTMLElement) {
        window.WS.mlDataElements[element.actionId] = e;
      }
    }

    /*
    // this should be after merge
    if (!element.hasOwnProperty('elementStatistics')) {
      if (element.hasOwnProperty('action') && element.action === 'input' && element.hasOwnProperty('element') && element.hasOwnProperty('actionId') && e instanceof HTMLElement) {
        console.log('collectMlData getElementDetails', e, element.action, element.actionId);
        element.elementStatistics = window.WS.collectMlData(e, element.action, element.actionId);
      }
    }
     */

    return element;
  };

  this.getElementDetailsAsString = function (e) {
    var element = this.getElementDetails(e);
    return JSON.stringify(element);
  };

  this.elementInShadowRoot = function (path) {
    var result = false;

    path.forEach(function (v, i) {
      if (v.shadowRoot && v.shadowRoot.querySelector(window.WU.getElementCss(path[0]))) {
        result = true;
      }
    });

    return result;
  };

  this.shadowRootSelector = function (path, element) {
    var result = [window.WU.getElementCss(element)];
    var item = 0;

    path.forEach(function (v, i) {
      if (v.shadowRoot && v.shadowRoot.querySelector(window.WU.getElementCss(path[item]))) {
        result.unshift(window.WU.getElementCss(v));
        item = i;
      }
    });

    return 'functionize-shadow::' + result.join('::');
  };

  this.isDisplayContents = function (element) {
    if (element instanceof Element) {
      let computedElement;
      let computedStyle = getComputedStyle(element);
      if (computedStyle.hasOwnProperty('display') && computedStyle.display === 'contents') {
        computedElement = element;

        // handle slot in shadowDom
        try {
          if (!computedElement.parentElement && computedElement.getRootNode().host) {
            return computedElement.getRootNode().host;
          }
        } catch (e) {}

        while (computedElement.parentElement) {
          computedElement = computedElement.parentElement;
          let innerStyle = getComputedStyle(computedElement);
          if (innerStyle.hasOwnProperty('display') && innerStyle.display !== 'contents') {
            element = computedElement;
            break;
          }
        }
      }
      return element;
    }
    return element;
  };

  this.setFunctionizeSelected = function (action, element) {
    return new Promise(function (resolve, reject) {
      chrome.runtime.sendMessage({ elementStatistics: action.actionId }, function (response) {
        resolve(response);
      });
    });
  };

  this.parseIframes = function () {
    // reset filter
    if (this.siteStatistics.filterActivated) {
      this.setIframeFilter();
    }

    window.WS.traverseIframe = window.WS.siteStatistics.traverseIframe(window.WS.iFunctionizeID || null, 0, iframeUID ? iframeUID.match(/(.*)-(.*)/)[2] + 0 : '');
    window.WS.traverseIframenextNodeId = window.WS.traverseIframe.nextNodeId;
    var localComp = JSON.stringify(JSON.parse(window.WS.traverseIframe.comp));
    window.WS.traverseIframeComp = [JSON.parse(localComp)];
  };

  this.targetElement = function (event, action, timeStamp, skipML, pathOverride, init, force, existingActionId, composedPath, forceML) {
    console.trace('targetElement');
    let e;
    let isShadow = true;

    if (typeof event.target !== 'object' && !pathOverride) {
      if (composedPath && this.elementInShadowRoot(composedPath)) {
        isShadow = true;
      } else {
        isShadow = false;
      }
      e = event;
    } else if (typeof event.composedPath === 'function' && Array.isArray(event.composedPath()) && event.composedPath().length > 0) {
      e = event.composedPath()[0];
    } else {
      e = event.target;
    }

    if (!force) {
      e = window.WS.isDisplayContents(e);
    }

    // var functionizeHash = e.getAttribute('data-functionize-hash');
    var elementName = null;
    var element = null;
    var belement = null;

    if (typeof timeStamp === 'undefined') timeStamp = 0;

    if (typeof e === 'undefined' || e == null || !(e instanceof Element)) return '';
    elementName = e.tagName.toLowerCase();

    if ((action === 'hover' || action === 'scroll' || action === 'click' || action === 'verify') && window.WU.isPotentialSvgChild(elementName) && !window.WS.enableSVGChildren) {
      const svgAncestor = e.closest('svg');
      if (svgAncestor && svgAncestor.getBoundingClientRect().height * svgAncestor.getBoundingClientRect().width < 10001) {
        e = svgAncestor;
        elementName = e.tagName.toLowerCase();
      }
    }

    if (
      (action === 'hover' || action === 'scroll' || action === 'click' || action === 'verify') &&
      (elementName === 'option' || elementName === 'optgroup' || e.closest('option'))
    ) {
      if (e.closest('select')) {
        e = e.closest('select');
        elementName = e.tagName.toLowerCase();
      }
    }

    if (element === null) {
      element = new wsElement();
    }

    window.fconsole.log('Getting element xpath');
    const shadowDom =
      isShadow && this.elementInShadowRoot(typeof event.composedPath === 'function' && !pathOverride && !composedPath ? event.composedPath() : pathOverride || composedPath || []);
    const xpath = shadowDom
      ? this.shadowRootSelector(
          typeof event.composedPath === 'function' && !pathOverride && !composedPath ? event.composedPath() : pathOverride || composedPath || [],
          typeof event.composedPath === 'function' ? event.composedPath()[0] : e
        )
      : elementName === 'svg'
        ? window.WU.getElementXPath(e, false, true)
        : window.WU.getElementXPath(e);
    window.fconsole.log('Getting element unique');
    const uniqueSelectors = window.WU.getElementUniqueSelectors(e);
    const uniqueSelectorsMulti = window.WU.getElementUniqueSelectorsTree(e);
    window.fconsole.log('Getting element uniquetree');
    const secondarySelectors = window.WU.getElementSecondarySelectors(e);
    window.fconsole.log('Getting element xpath2');
    const xpath2 = window.WU.getElementXPath(e, true);
    window.fconsole.log('Getting element xpath3');
    const xpath3 = window.WU.getElementTreeXPath(e, false, true, 0, false);
    window.fconsole.log('Getting element xpath4');
    const xpath4 = window.WU.getElementTreeXPath(e, true, true, 3);
    window.fconsole.log('Getting element xpath5');
    const xpath5 = window.WU.getElementTreeXPath(e, false, false);
    window.fconsole.log('Selectors are done');

    if (typeof action !== 'undefined' && action !== '') {
      element = {
        action: action,
        // functionizeHash: functionizeHash,
        element: elementName,
        timestamp: timeStamp,
        epoch: window.WU.getTime(),
        xpath: xpath,
        xpath2: xpath2,
        xpath3: xpath3,
        xpath4: xpath4,
        xpath5: xpath5,
        cssSelector: window.WU.getElementCss(e),
        cssSelector2: window.WU.getElementCss(e, true),
        index: Array.from(document.querySelectorAll(elementName))
          .filter((el) => !el.classList.contains(window.fUniqPrefix) && !el.closest(`.${window.fUniqPrefix}`))
          .indexOf(e),
        shadowDom: shadowDom,
        isScrolled: !!(window.pageYOffset || document.documentElement.scrollTop > 0),
        readyState: document.readyState,
      };
    } else {
      element = {
        element: elementName,
        xpath: xpath,
        timestamp: timeStamp,
        epoch: window.WU.getTime(),
        xpath2: xpath2,
        xpath3: xpath3,
        xpath4: xpath4,
        xpath5: xpath5,
        cssSelector: window.WU.getElementCss(e),
        cssSelector2: window.WU.getElementCss(e, true),
        index: Array.from(document.querySelectorAll(elementName))
          .filter((el) => !el.classList.contains(window.fUniqPrefix) && !el.closest(`.${window.fUniqPrefix}`))
          .indexOf(e),
        shadowDom: shadowDom,
        isScrolled: !!(window.pageYOffset || document.documentElement.scrollTop > 0),
        readyState: document.readyState,
      };
    }

    if (skipML !== true) {
      console.log('collecting ml data');
      try {
        if (typeof element.element !== 'undefined' && element.element !== 'iframe') {
          let mlElement;
          if (e instanceof Element || e instanceof HTMLDocument) {
            mlElement = e;
          } else if (e.hasOwnProperty('target')) {
            mlElement = e.target;
          } else {
            mlElement = e;
          }

          console.log('ml data element', mlElement);

          window.WU.setZoomLevel(mlElement);

          if (element.action === 'input' && !(this.lastMLAction === element.action && this.lastMLSelector === mlElement) && forceML !== true) {
            this.lastMLSelector = mlElement;
            this.lastMLAction = element.action;

            if (window.WS.collectMlDataOnKeydown && window.WS.keyDownMlData) {
              element.elementStatistics = window.WS.keyDownMlData;
              window.WS.keyDownMlData = '';
            } else {
              element.elementStatistics = window.WS.collectMlData(mlElement, element.action, element.actionId);
            }

            console.log('collectMlData element.elementStatistics', element.elementStatistics);

            if (element.hasOwnProperty('text') && element.text !== '' && mlElement.hasAttribute('functionizeid')) {
              element.mlText = mlElement.getAttribute('functionizeid');
            }
          } else if (element.action !== 'input') {
            this.lastMLSelector = mlElement;
            this.lastMLAction = element.action;
            element.elementStatistics = window.WS.collectMlData(mlElement, element.action, element.actionId);
            console.log('collectMlData element.elementStatistics', element.elementStatistics);
            if (element.hasOwnProperty('text') && element.text !== '' && mlElement.hasAttribute('functionizeid')) {
              element.mlText = mlElement.getAttribute('functionizeid');
            }
          }
        } else if (typeof element.action !== 'undefined' && element.action === 'pageinit' && !this.isIframe) {
          element.elementStatistics = window.WS.collectMlData(
            document.body && document.body.childElementCount > 0 ? document.body : document.children[0],
            element.action,
            element.actionId
          );
          console.log('collectMlData element.elementStatistics', element.elementStatistics);
        }
      } catch (e) {
        console.error('Exception: ' + e);
      }
    }

    if (existingActionId && typeof existingActionId === 'string') {
      console.log('generateActionId existingActionId', existingActionId);
      element.actionId = existingActionId;
    }

    console.log('targetElement generateActionId', element, element.actionId);
    if (typeof element !== 'undefined' && typeof element.actionId === 'undefined') {
      console.log('targetElement generateActionId generating new actionid');
      element.actionId = window.WU.generateActionId();
    }

    console.log('element actionId', element.actionId);

    try {
      if (getComputedStyle(e).display === 'none') {
        element.displayNone = 'true';
      }
    } catch (e) {}

    if (init) {
      element.actionType = 'init';
    }

    if (skipML !== true) {
      element['formData'] = JSON.stringify(window.WU.getFormProperties(e));
      // removing this feature for preFocus and postFocus due to issues in favor of data-focusvalue and data-focustext attributes
      /*
      if (e !== window.WS.activeElements.post && e !== window.WS.activeElements.pre) {
        element['preFocus'] = JSON.stringify(window.WS.targetElement(window.WS.activeElements.post, undefined, undefined, true));
        element['postFocus'] = JSON.stringify(window.WS.targetElement(e, undefined, undefined, true));
      }
      */
    }

    if (this.collectFormData) {
      element = this.addFormSerialization(e, element);
    }

    window.fconsole.log('Calling tree selectors...');
    /*
    element.forceFirstSelector = false;

    element.selectors = [
      {
        selectorType: 'XPATH',
        value: xpath,
        recorded: true,
        unique: false,
      },
      {
        selectorType: 'XPATH',
        value: xpath2,
        recorded: true,
        unique: false,
      },
      {
        selectorType: 'XPATH',
        value: xpath3,
        recorded: true,
        unique: false,
      },
      {
        selectorType: 'XPATH',
        value: xpath4,
        recorded: true,
        unique: false,
      },
      {
        selectorType: 'XPATH',
        value: xpath5,
        recorded: true,
        unique: false,
      },
      {
        selectorType: 'CSS',
        value: element.cssSelector,
        recorded: true,
        unique: false,
      },
      {
        selectorType: 'CSS',
        value: element.cssSelector2,
        recorded: true,
        unique: false,
      },
    ];
    */
    // populate multi dim selectors
    var append = '';
    if (uniqueSelectors != null) {
      var s = uniqueSelectors.split('|functionise|');
      var counter = 1;
      for (let ss in s) {
        append = '';
        if (counter > 1) append = counter;
        element['uniqueSelectors' + append] = s[ss];
        /*
        element.selectors.push({
          selectorType: 'XPATH',
          value: s[ss],
          recorded: true,
          unique: true,
        });
         */
        counter++;
      }
    }

    if (uniqueSelectorsMulti != null) {
      s = uniqueSelectorsMulti.split('|functionise|');
      counter = 1;
      for (let ss in s) {
        append = '';
        if (counter > 1) append = counter;
        element['uniqueSelectorsMulti' + append] = s[ss];
        /*
        element.selectors.push({
          selectorType: 'XPATH',
          value: s[ss],
          recorded: true,
          unique: true,
        });

         */
        counter++;
      }
    }

    if (secondarySelectors != null) {
      s = secondarySelectors.split('|functionise|');
      counter = 1;
      for (let ss in s) {
        append = '';
        if (counter > 1) append = counter;
        element['secondarySelectors' + append] = s[ss];
        /*
        element.selectors.push({
          selectorType: 'XPATH',
          value: s[ss],
          recorded: true,
          unique: true,
        });

         */
        counter++;
      }
    }

    // for shift clicks we need to send in mouse positions.   If sent we set it here below
    if (typeof e.mouseX !== 'undefined') {
      element.mouseX = 1; // e.mouseX;
    }

    if (typeof e.mouseY !== 'undefined') {
      element.mouseY = 1; // e.mouseY;
    }

    var type = e.getAttribute('type') || false;

    var createdTime = e.getAttribute('data-functionize-added') || '';
    if (typeof addedTime !== typeof undefined && addedTime !== false) {
      element.createdTime = createdTime;
    }
    createdTime = 0;

    e.querySelectorAll('[data-functionize-added]').forEach(function (el) {
      var t = parseInt(el.getAttribute('data-functionize-added') || 0);
      if (t > createdTime) createdTime = t;
    });

    if (createdTime > 0) element.childCreatedTime = createdTime;

    // Grab element id
    window.fconsole.log('Grabbing element id');
    var functionizeElementId = e.getAttribute('data-functionize-id') || '';
    if (typeof functionizeElementId !== 'undefined' && functionizeElementId !== false) {
      window.fconsole.log('Generating meta from mutation storage');
      var meta = this.generateMetaDataFromMutationStorage(functionizeElementId);
    }

    if (e.tagName.toLowerCase() === 'input') {
      // Overwrite the inputs to account for textarea
      // Remove textareas from the index as these are not really "input" elements by selenium standards
      var inputs = Array.from(Array.from(document.querySelectorAll('input:not(.' + window.fUniqPrefix + ', .' + window.fUniqPrefix + ' *)'))).filter(
        (input) => input.tagName.toLowerCase() !== 'textarea'
      );
      element.index = inputs.indexOf(e);
    }

    if (type) {
      element.type = type;
    }

    // console.log('collectMlData targetElement', e, element);

    window.fconsole.log('Targetting element ' + elementName + '  ' + JSON.stringify(element));
    element = this.getElementDetails(e, element);

    if (action === 'select') {
      var selectedOption = e.querySelector('option:checked');
      if (selectedOption) {
        element.text = selectedOption.textContent;

        let indexes = [];
        let text = [];
        let value = [];
        Array.from(e.options).forEach((option, i) => {
          if (option.selected) {
            indexes.push(i);
            text.push(option.innerText);
            value.push(option.value);
          }
        });

        if (e.hasAttribute('multiple')) {
          element.optionText = JSON.stringify(text);
          element.optionValue = JSON.stringify(value);
        }

        element.optionIndices = JSON.stringify(indexes);
      }
    }

    // If index is less than one we are dealing with a lone element
    if (element.index < 0) element.index = 0;

    window.fconsole.log('Checking parent');
    // If parent is undefined or length is 0, return element

    window.fconsole.log('Getting parent');

    belement = element;
    try {
      // element = this.addExtraElementData(e, element);
      element = this.dedupeSelectors(element);
      // element = this.addElementParentsChildData(e, element);
      // element = this.addElementSiblingData(e, element);
      element = this.formatelementData(e, element);
    } catch (err) {
      console.error(err);
      element = belement;
    }

    var hash = window.WU.randomText(20);
    e.setAttribute('data-functionize-hash', hash);
    e.addEventListener('change', function () {
      window.fconsole.log("Removing element's hash: " + hash);
      e.removeAttribute('data-functionize-hash');
    });
    window.fconsole.log('Returning element ' + hash);

    if (typeof this.iframeUID !== 'undefined' && this.iframeUID !== '') element.iframeUID = this.iframeUID;
    if (typeof this.popupUID !== 'undefined' && this.popupUID !== '') element.popupUID = this.popupUID;
    element.pageTitle = document.querySelector('title')?.textContent;

    if (window.WS.functionizeid) {
      element.functionizeid = window.WS.functionizeid;
    }
    if (!element.iframeUID) {
      element.iframeUID = window.WS.iframeUID;
    }

    console.log('Setting verifyattr_ here', element);

    if (element.action === 'verify') {
      if (element.text && !element.hasOwnProperty('verifyattr_text') && element.element !== 'select') {
        element.verifyattr_text = encodeURIComponent('eq#func#' + element.text);
      }
      if ((element.value && !element.hasOwnProperty('verifyattr_value')) || element.element === 'select') {
        element.verifyattr_value = encodeURIComponent('eq#func#' + element.value);
      }
    }

    if (element.action === 'input') {
      element.encrypt = false;
    }

    console.log('!! targetElement returning', element);
    return element;
  };

  this.generateMetaDataFromMutationStorage = function (functionizeElementId) {
    var metaData = {};
    if (typeof window.functionizeElementMutationStorage[functionizeElementId] !== 'undefined') {
      var storageObj = window.functionizeElementMutationStorage[functionizeElementId];
      return storageObj;
    }
  };
  /** ******* Element Targetting code end ****************/

  /** ******* Recording data and related methods    ****************/

  this.evaluateAjaxCall = function (method, url, timestamp) {
    window.fconsole.log('evaluate ajax is called');
    var lastAction = this.getLastRecordedDataSegment();
    window.fconsole.log('lastAction: ' + JSON.stringify(lastAction));
    if (typeof lastAction.epoch === 'undefined') {
      window.fconsole.log('No timestamp detected in: ' + JSON.stringify(lastAction));
      return;
    }
    var ajaxRecorded = false;
    if (typeof lastAction.ajaxMethod !== 'undefined') {
      window.fconsole.log('ajax is already recorded…');
      ajaxRecorded = true;
    }

    if (!ajaxRecorded && timestamp - parseInt(lastAction.epoch) > 50 && timestamp - parseInt(lastAction.epoch) < 240) {
      // this is probably a triggered ajax from our recorder action
      window.fconsole.log('Ajax call captured: ' + url);
      window.WS.updateLastAction({ ajaxMethod: method, ajaxUrl: url });
    } else {
      window.fconsole.log('Ajax call time is not in the preferred timezone: ' + (timestamp - parseInt(lastAction.epoch)) + ' Skipping….');
    }

    if (typeof window.userScroll === 'undefined' || typeof window.userScroll.timestamp === 'undefined') return;

    //check user scroll
    if (timestamp - window.userScroll.timestamp < 20) {
      //trigger lazyload
      window.WS.hasLazyLoad = true;
      console.log('lazyload trigger: ' + window.WS.hasLazyLoad);
    }
  };

  this.updateLastActionByEventLocation = function (data, skipML) {
    // console.log('updateLastActionByEventLocation', data);
    var selectedText = '';
    let anchorNode = false;
    if (window.getSelection) {
      selectedText = window.getSelection().toString();
      anchorNode = window.getSelection().anchorNode;
    } else if (document.selection) {
      selectedText = document.selection.createRange().text;
    }
    if (!data['selectedText'] && selectedText) data['selectedText'] = selectedText;
    window.fconsole.log('updateLastActionByEventLocation is called' + data.timestamp + '  ' + data.eventX);

    var lastAction = null;
    if (!window.TCM.isMaster) {
      if (this.lastAction) {
        lastAction = this.lastAction;
      } else {
        lastAction = this.targetElement(data.target, 'lastAction', undefined, skipML);
      }
    } else {
      lastAction = window.WS.getLastRecordedDataSegment();
    }

    // we see if this is event location
    if (typeof data.eventX !== 'undefined') {
      // check time difference for drag.   Require 500 milliseconds at least
      var timeDiff = data.timestamp - lastAction.timestamp;
      // if (timeDiff < 400) return;

      // check difference of location

      var xdiff = data.eventX - parseInt(window.WS.lastClickToSend.eventX);
      var ydiff = data.eventY - parseInt(window.WS.lastClickToSend.eventY);
      if ((Math.abs(xdiff) > 2 || Math.abs(ydiff) > 2) && lastAction) {
        console.log('// Check if the action text select not dragby');

        console.log('sectedText', selectedText);

        /** ********* textselect Action ***********/
        if (selectedText) {
          console.log('selectedText', selectedText);
          var lastActionSelector = lastAction.cssSelector;
          var selectors = ['xpath', 'xpath2', 'xpath3', 'xpath4', 'xpath5', 'cssSelector', 'cssSelector2', 'uniqueSelectors', 'uniqueSelectorsMulti', 'secondarySelectors'];
          var selfObj = this;

          selectors.forEach(function (value) {
            if (typeof lastAction[value] !== 'undefined' && lastAction[value]) {
              var selector = lastAction[value];
              var cssSelector = selector;
              if (!value.startsWith('css')) cssSelector = selfObj.xPathToCss(selector);

              try {
                var elements = document.querySelectorAll(cssSelector);
                if (elements.length === 1) {
                  lastActionSelector = cssSelector;
                  return;
                }
              } catch (e) {
                console.error('Selector did not work: ' + cssSelector + ' ' + e);
              }
            }
          });

          var commonTop = '';
          var foundCommonTop = false;
          var c;

          if (data.hasOwnProperty('event') && this.elementInShadowRoot(data.event.composedPath())) {
            c = document.querySelector(window.TCM.selectShadowDomElement(window.WS.shadowRootSelector(data.event.path, data.event.composedPath()[0])));
          } else {
            c = data.target;
          }

          var l;

          if (lastAction.xpath.includes('functionize-shadow')) {
            l = document.querySelector(window.TCM.selectShadowDomElement(lastAction.xpath));
          } else {
            l = document.querySelector(lastActionSelector);
          }

          while (!foundCommonTop) {
            console.log('!foundCommonTop', c === l, c, l);
            if (c === l || typeof c === 'undefined' || typeof l === 'undefined') {
              console.log('!foundCommonTop returning true');
              foundCommonTop = true;
            } else {
              var ltagname = l.tagName.toLowerCase();
              console.log('ltagname', ltagname);
              if (ltagname === 'html') {
                console.log('ltagname == html', l, c, lastActionSelector);
                l = document.querySelector(lastActionSelector);
                c = c.parentElement;
                console.log('ltagname == html after', l, c, lastActionSelector);
              } else {
                l = l.parentElement;
              }
            }
          }

          console.log('getSelectionCharOffsetsWithin', c);

          var getSelectionCharOffsetsWithin = window.WS.getSelectionCharOffsetsWithin(c, anchorNode);

          var changeSelector = window.WS.targetElement(c, 'textselect');

          console.log('targetElement', c);

          changeSelector.text = c.textContent;
          changeSelector.value = c.textContent;
          changeSelector.selectText = data.selectedText;
          changeSelector.selectionStart = getSelectionCharOffsetsWithin.start;
          changeSelector.selectionEnd = getSelectionCharOffsetsWithin.end;

          delete changeSelector.actionId;

          window.WS.updateLastAction(changeSelector);
          console.log('returning');
          return;
        }
      }
      console.log('not selected text');
      /** ********* textselect Action ***********/
      /*
      if (!window.TCM.isMaster) {
        console.log('not master');
        var command = {
          obj: 'WS',
          call: 'updateLastActionByEventLocation',
          arguments: new Array(data),
          meta: { fromUID: window.WS.popupUID },
        };
        window.fconsole.log('Sending relay to plugin: ' + command.call);
        self.port.emit('relay', command);
        return;
      }
       */
      // lastAction = window.WS.getLastRecordedDataSegment();

      xdiff = data.eventX - parseInt(lastAction.eventX);
      ydiff = data.eventY - parseInt(lastAction.eventY);
      let clientHeight = 0;
      console.log(typeof document.body, typeof document.body.clientHeight, typeof lastAction.clientHeight);
      if (typeof document.body !== 'undefined' && typeof document.body.clientHeight !== 'undefined' && typeof lastAction.clientHeight !== 'undefined') {
        clientHeight = document.body.clientHeight - lastAction.clientHeight;
      }
      if (Math.abs(xdiff) > 15 || Math.abs(ydiff) > 15 + Math.abs(clientHeight)) {
        // we update the action too to dragby
        var newdata = {};
        newdata.action = 'dragby';
        newdata.eventOffsetX = xdiff;
        newdata.eventOffsetY = ydiff;

        if (typeof data.selectedText !== 'undefined' && data.selectedText) {
          newdata.force_js = 1;
          newdata.value = data.selectedText;
        }

        // Set latest target's parent xpath
        try {
          // Get all elements at the specified coordinates
          var elementsFromPoint = document.elementsFromPoint(data.eventX, data.eventY);

          var fIndex = 0;
          var fElement = null;
          var lastActionXpath = null;

          // Determine the appropriate XPath to use
          if (lastAction.xpath5) {
            lastActionXpath = lastAction.xpath5;
          } else if (lastAction.xpath4) {
            lastActionXpath = lastAction.xpath4;
          } else if (lastAction.xpath3) {
            lastActionXpath = lastAction.xpath3;
          } else if (lastAction.xpath2) {
            lastActionXpath = lastAction.xpath2;
          } else if (lastAction.xpath) {
            lastActionXpath = lastAction.xpath;
          }

          lastActionXpath = lastActionXpath.split('/');
          var lastActionXpathLength = lastActionXpath.length;

          // Iterate over the elements from the point
          elementsFromPoint.forEach(function (attr, index) {
            var attrTagName = attr.tagName;

            if (typeof lastActionXpath[lastActionXpathLength - 1] === 'undefined') {
              lastActionXpath[lastActionXpathLength - 1] = '';
            }

            var lActionTagName = window.TCM.formatSelectorElement(lastActionXpath[lastActionXpathLength - 1], true);
            if (attrTagName.toLowerCase() !== lActionTagName.toLowerCase() && !fElement) {
              fIndex = index;
              fElement = attr;
            }

            lastActionXpathLength--;
          });

          // Set newdata.target_xpath based on the elements found
          if (window.WU.getElementXPath(elementsFromPoint[0])) {
            newdata.target_xpath = window.WU.getElementXPath(elementsFromPoint[0]);
          } else {
            newdata.target_xpath = lastAction.xpath;
            newdata.target_xpath2 = lastAction.xpath2;
            newdata.target_xpath3 = lastAction.xpath3;
            newdata.target_xpath4 = lastAction.xpath4;
            newdata.target_xpath5 = lastAction.xpath5;
          }
        } catch (e) {
          console.error(e.message);
        }

        window.WS.updateLastAction(newdata);
      } else {
        console.log('this is not good', Math.abs(xdiff), Math.abs(ydiff), Math.abs(clientHeight));
      }
    }
  };

  this.appendScreenShot = function (actionId, screenShot) {
    window.fconsole.log('Logging screenshot: ' + screenShot);
    var command = null;
    if (this.isIframe) {
      command = { obj: 'WS', call: 'appendScreenShot', arguments: new Array(actionId, screenShot) };
      window.TCM.sendCommand(command, window.parent);
      return;
    }

    if (this.isPopup) {
      command = { obj: 'WS', call: 'appendScreenShot', arguments: new Array(actionId, screenShot) };
      window.TCM.sendCommand(command, window.opener);
      return;
    }

    var action = this.getRecordingDataByAtionId(actionId);
    if (!action) return;
    action['screenShot'] = screenShot;
  };

  this.updateVariableLastAction = function (data) {
    console.log('updateVariableLastAction', data);
    setTimeout(() => {
      if (Object.keys(data).length > 0) {
        if (!window.TCM.isMaster) {
          // send up the chain
          var fromUID = window.WS.popupUID;
          if (window.WS.iframeUID != '') fromUID = window.WS.iframeUID;
          var command = {
            obj: 'WS',
            call: 'updateVariableLastAction',
            arguments: data,
            meta: { fromUID: fromUID },
          };
          window.fconsole.log('Sending relay to plugin: ' + command.call);
          console.trace('updateLastAction', data);
          self.port.emit('relay', command);
          return;
        }

        console.trace('updateLastAction', data);
        self.port.emit('message', {
          obj: 'TCM',
          call: 'updateLastAction',
          arguments: {
            data: data,
          },
          forMaster: true,
        });
      }
    }, 500);
  };

  this.updateLastAction = function (data) {
    console.log('updateLastAction', data);
    if (Object.keys(data).length > 0) {
      if (!window.TCM.isMaster) {
        // send up the chain
        var fromUID = window.WS.popupUID;
        if (window.WS.iframeUID != '') fromUID = window.WS.iframeUID;
        var command = {
          obj: 'WS',
          call: 'updateLastAction',
          arguments: data,
          meta: { fromUID: fromUID },
        };
        window.fconsole.log('Sending relay to plugin: ' + command.call);
        self.port.emit('relay', command);
        return;
      }

      var lastAction = this.getLastRecordedDataSegment();
      if (data.hasOwnProperty('hasLazyLoad') && lastAction.hasOwnProperty('hasLazyLoad')) {
        if (data.hasLazyLoad === lastAction.hasLazyLoad) {
          return;
        }
      }
      for (var p in data) lastAction[p] = data[p];

      this.recordedData[this.recordedData.length - 1] = lastAction;

      self.port.emit('message', {
        obj: 'TCM',
        call: 'updateLastAction',
        arguments: { data: data, lastAction: lastAction },
        forMaster: true,
      });
    }
  };

  this.updateLastActionByType = function (data, lastAction) {
    if (typeof data === 'undefined' || typeof lastAction === 'undefined') return;

    if (typeof lastAction == 'string') {
      lastAction = [lastAction];
    }

    self.port.emit('message', {
      obj: 'TCM',
      call: 'updateLastActionByType',
      arguments: { data: data, property: lastAction },
      forMaster: true,
    });
  };

  this.updateActionByActionId = function (data, actionId) {
    console.log('updateActionByActionId', data, actionId);
    if (Object.keys(data).length > 0) {
      if (!window.TCM.isMaster) {
        // send up the chain

        if (!data.hasOwnProperty('actionId') && typeof actionId !== 'undefined') {
          data = { ...data, actionId: actionId };
        }

        var fromUID = window.WS.popupUID;
        if (window.WS.iframeUID != '') fromUID = window.WS.iframeUID;
        var command = {
          obj: 'WS',
          call: 'updateActionByActionId',
          arguments: data,
          meta: { fromUID: fromUID },
        };
        window.fconsole.log('Sending relay to plugin: ' + command.call);
        self.port.emit('relay', command);
        return;
      }

      var action = this.getRecordingDataByActionId(actionId || data.actionId);

      console.log('updateLastAction action and data', action, data);
      if (action) {
        if (action.action === 'verify') {
          if (data.text && !data.hasOwnProperty('verifyattr_text') && data.element !== 'select') {
            data.verifyattr_text = encodeURIComponent('eq#func#' + data.text);
          }
          if ((data.value && !data.hasOwnProperty('verifyattr_value')) || data.element === 'select') {
            data.verifyattr_value = encodeURIComponent('eq#func#' + data.value);
          }
        }

        for (var p in data) action[p] = data[p];

        console.log('updateLastAction this is it', data, action);

        var index = this.recordedData.findIndex((recordedAction) => {
          return recordedAction.actionId == action.actionId;
        });

        this.recordedData[index] = action;

        console.trace('updateLastAction', data, action);
        self.port.emit('message', {
          obj: 'TCM',
          call: 'updateLastAction',
          arguments: { data: data, lastAction: action },
          forMaster: true,
        });
      }
    }
  };

  this.overloadActionByActionId = function (data, executeML, actionId) {
    console.log('overloadActionByActionId', data);
    if (!window.TCM.isMaster) {
      // send up the chain

      if (!data.hasOwnProperty('actionId') || !data.actionId) {
        data.actionId = actionId;
      }
      var fromUID = window.WS.popupUID;
      if (window.WS.iframeUID != '') fromUID = window.WS.iframeUID;
      var command = {
        obj: 'WS',
        call: 'overloadActionByActionId',
        arguments: data,
        meta: { fromUID: fromUID },
      };
      window.fconsole.log('Sending relay to plugin: ' + command.call);
      self.port.emit('relay', command);
      return;
    }

    var fieldsToKeep = [
      'path',
      'actionId',
      'url',
      'timestamp',
      'epoch',
      'selection_method',
      'force_selector',
      'selector',
      'skip_scroll',
      'suppress',
      'optional',
      'isVisualCheck',
      'updateVerifications',
    ];

    console.log('getRecordingDataByActionId', actionId, this.getRecordingDataByActionId(actionId), data.actionId, this.getRecordingDataByActionId(data.actionId));

    var action = this.getRecordingDataByActionId(actionId) || this.getRecordingDataByActionId(data.actionId);

    if (!action) {
      console.log('NO ACTION WITH ID', actionId, data.actionId, window.WS.recordedData);
      return;
    }

    for (let p in action) {
      if (fieldsToKeep.indexOf(p) < 0 && p.indexOf('pathselector') < 0 && p.indexOf('pathoffset') < 0) {
        delete action[p];
      }
    }

    for (let p in data) {
      try {
        action[p] = data[p];
      } catch (e) {
        console.log(e);
      }
    }

    var index = this.recordedData.findIndex((recordedAction) => {
      return recordedAction.actionId == action.actionId;
    });
    this.recordedData[index] = action;

    console.log('overloadActionByActionId result', action);

    self.port.emit('message', {
      obj: 'TCM',
      call: 'replaceLastAction',
      arguments: { lastAction: action },
      forMaster: true,
    });
  };

  this.getSiteStatistics = function (action, selector) {
    if (!action || !action.actionId || action.element === 'window') {
      return false;
    }

    if (action.hasOwnProperty('actionId')) {
      // we have an action id
      if (typeof this.siteStatisticsMap[action.actionId] !== 'undefined') {
        // we've already run ML
        if (this.siteStatisticsMap[action.actionId] === selector) {
          return false;
        }
      }
    }

    return true;
  };

  // this overloads the action meaning everything is removed before the merge bar a few fields
  this.overloadLastAction = function (data, executeML) {
    if (!window.TCM.isMaster) {
      // send up the chain

      var fromUID = window.WS.popupUID;
      if (window.WS.iframeUID != '') fromUID = window.WS.iframeUID;
      var command = {
        obj: 'WS',
        call: 'overloadLastAction',
        arguments: data,
        meta: { fromUID: fromUID },
      };
      window.fconsole.log('Sending relay to plugin: ' + command.call);
      self.port.emit('relay', command);
      return;
    }

    var fieldsToKeep = ['path', 'actionId', 'url', 'timestamp', 'epoch', 'elementStatistics', 'skip_scroll', 'suppress', 'optional', 'isVisualCheck'];

    var lastAction = this.getLastRecordedDataSegment();
    for (let p in lastAction) {
      if (fieldsToKeep.indexOf(p) < 0 && p.indexOf('pathselector') < 0 && p.indexOf('pathoffset') < 0) delete lastAction[p];
    }

    for (let p in data) lastAction[p] = data[p];

    this.recordedData[this.recordedData.length - 1] = lastAction;
    self.port.emit('message', {
      obj: 'TCM',
      call: 'replaceLastAction',
      arguments: { lastAction: lastAction },
      forMaster: true,
    });
  };

  this.getActionAttribute = function (action, attr) {
    if (attr == 'text') return action.text;
    if (attr == 'value') return action.value;
    try {
      if (attr == 'url' && action.action == 'pageinit') return action.url;
    } catch (e) {}
    if (typeof action['attr_' + attr] !== 'undefined') return action['attr_' + attr];
    if (typeof action[attr] !== 'undefined') return action[attr];
    return action['attr_' + attr];
  };

  this.setComputedVariable = function (computedVariable) {
    this.computedVariable = computedVariable;
    console.log('computedVariable', computedVariable);
  };

  this.getActionIdByStep = function (step) {
    if (step < 0) step = this.getStepByOffset(step);

    var action = this.recordedData[step - 1];
    if (typeof action === 'undefined') return action;

    return action.actionId;
  };

  this.getActionTypeByStep = function (step) {
    if (step < 0) step = this.getStepByOffset(step);

    var action = this.recordedData[step - 1];
    if (typeof action === 'undefined') return action;

    return action.action;
  };

  this.getStepByOffset = function (offset) {
    return this.recordedData.length + offset;
  };

  this.removeLastAction = function (allowInit, specificAction, lastOnly) {
    if (typeof allowInit === 'undefined')
      // weather to allow the deletion of init type actions...
      allowInit = false;

    if (typeof specificAction === 'undefined') specificAction = '';

    if (typeof lastOnly === 'undefined')
      // weather to allow the deletion of init type actions...
      lastOnly = false;

    if (allowInit && specificAction == '') {
      this.recordedData.pop();
    } else {
      for (var i = this.recordedData.length - 1; i > -1; i--) {
        var action = this.recordedData[i];

        if (lastOnly && i < this.recordedData.length - 1) return false;

        // skip if specified action is not met...
        if (specificAction != '' && action.action != specificAction) continue;
        if ((!allowInit && action.actionType == 'init') || action.action == 'pageinit') {
          // || action.action == "resize"
          // Give user error
          alert('You can not remove page initialization related action.');
          return false;
        }
        window.fconsole.log('rec size: ' + this.recordedData.length);
        this.recordedData.pop();
        window.fconsole.log('rec size2: ' + this.recordedData.length);
        break;
      }
    }
    // update rec counter
    this.decrementActionCount();
    this.recordWbData();
    return true;
  };

  this.removeActionByActionId = function (actionId, allowInit) {
    if (typeof actionId === 'undefined') {
      return false;
    }
    if (typeof allowInit === 'undefined') {
      // weather to allow the deletion of init type actions...
      allowInit = false;
    }
    var index = this.recordedData.findIndex((action) => {
      return action.actionId === actionId;
    });
    if (index != -1) {
      var action = this.recordedData[index];
      if (typeof actionId === 'undefined') {
        return false;
      }
      if ((!allowInit && action.actionType == 'init') || action.action == 'pageinit') {
        // || action.action == "resize"
        // Give user error
        alert('You can not remove page initialization related action.');
        return false;
      }
      this.recordedData.split(index, 1);
      // update rec counter
      this.decrementActionCount();
      this.recordWbData();
      return true;
    } else {
      return false;
    }
  };

  this.getLastActionByType = function (specificAction, offset) {
    if (typeof offset === 'undefined')
      // weather to allow the deletion of init type actions...
      offset = 0;

    if (typeof specificAction === 'undefined') specificAction = 'pageinit';

    var offsetCounter = 0;
    for (var i = this.recordedData.length - 1; i > -1; i--) {
      var action = this.recordedData[i];

      // skip if specified action is not met...
      if (specificAction != '' && action.action != specificAction) continue;

      if (offsetCounter == offset)
        // allows us to pull second to last action of the type with offset 1.  You can increment to go back farther with the same logic
        return action;

      offsetCounter++;
    }
    return {};
  };

  this.generateContextSwitchAction = function (recData, currentPath) {
    console.log('generateContextSwitchAction', recData, currentPath);

    // this needs to be removed for FE contextswitch actions down to the next comment

    /*
    var targetPathSelectors = [];
    var psp = recData.path.split('_');
    var path = '';
    for (var i = 0; i < psp.length; i++) {
      if (path != '') path += '_';
      path += psp[i];
      var pathSelector = '';
      if (typeof this.recData['pathselectors_' + path] !== 'undefined') pathSelector = this.recData['pathselectors_' + path];
      targetPathSelectors.push({ path: path, pathSelector: pathSelector });
    }
    var lastAction = this.getLastRecordedDataSegment();
    // generate action data
    var contextSwitchData = {
      action: 'contextswitch',
      targetPath: recData.path,
      path: currentPath,
      targetPathSelectors: targetPathSelectors,
      timestamp: window.WU.getTime(),
      epoch: window.WU.getTime(),
      actionId: window.WU.generateActionId(),
      url: lastAction.url,
      targetURL: recData.url,
      suppress_ml: false,
    };

    if (recData.hasOwnProperty('windowHeight')) {
      contextSwitchData.windowHeight = recData.windowHeight;
    }

    if (recData.hasOwnProperty('windowWidth')) {
      contextSwitchData.windowWidth = recData.windowWidth;
    }

    if (typeof recData.functionizeid !== 'undefined') {
      contextSwitchData.functionizeid = recData.functionizeid;
    }

    // everything above this comment is removed for FE contextswitch

    */
    // actionId below needs to swap with the commented line recData.actionId
    if (recData.path !== '' && typeof recData.iframeUID !== 'undefined') {
      self.port.emit('message', {
        obj: 'WS',
        call: 'contextSwitchProcessIframeMlData',
        meta: {
          iframeId: recData.iframeUID,
        },
        arguments: {
          functionizeid: recData.functionizeid,
          // actionId: contextSwitchData.actionId,
          actionId: recData.actionId,
        },
      });
    }

    // the two lines below need to be removed for FE contextswitch
    // this.recordedData.push(contextSwitchData);
    // this.recordWbData();
  };

  /** *** Twilio Phone Functions *****/

  this.generateFunctionizeappInputPhoneAction = function (data) {
    window.fconsole.log('Generating functionzieapp Input action with phone:' + data.phone);
    if (document.querySelector('input#phone').value !== data.phone) {
      // generate input action he he he
      var recData = {
        action: 'input',
        element: 'input',
        timestamp: window.WU.getTime(),
        epoch: window.WU.getTime(),
        xpath: '//input[@id="phone"]',
        uniqueSelectors:
          '//INPUT[@type="text"]|functionise|//INPUT[@class="form-control no-mouseflow"]|functionise|//INPUT[@id="phone"]|functionise|//INPUT[@name="email"]|functionise|//INPUT[@aria-required="true"]',
        uniqueSelectors2:
          '//div[@class="container padd-top20"]/div[@class="row"]/div[@class="col-sm-6 col-md-3 center-block nofloat nopadding loginFormDiv"]/div[@class="loginForm"]/div[@class="account-wall"]/FORM[@enctype="application/x-www-form-urlencoded"]/div[@class="loginFormTopArea"]/INPUT[@placeholder="123-456-7890"]',
        secondarySelectors: '',
        xpath2: '//div[@class="loginFormTopArea"]/input[@class="form-control no-mouseflow"]',
        xpath3: '',
        xpath4: '//div[@class="account-wall"]/form[@class="mainForm simple-form"]/div[@class="loginFormTopArea"]/input[@class="form-control no-mouseflow"]',
        xpath5: '/html/body/div/div/div/div[2]/div/form/div/input',
        cssSelector: 'input#email',
        cssSelector2: 'div.loginFormTopArea > input.form-control no-mouseflow',
        index: 0,
        type: 'email',
        text: '',
        value: `{{fze.action('${data.actionId}').value}}`,
        actualstring: data.phone,
        generatedValue: data.phone,
        attr_type: 'text',
        attr_value: '',
        attr_autofocus: '',
        attr_required: '',
        attr_placeholder: 'abc@example.com',
        attr_class: 'form-control no-mouseflow',
        attr_id: 'email',
        attr_name: 'phone',
        'attr_aria-required': 'true',
        x: '571',
        y: '202.8000030517578',
        attr_parent_element: 'DIV',
        attr_parent_index: '7',
        attr_parent_value: '',
        attr_parent_text: '',
        attr_parentclass: 'loginFormTopArea',
        attr_parent_x: '551',
        attr_parent_y: '182.8000030517578',
        scrollTop: 0,
        scrollLeft: 0,
      };

      recData.elementStatistics = window.WS.collectMlData(document.querySelector(recData.cssSelector));

      this.getRecordingData(recData);
    }
  };

  this.setFunctionizeappPhone = function (value) {
    var emailInput = document.querySelector('input#email');

    if (value.phone !== '') {
      window.WS.generateFunctionizeappInputPhoneAction(value);
      emailInput.value = value.phone;
    } else {
      emailInput.value = `{{fze.randomPhone('XXX-XXX-XXXX')}}`;
      // Dispatch a 'keyup' event using native JavaScript
      emailInput.dispatchEvent(new Event('keyup'));
    }
  };

  /* Functionize Email Integration Functions */

  this.generateFunctionizeappInputAction = function (data) {
    if (document.querySelector('input#email').value != data.email) {
      // generate input action he he he
      var recData = {
        action: 'input',
        element: 'input',
        timestamp: window.WU.getTime(),
        epoch: window.WU.getTime(),
        xpath: '//input[@id="email"]',
        uniqueSelectors:
          '//INPUT[@type="email"]|functionise|//INPUT[@class="form-control no-mouseflow"]|functionise|//INPUT[@id="email"]|functionise|//INPUT[@name="email"]|functionise|//INPUT[@aria-required="true"]',
        uniqueSelectors2:
          '//div[@class="container padd-top20"]/div[@class="row"]/div[@class="col-sm-6 col-md-3 center-block nofloat nopadding loginFormDiv"]/div[@class="loginForm"]/div[@class="account-wall"]/FORM[@enctype="application/x-www-form-urlencoded"]/div[@class="loginFormTopArea"]/INPUT[@placeholder="abc@example.com"]',
        secondarySelectors: '',
        xpath2: '//div[@class="loginFormTopArea"]/input[@class="form-control no-mouseflow"]',
        xpath3: '',
        xpath4: '//div[@class="account-wall"]/form[@class="mainForm simple-form"]/div[@class="loginFormTopArea"]/input[@class="form-control no-mouseflow"]',
        xpath5: '/html/body/div/div/div/div[2]/div/form/div/input',
        cssSelector: 'input#email',
        cssSelector2: 'div.loginFormTopArea > input.form-control no-mouseflow',
        index: 0,
        type: 'email',
        text: '',
        value: `{{fze.action('${data.actionId}').value}}`,
        actualstring: data.email,
        generatedValue: data.email,
        attr_type: 'email',
        attr_value: '',
        attr_autofocus: '',
        attr_required: '',
        attr_placeholder: 'abc@example.com',
        attr_class: 'form-control no-mouseflow',
        attr_id: 'email',
        attr_name: 'email',
        'attr_aria-required': 'true',
        x: '571',
        y: '202.8000030517578',
        attr_parent_element: 'DIV',
        attr_parent_index: '7',
        attr_parent_value: '',
        attr_parent_text: '',
        attr_parentclass: 'loginFormTopArea',
        attr_parent_x: '551',
        attr_parent_y: '182.8000030517578',
        scrollTop: 0,
        scrollLeft: 0,
      };

      recData.elementStatistics = window.WS.collectMlData(document.querySelector(recData.cssSelector));

      this.getRecordingData(recData);
    }
  };

  this.setFunctionizeappEmail = function (value) {
    console.log('setFunctionizeappEmail', value);
    const emailInput = document.querySelector('input#email');

    if (value.email !== '') {
      window.WS.generateFunctionizeappInputAction(value);
      emailInput.value = value.email;
    } else {
      emailInput.value = `{{fze.randomEmail('functionizeapp.com')}}`;
      emailInput.dispatchEvent(new Event('keyup'));
    }
  };

  // gets the values in the control window and sends them back or uses them as is
  this.getFunctionizeVariableProperties = function (data) {
    window.fconsole.log('getting functionize vars properties: ' + data.action.actionId + ' ' + data.attr);
    var command = null;
    if (!window.TCM.isController) {
      command = { obj: 'WS', call: 'getFunctionizeVariableProperties', arguments: data };
      window.TCM.sendCommand(command);
    } else if (window.TCM.isController) {
      // send it back///

      var value = window.WS.getActionAttribute(data.action, data.attr);

      // if no value is set for give attribute we alert the user...
      if (value == null || typeof value === 'undefined') {
        var actionType = window.WS.getActionTypeByStep(data.step);
        alert(
          data.attr.charAt(0).toUpperCase() + data.attr.slice(1) + ' for action ' + data.step + ' is undefined. Found action for step ' + data.step + ' was ' + actionType + '.'
        );
        return;
      }

      if (data.operator == 'parseInt') {
        value = parseInt(value.replace(/[^\d]/g, ''));
      } else if (data.operator == 'parseNumeric') {
        value = value.replace(/[^\d]/g, '');
      } else if (data.operator.indexOf('function') == 0) {
        var functionizeVariableValue = value;
        let code = 'window.funcCall = ' + data.operator;
        setTimeout(code, 1);
        if (typeof window.funcCall === 'function') value = window.funcCall();
      } else if (data.operator == 'toLowerCase') {
        value = value.toLowerCase();
      } else if (data.operator == 'substring') {
        if (value.substring(parseInt(data.parameter), parseInt(data.parameter1))) {
          value = value.substring(parseInt(data.parameter), parseInt(data.parameter1));
        }
      }

      window.fconsole.log('load Func var found as :' + data.action.actionId + ' ' + value);
      if (typeof window.WS.functionizeTmpVariable !== 'undefined' && typeof window.WS.functionizeTmpVariable.attr !== 'undefined') {
        window.WS.setFunctionizeVariable(data.action.actionId, value);
        return;
      }
      window.fconsole.log('sending functionize variable back');
      var args = new Array();
      args.push(data.action.actionId);
      args.push(value);
      command = { obj: 'WS', call: 'setFunctionizeVariable', arguments: args };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  // callback function
  this.setFunctionizeVariable = function (actionId, value) {
    window.fconsole.log('setting functionize vars: ' + actionId + ' ' + value);
    var parameters = '';
    if (typeof window.WS.functionizeTmpVariable === 'undefined' || typeof window.WS.functionizeTmpVariable.attr === 'undefined') return;

    if (typeof actionId === 'undefined') {
      alert('No such action can be found.');
      return;
    }

    // window.WS.functionizeTmpVariable.value = value;

    if (typeof value === 'undefined') {
      alert('No such attribute found: ' + window.WS.functionizeTmpVariable.attr);
      return;
    }

    if (value === '') {
      alert('Empty value found in action');
      return;
    }

    if (window.WS.functionizeTmpVariable.operator === 'substring') {
      if (window.WS.functionizeTmpVariable.hasOwnProperty('parameter') && window.WS.functionizeTmpVariable.parameter !== '') {
        parameters += `::${window.WS.functionizeTmpVariable.parameter}`;
      }
      if (window.WS.functionizeTmpVariable.hasOwnProperty('parameter1') && window.WS.functionizeTmpVariable.parameter1 !== '') {
        parameters += `,${window.WS.functionizeTmpVariable.parameter1}`;
      }
    }

    if (window.WS.functionizeTmpVariable.field == 'text') {
      document.querySelector(window.WS.functionizeTmpVariable.target).textContent = value;
      window.WS.functionizeTmpVariable.value.actualstring = value;
      window.WS.functionizeTmpVariable.value.text =
        '[functionizeVariable::' + actionId + '::' + window.WS.functionizeTmpVariable.attr + '::' + window.WS.functionizeTmpVariable.operator + parameters + ']';
    } else {
      // const element = document.querySelector(window.WS.functionizeTmpVariable.target);
      // if (element) {
      //   if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
      //     // For input and textarea elements
      //     element.value = value;
      //   } else if (element.tagName === 'SELECT') {
      //     // For select elements, set the value of the selected option
      //     element.value = value;
      //   }
      // }
      var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
      nativeInputValueSetter.call(window.WS.functionizeTmpVariable.target, value);
      var event = new Event('keydown', { bubbles: true });
      event.keyCode = 32; // space
      window.WS.functionizeTmpVariable.target.dispatchEvent(event);
      event = new Event('keypress', { bubbles: true });
      event.keyCode = 32; // space
      window.WS.functionizeTmpVariable.target.dispatchEvent(event);
      event = new Event('keyup', { bubbles: true });
      event.keyCode = 32; // space
      window.WS.functionizeTmpVariable.target.dispatchEvent(event);
      event = new Event('input', { bubbles: true });
      window.WS.functionizeTmpVariable.target.dispatchEvent(event);
      event = new Event('change', { bubbles: true });
      window.WS.functionizeTmpVariable.target.dispatchEvent(event);
      event = new Event('setvalue', { bubbles: true });
      window.WS.functionizeTmpVariable.target.dispatchEvent(event);
      window.WS.functionizeTmpVariable.value.generatedValue = value;
      window.WS.functionizeTmpVariable.value.value =
        '[functionizeVariable::' + actionId + '::' + window.WS.functionizeTmpVariable.attr + '::' + window.WS.functionizeTmpVariable.operator + parameters + ']';
    }

    window.WS.inputToSend = window.WS.functionizeTmpVariable.value;
    window.WS.getRecordingData();
    window.WS.functionizeTmpVariable = {};
  };

  this.loadFunctionizeVariable = function (target, value, eValue, field) {
    if (typeof field === 'undefined') field = 'value';
    // store temporarily for callback from parent...
    // if (typeof this.functionizeTmpVariable != 'function')
    window.fconsole.log('loading functionize vars');
    this.functionizeTmpVariable = {};
    this.functionizeTmpVariable.target = target;
    this.functionizeTmpVariable.value = value;
    this.functionizeTmpVariable.field = field;

    var eValue2 = eValue.substring(0, eValue.length - 1);
    var varVals = eValue2.split('::');
    var operator = '';
    var parameter = false;
    var parameter1 = false;
    if (varVals.length > 3 && varVals[3] != '') {
      operator = varVals[3];
      if (operator === 'substring') {
        if (varVals[4] && varVals[4] !== '') {
          var parameters = varVals[4].split(',');
          parameter = this.functionizeTmpVariable.parameter = parseInt(parameters[0]);

          if (parameters[1] && parameters[1] !== '') {
            parameter1 = this.functionizeTmpVariable.parameter1 = parseInt(parameters[1]);
          }
        }
      }
    }

    if (varVals.length < 3 || varVals[2] == '') {
      varVals[2] = 'text';
    }
    var attr = varVals[2];
    this.functionizeTmpVariable.attr = attr;
    this.functionizeTmpVariable.operator = operator;
    var step = varVals[1];

    var args = {
      step: step,
      attr: attr,
      operator: operator,
    };

    if (this.functionizeTmpVariable.hasOwnProperty('parameter')) {
      args.parameter = parameter;
    }

    if (this.functionizeTmpVariable.hasOwnProperty('parameter1')) {
      args.parameter1 = parameter1;
    }

    self.port.emit('message', {
      obj: 'f-vue',
      call: 'getFunctionizeVariableProperties',
      arguments: args,
      forMaster: true,
    });
  };

  this.hasAction = function (a, timestamp, distance) {
    if (typeof distance === 'undefined') distance = 3;
    for (var i = this.recordedData.length - 1; i > -1; i--) {
      if (this.recordedData.length - 1 - distance > i) return false;
      var action = this.recordedData[i];
      if (action.action == a && action.timestamp == timestamp) return true;
    }
    return false;
  };

  this.getLastRecordedDataSegment = function () {
    return this.getRecordedDataByIndex(this.recordedData.length - 1);
  };

  this.getRecordingDataByActionId = function (actionId) {
    for (var i = this.recordedData.length - 1; i > -1; i--) {
      if (this.recordedData[i].actionId == actionId) return this.recordedData[i];
    }
    return false;
  };

  this.getActionIndexByActionId = function (actionId) {
    for (var i = this.recordedData.length - 1; i > -1; i--) {
      if (this.recordedData[i].actionId == actionId) return i;
    }
    return false;
  };

  this.getRecordedDataByIndex = function (index) {
    if (this.recordedData[index] && Object.keys(this.recordedData[index]).length > 0) {
      return this.recordedData[index];
    }
    return {};
  };

  this.updateActionLogByActionId = function (data) {
    self.port.emit('message', {
      obj: 'TCM',
      call: 'updateActionLogByActionId',
      arguments: { actionId: data.actionId, action: data.action },
      forMaster: true,
    });
  };

  this.appendToRecordedDataByIndex = function (data, index) {
    window.fconsole.log('Extending action at index ' + index + ' with data: ' + JSON.stringify(data));
    var actionData = window.WS.recordedData[index];
    var newActionData = { ...actionData, ...data };
    if (data.action) {
      newActionData.action = data.action;
    }

    window.fconsole.log('New action at index: ' + JSON.stringify(newActionData));
    window.WS.recordedData[index] = newActionData;

    if (window.WS.isIframe || window.WS.isPopup) {
      var command = { obj: 'WS', call: 'updateActionLogByActionId', arguments: { actionId: newActionData.actionId, action: data } };
      window.TCM.sendCommandToParent(command);
      return;
    }

    self.port.emit('message', {
      obj: 'TCM',
      call: 'updateActionLogByActionId',
      arguments: { actionId: newActionData.actionId, action: data },
      forMaster: true,
    });
  };

  this.processIframeMlData = function (data) {
    console.log('processIframeMlData', data);
    // for (let i = 0; i < window.WS.traverseIframeComp[0].length; i++) {
    // if (typeof window.WS.traverseIframeComp[0][i][12] !== 'undefined' && window.WS.traverseIframeComp[0][i][12].hasOwnProperty('functi0nize-selected')) {
    // delete window.WS.traverseIframeComp[0][i][12]['functi0nize-selected'];
    // }
    // }
    let comp = window.WS.traverseIframeComp.concat(data.data.data);
    if (window.WS.isIframe) {
      console.log('processIframeMlData is iframe', data);
      // need next node id data in here
      this.sendProcessIframeMlData({
        data: comp,
        functionizeid: data.data.functionizeid,
        actionId: data.data.actionId,
        traverseIframenextNodeId: window.WS.traverseIframenextNodeId,
      });
    } else {
      let result = window.WS.siteStatistics.translateIFrameCompAndSelectIframe(JSON.parse(JSON.stringify(comp)), data.data.functionizeid);

      if (typeof window.WS.processIframeMlDataCache[data.data.actionId] !== 'undefined') {
        clearTimeout(window.WS.processIframeMlDataCache[data.data.actionId]);
      }

      window.WS.processIframeMlDataCache[data.data.actionId] = setTimeout(() => {
        self.port.emit('message', {
          obj: 'TCM',
          call: 'addMLDataToContextSwitch',
          arguments: { data: { result: result, functionizeid: data.data.functionizeid, actionId: data.data.actionId } },
          forMaster: true,
        });
      }, 1500);
    }
  };

  this.deleteActionByActionId = function (actionId) {
    let index = window.WS.recordedData.findIndex((action) => {
      return action.actionId === actionId;
    });
    if (index > -1) {
      window.WS.recordedData.splice(index, 1);
    }
  };

  this.appendToRecordedData = function (data, lastAction) {
    var actionId = '';
    if (typeof lastAction === 'object' && lastAction.hasOwnProperty('actionId')) {
      actionId = lastAction.actionId;
    } else if (typeof lastAction === 'string' && lastAction && lastAction.indexOf('|') === -1) {
      actionId = lastAction;
    }
    if (actionId) {
      if (window.WS.isIframe || window.WS.isPopup) {
        var command = { obj: 'WS', call: 'updateActionLogByActionId', arguments: { actionId: actionId, action: data } };
        window.TCM.sendCommandToParent(command);
        return;
      }

      self.port.emit('message', {
        obj: 'TCM',
        call: 'updateActionLogByActionId',
        arguments: { actionId: actionId, action: data },
        forMaster: true,
      });
    } else if (lastAction == null || typeof lastAction === 'undefined') {
      window.WS.appendToRecordedDataByIndex(data, window.WS.recordedData.length - 1);
    } else {
      // in case there are more potential match actions passed in
      var lastActions = lastAction.split('|');
      let found = false;

      // we will be looking for the last matching action
      // we go from the back

      for (var i = window.WS.recordedData.length - 1; i > -1; i--) {
        var action = window.WS.recordedData[i];
        if (data.hasOwnProperty('openerUID') && typeof data.openerUID !== 'undefined') {
          if (lastActions.indexOf(action.action) > -1 && action.path.indexOf(data.openerUID) > -1 && !action.hasOwnProperty('newpopup')) {
            console.log('newpopup maybe', data);
            // we append here
            found = true;
            window.WS.appendToRecordedDataByIndex(data, i);
            break;
          }
        } else {
          if (lastActions.indexOf(action.action) > -1) {
            if (this.removableNewPopup.includes(action.action) && !action.target) {
              console.log('newpopup delete');
              delete data.newpopup;
            }
            // we append here
            found = true;
            window.WS.appendToRecordedDataByIndex(data, i);
            break;
          }
        }
      }

      // this is a fallback for finding a matching action in the extension context
      // if (!found) {
      //  window.WS.updateLastActionByType(data, lastActions);
      // }
    }
    // window.WS.recordWbData();
  };

  this.removeFromRecordedData = function (data, lastAction) {
    window.WS.removeFromRecordedDataByIndex(data, window.WS.recordedData.length - 1);
  };

  this.removeFromRecordedDataByIndex = function (key, index) {
    var actionData = this.recordedData[index];
    window.fconsole.log('Removing ' + key + ' from action at index ' + index);
    delete actionData[key];
    this.recordedData[index] = actionData;
  };

  this.hasChangedInputValue = function (rdata) {
    if (rdata.action != 'input') return false;
    var action = 'input';
    // we take the last recorded action
    if (this.recordedData.length > 1) {
      // test for the last 8
      for (var lastActionCounter = 0; lastActionCounter < 8; lastActionCounter++) {
        var rdpIndex = this.recordedData.length - 1 - lastActionCounter;
        if (rdpIndex < 0) continue;
        var lastAction = this.getRecordedDataByIndex(rdpIndex);
        if (lastAction.action == 'input') {
          if (lastAction.index == rdata.index && lastAction.element == rdata.element) {
            if (lastAction.value != rdata.value) return true;
          }
        } else {
          // we have another type of action to look at
          if (lastAction.action != 'hover' || lastAction.action != 'scroll') {
            // we need to skip unless
            if (lastAction.action == 'click' && action == 'input') {
              // we allow to continue here as clicks do not interfere with this stuff
            } else {
              return false;
            }
          }
        }
      }
    }
    return false;
  };

  this.mergePreviusAction = function (rdata) {
    var action = '';
    if (rdata.action == 'input') action = 'input';

    if (rdata.action == 'select') action = 'select';

    if (rdata.action == 'resize') action = 'resize';

    if (rdata.action == 'scroll') action = 'scroll';

    if (rdata.action == 'click') action = 'click';

    if (action == '') return false;

    if (rdata.action == 'pageinit') return false;

    // Turn off merge for ace editor on intuit

    var foundEnter = false;

    window.fconsole.log('Running merge lookup');

    // we take the last recorded action
    if (this.recordedData.length >= 1) {
      // test for the last 6
      // ONLY ONE ACTION NOW….
      for (var lastActionCounter = 0; lastActionCounter > -1; lastActionCounter--) {
        var rdpIndex = this.recordedData.length - 1 + lastActionCounter;
        if (rdpIndex < 0) return false;
        window.fconsole.log('Considering last action at index:' + rdpIndex);
        var lastAction = this.getRecordedDataByIndex(rdpIndex);
        window.fconsole.log('Considering action for merge:  ' + lastAction.action + ' ' + rdpIndex + ' ' + lastActionCounter);

        // Stop merging actions for different lines in ace text editor for Intuit - by Ankur Verma
        if (rdata.attr_class == 'ace_text-input' && lastAction.y != rdata.y) {
          return false;
        }

        // do not merge on init action types...
        if (lastAction.actionType == 'init') continue;

        // paths do not match... skipping
        if (typeof lastAction.path !== 'undefined' && typeof rdata.path !== 'undefined' && lastAction.path != rdata.path) continue;

        console.log(lastAction, rdata);
        var field = null;
        if (lastAction.action == action && (lastAction.action == 'input' || lastAction.action == 'select')) {
          if (typeof rdata.optionIndices !== 'undefined') {
            lastAction.optionIndices = rdata.optionIndices;
            lastAction.optionText = rdata?.optionText || '';
            lastAction.optionValue = rdata?.optionValue || '';
            lastAction.text = rdata.text;
          }
          if (lastAction.shadowDom === true || rdata.shadowDom === true) {
            if (
              lastAction.index == rdata.index &&
              lastAction.element == rdata.element &&
              lastAction.cssSelector2 === rdata.cssSelector2 &&
              (lastAction.cssSelector === rdata.cssSelector ||
                (lastAction.hasOwnProperty('xpath5') && rdata.hasOwnProperty('xpath5') && lastAction.xpath5 === rdata.xpath5) ||
                (lastAction.hasOwnProperty('xpath4') && rdata.hasOwnProperty('xpath4') && lastAction.xpath4 === rdata.xpath4) ||
                (lastAction.hasOwnProperty('xpath3') && rdata.hasOwnProperty('xpath3') && lastAction.xpath3 === rdata.xpath3))
            ) {
              if (rdata.shadowDom) {
                lastAction.shadowDom = this.recordedData[rdpIndex].shadowDom = rdata.shadowDom;
                lastAction.xpath = this.recordedData[rdpIndex].xpath = rdata.xpath;
                lastAction.elementStatistics = this.recordedData[rdpIndex].elementStatistics = rdata.elementStatistics;
              }

              field = 'value';

              // if not an input element we swap for text value -- contenteditable
              if (rdata.element != 'input' && rdata.element != 'textarea' && rdata.value == '' && rdata.text != '') {
                field = 'text';
              }

              if (lastAction[field] != rdata[field] && foundEnter) return false; // if we are past enter action values have to be an exact match to merge
              if (
                lastAction[field] == '[functionizeappEmail]' &&
                typeof lastAction.generatedValue !== 'undefined' &&
                typeof rdata.value !== 'undefined' &&
                rdata.value.indexOf(lastAction.generatedValue) > -1
              )
                // this is dynamic email... we return true on this to keep everything as is
                return true;

              lastAction[field] = rdata[field];
              if (typeof rdata.actualstring !== 'undefined') {
                lastAction.actualstring = rdata.actualstring;
              }

              // deal with generatedValue field as well... for random emails.
              if (typeof rdata.generatedValue !== 'undefined') lastAction.generatedValue = rdata.generatedValue;
              if (typeof rdata.elementStatistics !== 'undefined') {
                lastAction.elementStatistics = rdata.elementStatistics;
              }
              window.fconsole.log('Last action ' + field + ' is swapped for ' + rdata[field]);
              window.fconsole.log('Merged action: ' + JSON.stringify(lastAction));
              this.recordedData[rdpIndex] = lastAction;
              return true;
            }
          } else if (!lastAction.shadowDom && !rdata.shadowDom && lastAction.index == rdata.index && lastAction.element == rdata.element) {
            field = 'value';

            // if not an input element we swap for text value -- contenteditable
            if (rdata.element != 'input' && rdata.element != 'textarea' && rdata.value == '' && rdata.text != '') {
              field = 'text';
            }
            if (lastAction[field] != rdata[field] && foundEnter) return false; // if we are past enter action values have to be an exact match to merge
            if (
              lastAction[field] == '[functionizeappEmail]' &&
              typeof lastAction.generatedValue !== 'undefined' &&
              typeof rdata.value !== 'undefined' &&
              rdata.value.indexOf(lastAction.generatedValue) > -1
            )
              // this is dynamic email... we return true on this to keep everything as is
              return true;

            lastAction[field] = rdata[field];
            if (typeof rdata.actualstring !== 'undefined') {
              lastAction.actualstring = rdata.actualstring;
            }
            // deal with generatedValue field as well... for random emails.
            if (typeof rdata.generatedValue !== 'undefined') lastAction.generatedValue = rdata.generatedValue;
            if (typeof rdata.elementStatistics !== 'undefined') {
              lastAction.elementStatistics = rdata.elementStatistics;
            }
            window.fconsole.log('Last action ', field, ' is swapped for ', rdata[field]);
            window.fconsole.log('Merged action: ' + JSON.stringify(lastAction));
            this.recordedData[rdpIndex] = lastAction;
            return true;
          }
        } else if (lastAction.action == 'resize' && lastAction.action == action) {
          // resize
          if (typeof rdata.windowWidth !== 'undefined' && typeof rdata.windowHeight !== 'undefined') {
            lastAction.windowWidth = rdata.windowWidth;
            lastAction.windowHeight = rdata.windowHeight;
            this.recordedData[rdpIndex] = lastAction;
            return true;
          }
        } else if (lastAction.action == 'scroll' && lastAction.action == action && !rdata.scrollToElement) {
          // don't overwrite element scrolls with window scrolls
          if (!rdata.hasOwnProperty('element') && lastAction.hasOwnProperty('element')) return false;
          // don't overwrite element scrolls with different elements
          if (rdata.hasOwnProperty('element') && lastAction.hasOwnProperty('element') && lastAction.hasOwnProperty('element') !== rdata.hasOwnProperty('element')) return false;
          // scroll
          if (typeof rdata.scrollTop !== 'undefined' && typeof rdata.scrollLeft !== 'undefined') {
            lastAction.scrollTop = rdata.scrollTop;
            lastAction.scrollLeft = rdata.scrollLeft;
            this.recordedData[rdpIndex] = lastAction;
            return true;
          }
        } else if (lastAction.action == 'click' && lastAction.action == action) {
          // click
          window.fconsole.log('Considering double click');
          if (rdata.xpath == lastAction.xpath && (!rdata.path || rdata.path == lastAction.path) && rdata.xpath3 == lastAction.xpath3) {
            window.fconsole.log('Double click time1: ' + rdata.timestamp);
            window.fconsole.log('Double click time2: ' + lastAction.timestamp);
            window.fconsole.log('Double click timetotal: ' + (rdata.timestamp - lastAction.timestamp));
            if (rdata.timestamp - lastAction.timestamp < 1000 && rdata.timestamp - lastAction.timestamp > 0) {
              // its a doubleclick
              window.fconsole.log('Merge found for action: ' + this.recordedData[rdpIndex].action);
              this.recordedData[rdpIndex].action = 'doubleclick';
              window.fconsole.log('Merge updated action to: ' + this.recordedData[rdpIndex].action);
              return true;
            }
          }
        } else {
          // we have another type of action to look at
          if (lastAction.action != 'hover' || lastAction.action != 'scroll') {
            // we need to skip unless
            if (action == 'input' || action == 'select' || action == 'enter') {
              // we allow to continue here as clicks do not interfere with this stuff
              foundEnter = true;
            } else {
              // we now stop this on click actions too...
              return false;
            }
          }
        }
      }
    }
    return false;
  };

  this.resetMlDataFilter = function () {
    window.WS.siteStatistics.treewalkerFilter = {
      acceptNode: function (node) {
        if (node.nodeType === 1) {
          // skip if script or style
          if (node.nodeName.toUpperCase() === 'SCRIPT' || node.nodeName.toUpperCase() === 'STYLE') {
            // skip current element and its children
            return NodeFilter.FILTER_REJECT;
          }
          // skip if all internal functionize element (f-functionise)
          const attrs = node.attributes;
          for (const attr of attrs) {
            if (attr.name === 'class') {
              if (attr.value === 'f-functionise') {
                return NodeFilter.FILTER_REJECT;
              }
            }
          }
        }
        return NodeFilter.FILTER_ACCEPT;
      },
    };
  };

  this.setCollectStatistics = function (state) {
    if (typeof state !== 'undefined' && typeof state === 'boolean') {
      // set data from vuex
      self.port.emit('message', {
        obj: 'TCM',
        call: 'setCollectStatistics',
        arguments: state,
        forMaster: true,
      });
      window.WS.collectStatistics = state;
      window.functionizeFilterMlData = state;
      window.WS.siteStatistics.filterActivated = state;

      // hack to reset the filter to default if turned off
      if (!state) {
        this.resetMlDataFilter();
      }

      if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'collectStatistics', state);
    } else {
      // get data from vuex
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setCollectStatistics',
        arguments: undefined,
        forMaster: true,
      });
    }
  };

  this.setPreferDomsnapshot = function (state) {
    // deprecating dom snapshot
    /*
    if (typeof state !== 'undefined' && typeof state === 'boolean') {
      // set data from vuex
      self.port.emit('message', {
        obj: 'TCM',
        call: 'setPreferDomsnapshot',
        arguments: state,
        forMaster: true,
      });
      window.WS.preferDomsnapshot = state;
      if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'preferDomsnapshot', state);
    } else {
      // get data from vuex
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setPreferDomsnapshot',
        arguments: undefined,
        forMaster: true,
      });
    }
     */
  };

  this.setCollectFormData = function (state) {
    console.log('setCollectFormData', state);
    if (typeof state !== 'undefined' && typeof state === 'boolean') {
      // set data from vuex
      self.port.emit('message', {
        obj: 'TCM',
        call: 'setCollectFormData',
        arguments: state,
        forMaster: true,
      });
      window.WS.collectFormData = state;
      if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'collectFormData', state);
    } else {
      // get data from vuex
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setCollectFormData',
        arguments: undefined,
        forMaster: true,
      });
    }
  };

  this.setEnableTabKeypress = function (state) {
    console.log('setEnableTabKeypress', state);
    if (typeof state !== 'undefined' && typeof state === 'boolean') {
      // set data from vuex
      self.port.emit('message', {
        obj: 'TCM',
        call: 'setEnableTabKeypress',
        arguments: state,
        forMaster: true,
      });
      window.WS.enableTabKeypress = state;
      if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'enableTabKeypress', state);
    } else {
      // get data from vuex
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setEnableTabKeypress',
        arguments: undefined,
        forMaster: true,
      });
    }
  };

  this.setLastActionIsInstructionOrPO = function (state) {
    if (typeof state !== 'undefined' && typeof state === 'boolean') {
      // set data from vuex
      self.port.emit('message', {
        obj: 'TCM',
        call: 'setLastActionIsInstructionOrPO',
        arguments: state,
        forMaster: true,
      });
      window.WS.lastActionIsInstructionOrPO = state;
      if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'lastActionIsInstructionOrPO', state);
    }
  };

  this.setForceZoom = function (state) {
    if (typeof state !== 'undefined' && typeof state === 'boolean') {
      // set data from vuex
      self.port.emit('message', {
        obj: 'TCM',
        call: 'setForceZoom',
        arguments: state,
        forMaster: true,
      });
      window.WS.forceZoom = state;

      if (window.WS.forceZoom) {
        document.querySelector('html').style.zoom = '1';
      }

      if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'forceZoom', state);
    } else {
      // get data from vuex
      self.port.emit('message', {
        obj: 'f-vue',
        call: 'setForceZoom',
        arguments: undefined,
        forMaster: true,
      });
    }
  };

  this.deleteActionsByIdsOnRecordedData = function (idsToRemove) {
    if (!window.TCM.isMaster) {
      var command = {
        obj: 'WS',
        call: 'deleteActionsByIdsOnRecordedData',
        arguments: idsToRemove,
        meta: { fromUID: window.WS.popupUID },
      };
      window.fconsole.log('Sending relay to plugin: ' + command.call);
      self.port.emit('relay', command);
      return;
    }
    window.WS.recordedData = window.WS.recordedData.filter((action) => !idsToRemove.includes(action.actionId));
  };

  this.updatePreviousActionData = function (data) {
    console.log('updatePreviousActionData', data);
    window.updatePreviousActionDataValue = null;
    if (data.hasOwnProperty('expression')) {
      setTimeout('window.updatePreviousActionDataValue = ' + `${data.expression};` + 'console.log(window.updatePreviousActionDataValue);', 1);
    } else {
      window.updatePreviousActionDataValue = data.value;
      if (data.modifier) {
        setTimeout(
          'window.updatePreviousActionDataValue = ' + `${window.updatePreviousActionDataValue.toString()}.${data.modifier};` + 'console.log(window.updatePreviousActionDataValue);',
          1
        );
      }
    }

    setTimeout(() => {
      if (window.WS.functionizeValidateCustomJSProperty == 'value') {
        window.WS.functionizeValidateCustomJSElement.value = window.updatePreviousActionDataValue;
      } else {
        window.WS.functionizeValidateCustomJSElement.innerText = window.updatePreviousActionDataValue;
      }

      window.WS.functionizeValidateCustomJSElement.dispatchEvent(new Event('keyup'));
      window.WS.updateVariableLastAction({
        [window.WS.functionizeValidateCustomJSProperty]: window.WS.functionizeValidateCustomJSDisplay,
        generatedValue: window.updatePreviousActionDataValue,
        actualstring: window.updatePreviousActionDataValue,
      });
    }, 500);
  };

  this.generateNewVariable = function (functionizeElement, actionId) {
    console.log('generateNewVariable', functionizeElement, actionId);

    this.suppressChangeListener = true;
    clearTimeout(window.WS.generateNewVariableTimer);

    window.WS.generateNewVariableTimer = setTimeout(() => {
      let variableDisplay = false;
      const element = functionizeElement;

      if (!element) {
        console.error('Element not found:', functionizeElement);
        return;
      }

      const value = element.value ? element.value.trim() : '';
      const text = element.textContent.trim();
      const regex = /\s*?{\s*?{(.+)}\s*?}/;

      if (regex.test(value)) {
        variableDisplay = value.match(regex);
        window.WS.functionizeValidateCustomJSProperty = 'value';
      } else if (regex.test(text)) {
        variableDisplay = text.match(regex);
        window.WS.functionizeValidateCustomJSProperty = 'text';
      }

      let variableValue = false;

      if (variableDisplay) {
        try {
          variableValue = variableDisplay[1];
        } catch (e) {
          variableValue = false;
        }

        if (variableValue) {
          window.WS.functionizeValidateCustomJSTime = Date.now();
          window.WS.functionizeValidateCustomJSElement = functionizeElement;
          window.WS.functionizeValidateCustomJSActionID = actionId;
          window.WS.functionizeValidateCustomJSDisplay = variableDisplay[0];
          window.postMessage(
            {
              call: 'resolvePageVariable',
              args: variableValue,
            },
            location.href
          );
        }
      }
    }, 300);
  };

  this.getResourceVariableData = function (data, elementProperty, element) {
    clearTimeout(window.WS.getPreviousActionDataTimer);
    window.WS.getPreviousActionDataTimer = setTimeout(() => {
      window.WS.functionizeValidateCustomJSProperty = elementProperty;
      window.WS.functionizeValidateCustomJSTime = Date.now();
      window.WS.functionizeValidateCustomJSElement = element;
      window.WS.functionizeValidateCustomJSDisplay = `{{${data}}}`;

      self.port.emit('message', {
        obj: 'TCM',
        call: 'getResourceVariableData',
        arguments: { expression: data },
        forVue: true,
      });
    }, 200);
  };

  this.getPreviousActionData = function (data, elementProperty, element) {
    console.log('getPreviousActionData', data);
    console.trace('getPreviousActionData');
    clearTimeout(window.WS.getPreviousActionDataTimer);
    window.WS.getPreviousActionDataTimer = setTimeout(() => {
      let actionId = data.match(/(?:\('|\(")(.*)(?:'\)|"\))/)[1];
      if (typeof actionId === 'string' && actionId.indexOf("')") > -1) {
        actionId = actionId.split("')")[0];
      }
      let propData = data.split('.');
      let property = null;
      let modifier = null;
      if (typeof propData[2] === 'string' && propData[2].indexOf('attributes[') > -1) {
        // attribute stuff
        property = propData[2].match(/attributes\[\'(.*)\'\]$/)[1];
      } else {
        property = propData[2];
      }

      if (propData.length > 3) {
        modifier = propData[3].replaceAll('}').trim();
      }

      let result = false;

      window.WS.functionizeValidateCustomJSProperty = elementProperty;
      window.WS.functionizeValidateCustomJSTime = Date.now();
      window.WS.functionizeValidateCustomJSElement = element;
      window.WS.functionizeValidateCustomJSDisplay = `{{${data}}}`;

      for (let i = 0; i < window.WS.recordedData.length; i++) {
        if (window.WS.recordedData[i].actionId == actionId) {
          result = window.WS.recordedData[i];
        }
      }

      console.log('getPreviousActionData property', property);

      // hack to return generated data for variables rather than the variable itself
      if (
        (property === 'value' || property === 'text') &&
        (result.hasOwnProperty('actualstring') || result.hasOwnProperty('generatedValue') || result.hasOwnProperty('selectText'))
      ) {
        if (result.hasOwnProperty('actualstring')) {
          property = 'actualstring';
        }
        if (result.hasOwnProperty('generatedValue')) {
          property = 'generatedValue';
        }
        if (result.hasOwnProperty('selectText')) {
          property = 'selectText';
        }
      }

      if (result) {
        let code = `function temp() {
            // window.WS.functionizeValidateCustomJSResult = null;
            try {
              return (() => { return (() => ${data} )() })();
            } catch (error) {
              console.log(error);
              return 'Cannot resolve expression';
            }
          }
          console.log(temp, temp());
          window.WS.functionizeValidateCustomJSResult = temp();`;
        window.WS.functionizeValidateCustomJSResult = null;
        fze.setAction(result);
        setTimeout(code, 1);

        setTimeout(() => {
          if (elementProperty === 'text') {
            element.innerText = window.WS.functionizeValidateCustomJSResult;
          } else {
            element.value = window.WS.functionizeValidateCustomJSResult;
          }
        }, 100);

        // we have to delay to wait for the action to be created before we can update
        setTimeout(() => {
          window.WS.updateVariableLastAction({
            [elementProperty]: window.WS.functionizeValidateCustomJSDisplay,
            generatedValue: window.WS.functionizeValidateCustomJSResult,
            actualstring: window.WS.functionizeValidateCustomJSResult,
          });
        }, 500);

        element.dispatchEvent(new Event('keyup'));
      } else {
        console.log('getPreviousActionData', data, element);
        self.port.emit('message', {
          obj: 'TCM',
          call: 'getPreviousActionData',
          arguments: { actionId: actionId, property: property, modifier: modifier, expression: data },
          forVue: true,
        });
      }
    }, 200);
  };

  this.getRecordingData = function (recData, doMergeWithData, suppressSetPath) {
    console.log('getRecordingData pageinit', recData);
    if (!window.TCM.recording) return;

    let lastActionData = {};
    window.TCM.domWalkElement = '';

    // Remove consecutive pageinit actions
    if (window.TCM.isPaused || window.TCM.isStopping) {
      return;
    }

    let enterToSendUp = false;
    if (window.localStorage.getItem('enterToSendUp')) {
      try {
        enterToSendUp = JSON.parse(window.localStorage.getItem('enterToSendUp'));
      } catch (e) {}
    }
    if (recData && recData.hasOwnProperty('action') && (recData.action === 'pageinit' || recData.action === 'navigate') && enterToSendUp) {
      this.getRecordingData(enterToSendUp, false);
      window.localStorage.removeItem('enterToSendUp');
      this.getRecordingData(recData, doMergeWithData, suppressSetPath);
      return;
    } else {
      window.localStorage.removeItem('enterToSendUp');
    }

    try {
      if (typeof recData !== 'undefined' && typeof recData.action !== 'undefined' && recData.action == 'pageinit' && this.recordedData.length) {
        lastActionData = this.recordedData[this.recordedData.length - 1];
        if ((recData.url == lastActionData.url && lastActionData.action == 'pageinit') || recData.url == 'about:blank') {
          if (!recData.hasOwnProperty('path') || !lastActionData.hasOwnProperty('path')) {
            return;
          }
          if ((recData.hasOwnProperty('path') || lastActionData.hasOwnProperty('path')) && recData.path === lastActionData.path) {
            return;
          }
        }
      }
    } catch (e) {}

    // if We are collecting CV Screen Coordinates Collection
    if (window.TCM.flagCVAreaSelection == true) return false;

    // stop recording where window error is on...
    if (this.hasWindowSizeError && window.TCM.isController) {
      if (typeof recData !== 'undefined' && typeof recData.action !== 'undefined') {
        if (recData.action != 'pageinit') return;
      }
    }
    if (this.unload) return;

    if (doMergeWithData == null || typeof doMergeWithData === 'undefined') doMergeWithData = true;

    console.log('createOpenAction getRecordingData 1st', recData);

    this.recData = {};

    if (recData != null && typeof recData !== 'undefined' && recData.action == 'verify' && recData.computed_vision_based_validation == 1) {
      this.lastClickToSend = this.clickToSend;
      this.clickToSend = {};
    } else if (recData != null && typeof recData !== 'undefined' && recData.action === 'prompt' && Object.keys(this.clickToSend).length > 0) {
      // for prompt actions we need to keep the original click
      this.lastClickToSend = this.clickToSend;
      this.clickToSend = {};
      this.getRecordingData(this.lastClickToSend, false);
      this.getRecordingData(recData);
    } else {
      if (this.clickToSend && Object.keys(this.clickToSend).length > 0) {
        // queued clicks need to be recorded here…
        this.lastClickToSend = this.clickToSend;
        this.clickToSend = {};
        if (recData != null && typeof recData !== 'undefined' && recData.action == 'click') {
          // we need to figure out what to do here.    Should not happen
          this.clickToSend = {};
        } else {
          this.getRecordingData(this.lastClickToSend, false);
          if (recData == null || typeof recData !== 'undefined')
            // if no data just click rec than return…
            return;
        }
      }
    }

    console.log('createOpenAction getRecordingData 2nd', recData);

    if (recData != null && typeof recData !== 'undefined') {
      if (recData.timestamp == undefined || recData.timestamp == '') {
        recData.timestamp = window.WU.getTime();
      }
      this.recData = recData;
      window.fconsole.log('Get Recording Data with param = ' + window.WU.stringify(this.recData));
    }

    if (this.testCaseTitle != '') {
      if (this.verify != null && this.verify != '') this.recData = this.verify.data;
      this.recData.testCaseTitle = this.testCaseTitle;
      this.recData.last = true;
      this.verify = null;
      doMergeWithData = false;
    } else if (this.verify != null && this.verify != undefined && this.verify != '') {
      this.recData = this.verify.data;
      this.recData.last = false;
      this.verify = null;
      doMergeWithData = false;
    }

    if (doMergeWithData) {
      // Helper function to check if an object is empty
      function isEmptyObject(obj) {
        console.log('isEmptyObject', obj);
        return JSON.stringify(obj).length === 0 || (Object.keys(obj).length === 0 && obj.constructor === Object);
      }

      // Helper function to deep compare two objects
      function objectsAreDifferent(obj1, obj2) {
        return JSON.stringify(obj1) !== JSON.stringify(obj2);
      }

      // Merge data if not empty and different from last
      if (this.inputToSend && Object.keys(this.inputToSend).length > 0 && objectsAreDifferent(this.inputToSend, this.lastInputToSend)) {
        window.fconsole.log('Rec Input');
        this.recData = { ...this.recData, ...this.inputToSend };
        this.lastInputToSend = this.inputToSend;
        if (this.recData.action === 'input') {
          let inpValue = this.recData.value?.trim();
          if (inpValue && typeof window.WS.recordedRandomVariables[inpValue] !== 'undefined') {
            this.recData.value = window.WS.recordedRandomVariables[inpValue];
          }
        }
      } else if (this.clickToSend && !isEmptyObject(this.clickToSend) && objectsAreDifferent(this.clickToSend, this.lastClickToSend)) {
        window.fconsole.log('Rec Click');
        this.recData = { ...this.recData, ...this.clickToSend };
        this.lastClickToSend = this.clickToSend;
      } else if (!isEmptyObject(this.selectToSend) && objectsAreDifferent(this.selectToSend, this.lastSelectToSend)) {
        window.fconsole.log('Rec Select');
        this.recData = { ...this.recData, ...this.selectToSend };
        this.lastSelectToSend = this.selectToSend;
        this.selectToSend = {};
      } else if (!isEmptyObject(this.radioToSend) && objectsAreDifferent(this.radioToSend, this.lastRadioToSend)) {
        window.fconsole.log('Rec Radio');
        this.recData = { ...this.recData, ...this.radioToSend };
        this.lastRadioToSend = this.radioToSend;
        this.radioToSend = {};
      } else if (!isEmptyObject(this.checkToSend) && objectsAreDifferent(this.checkToSend, this.lastCheckToSend)) {
        window.fconsole.log('Rec Check');
        this.recData = { ...this.recData, ...this.checkToSend };
        this.lastCheckToSend = this.checkToSend;
        this.checkToSend = {};
      } else if (!isEmptyObject(this.enterToSend) && objectsAreDifferent(this.enterToSend, this.lastEnterToSend)) {
        window.fconsole.log('Rec Enter');
        this.recData = { ...this.recData, ...this.enterToSend };
        this.lastEnterToSend = this.enterToSend;
        this.enterToSend = {};
      } else if (!isEmptyObject(this.scrollToElementOnToSend) && objectsAreDifferent(this.scrollToElementOnToSend, this.lastScrollToElementOnToSend)) {
        window.fconsole.log('Rec scroll');
        this.recData = { ...this.recData, ...this.scrollToElementOnToSend };
        this.lastScrollToElementOnToSend = this.scrollToElementOnToSend;
        this.scrollToElementOnToSend = {};
      } else if (!isEmptyObject(this.hoverOnToSend) && objectsAreDifferent(this.hoverOnToSend, this.lastHoverOnToSend)) {
        window.fconsole.log('Rec Hover');
        this.recData = { ...this.recData, ...this.hoverOnToSend };
        this.lastHoverOnToSend = this.hoverOnToSend;
        this.hoverOnToSend = {};
      } else if (!isEmptyObject(this.html5dragdropToSend) && objectsAreDifferent(this.html5dragdropToSend, this.lastHtml5dragdropToSend)) {
        window.fconsole.log('Rec HTML5DragDrop');
        this.recData = { ...this.recData, ...this.html5dragdropToSend };
        this.lastHtml5dragdropToSend = this.html5dragdropToSend;
        this.html5dragdropToSend = {};
      }
    }

    console.log('createOpenAction getRecordingData 3', recData);

    if (this.collectStatistics || (window.functionizeFilterMlData && typeof this.recData === 'object')) {
      this.recData.elementStatisticsFilter = 'true';
    }

    this.recData = { ...this.recData, hasScroll: this.hasScroll };

    if (window.WS.pointerDownTrace.length > 0) {
      this.recData.pointerDownTrace = window.WU.cleanAndFormatPointerDownTraceData(window.WS.pointerDownTrace);
      if (!this.recData.hasOwnProperty('pointerDownTraceTime') && window.WS.pointerDownTraceTimestampOffset > 0) {
        this.recData.pointerDownTraceTime = window.WS.pointerDownTraceTimestampOffset;
      }
    }

    window.WS.pointerDownTrace = [];
    window.WS.pointerDownTraceTimestampOffset = null;

    if (Object.keys(this.recData).length === 0) {
      console.log('RecData is empty… not recording anything…');
      return;
    }

    if (typeof this.recData.action === 'undefined' || this.recData.action === '') {
      console.log('no action found in rec data = ' + JSON.stringify(this.recData));
      // we discard this...
      this.recData = {};
      return;
    }

    /*
    if (JSON.stringify(this.recData).includes(window.fUniqPrefix)) {
      console.log('Functionise prefix found in rec data…  skipping.');
      // we discard this...
      this.recData = {};
      return;
    }
    */

    if (typeof this.recData.scrollTop === 'undefined') {
      // only set it once…
      this.recData.scrollTop = window.scrollY;
      this.recData.scrollLeft = window.scrollX;
    }

    if (this.recData.action == 'verify') {
      // reset c counter for new checkpoints.
      this.ckeyDownCounter = 0;
    }

    console.trace('getRecordingData generateActionId', this.recData, this.recData.actionId);

    if (typeof this.recData.actionId === 'undefined' || !this.recData.actionId) {
      // add the action ID
      this.recData.actionId = window.WU.generateActionId();
    }
    // this.recData.functionizeHtmlSource = document.documentElement.outerHTML;
    var actionId = this.recData.actionId;

    console.log('lazyload: ' + window.WS.hasLazyLoad);
    //attach leazy load if any
    if (typeof this.recData.hasLazyLoad == 'undefined' || !this.recData.hasLazyLoad) {
      this.recData.hasLazyLoad = window.WS.hasLazyLoad;
    }

    if (this.recData.action === 'pageinit' && !this.pageInitId) {
      this.pageInitId = this.recData.actionId;
    }

    // Set page title if not yet set
    if (typeof this.recData['pageTitle'] === 'undefined') {
      this.recData['pageTitle'] = document.querySelector('title')?.textContent;
    }

    // Set url if not yet set
    if (typeof this.recData['url'] === 'undefined' && !this.isIframe) {
      this.recData['url'] = this.locUrl;
      window.fconsole.log('URL is not yet set.   Setting to to : ' + this.recData['url']);
    }

    // check for valid domain
    var isValidURL = this.isValidURL(this.recData['url']);
    if (!isValidURL) {
      alert('You are not allowed to record on this URL, please contact your account manager to enable functionality.');
      return;
    }

    // get mousetrace for click and hover events
    if ((this.recData.action == 'hover' || this.recData.action == 'scroll' || this.recData.action == 'click') && typeof this.recData['mouseoverTraceX0'] === 'undefined') {
      // we set mouse trace values
      window.fconsole.log('Mouse trace size: ' + this.mouseoverTraceX.length);
      for (var i = 0; i < this.mouseoverTraceX.length; i++) {
        this.recData['mouseoverTraceX' + i] = this.mouseoverTraceX[i] - parseInt(this.recData['eventX']);
        this.recData['mouseoverTraceY' + i] = this.mouseoverTraceY[i] - parseInt(this.recData['eventY']);
      }
      // take out all prev elements other than current one...
      try {
        this.mouseoverTraceX.shift();
        this.mouseoverTraceX.shift();
        this.mouseoverTraceY.shift();
        this.mouseoverTraceY.shift();
      } catch (e) {}
    }

    // remove functionizeHash before saving the action data
    if (this.recData.hasOwnProperty('funcitonizeHash')) {
      delete this.recData.functionizeHash;
    }

    // we will use this to reference our element
    var cssSelector = this.getUniqueSelectorFromElementData(this.recData);
    // set screenshot but we give the flash to take sometime to get to effect
    // second param is delay in ms
    var delay = 20;
    if (window.WS.shiftDown) delay = 5;
    // compute statistics
    if (window.WS.recData.action !== 'init' && window.WS.recData.action !== 'input' && window.WS.recData.action !== 'notonpage') {
      try {
        if (typeof window.WS.recData.elementStatistics === 'undefined' && this.getSiteStatistics(window.WS.recData, cssSelector)) {
          if (typeof window.WS.recData.element !== 'undefined' && window.WS.recData.element !== 'iframe') {
            let element = document.querySelector(cssSelector);
            if (element) {
              window.WS.recData.elementStatistics = window.WS.collectMlData(element, window.WS.recData.action, window.WS.recData.actionId);
              this.siteStatisticsMap[window.WS.recData.actionId] = cssSelector;
            }
          }
        }
      } catch (e) {
        console.error('Exception: ' + e);
      }
    }

    console.log('createOpenAction getRecordingData 4', recData);

    var command = {};

    if (this.isIframe) {
      // add iframe URL
      this.recData['url'] = this.locUrl;
      if (window.parentUrl) {
        this.recData['topUrl'] = window.parentUrl;
      }

      console.log('iframe action', this.recData);

      if (typeof suppressSetPath === 'undefined') suppressSetPath = false;
      // set this value for internal use making it easy to use cross frame advance features
      if (typeof this.recData.iframeUID === 'undefined' && this.iframeUID != '') this.recData.iframeUID = this.iframeUID;

      this.hasScroll = false;

      if (this.recData.action === 'pageinit') {
        window.pageInitAction = this.recData;
        return;
      }

      if (window.pageInitAction) {
        command = {
          obj: 'WS',
          call: 'iframeRecordingData',
          arguments: new Array(window.pageInitAction, this.iframeUID),
          meta: { suppressSetPath: suppressSetPath },
        };
        window.TCM.sendCommand(command, window.parent);
        window.pageInitAction = false;
      }

      this.lastAction = this.recData;

      command = {
        obj: 'WS',
        call: 'iframeRecordingData',
        arguments: new Array(this.recData, this.iframeUID),
        meta: { suppressSetPath: suppressSetPath },
      };
      window.TCM.sendCommand(command, window.parent);
      if (this.recData.action != 'verify' && this.recData.action != 'input') {
        // these are set earlier on before they bubble up...
        this.setFlash(document.querySelector(cssSelector));
        // const elements = document.querySelectorAll(this.recData.element);
        // if (this.recData.index >= 0 && this.recData.index < elements.length) {
        //   this.setFlash(elements[this.recData.index]);
        // }
      }
      return;
    }

    console.log('createOpenAction getRecordingData 5', recData);

    window.fconsole.log('Checking newUrl');
    if (this.locUrl != document.location.href) {
      this.locUrl = document.location.href;
      this.recData['newUrl'] = this.locUrl;
    }

    window.fconsole.log('Checking isPopup');
    if (this.isPopup) {
      // we need to load this even in a popup...
      // this.recData['url_' + this.popupUID] = document.location.href;
      if (!this.removableNewPopup.includes(this.recData.action)) {
        this.recData['url'] = document.location.href;
      }
      if (typeof this.recData.popupUID === 'undefined' && this.recData.popupUID != '') this.recData.popupUID = this.popupUID;

      this.hasScroll = false;

      if (
        !this.recData.hasOwnProperty('windowHeight') ||
        !this.recData.hasOwnProperty('windowWidth') ||
        this.recData.windowWidth !== window.innerWidth ||
        this.recData.windowHeight !== window.innerHeight
      ) {
        this.recData.windowHeight = window.innerHeight;
        this.recData.windowWidth = window.innerWidth;
      }

      if (typeof this.recData.browserWindowWidth === 'undefined') {
        this.recData.browserWindowWidth = window.outerWidth;
        this.recData.browserWindowHeight = window.outerHeight;
      }

      window.fconsole.log('Sending popup rec data to conrol: ' + JSON.stringify(this.recData));

      this.lastAction = this.recData;

      command = {
        obj: 'WS',
        call: 'popupRecordingData',
        arguments: new Array(this.recData, this.popupUID),
      };
      window.TCM.sendCommand(command, window.opener);
      if (this.recData.action != 'verify' && this.recData.action != 'input') {
        // these are set earlier on before they bubble up...
        this.setFlash(document.querySelector(cssSelector));
        // this.setFlash(document.querySelector(this.recData.element)[this.recData.index]);
      }
      return;
    }

    console.log('createOpenAction getRecordingData 6', recData);
    window.fconsole.log('Cleaning recData');
    for (var d in this.recData) {
      if (typeof this.recData[d] === 'undefined' || typeof this.recData[d] === 'function')
        // undefined or functions
        this.recData[d] = '';
    }

    if (!this.lastActionIsInstructionOrPO) {
      window.fconsole.log('Considering merge');
      var merged = this.mergePreviusAction(this.recData);
      window.fconsole.log('Merge returned: ' + merged);
      if (merged) {
        console.log('createOpenAction getRecordingData merged', recData);
        // if merged or empty we do not add anything
        window.fconsole.log('Merged data found: ' + window.WU.stringify(this.recData));
        // record the merge though…
        this.recordWbData();
        if (typeof this.recData.path === 'undefined' || this.recData.path == '') {
          if (this.recData.action != 'verify' && this.recData.action != 'input' && this.recData.action != 'scroll') {
            // these are set earlier on before they bubble up...
            this.setFlash(document.querySelector(cssSelector));
            // this.setFlash(document.querySelector(this.recData.element)[this.recData.index]);
          }
        }
        return;
      }
    }

    if (
      this.recData.action === 'input' &&
      (!this.recData.hasOwnProperty('elementStatistics') || !this.recData.elementStatistics) &&
      !!window.WS.mlDataElements[this.recData.actionId]
    ) {
      this.recData.elementStatistics = window.WS.collectMlData(window.WS.mlDataElements[this.recData.actionId], this.recData.action, this.recData.actionId);
    }

    // window.TCM.triggerRecorderScreenshot(window.WS.recData, delay);
    if (typeof this.recData.windowWidth === 'undefined') {
      // only set it once…
      this.recData.windowWidth = window.innerWidth;
      this.recData.windowHeight = window.innerHeight;
    }

    if (typeof this.recData.browserWindowWidth === 'undefined') {
      this.recData.browserWindowWidth = window.outerWidth;
      this.recData.browserWindowHeight = window.outerHeight;
    }

    if (typeof this.recData.path === 'undefined') this.recData.path = '';

    lastActionData = {};
    if (this.recordedData.length > 0) lastActionData = this.recordedData[this.recordedData.length - 1];

    // check if last action is pageinit
    if (lastActionData.hasOwnProperty('action') && lastActionData.action === 'pageinit' && lastActionData.hasOwnProperty('windowHeight')) {
      // check if window height is greater than pageinit window height
      if (Number(lastActionData.windowHeight) < Number(this.recData.windowHeight)) {
        // update pageinit action window height value to current action window height
        window.WS.updateActionByActionId(
          {
            windowHeight: this.recData.windowHeight,
          },
          lastActionData.actionId
        );
      }
    }

    if (typeof lastActionData.path === 'undefined') lastActionData.path = '';

    if (
      this.removableNewPopup.includes(this.recData.action) &&
      this.recData.action !== 'navigate' &&
      lastActionData.hasOwnProperty('url') &&
      typeof lastActionData.url !== 'undefined' &&
      lastActionData.url !== this.recData.url
    ) {
      this.recData['url'] = lastActionData.url;
    }

    // if (this.recData.path != '') {
    // if (lastActionData.path != '' && lastActionData.path == this.recData.path && lastActionData.url != this.recData.url) {
    // TO DO -- just uncommented this.   Why is this here???   This is erroneous
    // this.recData.url = lastActionData.url;
    // var cWPopupId = this.recData.path;
    // cWPopupId = cWPopupId.replace('popup', '');
    // cWPopupId = cWPopupId.replace('iframe', '');
    // this.recData['url_' + cWPopupId] = lastActionData.url;
    // }
    // }

    // assign same path to setVariable and verifyVariable actions
    if (this.recData.action === 'setVariable' || this.recData.action === 'verifyVariable') {
      this.recData.path = lastActionData.path;
    }

    // in case of path change let's generate a contextSwitch action
    // if (this.useContextSwitchAction && lastActionData.path != this.recData.path && this.recData.action !== 'setVariable' && this.recData.action !== 'verifyVariable') {
    //   this.generateContextSwitchAction(this.recData, lastActionData.path);
    // }

    if (this.recData.hasOwnProperty('iframeUID') && this.recData.iframeUID !== '') {
      this.generateContextSwitchAction(this.recData, lastActionData.path);
    }

    // set Suggest Verifications Input
    if (typeof this.recData.text !== 'undefined' && this.recData.text) {
      if (typeof window.TCM.suggestVerificationsInput[this.recData.actionId] === 'undefined') window.TCM.suggestVerificationsInput[this.recData.actionId] = {};

      window.TCM.suggestVerificationsInput[this.recData.actionId]['text'] = this.recData.text;

      if (typeof this.recData.actualstring !== 'undefined' && this.recData.actualstring)
        window.TCM.suggestVerificationsInput[this.recData.actionId]['text'] = this.recData.actualstring;

      window.TCM.suggestVerificationsInput[this.recData.actionId]['step'] = this.recordedData.length + 1;
    }
    if (typeof this.recData.value !== 'undefined' && this.recData.value) {
      if (typeof window.TCM.suggestVerificationsInput[this.recData.actionId] === 'undefined') window.TCM.suggestVerificationsInput[this.recData.actionId] = {};

      window.TCM.suggestVerificationsInput[this.recData.actionId]['value'] = this.recData.value;

      if (typeof this.recData.actualstring !== 'undefined' && this.recData.actualstring)
        window.TCM.suggestVerificationsInput[this.recData.actionId]['value'] = this.recData.actualstring;

      window.TCM.suggestVerificationsInput[this.recData.actionId]['step'] = this.recordedData.length + 1;
    }

    /* REMOVING THIS DUE TO CONTENT BEING COMMENTED OUT - UNNECESSARY?
    if (typeof this.recData.path !== 'undefined' && this.recData.action == 'pageinit' && this.recData.path.indexOf('iframe') >= 0) {
      window.WS.iframeInitPathSelector = this.recData.path;
      var iframeClass = document.querySelector(cssSelector).getAttribute('class');
      if (typeof iframeClass !== 'undefined' && iframeClass.indexOf('cke_') >= 0 && document.querySelector(cssSelector).contentDocument.querySelector('body').textContent === '') {
        // document.querySelector(iframeClass).contentDocument.querySelector('body').innerHTML = '<p>PAGEINIT</p>';
        // document.querySelector(this.recData.cssSelector).contentDocument.querySelector('body').innerHTML = '<p>PAGEINIT</p>';
      }
    }
     */

    // add iframe Coordinates required in drag drop functionality
    if (this.recData.action == 'pageinit' && typeof this.recData['path'] !== 'undefined' && this.recData['path']) {
      if (cssSelector) {
        // Get the element using the selector
        var element = document.querySelector(cssSelector);

        // Get the offset position of the element
        var rect = element.getBoundingClientRect();
        this.recData['eventX'] = rect.left + window.scrollX;
        this.recData['eventY'] = rect.top + window.scrollY;

        // Get the attribute 'data-functionise-uid'
        var datafunctioniseuid = element.getAttribute('data-functionise-uid') || '';
        this.iframeCoordinates[datafunctioniseuid] = {};

        // Store the coordinates in iframeCoordinates
        this.iframeCoordinates[datafunctioniseuid]['eventX'] = this.recData['eventX'];
        this.iframeCoordinates[datafunctioniseuid]['eventY'] = this.recData['eventY'];
      }
    }

    // remove fakepath of file for file upload action and add only base name of file.
    if (this.recData.action == 'input' && this.recData.type == 'file') {
      var inputFileValue = this.recData.value;
      this.recData.value = inputFileValue.split('\\').pop();
    }
    if (this.recData.action == 'verify' && window.WS.locUrl.indexOf('doublegood') > 0) {
      // Select all elements with the 'f-disabled' attribute
      var elements = document.querySelectorAll('[f-disabled]');

      // Iterate over the selected elements
      elements.forEach(function (element) {
        // Remove the 'disabled' attribute
        element.removeAttribute('disabled');
        // Remove the 'f-disabled' attribute
        element.removeAttribute('f-disabled');
      });
    }

    var notValidInputElements = ['a'];
    if (this.recData.action == 'input' && notValidInputElements.indexOf(this.recData.element) >= 0) {
      return;
    }

    console.log('createOpenAction getRecordingData down here', recData);

    try {
      if (this.recData.text !== '' && this.lastClickToSend) {
        var lastInputActionSelector = cssSelector;

        if (
          window.WS.ignore_hidden_elements &&
          lastInputActionSelector &&
          document.querySelector(lastInputActionSelector) &&
          Array.from(document.querySelector(lastInputActionSelector).querySelectorAll('*:not(script)')).filter((el) => window.WU.elementIsHidden(el)).length > 0 &&
          document.querySelector(lastInputActionSelector).innerHTML.length < 1000
        ) {
          // Create a temporary div and append it to the document body
          var tempDiv = document.createElement('div');
          tempDiv.className = 'f-functionise f-functionise-elementdataclone';
          tempDiv.innerHTML = document.querySelector(lastInputActionSelector).innerHTML;
          document.body.appendChild(tempDiv);

          // Remove hidden elements inside the temporary div
          var hiddenElements = Array.from(tempDiv.querySelectorAll('*:not(script)')).filter((el) => window.WU.elementIsHidden(el));
          hiddenElements.forEach(function (hiddenElement) {
            hiddenElement.remove();
          });

          // Get the cleaned text and remove the temporary div
          var actualVal = tempDiv.textContent || tempDiv.innerText;
          document.body.removeChild(tempDiv);
          this.recData.text = window.WU.cleanValue(actualVal);
        }
      }
    } catch (e) {
      console.error(e);
    }

    var currentInstructionStep = window.WU.store('currentInstructionStep');
    if (typeof currentInstructionStep !== 'undefined' && currentInstructionStep != 'undefined' && currentInstructionStep) {
      this.recData.instruction_step = currentInstructionStep;
    }
    console.log('Adding rec data', this.recData.iframeUID);
    if (window.WS.recData.action == 'input') {
      if (window.WS.recData.type === 'file' || window.WS.recData.type === 'date' || window.WS.recData.type === 'time') {
        window.WS.recData['dontlosefocus'] = '0';
      } else {
        window.WS.recData['dontlosefocus'] = '1';
      }
    }

    this.lastAction = this.recData;
    this.recordedData.push(this.recData);
    this.setLastActionIsInstructionOrPO(false);
    // Add affected elements
    window.AMD.waitAndUpdateAction(this.recData);

    if (this.recordedData.length > 500 && JSON.stringify(this.recordedData) > 1024 * 1024) {
      // 1MB limit
      // trigger end of recording now.
      window.TCM.stopTask(true);
    }

    console.log('createOpenAction getRecordingData sending', recData);

    if (typeof this.recData.action !== 'undefined') {
      if (this.recData.action == 'verify') {
        // we disable mouseout activation if enabled from the panel
        // on verification actions....
        if (!window.WS.settings['disableMouseoutAction'] && window.WS.settings['disableMouseout']) {
          window.WS.setSettings('disableMouseout', false);
          window.WS.saveSettings();
          // Select all elements with the class based on the window.fUniqPrefix and '-mouseoutsetting'
          let result = document.querySelectorAll('.' + window.fUniqPrefix + '-mouseoutsetting');

          // Loop through each element and remove the 'f-disableLink' class
          result.forEach(function (element) {
            element.classList.remove('f-disableLink');

            // Set the text content to 'Disable Mouseout'
            element.textContent = 'Disable Mouseout';
          });
        }
      }

      this.hasScroll = false;

      this.recordWbData();

      // now every action will produce an increased action counter so no need to do this...
      window.fconsole.log('Calling increment action count');
      this.incrementActionCount();

      if (typeof this.recData.path === 'undefined' || this.recData.path == '') {
        if (this.recData.action != 'verify' && this.recData.action != 'input') {
          // these are set earlier on before they bubble up...
          console.log('setFlash1' + cssSelector);
        }
        this.setFlash(document.querySelector(cssSelector));
      }
    }
    // creare data holder...
    this.recData = {};
  };

  this.getUniqueSelectorFromElementData = function (recData) {
    if (typeof recData.functionizeHash !== 'undefined') {
      // Select elements with the specified data attribute
      var elements = document.querySelectorAll("[data-functionize-hash='" + recData.functionizeHash + "']");

      // Check if any elements were found
      if (elements.length > 0) {
        return "[data-functionize-hash='" + recData.functionizeHash + "']";
      }
    }
    var selfObj = this;
    var foundSelector = recData.cssSelector;
    // we start with the css Selector and ideally i just works...
    var selectors = ['cssSelector', 'cssSelector2', 'xpath', 'xpath2', 'xpath3', 'xpath4', 'xpath5', 'uniqueSelectors', 'uniqueSelectorsMulti', 'secondarySelectors'];

    selectors.forEach((value) => {
      if (typeof recData[value] !== 'undefined' && recData[value]) {
        var selector = recData[value];
        var cssSelector = selector;
        if (value.indexOf('css') != 0) cssSelector = selfObj.xPathToCss(selector);
        try {
          // Check if there is exactly one element matching the CSS selector
          if (document.querySelectorAll(cssSelector).length === 1) {
            foundSelector = cssSelector;
            return false;
          }
        } catch (e) {
          window.fconsole.log('Selector did not work: ' + cssSelector + ' ' + e);
        }
      }
    });
    // this is what we are doing currently. Above is an improvement...
    return foundSelector;
  };

  this.setPathOnData = function (data, UID, type) {
    console.log('tamas WS.setPathOnData Setting path on data: ' + UID + ' type: ' + type);
    var index = 0;
    if (type == 'iframe') {
      index = this.getIframeIndexByUID(UID);
    }
    if (type == 'popup') {
      index = UID;
    }
    if (typeof data.path === 'undefined' || data.path == '') {
      data.path = type + index;
    } else {
      // add current path
      data.path = type + index + '_' + data.path;
    }
    if (type == 'iframe') data['pathselectors_' + data.path] = this.getBestIframeSelectorByUID(UID);

    return data;
  };

  this.iframeRecordingData = function (data, iframeUID) {
    console.log('iframe recording data received' + JSON.stringify(data));

    if (
      typeof data.action !== 'undefined' &&
      data.action == 'pageinit' &&
      data['pathselectors_' + data.path] != 'undefined' &&
      data['pathselectors_' + data.path] != '' &&
      data['xpath'] == 'undefined'
    ) {
      var pathselectorsiframe = data['pathselectors_' + data.path];
      var selc = window.WS.xPathToCss(selector);
      var element = document.querySelector(selc);

      if (element) {
        data['xpath'] = window.WU.getElementXPath(element);
        data['xpath2'] = window.WU.getElementXPath(element, true);
        // no dynamic ids….
        data['xpath3'] = window.WU.getElementTreeXPath(element, false, true, 0, false);
        // a longer class based selector...
        data['xpath4'] = window.WU.getElementTreeXPath(element, true, true, 3);
        // no attributes…
        data['xpath5'] = window.WU.getElementTreeXPath(element, false, false);
        data['uniqueSelectors'] = window.WU.getElementUniqueSelectors(element);
        data['uniqueSelectorsMulti'] = window.WU.getElementUniqueSelectorsTree(element);
        data['secondarySelectors'] = window.WU.getElementSecondarySelectors(element);
        data['cssSelector'] = window.WU.getElementCss(element);
        data['cssSelector2'] = window.WU.getElementCss(element, true);
      }

      if (data['xpath'] === '') data['xpath'] = data['pathselectors_' + data.path];
    }

    window.WS.getRecordingData(data, false);
    console.log('Iframe data received. New data = ' + window.WU.stringify(window.WS.recordedData));
  };

  this.popupRecordingData = function (data, popupUID) {
    window.fconsole.log('Popup Recording data received:' + JSON.stringify(data));
    window.WS.getRecordingData(data, false);
  };

  this.recordWbData = function (isFinal) {
    if (isFinal == null || isFinal == undefined) isFinal = false;

    if (window.TCM.isPaused) return;

    var command = null;

    if (this.isIframe) {
      // call parent to record
      if (!window.TCM.isControl) this.recordedData = new Array();

      command = { obj: 'WS', call: 'recordWBData', arguments: isFinal };
      window.TCM.sendCommand(command, window.parent);
      return;
    }

    if (this.isPopup) {
      // this.getRecordingData();
      this.recordedData = new Array();
      command = { obj: 'WS', call: 'recordWBData', arguments: isFinal };
      window.TCM.sendCommand(command, window.opener);
      return;
    }

    // var command = {obj:'TCM', call: 'recordData',arguments: {data: this.recordedData}};
    // window.TCM.sendCommandToMaster(command);

    var payload = [];
    if (this.lastRecordedActionId != '') {
      for (var i = this.recordedData.length - 1; i > 0; i--) {
        if (this.recordedData[i].actionId != this.lastRecordedActionId) {
          payload.unshift(this.recordedData[i]);
        } else {
          break;
        }
      }
      // we resend the last action as it is an update
      if (payload.length == 0) payload.unshift(this.recordedData[this.recordedData.length - 1]);
    } else {
      payload = this.recordedData;
    }

    if (
      this.siteStatistics.filterActivated &&
      payload[payload.length - 1]?.elementStatistics?.filter?.EXCLUDE &&
      payload[payload.length - 1].elementStatistics.filter.EXCLUDE.hasOwnProperty('viewport')
    ) {
      delete payload[payload.length - 1].elementStatistics.filter.EXCLUDE.viewport;
    }

    this.lastRecordedActionId = this.recordedData[this.recordedData.length - 1].actionId;
    if (typeof self !== 'undefined' && typeof self.port !== 'undefined')
      self.port.emit('message', {
        obj: 'TCM',
        call: 'recordData',
        arguments: [payload[payload.length - 1]],
        forMaster: true,
      });

    this.hasScroll = false;

    if (this.recordedData[this.recordedData.length - 1].hasOwnProperty('elementStatistics')) {
      delete this.recordedData[this.recordedData.length - 1].elementStatistics;
    }

    if (this.recordedData[this.recordedData.length - 1].hasOwnProperty('preFocus')) {
      delete this.recordedData[this.recordedData.length - 1].preFocus;
    }

    if (this.recordedData[this.recordedData.length - 1].hasOwnProperty('postFocus')) {
      delete this.recordedData[this.recordedData.length - 1].postFocus;
    }

    if (this.recordedData[this.recordedData.length - 1].hasOwnProperty('formSerialized')) {
      delete this.recordedData[this.recordedData.length - 1].formSerialized;
    }
  };

  // trigger the creation of an action
  // for now only on input…
  this.createAction = function (e, atype) {
    console.log('Creating action type', e, atype);
    if (!window.WS.on) return;
    e.action = atype;
    window.WS[atype + 'ToSend'] = e;
    window.WS.getRecordingData();
  };

  this.createSetStorageAction = function (functioniseSetLocalStorageType, functioniseSetStorageName, functioniseSetStorageValue, functioniseSetStorageDuration) {
    window.fconsole.log('Creating set cookie action #1');
    if (!window.WS.on) return;

    var storagedays = functioniseSetStorageDuration / (24 * 3600);
    var data = null;
    if (functioniseSetLocalStorageType == 'COOKIE') {
      window.WU.cookie(functioniseSetStorageName, functioniseSetStorageValue, { expires: storagedays, path: '/' });
      data = {
        action: 'setCookie',
        cookie_name: functioniseSetStorageName,
        cookie_value: functioniseSetStorageValue,
        cookie_duration: functioniseSetStorageDuration,
        timestamp: window.WU.getTime(),
      };
    } else {
      data = {
        action: 'setHTMLStorage',
        storage_name: functioniseSetStorageName,
        storage_value: functioniseSetStorageValue,
        timestamp: window.WU.getTime(),
      };
    }
    window.WS.getRecordingData(data);
  };

  this.createpageVariableAction = function (inputvar, customDescriptionString, outcomeOverride) {
    window.fconsole.log('Creating page variables');
    if (!window.WS.on) return;

    var inVar = {};
    inVar['action'] = 'pageVariables';
    inVar['timestamp'] = window.WU.getTime();

    var pv = 1;
    inputvar.forEach(function (attr, index) {
      var attrSplit = attr.split('|FUNC|');

      // inVar[attrSplit[0]] = attrSplit[1]+'#func#'+attrSplit[2];
      inVar['pageVariable_' + pv] = attrSplit[0] + '#func#' + attrSplit[1] + '#func#' + attrSplit[2];
      pv++;
    });

    var data = inVar;
    // data['custom_description'] = customDescriptionString;
    /*
    if (outcomeOverride) {
      data['elementCode'] = outcomeOverride;
    }
 */
    window.WS.getRecordingData(data);
  };

  this.createResourceVariableAction = function (actionData) {
    window.fconsole.log('Creating resource variables');
    if (!window.WS.on) return;

    var inVar = {};
    inVar['action'] = 'resourceVariable';
    inVar['timestamp'] = window.WU.getTime();
    inVar['resourceVariable'] = actionData;
    var data = inVar;

    window.WS.getRecordingData(data);
  };

  this.createVisPageChkAction = function (data) {
    window.fconsole.log('Creating take full cv action');
    if (!window.WS.on) return;
    let value = {
      action: 'vispagechk',
      visual_comparison_type: data.visual_comparison_type,
      change_percentage_allowed: data.change_percentage_allowed,
      visual_comparison_match: data.visual_comparison_match,
      timestamp: window.WU.getTime(),
    };
    this.inputToSend = {};
    window.WS.getRecordingData(value);
  };

  this.createSMSAction = function (data) {
    window.fconsole.log('Creating SMS action', data);
    if (!window.WS.on) return;
    let value = {
      action: 'smssend',
      fromNumber: data.fromNumber,
      toNumber: data.toNumber,
      message: data.message,
      timestamp: window.WU.getTime(),
      displayRaw: true,
    };
    this.inputToSend = {};
    window.WS.getRecordingData(value);
  };

  this.createExtensionAction = function (data) {
    window.fconsole.log('Creating extension action', data);
    if (!window.WS.on) return;
    let value = {
      action: 'extension',
      extensionName: data.extensionName,
      extensionEndpoint: data.extensionEndpoint,
      extensionId: data.extensionId,
      requestBody: data.requestBody,
      extensionResponse: data.result,
      extensionResponseMain: data.response,
      timestamp: window.WU.getTime(),
    };
    this.inputToSend = {};
    window.WS.getRecordingData(value);
  };

  this.createWaitAction = function (data) {
    console.log('createWaitAction', data);
    if (!window.WS.on) return;
    var action = {
      action: 'wait',
      time: data.time,
      smart_wait: data.smart_wait,
      timestamp: window.WU.getTime(),
    };
    this.inputToSend = {};
    window.WS.getRecordingData(action);
  };

  this.resetCanvasSignature = function () {
    this.enableCaptureSignature = false;
    this.canvasSignature = [];
    this.canvasSignatureSingle = {};
    this.canvasSignatureCount = 0;
    this.canvasSignatureEnabled = false;
    this.canvasSignatureElement = '';
  };

  this.createSignatureAction = function () {
    if (!window.WS.on) return;

    var targetEl = window.WS.targetElement(window.WS.canvasSignatureElement, 'esignature');
    if (targetEl) {
      targetEl['timestamp'] = window.WU.getTime();
      targetEl['mouse_movement'] = JSON.stringify(window.WS.canvasSignature);
      window.WS.clickToSend = {};
      window.WS.getRecordingData(targetEl);
      this.resetCanvasSignature();
    }
  };

  this.getIndicesOf = function (searchStr, str, caseSensitive) {
    var startIndex = 0;
    var searchStrLen = searchStr.length;
    var index;
    var indices = [];
    if (!caseSensitive) {
      str = str.toLowerCase();
      searchStr = searchStr.toLowerCase();
    }
    while ((index = str.indexOf(searchStr, startIndex)) > -1) {
      indices.push(index);
      startIndex = index + searchStrLen;
    }
    return indices;
  };

  this.evaluateStringForFunctionizeVars = function (eValue) {
    var indexArr = window.WS.getIndicesOf('[functionizeVariable:', eValue, false);
    console.log('SOURAV1', indexArr);

    var strFormat = eValue;
    var strValue = eValue;

    for (var i = 0; i < indexArr.length; i++) {
      var posStartBracket = indexArr[i];
      var posClosingBracket = eValue.indexOf(']', posStartBracket);

      var eValue2 = eValue.substring(posStartBracket, posClosingBracket + 1);

      console.log('SOURAV2', eValue2);
      var strSearch = eValue2;
      eValue2 = eValue2.substring(0, eValue2.length - 1);
      console.log('SOURAV3', eValue2);

      var varVals = eValue2.split('::');
      console.log('SOURAV4', varVals);
      var operator = '';
      if (varVals.length > 3 && varVals[3] != '') {
        operator = varVals[3];
      }
      if (varVals.length < 3 || varVals[2] == '') {
        varVals[2] = 'text';
      }
      console.log('SOURAV5', varVals);
      var attr = varVals[2];
      console.log('SOURAV6', attr);
      var step = parseInt(varVals[1]);
      console.log('SOURAV7', step);
      if (isNaN(step)) {
        // validation
        alert('Invalid variable definition.  Step number was parsed as: ' + step);
        return;
      }

      var actionId = window.WS.getActionIdByStep(step);
      console.log('SOURAV8', actionId);
      var action = this.recordData[step - 1];
      var value = window.WS.getActionAttribute(action, attr);
      console.log('SOURAV9', value);
      // if no value is set for give attribute we alert the user...
      if (value == null || typeof value === 'undefined') {
        var actionType = window.WS.getActionTypeByStep(step);
        alert(attr.charAt(0).toUpperCase() + attr.slice(1) + ' for action ' + step + ' is undefined. Found action for step ' + step + ' was ' + actionType + '.');
        return;
      }

      if (operator == 'parseInt') {
        value = parseInt(value.replace(/[^\d]/g, ''));
      } else if (operator == 'parseNumeric') {
        value = value.replace(/[^\d]/g, '');
      } else if (operator == 'toLowerCase') {
        value = value.toLowerCase();
      } else if (operator.indexOf('function') == 0) {
        var functionizeVariableValue = value;
        let code = 'window.funcCall = ' + operator;
        setTimeout(code, 1);
        if (typeof window.funcCall === 'function');
        value = window.funcCall();
      }

      if (typeof actionId === 'undefined') {
        alert('No such action can be found.');
        return;
      }

      if (typeof value === 'undefined') {
        alert('No such attribute found: ' + attr);
        return;
      }

      if (value === '') {
        alert('Empty value found in action');
        return;
      }
      strFormat = strFormat.replace(strSearch, '[functionizeVariable::' + actionId + '::' + attr + '::' + operator + ']');
      strValue = strValue.replace(strSearch, value);
    }

    var returnData = {};
    returnData['strValue'] = strValue;
    returnData['strFormat'] = strFormat;

    return returnData;
  };

  this.createOpenAction = function (URL, newtab) {
    console.log('createOpenAction', URL, newtab);
    var n = URL.indexOf('ProjectVariable');
    var oUrl = URL;
    if (n > 0) {
      var URLE = URL.split('::');
      var URLEX = URLE[1].split(']');

      var projectVariableLoadCookieVariable = 'projectVariableSave_' + window.projectId + '_' + URLEX[0];
      var projectVariableLoadCookieVariableValue = window.WU.cookie(projectVariableLoadCookieVariable);

      URL = projectVariableLoadCookieVariableValue;
    }

    var returnData = window.WS.evaluateStringForFunctionizeVars(URL);
    console.log('SOURAV', returnData);
    URL = returnData['strFormat'];
    var navURL = returnData['strValue'];

    window.fconsole.log('Creating open action ' + URL);
    if (!window.WS.on) return;

    if (typeof projectVariableLoadCookieVariableValue === 'undefined' || !projectVariableLoadCookieVariableValue) {
      oUrl = navURL;
    }

    n = oUrl.indexOf('http');
    var updatenavurl = true;
    if (n < 0) {
      oUrl = 'https://' + oUrl;
      updatenavurl = false;
    }

    if (updatenavurl) navURL = oUrl;

    if (URL != navURL) {
      oUrl = URL;
    }

    if (!updatenavurl) navURL = oUrl;

    var isValidURL = this.isValidURL(navURL);
    if (!isValidURL) {
      alert('You are not allowed to record on this URL, please contact your account manager to enable functionality.');
      return;
    }

    var data = {};
    if (newtab) {
      data = { action: 'navigate', url: oUrl, timestamp: window.WU.getTime(), target: '_blank', epoch: Date.now() };
    } else {
      data = { action: 'navigate', url: oUrl, timestamp: window.WU.getTime(), epoch: Date.now() };
    }

    console.log('createOpenAction here', data);

    window.WS.getRecordingData(data, false);
    //if (!window.TCM.isMaster && window.TCM.isController) {
    //  setTimeout(function() {
    //    window.top.location = navURL;
    //  }, 100);
    //} else {
    if (newtab) {
      window.open(navURL, '_blank');
    } else {
      setTimeout(function () {
        location = navURL;
      }, 100);
    }
    //}
  };

  this.createEscapeAction = function () {
    if (!window.TCM.isMaster) {
      var command = {
        obj: 'WS',
        call: 'createEscapeAction',
        arguments: null,
        meta: { fromUID: window.WS.popupUID },
      };
      window.fconsole.log('Sending relay to plugin: ' + command.call);
      self.port.emit('relay', command);
      return;
    }
    try {
      window.fconsole.log('Creating escape action ');
      if (!window.WS.on) return;
      var lastAction = this.getLastRecordedDataSegment();
      if (lastAction.action != 'keypress' && lastAction.keyCode != 27) {
        var data = { action: 'keypress', keyCode: 27, key: 'Escape', timestamp: window.WU.getTime(), url: window.WS.locUrl };
        window.WS.getRecordingData(data);
      }
    } catch (err) {
      alert(err.message);
    }
  };

  this.createKeypressAction = function (e) {
    if (!window.WS.on) return;
    try {
      if (window.WS.keypressDebounce) {
        return;
      }
      window.WS.keypressDebounce = setTimeout(() => {
        console.log('Creating keypress action', e);
        var data = {
          action: 'keypress',
          keyCode: e.keyCode,
          key: e.key !== 'Backspace' ? e.key : 'BackSpace',
          timestamp: window.WU.getTime(),
          url: window.WS.locUrl,
          metaKey: e.metaKey || false,
          shiftKey: e.shiftKey || false,
          altKey: e.altKey || false,
          ctrlKey: e.ctrlKey || false,
        };
        window.WS.getRecordingData(data, false);
        if (e.execute) {
          if (e.ctrlKey && e.key == 'R') {
            location.reload();
          } else if (e.altKey && e.key == 'ArrowLeft') {
            window.history.back();
          } else if (e.altKey && e.key == 'ArrowRight') {
            window.history.forward();
          } else {
            document.dispatchEvent(
              new KeyboardEvent('keydown', {
                key: e.key,
                keyCode: e.keyCode,
                metaKey: e.metaKey || false,
                shiftKey: e.shiftKey || false,
                altKey: e.altKey || false,
                ctrlKey: e.ctrlKey || false,
              })
            );
          }
        }
        window.WS.keypressDebounce = false;
      }, 300);
    } catch (err) {
      console.error(err);
    }
  };

  this.createEmailreceiveAction = function (newtab, URL, path) {
    if (!window.WS.on) return;

    var data = { action: 'emailreceive', url: URL, timestamp: window.WU.getTime() };

    if (path) {
      data.path = path;
    }

    if (newtab) {
      data.target = '_blank';
    }

    window.WS.getRecordingData(data);
    if (!window.TCM.isMaster && window.TCM.isController) {
      // this is a frameset and we are calling this from the child iframe
      setTimeout(function () {
        window.top.location = URL;
      }, 100);
    } else {
      if (newtab) {
        window.open(URL, '_blank');
      } else {
        setTimeout(function () {
          location = URL;
        }, 100);
      }
    }
  };

  this.createComputedVisionVerifyAction = function (selector, visualRect) {
    try {
      if (!window.WS.on) return;

      var method = 'verify';
      var element = document.querySelector(selector);

      window.WS.verifyCurrentElement = element;
      var result = new functioniseTestResult();
      result.action = method;
      window.TCM.isVerifying = false;

      var selection = window.WS.verifyCurrentElement;
      var tagName = selection ? selection.tagName : '';
      var index = selection ? Array.prototype.indexOf.call(document.querySelectorAll(tagName), selection) : -1;

      result.tagName = tagName;
      result.index = index;
      result.value = selection ? selection.value : '';
      result.text = selection ? selection.textContent : '';
      result.id = selection ? selection.id : '';
      result.data = window.WS.targetElement(selection, method, 0);
      result.data.scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
      result.data.scrollLeft = window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0;

      result.data.mouseX = 1;
      result.data.mouseY = 1;
      result.data.eventX = 0;
      result.data.eventY = 0;
      result.computed_vision_based_validation = 1;
      result.data.path = '';
      if (typeof visualRect !== 'undefined' && visualRect) {
        result.visual_rect = visualRect;
      }

      window.WS.getRecordingData(result);
    } catch (err) {}
  };

  this.createDBExplorerAction = function (newtab, URL, path) {
    window.fconsole.log('Creating DB Explorer action');
    if (!window.WS.on) return;

    var data = { action: 'DBExplorer', url: URL, timestamp: window.WU.getTime() };

    if (path) {
      data.path = path;
    }

    // set '_blank' for new tab navigation
    if (newtab) {
      data.target = '_blank';
    }

    window.WS.getRecordingData(data);
    if (!window.TCM.isMaster && window.TCM.isController) {
      // this is a frameset and we are calling this from the child iframe
      setTimeout(function () {
        window.top.location = URL;
      }, 100);
    } else {
      if (newtab) {
        window.open(URL, '_blank');
      } else {
        setTimeout(function () {
          location = URL;
        }, 100);
      }
    }
  };

  this.createFileViewerAction = function (newtab, URL, path) {
    window.fconsole.log('Creating File Viewer action');
    if (!window.WS.on) return;

    var data = { action: 'fileViewer', url: URL, timestamp: window.WU.getTime() };

    if (path) {
      data.path = path;
    }

    // set '_blank' for new tab navigation
    if (newtab) {
      data.target = '_blank';
    }

    window.WS.getRecordingData(data);
    if (!window.TCM.isMaster && window.TCM.isController) {
      // this is a frameset and we are calling this from the child iframe
      setTimeout(function () {
        window.top.location = URL;
      }, 100);
    } else {
      if (newtab) {
        window.open(URL, '_blank');
      } else {
        setTimeout(function () {
          location = URL;
        }, 100);
      }
    }
  };

  this.createSMSreceiveAction = function (newtab, URL, path) {
    window.fconsole.log('Creating smsreceive action');
    if (!window.WS.on) return;
    var data = { action: 'smsreceive', url: URL, timestamp: window.WU.getTime() };

    if (path) {
      data.path = path;
    }

    // set '_blank' for new tab navigation
    if (newtab) {
      data.target = '_blank';
    }

    window.WS.getRecordingData(data);
    if (!window.TCM.isMaster && window.TCM.isController) {
      // this is a frameset and we are calling this from the child iframe
      setTimeout(function () {
        window.top.location = URL;
      }, 100);
    } else {
      // setTimeout(function() { location =  URL},100);
      if (newtab) {
        window.open(URL, '_blank');
      } else {
        setTimeout(function () {
          location = URL;
        }, 100);
      }
    }
  };

  this.createApiAction = function (newtab, URL, path) {
    window.fconsole.log('Creating apicall action');
    if (!window.WS.on) return;

    var data = { action: 'apicall', url: URL, timestamp: window.WU.getTime() };

    if (path) {
      data.path = path;
    }

    // set '_blank' for new tab navigation
    if (newtab) {
      data.target = '_blank';
    }

    window.WS.getRecordingData(data);
    if (!window.TCM.isMaster && window.TCM.isController) {
      // this is a frameset and we are calling this from the child iframe
      setTimeout(function () {
        window.top.location = URL;
      }, 100);
    } else {
      if (newtab) {
        window.open(URL, '_blank');
      } else {
        setTimeout(function () {
          location = URL;
        }, 100);
      }
    }
  };

  this.createDownload = function (filename, contentType, fileUrl) {
    console.log('Creating download action ', Number(this.maxDownloadInterval), filename, contentType, fileUrl);
    if (!window.WS.on) return;
    if (window.WS.createDownloadTimer && Number(this.maxDownloadInterval) !== 0) {
      clearTimeout(window.WS.createDownloadTimer);
    }
    window.WS.createDownloadTimer = setTimeout(() => {
      console.log('executing Creating download action in settimeout', filename, contentType, fileUrl);
      var data = { action: 'download', filename: filename, timestamp: window.WU.getTime() };
      if (typeof contentType !== 'undefined' && contentType) {
        data.contentType = contentType;
      }
      if (typeof fileUrl !== 'undefined' && fileUrl) {
        data.fileUrl = fileUrl;
      }
      let lastAction = window.WS.getLastRecordedDataSegment();
      if (lastAction && lastAction.hasOwnProperty('path')) {
        data.path = lastAction.path;
      }
      window.WS.getRecordingData(data);
    }, Number(this.maxDownloadInterval));
  };

  this.setMaxDownloadInterval = function (time) {
    console.log('updateMaxDownload injected', time);
    this.maxDownloadInterval = time;
    self.port.emit('message', {
      obj: 'TCM',
      call: 'setMaxDownloadInterval',
      arguments: { time: time },
      forMaster: true,
    });

    if (window.TCM.isMaster) window.TCM.sendValueToDescendants('WS', 'maxDownloadInterval', time);
  };

  // element is an advanced editor type not a straight html element
  this.saveAdvancedCoderData = function (element, actionId) {
    if (element == null) {
      // we have no custom code created…  was a simple advanced coder tab open
      window.TCM.stopEdit();
      return;
    }
    if (element.action == 'customcode') {
      // we need to create a new code action basically and record it
      element.elementCode = element.data['code'];

      // added to attach the element selection as well to the custom code- Oct 8, 2015 b Ankur
      element.elementSelect = element.data['element'];

      delete element['data'];
      this.getRecordingData(element);
      // stop edit and return;
      window.TCM.stopEdit();
      return;
    }

    var lastAction = actionId ? this.getRecordingDataByActionId(actionId) : this.getLastRecordedDataSegment();

    if (
      (!window.TCM.clickAttributeEditorValue || typeof window.TCM.clickAttributeEditorValue['filledValue'] === 'undefined') &&
      (lastAction.action == 'input' || lastAction.action == 'verify' || lastAction.action == 'hover' || lastAction.action == 'scroll')
    ) {
      // no click action needed here
      if (element.data['element'] != '') this.appendToRecordedData({ elementSelect: element.data['element'] }, actionId);
      if (element.data['code'] != '') this.appendToRecordedData({ elementCode: element.data['code'] }, actionId);

      window.TCM.stopEdit();
      return;
    }
    // create a click action here
    // this.createAction(element, 'click');
    this.appendToRecordedData({ advancedCoder: true });
    if (element.data['element'] != '') this.appendToRecordedData({ elementSelect: element.data['element'] }, actionId);
    if (element.data['code'] != '') this.appendToRecordedData({ elementCode: element.data['code'] }, actionId);

    // now call stop edit
    window.TCM.stopEdit();
    // we now trigger the click
    window.fconsole.log('Triggering click');
    // create selector as it was in the panel
    var elIndex = element.index;
    if (elIndex < 0) elIndex = 0;

    this.triggerAction(element.element, elIndex, element.path, 'click');
    // reset shift key
    window.TCM.setShiftDown(false);
    this.isClicking = false;
    this.addingFunctioniseHider = false;

    var lastInputAction = actionId ? this.getRecordingDataByActionId(actionId) : this.getLastRecordedDataSegment();
    var filledValue = null;

    if (
      (lastInputAction.element == 'input' ||
        lastInputAction.element == 'textarea' ||
        (lastInputAction.hasOwnProperty('xpath') && typeof lastInputAction.xpath !== 'undefined' && lastInputAction.xpath.indexOf('brace-editor') > 0)) &&
      window.TCM.flagshiftclickinput
    ) {
      var newRecData = JSON.parse(JSON.stringify(window.WS.recordedData));

      lastInputAction = newRecData[newRecData.length - 1];

      lastInputAction['actionId'] = '';
      lastInputAction['action'] = 'input';

      filledValue = window.TCM.clickAttributeEditorValue['filledValue'];
      var actualstring = window.TCM.clickAttributeEditorValue['actualstring'];
      lastInputAction['value'] = actualstring;

      // Input value in field
      switch (window.TCM.clickAttributeEditorValue['filledOpr']) {
        case 'FAE':
          filledValue = window.TCM.getFunctionizeappEmail();
          lastInputAction['actualstring'] = filledValue;
          lastInputAction['generatedValue'] = filledValue;
          window.WS.recordedRandomVariables[filledValue] = '[functionizeAppEmail]';
          break;
        case 'RS':
          filledValue = actualstring.replace('[randomString]', window.WU.randomFunctionizeString(10));
          lastInputAction['actualstring'] = filledValue;
          lastInputAction['generatedValue'] = filledValue;
          window.WS.recordedRandomVariables[filledValue] = '[randomString]';
          break;
        case 'RT':
          filledValue = actualstring.replace('[randomText]', window.WU.randomFunctionizeText(10));
          lastInputAction['actualstring'] = filledValue;
          lastInputAction['generatedValue'] = filledValue;
          window.WS.recordedRandomVariables[filledValue] = '[randomText]';
          break;
        case 'RTS':
          filledValue = actualstring.replace('[randomTextSmall]', window.WU.randomFunctionizeTextSmall(10));
          lastInputAction['actualstring'] = filledValue;
          lastInputAction['generatedValue'] = filledValue;
          window.WS.recordedRandomVariables[filledValue] = '[randomTextSmall]';
          break;
        case 'RTU':
          filledValue = actualstring.replace('[randomTextUpper]', window.WU.randomFunctionizeTextUpper(10));
          lastInputAction['actualstring'] = filledValue;
          lastInputAction['generatedValue'] = filledValue;
          window.WS.recordedRandomVariables[filledValue] = '[randomTextUpper]';
          break;
        case 'FD':
          filledValue = window.WU.functionizeDate(actualstring);
          lastInputAction['actualstring'] = filledValue;
          lastInputAction['generatedValue'] = filledValue;
          window.WS.recordedRandomVariables[filledValue] = actualstring;
          break;
        case 'RN':
          if (actualstring.indexOf('[randomNumber]') > -1) {
            filledValue = actualstring.replace('[randomNumber]', window.WU.randomFunctionizeNumber(10));
            lastInputAction['actualstring'] = filledValue;
            lastInputAction['generatedValue'] = filledValue;
            window.WS.recordedRandomVariables[filledValue] = '[randomNumber]';
          } else if (actualstring.indexOf('[randomNumber') > -1) {
            window.randomVariableType = actualstring;
            var matches = actualstring.match(/\[randomNumber(.*?)\]/);
            if (matches != null) {
              var length = 10;
              if (matches.length > 1 && matches[1] != '') {
                length = parseInt(matches[1].substring(0, 2));
                if (isNaN(length)) length = 10;
              }

              var notIncNumber = '';
              var notInc = matches[1].split('#');
              if (notInc.length > 1) {
                var notIncD = parseInt(notInc[1].toLowerCase().replace('n', ''));
                if (notIncD != 'undefined' && notIncD >= 0 && notIncD < 10 && notIncD != notInc[1]) {
                  notIncNumber = notIncD;
                }
              }

              filledValue = actualstring.replace(matches[0], window.WU.randomFunctionizeNumber(length, notIncNumber));
              lastInputAction['actualstring'] = filledValue;
              lastInputAction['generatedValue'] = filledValue;
              window.WS.recordedRandomVariables[filledValue] = actualstring;
            }
          }
          break;
        case 'SV':
          lastInputAction['actualstring'] = filledValue;
          lastInputAction['generatedValue'] = filledValue;
          break;
        case 'SI':
          lastInputAction['actualstring'] = filledValue;
          lastInputAction['generatedValue'] = filledValue;
          break;
        case 'LOAD':
          try {
            if (typeof this.recordedData[this.recordedData.length - 1] !== 'undefined') {
              if (typeof this.recordedData[this.recordedData.length - 1].projectVariableLoad_name !== 'undefined')
                delete this.recordedData[this.recordedData.length - 1].projectVariableLoad_name;
              if (typeof this.recordedData[this.recordedData.length - 1].projectVariableLoad_attribute !== 'undefined')
                delete this.recordedData[this.recordedData.length - 1].projectVariableLoad_attribute;
              if (typeof this.recordedData[this.recordedData.length - 1].projectVariableLoad_operation !== 'undefined')
                delete this.recordedData[this.recordedData.length - 1].projectVariableLoad_operation;
            }
          } catch (e) {
            window.fconsole.log(e);
          }
          lastInputAction['actualstring'] = filledValue;
          lastInputAction['generatedValue'] = filledValue;
          break;
      }

      var lastInputActionSelector = this.getUniqueSelectorFromElementData(lastInputAction);

      if (window.TCM.clickAttributeEditorValue['filledOpr'] == 'SI') {
        // Add in conditional for the Ace Editor
        filledValue = filledValue.replace(/\n/g, '\\n');
        var jStringOver = "var fEditor = ace.edit('brace-editor'); fEditor.setValue(\"" + filledValue + '");';

        var userCode = 'function codeanon() {\n ' + jStringOver + '\n}; ' + 'codeanon();';

        try {
          lastInputAction.elementCode = jStringOver;
          lastInputAction.specialInput = true;
          window.WS.getRecordingData(lastInputAction);
          window.postMessage({ call: 'evaluateUserCode', evalcode: userCode }, '*');
        } catch (err) {
          console.error(err.message);
        }
      } else {
        var selection = document.querySelector(lastInputActionSelector);
        selection.value = filledValue;

        var ev = new KeyboardEvent('keydown', { keyCode: 32, which: 32 });
        selection.dispatchEvent(ev);

        ev = new KeyboardEvent('keypress', { keyCode: 32, which: 32 });
        selection.dispatchEvent(ev);

        ev = new KeyboardEvent('keyup', { keyCode: 32, which: 32 });
        selection.dispatchEvent(ev);

        var input = selection;
        if (typeof input !== 'undefined') {
          var lastValue = input.value;
          input.value = filledValue;
          var event = new Event('input', { bubbles: true });
          event.simulated = true;
          var tracker = input._valueTracker;
          if (tracker) {
            tracker.setValue(lastValue);
          }

          input.dispatchEvent(event);
        }

        window.TCM.clickAttributeEditorValue = {};

        window.TCM.flagshiftclickinput = false;
        window.WS.getRecordingData(lastInputAction);
      }

      if (typeof lastInputAction['actualstring'] !== 'undefined' && lastInputAction['actualstring']) {
        lastAction = window.WS.getRecordingDataByActionId(actionId);

        if (typeof window.TCM.runtimeReplacementStrings[lastAction.actionId] === 'undefined') window.TCM.runtimeReplacementStrings[lastAction.actionId] = {};

        // set Suggest Verifications Input
        if (typeof window.TCM.suggestVerificationsInput[lastAction.actionId] === 'undefined') window.TCM.suggestVerificationsInput[lastAction.actionId] = {};

        if (typeof value.text !== 'undefined' && value.text) {
          window.TCM.runtimeReplacementStrings[lastAction.actionId]['text'] = value.actualstring;

          window.TCM.suggestVerificationsInput[lastAction.actionId]['text'] = value.actualstring;
        }

        if (typeof value.value !== 'undefined' && value.value) {
          window.TCM.runtimeReplacementStrings[lastAction.actionId]['value'] = value.actualstring;

          window.TCM.suggestVerificationsInput[lastAction.actionId]['value'] = value.actualstring;
        }

        window.TCM.suggestVerificationsInput[lastAction.actionId]['step'] = window.WS.recordedData.length;
      }
    }
  };

  this.triggerAction = function (tagName, index, path, action) {
    // use native calls
    // element.click();
    if (typeof path === 'undefined') path = '';
    window.fconsole.log('Trigger action called ' + path);
    var paths = path.split('_');
    var currentPathTarget = paths.shift();
    var newPath = '';
    var command = null;
    if (paths.length > 0) newPath = paths.join('_');
    if (currentPathTarget.indexOf('iframe') > -1) {
      // if we are targeting an iframe
      var iframeIndex = parseInt(currentPathTarget.replace('iframe', ''));
      var iframes = Array.from(document.querySelectorAll('body iframe')).filter((iframe) => !iframe.matches(`.${window.fUniqPrefix}, .${window.fUniqPrefix} *`));

      var iframe = iframes[iframeIndex];

      command = { obj: 'WS', call: 'triggerAction', arguments: [tagName, index, newPath, action] };
      if (iframe) {
        window.TCM.sendCommand(command, iframe.contentWindow);
      }
      return;
    } else if (currentPathTarget.indexOf('popup') > -1) {
      var UID = currentPathTarget.replace('popup', '');
      var win = window.WS.getPopupReferenceByUID(UID);
      if (typeof win === 'undefined' && win == null) {
        self.port.emit('message', {
          obj: 'TCM',
          call: 'showDialog',
          arguments: 'Unable to find target window to execute your code. The window may have been closed?',
          forVue: true,
        });
        return;
      }
      var args = new Array(tagName, index, newPath, action);
      command = { obj: 'WS', call: 'triggerAction', arguments: args };
      window.TCM.sendCommand(command, win);
      return;
    }
    window.fconsole.log('Getting element for click by ' + tagName + ' at index ' + index);
    try {
      // Select all elements matching 'body ' + tagName
      var elements = document.querySelectorAll('body ' + tagName);

      // Ensure the index is valid
      if (index >= 0 && index < elements.length) {
        var element = elements[index];

        // Add class using native JavaScript
        element.classList.add('z-highlighted');

        // Click the element using native JavaScript
        element.click();
      }
    } catch (e) {
      window.fconsole.log(e);
    }
  };

  /** ******* Recording data and related methods end ****************/

  /** ******* Test user code action… we need to target the right frame or window ************/

  // format user code - replace values for functionize variables and steps
  this.formatUserCode = function (strCode) {
    var emailRegex = /\[functionize.*\]/gim;
    var matches = strCode.match(emailRegex);
    if (typeof matches === 'undefined' || matches == null) {
      return strCode;
    }

    var self = this;

    matches.forEach(function (value, index) {
      var ftag = value; // .match(/::\[([\w\d\s:#]+)\]/ig);

      var setValue = '""';

      // functionize variables

      if (typeof ftag !== 'undefined') {
        var processTag = ftag.substring(1, ftag.length - 1);
        if (
          processTag.replace(/[0-9]/g, '').trim() == 'functionizeappEmail' ||
          processTag.replace(/[0-9]/g, '').trim() == 'functionizeappPhone' ||
          processTag.replace(/[0-9]/g, '').trim() == 'randomString'
        ) {
          if (typeof window.TCM.runtimeVariables !== 'undefined' && typeof window.TCM.runtimeVariables[processTag] !== 'undefined') {
            setValue = '"' + window.TCM.runtimeVariables[processTag].replace('"', '"') + '"';
          }
        }

        // functionize recorded step value;

        if (processTag.substring(0, 19) == 'functionizeVariable') {
          var stepdata = processTag.split('::');

          var stepnumber = parseInt(stepdata[1].trim()) - 1;
          var attribute = stepdata[2].trim();

          if (
            typeof window.WS.recordedData[stepnumber] !== 'undefined' &&
            window.WS.recordedData[stepnumber] != null &&
            typeof window.WS.recordedData[stepnumber][attribute] !== 'undefined' &&
            window.WS.recordedData[stepnumber][attribute] != null
          ) {
            setValue = '"' + window.WS.recordedData[stepnumber][attribute].replace('"', '"') + '"';
            if (attribute == 'value' && typeof window.WS.recordedData[stepnumber].actualstring !== 'undefined' && window.WS.recordedData[stepnumber].actualstring) {
              setValue = '"' + window.WS.recordedData[stepnumber].actualstring.replace('"', '"') + '"';
            }
          } else {
            if (
              typeof window.TCM.runtimeReplacementStrings[stepdata[1]] !== 'undefined' &&
              typeof window.TCM.runtimeReplacementStrings[stepdata[1]][attribute] !== 'undefined' &&
              window.TCM.runtimeReplacementStrings[stepdata[1]][attribute] != null
            ) {
              setValue = '"' + window.TCM.runtimeReplacementStrings[stepdata[1]][attribute].replace('"', '"') + '"';
            }
          }
        }

        strCode = strCode.replace(value, setValue);
      }
    });
    return strCode;
  };

  this.testUserCode = function (code, type, path, isValidate, source) {
    code = this.formatUserCode(code);

    if (typeof source === 'undefined' || source == null) {
      source = 'self';
    }
    // if path is ' we are at the target so execute the code
    window.fconsole.log('Test user code is called with path: ' + path + ' and source: ' + source);
    if (typeof path === 'undefined') {
      path = '';
    }

    if (path != window.WS.path && source == 'master') {
      return false;
    }

    var command = null;
    var args = null;

    /*
    if (path != window.WS.path && source == 'self') {
      // this is case of framesets...
      // send to parent...
      command = {
        obj: 'WS',
        call: 'testUserCode',
        arguments: new Array(code, type, path, isValidate, 'iframe'),
      };
      var target = window.parent;
      window.TCM.sendCommand(command, target);
      return;
    }
     */

    if (path == '' || path == window.WS.path) {
      window.fconsole.log('Path match found');
      if (typeof isValidate === 'undefined' || !isValidate) {
        return window.WS.executeUserCode(code, type);
      } else {
        return window.WS.validateUserCode(code, type);
      }
    }
    var paths = path.split('_');
    var currentPathTarget = paths.shift();
    var newPath = '';
    var iframe = null;
    if (paths.length > 0) newPath = paths.join('_');
    if (currentPathTarget.indexOf('iframe') > -1) {
      // if we are targeting an iframe
      window.fconsole.log('Iframe target found');
      var iframeIndex = parseInt(currentPathTarget.replace('iframe', ''));
      let iframe;
      if (window.TCM.isMaster && !window.TCM.isController) {
        // Look for frames here...
        iframe = document.getElementsByTagName('frame')[iframeIndex];
      } else {
        const iframes = Array.from(document.querySelectorAll('body iframe')).filter((frame) => {
          return !frame.matches('.' + window.fUniqPrefix + ', .' + window.fUniqPrefix + ' *');
        });
        iframe = iframes[iframeIndex];
      }

      if (!document.querySelector(iframe)) {
        window.fconsole.log('Iframe target can not be found...');
        window.functionizeVex.dialog.alert('Unable to find target iframe to execute your code.	The iframe may have been removed from the DOM?');

        if (isValidate) window.WS.validateUserCodeCallback(false);
        return;
      }
      if (window.TCM.isMaster && !window.TCM.isController)
        // reset path if we have a frameset and are in the master
        newPath = path;

      args = new Array(code, type, newPath, isValidate, 'master');
      command = { obj: 'WS', call: 'testUserCode', arguments: args };
      window.TCM.sendCommand(command, document.querySelector(iframe).contentWindow);
    } else if (currentPathTarget.indexOf('popup') > -1) {
      var UID = currentPathTarget.replace('popup', '');
      var win = window.WS.getPopupReferenceByUID(UID);
      if (typeof win === 'undefined' || win == null) {
        self.port.emit('message', {
          obj: 'TCM',
          call: 'showDialog',
          arguments: 'Unable to find target window to execute your code. The window may have been closed?' + path + ' ' + newPath,
          forVue: true,
        });
        if (isValidate && window.TCM.isController) window.WS.validateUserCodeCallback(false);
        return;
      }

      if (window.TCM.isMaster && !window.TCM.isController)
        // reset path if we have a frameset and are in the master
        newPath = path;

      args = new Array(code, type, newPath, isValidate, 'master');
      command = { obj: 'WS', call: 'testUserCode', arguments: args };
      window.TCM.sendCommand(command, win);
    } else {
      // we could not find the target frame or window
      if (typeof self !== 'undefined' && typeof self.port !== 'undefined') {
        self.port.emit('message', {
          obj: 'TCM',
          call: 'showDialog',
          arguments: 'Unable to find target iframe or window to execute your code. The window /iframe may have been closed.',
          forVue: true,
        });
      } else {
        alert('Unable to find target iframe or window to execute your code.	 The window /iframe may have been closed.');
      }

      if (isValidate && window.TCM.isController) window.WS.validateUserCodeCallback(false);
    }
    return false;
  };

  this.executeUserCode = function (code, type) {
    try {
      var data;
      let temp = 'window.WS.functionizeValidateCustomJSResult = null; window.WS.functionizeValidateCustomJSResult = ' + code;
      console.log('executeUserCode', temp);
      setTimeout(temp, 1);
      setTimeout(() => {
        var el = window.WS.functionizeValidateCustomJSResult;
        console.log('executeUserCode', el, type);
        if (type == 'element') {
          el = el();
          if (el instanceof Element && el !== null && !this.isFunctioniseElement(el)) {
            this.removeHighlights();
            // Add class using native JavaScript
            el.classList.add('z-highlighted');
            // Initialize tippy.js tooltip
            window.WU.tippyInstance = tippy(el, {
              content: 'This is the element returned by your code.',
            });
            window.WU.tippyInstance.show();
            data = 'Code has been validated.';
          } else {
            data = 'Code did not return a valid element. Please try again';
          }
        } else {
          // code needs boolean return value
          if (typeof el === 'boolean') {
            data = 'Code currently returns "' + el + '".';
          } else {
            data = 'Code did not return a valid boolean type. Please try again';
          }
        }

        self.port.emit('message', {
          obj: 'TCM',
          call: 'showDialog',
          arguments: data,
          forVue: true,
        });
      }, 500);
    } catch (e) {
      console.log('evaluateUserCodeError', e);
      self.port.emit('message', {
        obj: 'TCM',
        call: 'showDialog',
        arguments: e.message,
        forVue: true,
      });
      window.postMessage({ call: 'evaluateUserCode', evalcode: code }, '*');
    }
  };

  this.validateUserCode = function (code, type) {
    try {
      let temp = 'window.WS.functionizeValidateCustomJSResult = null; window.WS.functionizeValidateCustomJSResult = ' + code;
      console.log('executeUserCode', temp);
      setTimeout(temp, 1);
      setTimeout(() => {
        var el = window.WS.functionizeValidateCustomJSResult;
        console.log('executeUserCode', el);
        var valid = false;
        if (type === 'element') {
          if (el instanceof Element && el !== null && !this.isFunctioniseElement(el)) {
            valid = true;
          }
        } else {
          // Code needs boolean return value
          if (typeof el === 'boolean') {
            valid = true;
          }
        }
        // we need to make callback
        this.validateUserCodeCallback(valid);
      }, 500);
    } catch (e) {
      window.fconsole.log(e);
    }
  };

  this.validateUserCodeCallback = function (valid, source) {
    if (typeof source === 'undefined') source = 'self';

    var command = { obj: 'WS', call: 'validateUserCodeCallback', arguments: valid };
    if (window.WS.isIframe && !window.TCM.isController && source != 'master') {
      window.TCM.sendCommand(command, window.parent);
      return;
    }
    if (window.WS.isPopup && !window.TCM.isController && source != 'master') {
      window.TCM.sendCommand(command, window.opener);
      return;
    }
    if (window.TCM.isMaster && !window.TCM.isController) {
      command = { obj: 'WS', call: 'validateUserCodeCallback', arguments: new Array(valid, 'master') };
      window.TCM.sendCommandToDescendants(command);
      return;
    }
    // we are in the main window so we send it to the panel
    if (window.TCM.isController) window.TCM.advancedEditor.oEditor.validateUserCodesCallback(valid, '');
  };

  /** *********  Iframe and popwindow methods ******************/

  this.frameEnd = function (UID) {
    // rerun to be sure we are not covering iframes that are going away
    // We have disabling off for now...
    window.WS.disableExternalIframes();
    window.fconsole.log('frame end called');
  };

  // TODO: -- We need this stored at the time of creation of the frame registration
  this.getIframeIndexByUID = function (UID) {
    var foundIndex = -1;
    var index = 0;
    var tag = document.querySelectorAll('iframe').length < 1 ? 'frame' : 'iframe';

    // Select elements using native JavaScript
    var elements = Array.from(document.querySelectorAll(tag)).filter((el) => !el.classList.contains(window.fUniqPrefix));

    // Iterate over elements and check UID
    elements.forEach((element) => {
      try {
        var elementUID = element.getAttribute('UID') || '';
        if (elementUID === UID) foundIndex = index;
      } catch (e) {
        console.log(e);
      }
      index++;
    });

    // If UID was not found, check in this.iframes
    if (foundIndex === -1) {
      for (var i in this.iframes) {
        if (this.iframes[i].UID === UID) foundIndex = this.iframes[i].index;
      }
    }

    return foundIndex;
  };

  // get iframe by uid
  this.getIframeByUID = function (UID, URL) {
    var foundIframe = null;
    var tag = 'iframe';
    if (document.querySelectorAll('iframe').length < 1) {
      tag = 'frame';
    }

    var elements = Array.from(document.querySelectorAll(tag)).filter((el) => !el.classList.contains(window.fUniqPrefix));

    // Iterate over the filtered elements
    elements.forEach(function (element) {
      try {
        // TODO: Check if the attribute it's 'data-UID' or just 'UID'
        if (element.getAttribute('UID') === UID) {
          foundIframe = element;
        }
      } catch (e) {
        window.fconsole.log(e);
      }
    });
    if (foundIframe == null) {
      // iframe was probably removed…
      for (var i in this.iframes) {
        if (this.iframes[i].UID == UID) foundIframe = this.iframes[i];
      }
    }

    if (foundIframe == null) {
      foundIframe = window.WS.siteStatistics.iframeList.find((iframe) => iframe.UID === UID);
    }

    if (foundIframe == null) {
      foundIframe = window.WS.siteStatistics.iframeList.find((iframe) => iframe.src === URL);
    }

    return foundIframe;
  };

  this.getBestIframeSelectorByUID = function (UID) {
    var selector = '';
    var tag = document.querySelectorAll('iframe').length < 1 ? 'frame' : 'iframe';

    // Select elements using native JavaScript
    var elements = Array.from(document.querySelectorAll(tag)).filter((el) => !el.classList.contains(window.fUniqPrefix));

    // Iterate over the filtered elements
    elements.forEach(function (element) {
      try {
        if (element.getAttribute('UID') === UID) {
          var useIds = true;
          var tagName = element.tagName.toLowerCase();

          if (
            (window.location.host.indexOf('cigna') > -1 && (tagName === 'iframe' || tagName === 'frame')) ||
            ((tagName === 'iframe' || tagName === 'frame') && element.id !== undefined && element.id.search('\\d') > -1)
          ) {
            useIds = false;
          }

          var skipDynamicAttributes = false;
          var isSkippable = false;

          if (
            window.location.host.indexOf('cpap') > -1 ||
            window.location.host.indexOf('stripe') > -1 ||
            ((tagName === 'iframe' || tagName === 'frame') && element.id !== undefined && element.id.search('\\d') > -1)
          ) {
            isSkippable = true;
          }

          if (isSkippable && element.id !== undefined) {
            skipDynamicAttributes = true;
          }

          if (element.id !== undefined && useIds && !skipDynamicAttributes) {
            selector = `//iframe[@id="${element.id}"]`;
            return false;
          } else if (element.attributes && element.attributes.length > 0) {
            for (var i = 0; i < element.attributes.length; i++) {
              var attr = element.attributes[i];

              if (
                attr.name.indexOf('functionise') > -1 ||
                attr.name.indexOf('functionize') > -1 ||
                attr.value.indexOf('functionise') > -1 ||
                attr.value.indexOf('functionize') > -1 ||
                attr.value.indexOf('functi0nize') > -1 ||
                attr.value.search('\\d') > -1
              ) {
                continue;
              }

              if (!useIds && (attr.name === 'id' || attr.name === 'src')) {
                continue;
              }

              if (isSkippable && attr.value.length > 0 && attr.value[attr.value.length - 1].search('\\d') > -1) {
                continue;
              }

              if (attr.name === 'class') {
                attr.value = attr.value.replace('z-highlighted', '').replace('z-flash-highlighted', '');
              }

              if (attr.value.length > 200 || attr.value === '') continue;

              var s = element.tagName + '[' + attr.name + '="' + attr.value + '"]';
              var matches = document.querySelectorAll(s);

              if (matches.length === 1) {
                selector = `//${element.tagName.toLowerCase()}[@${attr.name}="${attr.value}"]`;
                return false;
              }
            }
          }

          if (selector === '') {
            selector = window.WU.getElementXPath(element);
          }
        }
      } catch (e) {
        window.fconsole.log(e);
      }
    });

    if (selector === '') {
      // iframe was probably removed…
      for (var i in this.iframes) {
        if (this.iframes[i].UID === UID) selector = this.iframes[i].selector;
      }
    }

    return selector;
  };

  this.popupStart = function (UID) {
    // do nothing for now….
  };

  this.getPopupReferenceByUID = function (popupUID) {
    for (var i = 0; i < this.popups.length; i++) {
      var p = this.popups[i];
      if (p.id == popupUID) return p.reference;
    }
    return null;
  };

  /** *********  Iframe and popwindow methods end    ******************/

  /** *********  Errors and misc methods    ******************/

  this.setWindowSizeError = function (on) {
    // return; ///window size error is off as for now….
    if (on && !this.hasWindowSizeError) {
      this.hasWindowSizeError = true;

      // Add layer window with warning to prevent user actions
      var zi = 21474836405; // fTopZindex; //window.WU.getTopZindex();
      let errorDiv = document.createElement('div');
      errorDiv.id = window.fUniqPrefix + '-error';
      errorDiv.className = window.fUniqPrefix + ' ' + window.fUniqPrefix + '-error';
      errorDiv.style.cssText = 'opacity:0.8;background-color:#333;position:fixed;width:100%;height:100%;top:0px;left:0px;z-index:' + zi + ';';

      var innerDiv = document.createElement('div');
      innerDiv.style.cssText = 'position:relative;top:100px;margin:auto;width:400px;opacity:1;padding:20px;background:#FFFFFF;color:#333333;border:1px solid #CC0000;';
      innerDiv.innerHTML =
        'Your window is larger (' +
        window.innerWidth +
        'x' +
        window.innerHeight +
        ') than the maximum allowed screen resolution of ' +
        this.maxWindowWidth +
        'x' +
        this.maxWindowHeight +
        'px. Please resize your window to continue recording. As soon as your window size is within range this message should disappear.';

      errorDiv.appendChild(innerDiv);
      document.body.appendChild(errorDiv);

      var topElement = document.querySelector('#f-functionise-tc-manager');
      var topZ = '100001';
      if (topElement) {
        topZ = window.getComputedStyle(topElement).getPropertyValue('z-index');
      }
      errorDiv.style.zIndex = parseInt(topZ) - 1;
    } else if (!on && this.hasWindowSizeError) {
      this.hasWindowSizeError = false;

      // Remove layer
      let errorDiv = document.getElementById(window.fUniqPrefix + '-error');
      if (errorDiv) {
        errorDiv.remove();
      }
    }
  };

  this.showJsError = function (msg) {
    try {
      if (this.doRecording > 0 && this.on && this.settings.showRecordtimeErrors) {
        self.port.emit('message', {
          obj: 'TCM',
          call: 'showDialog',
          arguments: 'Javascript Runtime Error',
          forVue: true,
        });
      }
    } catch (e) {}
  };

  this.initFunctionised = function () {
    if (this.isFunctionised) return true;
    this.isFunctionised = true;
    injectCSS('styles/functionise.css');
    // injectCSS('styles/qtip.css');
    // for test bubbles...
    this.settings.helperOn = true;
    // turn off bubble animations
    // window.TH.doAnimation = false;
    window.WU.cookie('functionised', '1', { expires: 0, path: '/' });
    if (window.TCM.iframe != null) {
      // remove master iframe
      window.TCM.iframe.remove();
    }

    var command = { obj: 'WS', call: 'getFunctionised' };
    window.TCM.sendCommandToDescendants(command);
    return true;
  };

  this.setVariables = function (data) {
    if (window.fze) window.fze.setVariables(data);
    if (window.TCM.isMaster) {
      let command = { obj: 'WS', call: 'setVariables', arguments: data };
      window.TCM.sendCommandToDescendants(command);
    }
  };

  this.isFunctioniseAlertElement = function (e) {
    // Check if the element has the specified class
    if (e.closest('div.' + window.fUniqPrefix + '-alert') || e.classList.contains(window.fUniqPrefix + '-alert')) {
      window.fconsole.log('Functionise alert element found2 ' + e.tagName);
      return true;
    }

    window.fconsole.log('Non alert element found: ' + e.tagName);
    return false;
  };

  this.isFunctioniseElement = function (e, alertOk) {
    return window.WU.isFunctionizeElement(e, alertOk);
  };

  this.isTCMButton = function (e) {
    if (e.classList.contains(window.fUniqPrefix + '-k-button')) {
      return true;
    }
    return false;
  };

  this.addElementParentsChildData = function (e, element) {
    window.fconsole.log('Getting parent details');
    var parentData = this.getElementParentDetails(e);

    var looplimit = 10;
    var lp = 0;
    var newKey = null;
    for (let key1 in parentData) {
      var parent = parentData[key1];
      window.fconsole.log('Parent:' + JSON.stringify(parent) + ' lp' + lp);
      lp++;
      for (var key in parent) {
        if (parent[key] == null || typeof parent[key] === 'undefined') parent[key] = '';

        newKey = 'attr_parent' + key1 + '_' + key;
        if (key.indexOf('attr') > -1) {
          newKey = key.replace('attr_', 'attr_parent' + key1 + '_');
        }

        element[newKey] = parent[key];
        if (element[newKey] != null && typeof element[newKey].replace === 'function')
          // strip highlighted class from strings
          element[newKey] = element[newKey].replace('z-highlighted', '');

        if (window.WS.limitDataCapture && window.WU.isString(element[newKey])) element[newKey] = element[newKey].substring(0, 255);
      }
      if (lp > looplimit) break;
    }

    lp = 0;
    var childOuterData = this.getElementChildDetails(e);
    for (var key2 in childOuterData) {
      lp++;

      var childData = childOuterData[key2];

      for (let key1 in childData) {
        var child = childData[key1];
        if (typeof child === 'undefined' || child == null) {
          child = '';
        }
        newKey = 'attr_child' + key2 + '_' + key1;
        element[newKey] = child;
        if (element[newKey] != null && typeof element[newKey].replace === 'function')
          // strip highlighted class from strings
          element[newKey] = element[newKey].replace('z-highlighted', '');
        if (window.WS.limitDataCapture && window.WU.isString(element[newKey])) element[newKey] = element[newKey].substring(0, 255);
      }

      if (lp > looplimit) break;
    }
    return element;
  };

  this.addElementSiblingData = function (e, element) {
    try {
      var looplimit = 10;
      var lp = 0;
      var siblingData = this.elementAllSiblings(e);

      for (var key1 in siblingData) {
        var sibling = siblingData[key1];
        for (var key in sibling) {
          if (sibling[key] == null || typeof sibling[key] === 'undefined') sibling[key] = '';

          var newKey = 'attr_sibling' + key1 + '_' + key;
          if (key.indexOf('attr') > -1) {
            newKey = key.replace('attr_', 'attr_sibling' + key1 + '_');
          }

          element[newKey] = sibling[key];
          if (element[newKey] != null && typeof element[newKey].replace === 'function')
            // strip highlighted class from strings
            element[newKey] = element[newKey].replace('z-highlighted', '');

          if (window.WS.limitDataCapture && window.WU.isString(element[newKey])) element[newKey] = element[newKey].substring(0, 255);
        }
        lp++;
        if (lp >= looplimit) {
          break;
        }
      }
      return element;
    } catch (e) {}
  };

  this.getElementParentDetails = function (e) {
    var parentData = [];
    var looplimit = 10;
    var done = false;

    var lp = 0;
    var cElement = e;

    while (!done) {
      if (cElement.tagName && cElement.tagName.toLowerCase() !== 'body' && cElement.tagName.toLowerCase() !== 'html') {
        var parentElement = cElement.parentElement;
        var parent = this.getElementDetails(parentElement);

        parent.attr_element = parentElement.tagName;
        parent.attr_index = Array.from(document.querySelectorAll(parentElement.tagName))
          .filter((el) => !el.matches('.' + window.fUniqPrefix + ', .' + window.fUniqPrefix + ' *'))
          .indexOf(parentElement);

        parentData.push(parent);
        cElement = parentElement;
      } else {
        done = true;
      }
      lp++;
      if (lp >= looplimit) {
        done = true;
      }
    }
    return parentData;
  };

  this.getElementChildDetails = function (e) {
    var childData = [];
    var looplimit = 10;
    var lp = 0;
    var cElement = e;
    var children = Array.from(cElement.children);

    for (var i = 0; i < children.length; i++) {
      var child = this.getElementDetails(children[i]);
      child.attr_element = cElement.tagName;
      child.attr_index = Array.from(cElement.parentElement.querySelectorAll(cElement.tagName))
        .filter((el) => !el.matches('.' + window.fUniqPrefix + ', .' + window.fUniqPrefix + ' *'))
        .indexOf(cElement);

      childData.push(child);
      lp++;
      if (lp >= looplimit) break;
    }

    return childData;
  };

  this.elementAllSiblings = function (mainEl) {
    var allSiblings = [];
    var lElem = mainEl;
    var selfObj = this;
    var looplimit = 10;
    var lp = 0;

    // Get all siblings by using the parentNode property
    var siblings = Array.from(lElem.parentNode.children).filter((child) => child !== lElem);

    for (var i = 0; i < siblings.length; i++) {
      var cElement = siblings[i];
      var sibling = selfObj.getElementDetails(cElement);

      sibling.attr_element = cElement.tagName;
      sibling.attr_index = Array.from(cElement.parentNode.children)
        .filter((el) => el.tagName === cElement.tagName)
        .indexOf(cElement);

      if (window.WU.stringify(sibling).indexOf(window.fUniqPrefix) < 0) {
        allSiblings.push(sibling);
      }

      lp++;
      if (lp >= looplimit) break;
    }

    return allSiblings;
  };

  this.dedupeSelectors = function (element) {
    var availSelectors = [];
    var selectors = ['xpath', 'xpath2', 'xpath3', 'xpath4', 'xpath5', 'cssSelector', 'cssSelector2', 'uniqueSelectors', 'uniqueSelectorsMulti', 'secondarySelectors'];

    selectors.forEach(function (value) {
      if (availSelectors.includes(element[value])) {
        delete element[value];
      } else {
        availSelectors.push(element[value]);
      }
    });

    return element;
  };

  this.xPathToCss = function (xpath) {
    var cssSelector = '';
    try {
      cssSelector = xPathToCss(xpath);
    } catch (e) {
      window.fconsole.log('Exception parsing xpath:' + xpath + ' ' + e);
    }
    return cssSelector;
  };

  this.addFormSerialization = function (e, element) {
    var form = e.closest('form');
    var nodeTypes = ['input', 'label', 'select', 'textarea', 'button', 'fieldset', 'legend', 'datalist', 'output', 'option', 'optgroup'];

    if (form) {
      var elements = form.elements;
      var elementArray = [];

      for (var i = 0; i < elements.length; i++) {
        if (nodeTypes.includes(elements[i].nodeName.toLowerCase())) {
          elementArray.push(this.getElementDetails(elements[i]));
        }
      }

      element.formSerialized = JSON.stringify(elementArray);
    }

    return element;
  };

  this.addExtraElementData = function (e, element) {
    // window.fconsole.log("SOURAV - START");
    var windowScrollTop = window.pageYOffset || document.documentElement.scrollTop;
    var elementOffsetTop = e.getBoundingClientRect().top + windowScrollTop;
    var offsetFold = elementOffsetTop - windowScrollTop;

    element['offset_fold'] = offsetFold;

    var cElement = e;
    if (cElement.tagName.toLowerCase() !== 'html') {
      var parentElement = cElement.parentElement;
      if (parentElement) {
        var parentOffsetTop = parentElement.getBoundingClientRect().top + windowScrollTop;
        var elementOffsetParentTop = cElement.getBoundingClientRect().top + windowScrollTop;
        element['parent_offset'] = parseInt(elementOffsetParentTop) - parseInt(parentOffsetTop);
      }

      var loopLimit = 10;
      var done = false;
      var scrollOffset = 0;
      var lp = 0;

      while (!done) {
        if (cElement.tagName) {
          cElement = cElement.parentElement;
          if (cElement) {
            scrollOffset = cElement.scrollTop || 0;
            if (scrollOffset > 0) {
              done = true;
            }
          } else {
            done = true;
          }
        } else {
          done = true;
        }

        lp++;
        if (lp >= loopLimit) {
          done = true;
        }
      }

      if (scrollOffset) {
        element['scroll_offset'] = scrollOffset;
      }
    }

    return element;
  };

  this.formatelementData = function (e, element) {
    try {
      var dataFunctionizeDisabled = e.getAttribute('data-functionize-disabled') || '';
      if (dataFunctionizeDisabled === 'disabled') {
        element['attr_disabled'] = 'disabled';
      }

      for (var index in element) {
        if (index.startsWith('verify')) {
          delete element[index];
        }
      }

      if (e.hasAttribute('f-disabled')) {
        delete element['attr_f-disabled'];
        delete element['attr_disabled'];
      }

      return element;
    } catch (error) {
      // Handle errors if necessary
    }
  };

  this.checkWindowNavigateState = function () {
    var waitString = '<div class="' + window.fUniqPrefix + '_formError f-hide_event"></div><div class="' + window.fUniqPrefix + '_navigate_state_div"><table>';

    waitString +=
      '<tr><td colspan="2" style="line-height: 20px;padding-bottom: 12px;"><label>We have observed that the browser navigation buttons were used for this action. Select the correct navigation option used in this action:</label></td></tr>';

    waitString +=
      '<tr><td style="text-align: left;width: 120px;"><label>Navigate Type:</label></td><td><input type="radio" value="back" name="' +
      window.fUniqPrefix +
      '_navigate_state_type"><label>Back</label><input type="radio" value="forward" name="' +
      window.fUniqPrefix +
      '_navigate_state_type"><label>Forward</label></td></tr>';

    waitString += '</table></div>';
  };

  this.isValidURL = function (url) {
    var isValidURL = true;
    var enter = false;
    let testingUrls = [];
    if (typeof window.WS.testing_urls == 'string') {
      testingUrls = JSON.parse(window.WS.testing_urls);
    }
    if (testingUrls && testingUrls.length) {
      testingUrls.forEach((attr) => {
        if (!enter) {
          isValidURL = false;
          enter = true;
        }
        if (url.indexOf(attr) > -1) {
          isValidURL = true;
        }
      });
    }
    return isValidURL;
  };

  this.getSelectionCharOffsetsWithin = function (element, originalElement) {
    function calculateOffset(pElement, container, offset) {
      let position = 0;
      const walker = document.createTreeWalker(pElement, NodeFilter.SHOW_TEXT, null, false);
      let currentNode = walker.nextNode();
      while (currentNode) {
        if (currentNode === container) {
          position += offset;
          break;
        } else {
          position += currentNode.textContent.length;
        }
        currentNode = walker.nextNode();
      }
      return position;
    }
    function getSelectionPositions(pElement) {
      const selection = window.getSelection();
      if (selection.rangeCount === 0) {
        console.log('No selection made');
        return;
      }
      const range = selection.getRangeAt(0);
      if (!range.intersectsNode(pElement)) {
        console.log('Selection is outside the specified element');
        return;
      }
      const startContainer = range.startContainer;
      const startOffset = range.startOffset;
      const endContainer = range.endContainer;
      const endOffset = range.endOffset;
      //console.log('Start Container:', startContainer);
      //console.log('Start Offset:', startOffset);
      //console.log('End Container:', endContainer);
      //console.log('End Offset:', endOffset);
      const startPosition = calculateOffset(pElement, startContainer, startOffset);
      const endPosition = calculateOffset(pElement, endContainer, endOffset);
      return { start: startPosition, end: endPosition };
    }

    var start = 0;
    var end = 0;
    var offset = 0;
    var sel, range, priorRange;
    if (typeof window.getSelection !== 'undefined') {
      if (document.activeElement && (document.activeElement.tagName.toLowerCase() == 'textarea' || document.activeElement.tagName.toLowerCase() == 'input')) {
        start = document.activeElement.selectionStart;
        end = document.activeElement.selectionEnd;
      } else {
        sel = window.getSelection();
        range = sel.getRangeAt(0);

        start = range.startOffset;
        end = range.endOffset;

        if (sel.baseNode.parentNode.hasChildNodes()) {
          for (var i = 0; sel.baseNode.parentNode.childNodes.length > i; i++) {
            var cnode = sel.baseNode.parentNode.childNodes[i];

            if (originalElement && cnode === originalElement) {
              break;
            }

            if (cnode.nodeType == document.TEXT_NODE) {
              /*
              if (offset + cnode.length > start) {
                break;
              }
               */
              offset = offset + cnode.length;
            } else if (cnode.nodeType == document.ELEMENT_NODE) {
              /*
              if (offset + cnode.textContent.length > start) {
                break;
              }
              */
              offset = offset + cnode.textContent.length;
            }
          }
        }
        start = start + offset;
        end = end + offset;

        console.log('position 1', start, end, element);

        const position = getSelectionPositions(element);

        console.log('position 2', position.start, position.end, cnode);
        if (start != position.start && end != position.end) {
          start = position.start;
          end = position.end;
        }
      }
    } else if (typeof document.selection !== 'undefined' && (sel = document.selection).type != 'Control') {
      console.log('getSelectionCharOffsetsWithin DOWN HERE');
      range = sel.createRange();
      priorRange = document.body.createTextRange();
      priorRange.moveToElementText(element);
      priorRange.setEndPoint('EndToStart', range);
      start = priorRange.text.length;
      end = start + range.text.length;
    }
    return {
      start: start,
      end: end,
    };
  };

  this.removeVerifyAttributes = function (element) {
    for (let index in element) {
      if (index.startsWith('verify') || index.startsWith('elementCode') || index.startsWith('elementSelect')) {
        delete element[index];
      }
    }
    return element;
  };

  this.getUniqueSelector = function (actionData) {
    var selfObj = this;
    var lastInputActionSelector = actionData.cssSelector;
    var selectors = ['xpath', 'xpath2', 'xpath3', 'xpath4', 'xpath5', 'cssSelector', 'cssSelector2', 'uniqueSelectors', 'uniqueSelectorsMulti', 'secondarySelectors'];

    selectors.forEach((value) => {
      if (actionData[value] !== undefined && actionData[value]) {
        window.fconsole.log('Trying selector ' + value);
        var selector = actionData[value];
        var cssSelector = selector;
        if (value.indexOf('css') !== 0) cssSelector = selfObj.xPathToCss(selector);

        try {
          var elements = document.querySelectorAll(cssSelector);
          if (elements.length !== 1) {
            window.fconsole.log('Selector returned ' + elements.length + ' elements. Skipping...');
            return;
          }
        } catch (e) {
          window.fconsole.log('Selector did not work: ' + cssSelector + ' ' + e);
          return;
        }

        try {
          var elementSelector = document.querySelector(cssSelector);
          getComputedStyle(elementSelector, null);
          lastInputActionSelector = cssSelector;
          window.fconsole.log('Setting unique selector:  ' + value);
        } catch (e) {
          window.fconsole.log('Selector did not work: ' + cssSelector + ' ' + e);
        }
      }
    });
    return lastInputActionSelector;
  };

  this.restoreActionLogByInstructionStep = function (stepNo) {
    for (var i = this.recordedData.length - 1; i > 0; i--) {
      var action = this.recordedData[i];
      if (action.instruction_step >= stepNo) {
        this.recordedData.pop();
        this.decrementActionCount();
      } else break;
    }
    this.recordWbData();
    return true;
  };
} // Webinage sender

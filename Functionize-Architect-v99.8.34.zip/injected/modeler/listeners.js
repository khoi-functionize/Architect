import { functioniseChangeListener } from './listeners/functioniseChangeListener';
import {
  functioniseScrollListener,
  functioniseClickListener,
  functioniseFocusListener,
  functionisePointerdownListener,
  functioniseTouchMoveListener,
  functionisePointerupListener,
  functioniseMousedownListener,
  functioniseMouseupListener,
  functioniseMouseoverListener,
  functioniseMouseoutListener,
  functioniseMouseenterListener,
  functioniseKeydownListener,
  functioniseKeyupListener,
  functioniseInputListener,
  functioniseContextMenuListener,
  functioniseMousemoveListener,
  functionizePointermoveListener,
  functioniseDragstartListener,
  functioniseDragdropListener,
  functioniseDragoverListener,
  functioniseDragenterListener,
  functioniseDragleaveListener,
  functioniseDragendListener,
  functioniseFullscreenchangeListener,
  functioniseBeforePrintListener,
  functioniseAfterPrintListener,
  functioniseMessageListener,
  functionizeResizeListener,
  functionisePointerupWindowListener,
  functioniseClickWindowListener,
  functioniseMouseupWindowListener,
  // functioniseBeforeUnloadListener,
} from './listeners/allListeners';

/**
 * File containing logic that replaces event listeners in the document
 */

export function removeFunctioniseListeners() {
  window.functioniseListenersAdded = false;
  document.removeEventListener('input', functioniseInputListener, true);
  document.removeEventListener('scroll', functioniseScrollListener, true);
  document.removeEventListener('click', functioniseClickListener, true);
  window.removeEventListener('click', functioniseClickWindowListener, true);
  document.removeEventListener('focus', functioniseFocusListener, true);
  document.removeEventListener('pointerdown', functionisePointerdownListener, true);
  document.removeEventListener('touchmove', functioniseTouchMoveListener, { passive: false });
  document.removeEventListener('pointerup', functionisePointerupListener, true);
  window.removeEventListener('pointerup', functionisePointerupWindowListener, true);
  document.removeEventListener('mousedown', functioniseMousedownListener, true);
  document.removeEventListener('mouseup', functioniseMouseupListener, true);
  window.removeEventListener('mouseup', functioniseMouseupWindowListener, true);
  document.removeEventListener('mouseover', functioniseMouseoverListener, true);
  document.removeEventListener('mouseenter', functioniseMouseenterListener, true);
  document.removeEventListener('mouseout', functioniseMouseoutListener, true);
  document.removeEventListener('keydown', functioniseKeydownListener, true);
  document.removeEventListener('keyup', functioniseKeyupListener, true);
  document.removeEventListener('contextmenu', functioniseContextMenuListener, false);
  document.removeEventListener('change', functioniseChangeListener, true);
  // document.addEventListener('blur', functioniseBlurListener, true);
  document.removeEventListener('mousemove', functioniseMousemoveListener, true);
  document.removeEventListener('dragstart', functioniseDragstartListener, true);
  document.removeEventListener('drop', functioniseDragdropListener, true);
  document.removeEventListener('dragover', functioniseDragoverListener, true);
  document.removeEventListener('dragend', functioniseDragendListener, true);
  document.removeEventListener('dragenter', functioniseDragenterListener, true);
  document.removeEventListener('dragleave', functioniseDragleaveListener, true);
  document.removeEventListener('mozfullscreenchange', functioniseFullscreenchangeListener, true);
  window.removeEventListener('beforeprint', functioniseBeforePrintListener, true);
  window.removeEventListener('afterprint', functioniseAfterPrintListener, true);
  window.removeEventListener('message', functioniseMessageListener, true);
  window.removeEventListener('resize', functionizeResizeListener, true);
  window.removeEventListener('pointermove', functionizePointermoveListener, true);
  // window.removeEventListener('beforeunload', functioniseBeforeUnloadListener, true);
}

export function addFunctioniseListeners() {
  window.functioniseMouseTimer = null;
  window.lastMousemoveElement = null;
  window.functioniseListenersAdded = true;

  window.removeFunctioniseListeners = removeFunctioniseListeners;
  removeFunctioniseListeners();

  document.addEventListener('input', functioniseInputListener, true);
  document.addEventListener('scroll', functioniseScrollListener, true);
  document.addEventListener('click', functioniseClickListener, true);
  window.addEventListener('click', functioniseClickWindowListener, true);
  document.addEventListener('focus', functioniseFocusListener, true);
  document.addEventListener('pointerdown', functionisePointerdownListener, true);
  document.addEventListener('touchmove', functioniseTouchMoveListener, { passive: false });
  document.addEventListener('pointerup', functionisePointerupListener, true);
  window.addEventListener('pointerup', functionisePointerupWindowListener, true);
  document.addEventListener('mousedown', functioniseMousedownListener, true);
  document.addEventListener('mouseup', functioniseMouseupListener, true);
  window.addEventListener('mouseup', functioniseMouseupWindowListener, true);
  document.addEventListener('mouseover', functioniseMouseoverListener, true);
  document.addEventListener('mouseenter', functioniseMouseenterListener, true);
  document.addEventListener('mouseout', functioniseMouseoutListener, true);
  document.addEventListener('keydown', functioniseKeydownListener, true);
  document.addEventListener('keyup', functioniseKeyupListener, true);
  document.addEventListener('contextmenu', functioniseContextMenuListener, false);
  document.addEventListener('change', functioniseChangeListener, true);
  // document.addEventListener('blur', functioniseBlurListener, true);
  document.addEventListener('mousemove', functioniseMousemoveListener, true);
  document.addEventListener('dragstart', functioniseDragstartListener, true);
  document.addEventListener('dragenter', functioniseDragenterListener, true);
  document.addEventListener('dragleave', functioniseDragleaveListener, true);
  document.addEventListener('drop', functioniseDragdropListener, true);
  document.addEventListener('dragover', functioniseDragoverListener, true);
  document.addEventListener('dragend', functioniseDragendListener, true);
  document.addEventListener('mozfullscreenchange', functioniseFullscreenchangeListener, true);
  window.addEventListener('beforeprint', functioniseBeforePrintListener, true);
  window.addEventListener('afterprint', functioniseAfterPrintListener, true);
  window.addEventListener('message', functioniseMessageListener, true);
  window.addEventListener('resize', functionizeResizeListener, true);
  window.addEventListener('pointermove', functionizePointermoveListener, true);
  // window.addEventListener('beforeunload', functioniseBeforeUnloadListener, true);
}

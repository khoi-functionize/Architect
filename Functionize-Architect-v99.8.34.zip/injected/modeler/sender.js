import { WebionageUtils } from './webionageutils';
import { SeleniumBridge } from './seleniumbridge';
import * as tester from '../tester/tester';
import { addFunctioniseListeners, removeFunctioniseListeners } from './listeners';
import { injectCSS } from '../tester/cssInjector';

var vex = require('vex-js');
vex.registerPlugin(require('vex-dialog'));
vex.defaultOptions.className = `vex-theme-os ${window.fUniqPrefix}-alert`;

export function initSender() {
  // Initialize Main Objects
  console.log('functionise.js Functionise hello');

  window.functioniseAddOn = true;

  // set cookies & variables for functionize if the sandbox environment is set to true
  // set app flag for non app use cases
  if (typeof window.functioniseApp == 'undefined') window.functioniseApp = false;

  if (typeof window.fzeBrowser == 'undefined' || !window.fzeBrowser) window.fzeBrowser = {};

  //if (typeof self == 'undefined' || typeof self.port == 'undefined') {
  //plugin messaging in chrome...
  //mobile
  //if (typeof window.Ti != 'undefined') {
  //  alert('App found');
  //  window.self = {
  //    port: {
  //      emit: function(event, command) {
  //        window.Ti.App.fireEvent('app:fromWebView', { message: JSON.stringify(command) });
  //     },
  //   },
  // };
  //} else {
  //}

  //add listener for page scripts
  window.addEventListener(
    'functionize-page-message',
    function (event) {
      var method = event.detail.method;
      switch (method) {
        case 'wait':
        case 'navigate':
        case 'projectVariable':
        case 'pageVariables':
        case 'setCookie':
        case 'setHTMLStorage':
          window.seleniumBridge.triggerSimpleAction(event);
          break;
        case 'apicall':
        case 'smsreceive':
        case 'fileViewer':
        case 'DBExplorer':
        case 'emailreceive':
          window.seleniumBridge.triggerFunctionizeAppActions(event);
          break;
        default:
          window.seleniumBridge.triggerAction(event);
      }
    },
    false
  );

  //port init for plugin communications...
  if (typeof self.port !== 'undefined' && typeof self.port.on === 'function') {
    //Firefox
    self.port.on('message', pluginEventListener);
  } else if (typeof chrome !== 'undefined') {
    // eslint-disable-next-line no-unused-expressions
    chrome.runtime?.onMessage?.addListener(function (request, _sender, sendResponse) {
      //window.fconsole.log(sender.tab ? "from a content script:" + sender.tab.url : "from the extension");
      if (request.hasOwnProperty('keepAliveMessage')) {
        sendResponse({ time: Date.now() });
        return true;
      }
      pluginEventListener(request);
    });

    if (typeof window.chromePort !== 'undefined') {
      //document.addEventListener("message",pluginEventListener); //chrome version
      window.chromePort.onMessage.addListener(function (request, sender, sendResponse) {
        window.fconsole.log('Listener triggered', request, sender, sendResponse);
        pluginEventListener(request);
      });

      window.self = {
        port: {
          emit: function (event, command) {
            window.fconsole.log('Sending chrome message...', command);
            window.fconsole.log(window.chromePort);
            try {
              window.chromePort.postMessage(command);
            } catch (e) {
              window.fconsole.log('Chrome message exception: ' + e.message);
            }
          },
        },
      };
    } else {
      console.log('Chrome port is undefined');
      (async () => {
        while (typeof window.chromePort == 'undefined') {
          console.log('Chrome port is undefined');
          console.log('waiting...');
          await new Promise((resolve) => setTimeout(resolve, 100));
        }
        console.log('Chrome port is defined');
        window.chromePort.onMessage.addListener(function (request, sender, sendResponse) {
          window.fconsole.log('Listener triggered', request, sender, sendResponse);
          pluginEventListener(request);
        });

        if (typeof self == 'undefined' || typeof self.port == 'undefined') {
          window.self = {
            port: {
              emit: function (event, command) {
                window.fconsole.log('Sending chrome message...', command);
                window.fconsole.log(window.chromePort);
                try {
                  window.chromePort.postMessage(command);
                } catch (e) {
                  window.fconsole.log('Chrome message exception: ' + e.message);
                }
              },
            },
          };
        }
      })();
    }
  }

  if (typeof window.functionizePluginInstalled == 'undefined') window.functionizePluginInstalled = false;

  if (typeof window.functionizeIsSeleniumTest == 'undefined')
    //raw selenium scripts run through our recorder...
    window.functionizeIsSeleniumTest = false;

  if (window.functionizeIsSeleniumTest) {
    window.seleniumBridge = new SeleniumBridge();
  }

  window.isFunctioniseReloaded = false;

  //var functioniseControlEnabled = true;
  window.advancedPanelInjected = false;

  if (window.isFunctioniseLoaded) {
    window.fconsole.log('Functionise has already been loaded.');
    document.addEventListener('DOMContentLoaded', function () {
      if (window.TCM) {
        window.TCM.removeCoverer();
      }
    });
    //just to be sure....
    window.isFunctioniseReloaded = true;
  }
  if (!window.isFunctioniseReloaded) {
    //if loaded only once

    window.isFunctioniseLoaded = true;
    window.functionisePreinitReady = false;
    window.isFunctioniseCompatible = true;
    if (typeof window.isFunctioniseTester == 'undefined') window.isFunctioniseTester = false;

    if (typeof window.isPopup == 'undefined') window.isPopup = false;

    if (typeof window.popupUID == 'undefined') window.popupUID = '';

    window.isFunctionised = false;
    window.TH = null; // tooltip herler
    window.WS = null; ///web sender
    window.TCM = null; //   test case manager
    window.WU = new WebionageUtils();
    window.WU.init();
    window.AMD = null;
    window.ZStyles = null;
    window.ZDealCss = null;
    window.MC = null; // meta checker
    window.functioniseHttpServer = 'http://app.functionize.com/';
    window.functioniseHttpsServer = 'https://app.functionize.com/';
    window.functioniseHttpHost = 'app.functionize.com';
    window.functionizeCouldHttpHost = 'storage-download.googleapis.com';
    window.functionizeCloudStorage = 'storage-download.googleapis.com/functionize-public';
    window.functionisePreInitMessages = new Array();
    window.fUniqPrefix = 'f-functionise';
    window.fTopZindex = null; //top zindex found on the page….
    window.functioniseRegisterRetry = null;
    window.functioniseRegisterRetryCount = 0;
    window.functioniseRegisterMaxRetryCount = 60; //15 seconds
    window.functioniseWindowLoadedEvent = false;
    window.functionizeIframeIndex = 0;
    window.functionizeElementMutationStorage = {};
    window.pluginEventListener = pluginEventListener;
    window.functionizeVex = vex;
    window.removeFunctioniseListeners = removeFunctioniseListeners;
    window.addFunctioniseListeners = addFunctioniseListeners;

    if (window.location == null) {
      window.location = { protocol: 'https:' };
    }

    if (typeof functioniseControlTabId != 'undefined') {
      //plugin based recording add css immediately
      if (window.canAddHTML) {
        injectCSS('styles/functionise.css');
      }
    }
    window.onerror = function (msg) {
      if (window.functioniseJsErrors == '') {
        window.functioniseJsErrors = msg;
      } else {
        window.functioniseJsErrors = msg + '|' + window.functioniseJsErrors;
      }
    };

    if (document.readyState != 'loading') {
      //in case the ready is not called (later attachement??)
      window.fconsole.log('Documment is ready');
      functioniseDocumentReady();
    } else {
      document.addEventListener('DOMContentLoaded', function () {
        functioniseDocumentReady();
      });
      //just in case... we have seen some cases where it does not get called
      window.functionizeDomcheck = setInterval(function () {
        if (document.readyState != 'loading') functioniseDocumentReady();
      }, 10);
      window.addEventListener('load', (event) => {
        if (document.readyState != 'loading') {
          functioniseDocumentReady();
        }
      });

      document.addEventListener('readystatechange', (event) => {
        if (document.readyState != 'loading') {
          functioniseDocumentReady();
        }
      });

      document.addEventListener('DOMContentLoaded', (event) => {
        if (document.readyState != 'loading') {
          functioniseDocumentReady();
        }
      });
    }
  }
}

export function pluginEventListener(d) {
  // ignore vuex sync messages
  if (d && d.hasOwnProperty('type') && d.type === '@@STORE_SYNC_MUTATION') return;
  window.fconsole.log('Data received: ' + JSON.stringify(d));
  if (window.functioniseApp) {
    d = decodeURIComponent(d);
  }

  var data;
  if (typeof window.Ti != 'undefined') {
    //coming from an app call...
    try {
      data = JSON.parse(d);
    } catch (e) {
      window.fconsole.log(e.message);
    }
  } else if (d != null && typeof d.detail != 'undefined') {
    //chrome
    data = d.detail;
  } else {
    //FF
    data = d;
  }

  if (data == null || data.obj == null || data.call == null) {
    window.fconsole.log('Plugin data received as null');
    return;
  }

  if (typeof data.meta == 'undefined') data.meta = {};

  if (window.WS == null) {
    window.fconsole.log('WS is not ready...    queuing message...');
    queuedMessages.push(d);
    retryQueuedMessages();
    return;
  }

  if (typeof data.meta.UID != 'undefined') {
    if (data.meta.UID != window.WS.iframeUID && data.meta.UID != window.WS.popupUID) {
      //message was not intended for this frame or window so ignore
      //PLUGIN IS CONTROLING THIS NOW….
    } else if (data.meta.UID == window.WS.iframeUID) {
      //we set iframeIndex as it was passed back
    } else if (data.meta.UID == window.WS.popupUID) {
      //we set iframeIndex as it was passed back
      if (typeof data.meta.index != 'undefined') {
        window.WS.popupIndex = data.meta.index;
        //ping back???
      }
    }
  }

  //we now check if the message has an ignore UID meaning we should not execute it
  if (window.WS.isIframe && typeof data.meta.ignoreIframeUID != 'undefined' && data.meta.ignoreIframeUID == window.WS.iframeUID) {
    window.fconsole.log('Skipping on ignore UID match');
    return;
  }

  //we now check if the message has an ignore UID meaning we should not execute it
  if (window.WS.isPopup && typeof data.meta.ignorePopupUID != 'undefined' && data.meta.ignorePopupUID == window.WS.popupUID) {
    window.fconsole.log('Skipping on ignore UID match');
    return;
  }

  //Ignore messages bound for iframe that are not registered.
  if (window.WS.isIframe && !window.TCM.hasSentRegistration) {
    if (data.call == 'requestRegistration') {
      window.fconsole.log('Iframe  is not yet registered - queuing reg request');
      queuedMessages.push(d);
      retryQueuedMessages();
      return;
    }
    window.fconsole.log('Iframe  is not yet registered - ignoring messages');
  }
  window.fconsole.log('Calling object');
  if (data.call == 'requestRegistration') {
    clearTimeout(window.functionizeRequestRegistrationTimer);
    window.functionizeRequestRegistrationTimer = setTimeout(() => {
      callObjectFromPlugin(data);
    }, 100);
    return;
  }
  callObjectFromPlugin(data);
}

//message queue that we got before WS was initialized...
var queuedMessages = new Array();
export function retryQueuedMessages() {
  if (queuedMessages.length < 1) return;
  if (window.WS == null) {
    window.fconsole.log('WS is null.      queuing message with ' + queuedMessages.length + ' of messages');
    setTimeout(function () {
      retryQueuedMessages();
    }, 100);
    return;
  }
  while (queuedMessages.length > 0) {
    window.fconsole.log('Resending queued messages...');
    pluginEventListener(queuedMessages.shift());
  }
}

//hook for plugin
export function callObjectFromPlugin(data) {
  window.fconsole.log('Object call received: ' + data.obj + ' ' + data.call);
  if (data.obj != 'window' && window[data.obj] == null) {
    //we are not ready yet to accept calls.    We need to retry these in a little bit.
    if (typeof data.tryCount == 'undefined') data.tryCount = 0;

    data.tryCount++;
    if (data.tryCount < 20)
      setTimeout(function () {
        callObjectFromPlugin(data);
      }, 100);

    return;
  }
  if (typeof data.arguments != 'undefined') {
    if (!Array.isArray(data.arguments)) {
      window.fconsole.log('Calling object with call:' + data.call);
      try {
        try {
          if (typeof data.meta != 'undefined')
            //assign meta as we need it going forward
            data.arguments.meta = data.meta;
        } catch (e) {}
        if (data.obj != 'window') {
          window[data.obj][data.call](data.arguments);
        }
        //window[data.obj][data.call].apply(null, new Array(data.arguments));
        else window[data.call].apply(null, new Array(data.arguments));
      } catch (e) {
        console.error('Exception calling obj: ', e, data);
      }
    } else {
      try {
        if (data.call == 'receiveMultiMessage') {
          //this requires the below call need to figure out why...
          if (data.obj != 'window') window[data.obj][data.call](data.arguments);
          else window[data.call](data.arguments);
        } else {
          if (data.obj != 'window') window[data.obj][data.call].apply(null, data.arguments);
          else window[data.call].apply(null, data.arguments);
        }
      } catch (e) {
        window.fconsole.log('Exception calling obj: ' + e);
      }
    }
  } else {
    try {
      if (data.obj != 'window') window[data.obj][data.call]();
      else window[data.call]();
    } catch (e) {
      window.fconsole.log('Exception calling obj: ' + e);
    }
  }
}

const functioniseDocumentReady = function () {
  console.log('fdocument ready called functioniseDocumentReady');
  clearInterval(window.functionizeDomcheck);
  //we decide here to overlay waiting window until page is fully loaded or not
  //overlays should be from window above
  if (document.body === null && document.getElementsByTagName('frameset').length < 1) {
    //alert('Unable to start modeling. No body tag detected on page!');
    console.log('no body tag detected… functioniseDocumentReady');
    return;
  } else if (document.body === null) {
    //we check for the body tag...
    console.log('Creating a body as it does not exist functioniseDocumentReady');
    var body = document.createElement('body');
    var nodeToAppendTo = document.firstChild;
    var it = 0;
    while (nodeToAppendTo.nodeType == Node.COMMENT_NODE) {
      it++;
      nodeToAppendTo = nodeToAppendTo.nextElementSibling;
      window.fconsole.log('New node considered ' + nodeToAppendTo);
      if (it > 100) break;
    }
    window.fconsole.log('New node considered ' + nodeToAppendTo);
    try {
      nodeToAppendTo.appendChild(body);
      document.body.style.position = 'absolute';
      document.body.style.top = '0px';
      document.body.style.left = '0px';
    } catch (e) {
      console.log();
    }
  }
  if (!window.isFrameset) {
    window.fconsole.log('fready with l=' + document.getElementsByTagName('body').length);
  }

  window.fTopZindex = window.WU.getTopZindex();

  window.fconsole.log(window.WU.store('functionise'));
  window.fconsole.log(window.WU.cookie('functionise'));
  if (
    window.WU.storeAndCookie('functionise') == 'true' ||
    document.referrer.indexOf(window.functioniseHttpHost) > -1 ||
    window.functioniseApp ||
    window.functionizeStandalone ||
    window.isRuntimeDebug
  ) {
    //add our css class
    //remove the one added by the plugin
    window.fconsole.log('Removing cover #' + window.fUniqPrefix + '-loading');
    var loadingElement = document.getElementById(window.fUniqPrefix + '-loading');

    if (loadingElement) {
      loadingElement.remove();
    } else {
      window.fconsole.log('cover not found... setting timeout on remove action');
      window.functionizeLoaderRemove = setInterval(() => {
        var loadingElementInterval = document.getElementById(window.fUniqPrefix + '-loading');
        if (loadingElementInterval) {
          loadingElementInterval.remove();
          clearInterval(window.functionizeLoaderRemove);
        }
      }, 250);
    }

    injectCSS('styles/functionise.css');
    window.isFunctioniseTester = true;
  } else {
    window.fconsole.log('Functionize Cookie and referrer not found. Functionize tester not enabled.');
  }

  //if iframe uid is set listeners are already attached...
  //addFunctioniseListeners();
  addFunctioniseListeners();
  window.functioniseListenersAdded = true;

  console.log('addon ' + window.functioniseAddOn + ' ' + window.functioniseSession);

  if (window.functioniseAddOn && window.functioniseSession) {
    //we need to explicitly call this from the extension
    console.log('Setting session');
    window.WU.storeAndCookie('functioniseSession', window.functioniseSession);
    window.WU.storeAndCookie('functionise', 'true', { expires: 3650, path: '/' });
    console.log('set timeout for window load', functioniseWindowLoaded);
    setTimeout(function () {
      console.log('call functioniseWindowLoaded', functioniseWindowLoaded);
      functioniseWindowLoaded();
    }, 200); //give time for the rest of teh script to init...
  } else if (window.functioniseApp) {
    console.log('set timeout for window load');
    setTimeout(function () {
      functioniseWindowLoaded();
    }, 200); //give time for the rest of teh script to init...
  } else {
    console.log('adding window load event');
    setTimeout(function () {
      functioniseWindowLoaded();
    }, 200); //give time for the rest of teh script to init...
  }
};

window.functioniseDocumentReady = functioniseDocumentReady;
//run tume script call...
export function getFunctionised() {
  if (window.isFunctionised) {
    return true;
  }
  window.isFunctionised = true;
  /*
	TODO: commenting this out because we don't use the functionise.js in this injected script
		if (typeof inc == 'undefined')
			window.inc = false;

		if (window.inc) {
			//add full js stuff here…
			var s = document.createElement("script");
			s.type = "text/javascript";
			s.src = window.location.protocol + '//' + window.functioniseHttpHost + '/wbjs/functionised.js';
			//s.src = window.location.protocol+'//'+window.functionizeCloudStorage+'/functionised.js';
			window.fconsole.log("Adding script " + s);
			document.head.appendChild(s);
		} else {
			window.fconsole.log("Functionised is initing");
			initFunctionised();
		}*/
  return true;
}

export function isFunctioniseRegistered() {
  if (window.TCM == null) {
    return false;
  }
  return window.TCM.registered;
}

export function retryFunctioniseRegister(arg) {
  try {
    window['registered'].apply(null, arg);
    clearInterval(window.functioniseRegisterRetry);
    window.functioniseRegisterRetryCount++;
  } catch (e) {
    window.fconsole.log(e);
  }
}

export function functioniseWindowLoaded() {
  try {
    console.log('load event');
    //if using the add on this could get called multiple times.     Do not touch...
    if (window.functioniseWindowLoadedEvent) {
      console.log('Load event already fired');
      return;
    }
    document.querySelectorAll('textarea').forEach((textarea) => {
      textarea.style.resize = 'none';
    });
    window.functioniseWindowLoadedEvent = true;
    //signal that the document is ready
    if (window.canAddHTML) {
      document.body.setAttribute('functioniseloaded', 'true');
    }

    /* For testing only */
    if (window.WU.getParameterByName('registerFunctionised') == '1') {
      console.log('Getting functionised');
      getFunctionised();
    }
    console.log('load event2');
    if (window.WU.getParameterByName('registerFunctionise') == 'true') {
      window.fconsole.log('Registering functionise');
      window.WU.cookie('functionise', 'true', { expires: 3650, path: '/' });
      window.WU.store('functionise', 'true');
      window.WU.cookie('functioniseSession', window.WU.getParameterByName('functioniseSession'));
      window.WU.store('functioniseSession', window.WU.getParameterByName('functioniseSession'));
      if (window.WU.getParameterByName('functioniseDemo') == 'true') {
        window.WU.storeAndCookie('functioniseDemo', 'true');
      } else {
        window.WU.storeAndCookie('functioniseDemo', 'false');
      }

      var session = window.WU.getParameterByName('functioniseSession');
      var command = {
        obj: 'window',
        call: 'domainRegistered',
        arguments: { urlHash: window.WU.getParameterByName('urlHash') },
        meta: { functioniseSession: session, functioniseToken: window.functioniseToken },
      };
      var browser = window.WU.getBrowser();
      if (browser.name == 'msie' && parseFloat(browser.version) < 10) command = JSON.stringify(command);

      try {
        console.log('sending registration', command);
        if (window.MessageChannel) {
          var m = new MessageChannel();
          window.parent.postMessage(command, '*', [m.port2]);
          console.log('sending to m.port2', [m.port2]);
        } else {
          console.log('sending to parent *');
          window.parent.postMessage(command, '*');
        }
      } catch (e) {
        // window.console.log('Unable to send message to target:' + window.WU.stringify(target) + ' with error:' + e);
      }

      var url = window.functioniseHttpsServer + 'starttest/register?c=' + window.WU.getParameterByName('functioniseSession') + '&did=' + window.WU.getParameterByName('did');
      function fetchJsonp(url, callback) {
        console.log('fetchJsonp');
        const script = document.createElement('script');
        const callbackName = `jsonpCallback_${Date.now()}`;

        window[callbackName] = function (data) {
          delete window[callbackName];
          document.body.removeChild(script);
          if (callback) callback(data);
        };

        script.src = `${url}?callback=${callbackName}`;
        document.body.appendChild(script);
      }

      fetchJsonp(url, function (data) {});
      return;
    }

    window.fconsole.log('load event3');

    //not to do add invalid browsers to the list of skips
    if (window.WU.cookie('functionise') == 'false' && document.referrer.indexOf(window.functioniseHttpHost) < 0) {
      // window.console.log('Functionise off…');
      return;
    } else {
      console.log('continue');
    }

    window.fconsole.log('Referrer: ' + document.referrer);

    if (window.WU.cookie('functionise') == 'true' || window.WU.store('functionise') == 'true') {
      //TCM.enableFunctionise();
      // window.console.log('Functionise found at ');
      window.isFunctioniseTester = true;
      window.WU.cookie('functionise', 'true', { expires: 3650, path: '/' });
      window.WU.store('functionise', 'true');
    } else {
      console.log('PROBLEM: Functionise not found but setting anyway');
      window.isFunctioniseTester = true;
      window.WU.cookie('functionise', 'true', { expires: 3650, path: '/' });
      window.WU.store('functionise', 'true');
    }

    if (window.isFunctioniseTester) {
      window.functionisePreinitReady = true;
      if (document.location != null) window.fconsole.log('Adding tester javascript file on ' + document.location.href);
      else window.fconsole.log('Adding tester javascript file on null');

      injectCSS('styles/functionise.css');

      console.log('Calling preInit.... ' + window.functionisePreinitReady);
      tester.preInitFunctionise();
    } else {
      if (document.location != null) window.fconsole.log('No testing environment found on ' + document.location.href);
      else window.fconsole.log('No testing environment found on null');
      var element = document.getElementById(window.fUniqPrefix + '-loading');
      if (element) {
        element.parentNode.removeChild(element);
      }
    }
  } catch (e) {
    window.fconsole.log(e);
  }
}

export { functioniseDocumentReady };

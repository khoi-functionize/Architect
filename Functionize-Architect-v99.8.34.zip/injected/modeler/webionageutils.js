import { wsElement } from './common';
import { initStyleInterval } from '../lib/jq-style';
import tippy from 'tippy.js';

//Webionage Utils object here
export function WebionageUtils() {
  this.currentBrowser = null;
  this.searchEngne = null;
  this.coveredElementClasses = new Array();
  this.nodeCheck = false;
  this.events = {};
  this.eventElements = new Array();
  this.hoverClasses = new Array();
  this.jquerySpecialChars = '!"#$%&\'()*+,./:;<=>?@[]^`{|}~'.split('');
  this.lastHiderPosition = { left: 0, top: 0 };
  this.textCharacterLimit = 10000; //only api explorer URLs will get higher limits
  this.svgTags = new Array();
  this.htmlEncoderDiv = document.createElement('div');
  this.adjustZIndexElements = {};
  this.tippyInstance = false;
  this.tippyElement = false;

  this.init = function () {
    initStyleInterval();
  };

  this.getOffset = function (element) {
    let rect = element.getBoundingClientRect();
    let win = element.ownerDocument.defaultView;
    return {
      top: rect.top + win.pageYOffset,
      left: rect.left + win.pageXOffset,
    };
  };

  this.showTippy = function (element, content) {
    window.WU.tippyElement = element;
    window.WU.destroyTippyInstance();
    return tippy(element, {
      content: content,
      allowHTML: true,
      theme: 'functionize',
    });
  };

  this.destroyTippyInstance = function () {
    if (window.WU.tippyInstance) {
      window.WU.tippyInstance.destroy();
      window.WU.tippyInstance = false;
    }
  };

  this.elementIsHidden = function (el) {
    var style = window.getComputedStyle(el);
    return style.display === 'none' || style.visibility === 'hidden';
  };

  this.cleanStringForXpath = function (str) {
    if (str.indexOf("'") < 0 && str.indexOf('"') < 0) return str;
    var parts = str.match(/[^'"]+|['"]/g);
    parts = parts.map(function (part) {
      if (part === "'") {
        return '"\'"'; // output "'"
      }

      if (part === '"') {
        return "'\"'"; // output '"'
      }
      return "'" + part + "'";
    });
    return 'concat(' + parts.join(',') + ')';
  };

  this.cloneNodeWithEvents = function (orgNode) {
    var orgNodeEvenets = orgNode.getElementsByTagName('*');
    var cloneNode = orgNode.cloneNode(true);
    var cloneNodeEvents = cloneNode.getElementsByTagName('*');

    var allEvents = new Array(
      'onabort',
      'onbeforecopy',
      'onbeforecut',
      'onbeforepaste',
      'onblur',
      'onchange',
      'onclick',
      'oncontextmenu',
      'oncopy',
      'ondblclick',
      'ondrag',
      'ondragend',
      'ondragenter',
      'ondragleave',
      'ondragover',
      'ondragstart',
      'ondrop',
      'onerror',
      'onfocus',
      'oninput',
      'oninvalid',
      'onkeydown',
      'onkeypress',
      'onkeyup',
      'onload',
      'onmousedown',
      'onmousemove',
      'onmouseout',
      'onmouseover',
      'onmouseup',
      'onmousewheel',
      'onpaste',
      'onreset',
      'onresize',
      'onscroll',
      'onsearch',
      'onselect',
      'onselectstart',
      'onsubmit',
      'onunload'
    );

    // The node root
    for (var j = 0; j < allEvents.length; j++) {
      let code = 'if( orgNode.' + allEvents[j] + ' ) cloneNode.' + allEvents[j] + ' = orgNode.' + allEvents[j];
      setTimeout(code, 1);
    }

    // Node descendants
    for (let i = 0; i < orgNodeEvenets.length; i++) {
      for (let j = 0; j < allEvents.length; j++) {
        let code = 'if( orgNodeEvenets[i].' + allEvents[j] + ' ) cloneNodeEvents[i].' + allEvents[j] + ' = orgNodeEvenets[i].' + allEvents[j];
        setTimeout(code, 1);
      }
    }

    return cloneNode;
  };

  this.filterHoverClasses = function (classValues) {
    if (typeof classValues !== 'string' || !classValues) return '';
    var classes = classValues.split(' ');
    //window.fconsole.log("class length: " + classes.length);
    if (classes.length > 20) return classValues.trim().replace('z-highlighted', '').replace('z-flash-highlighted', '');
    for (var i = classes.length - 1; i > -1; i--) {
      if (this.hoverClasses.indexOf(classes[i]) > -1) classes.splice(i, 1);
    }
    return classes.join(' ').trim().replace('z-highlighted', '').replace('z-flash-highlighted', '');
  };

  this.sanitizeAttributeName = function (string) {
    if (string.indexOf('functionise') > -1 || string.indexOf('functionize') > -1) return ''; //we restrict this attribute
    for (var char in this.jquerySpecialChars) {
      if (string.indexOf(this.jquerySpecialChars[char]) > -1) string = string.replace(this.jquerySpecialChars[char], '\\\\' + this.jquerySpecialChars[char]);
    }
    return string;
  };

  this.getElementUniqueSelectors = function (element) {
    try {
      // window.fconsole.log("Hover classes found: " + JSON.stringify(this.hoverClasses));
      let selectors = [];

      if (typeof element === 'undefined' || typeof element.tagName === 'undefined') return '';

      if (element.attributes && element.attributes.length > 0) {
        Array.from(element.attributes).forEach((attr) => {
          let attribute = { name: attr.name, value: attr.value };

          if (attribute.name === 'class') {
            attribute.value = window.WU.filterHoverClasses(element.className);
          }

          if (
            attribute.name.includes('functionize') ||
            attribute.name.includes('functionise') ||
            attribute.value.includes('functionize') ||
            attribute.value.includes('functionise') ||
            attribute.name.includes('functi0nize')
          ) {
            return;
          }

          if (attribute.value.length > 500 || attribute.value === '') return;

          let attrName = window.WU.sanitizeAttributeName(attribute.name);
          let attrValue = window.WU.sanitizeAttributeName(attribute.value);
          if (attrName !== attribute.name) return;

          let selector = element.tagName + '[' + attrName + '="' + attrValue + '"]';
          try {
            let matches = document.querySelectorAll(selector);
            if (matches.length === 1) {
              selector = '//' + element.tagName + '[@' + attrName + '="' + attrValue + '"]';
              selectors.push(selector);
            } else if (matches.length <= 5) {
              matches.forEach((match, i) => {
                if (match === element) {
                  selector = '(//' + element.tagName + '[@' + attrName + '="' + attrValue + '"])[' + (i + 1) + ']';
                  selectors.push(selector);
                }
              });
            }
          } catch (e) {
            window.fconsole.log(e.message);
          }
        });
      }

      return selectors.join('|functionise|');
    } catch (e) {
      window.fconsole.log(e.message);
      return '';
    }
  };

  this.getElementUniqueSelectorsTree = function (element) {
    try {
      this.checkNodeSupport();
      var paths = [];
      var hasSkippedElements = false;
      // Use nodeName (instead of localName) so namespace prefix is included (if any).
      for (; element && element.nodeType == 1; element = element.parentNode) {
        if (element.nodeName.toLowerCase() == 'option' || element.nodeName.toLowerCase() == 'html' || element.nodeName.toLowerCase() == 'body') continue; //we do not allow option elements.    We deal with the select directly
        var index = 0;
        // EXTRA TEST FOR ELEMENT.ID
        var attrFound = false;
        var selector = '';
        var selectorMatchCount = 1000;
        for (let attr of element.attributes) {
          let attribute = { name: attr.name, value: attr.value };
          //element.attributes[ attr.name ] = attr.value;
          //style is usually dynamic so we skip it...
          if (attribute.name == 'class' || attribute.name == 'id' || attribute.name == 'style') return;

          if (
            attribute.name.indexOf('functionize') > -1 ||
            attribute.name.indexOf('functionise') > -1 ||
            attribute.value.indexOf('functionize') > -1 ||
            attribute.value.indexOf('functionise') > -1 ||
            attribute.name.indexOf('functi0nize') > -1
          )
            return;

          attribute.value = attr.value.trim();
          if (attribute.value.length > 200 || attribute.value == '') return; //atribute is too big for us to store or no value...

          var attrName = window.WU.sanitizeAttributeName(attribute.name);
          var attrValue = window.WU.sanitizeAttributeName(attribute.value);
          if (attrName != attribute.name) return; ///special characters are not allowed here…
          var s = element.tagName + '[' + attrName + '="' + attrValue + '"]';
          try {
            var matches = document.querySelectorAll(s);
            if (matches.length < selectorMatchCount) {
              //this will select the most unique attribute...
              selectorMatchCount = matches.length;
              selector = element.tagName + '[@' + attrName + '="' + attrValue + '"]';
            }
          } catch (e) {
            window.fconsole.log(e.message);
          }
        }

        if (selector == '') {
          for (var sibling = element.previousSibling; sibling; sibling = sibling.previousSibling) {
            // Ignore document type declaration.
            if (sibling.nodeType == Node.DOCUMENT_TYPE_NODE) continue;

            if (sibling.nodeName == element.nodeName)
              //Selenium does not count the hidden elements…
              ++index;
          }

          var tagName = element.nodeName.toLowerCase();
          var pathIndex = '';
          if (element.className !== undefined) {
            var classs = window.WU.filterHoverClasses(element.className);
            if (classs !== '') {
              pathIndex = '[@class="' + window.WU.escapeHtml(classs) + '"]';
            } else {
              pathIndex = index ? '[' + (index + 1) + ']' : '[1]';
            }
          } else {
            pathIndex = index ? '[' + (index + 1) + ']' : '[1]';
          }
          selector = tagName + pathIndex;
        }
        //window.fconsole.log("Adding new unique tree selector: " + selector);
        paths.splice(0, 0, selector);
      }
      var basePath = '//';
      return paths.length ? basePath + paths.join('/') : null;
    } catch (e) {
      window.fconsole.log(e.message);
      return '';
    }
  };

  this.getElementSecondarySelectors = function (element, lookForParent) {
    try {
      if (typeof lookForParent === 'undefined') lookForParent = true;

      var selectors = [];
      if (typeof element === 'undefined' || typeof element.tagName === 'undefined') return '';

      if (element.textContent !== '') {
        // Text-based selector
        var text = element.textContent.trim();
        var lines = text.split('\n');
        var line = lines[0];
        while (line.includes("'")) line = line.replace("'", 'FfunctioniseApostrophyF');

        var lineToRec = line;
        while (line.includes('FfunctioniseApostrophyF')) {
          line = line.replace('FfunctioniseApostrophyF', "'");
          lineToRec = lineToRec.replace('FfunctioniseApostrophyF', "\\'");
        }

        try {
          var matches = Array.from(document.querySelectorAll(element.tagName + ':not(:empty)')).filter((el) => el.textContent.includes(this.cleanStringForXpath(line)));
          matches = matches.filter((match) => match.textContent.trim() === text);

          if (matches.length > 1 && matches.length < 6) {
            var selector = '//' + element.tagName + "[text() = '" + this.cleanStringForXpath(lines[0]) + "']";
            selectors.push(selector);
          }
        } catch (e) {
          window.fconsole.log(e.message);
        }
      }

      if (element.attributes && element.attributes.length > 0) {
        Array.from(element.attributes).forEach(function (attr) {
          let attribute = { name: attr.name, value: attr.value };
          if (attribute.name === 'class') {
            attribute.value = window.WU.filterHoverClasses(element.className);
          }

          if (
            attribute.name.includes('functionize') ||
            attribute.name.includes('functionise') ||
            attribute.value.includes('functionize') ||
            attribute.value.includes('functionise') ||
            attribute.name.includes('functi0nize')
          ) {
            return;
          }
          // Atribute is too big for us to store or no value...
          if (attribute.value.length > 200 || attribute.value === '') return;

          var attrName = window.WU.sanitizeAttributeName(attribute.name);
          var attrValue = window.WU.sanitizeAttributeName(attribute.value);
          // Special characters are not allowed here…
          if (attrName !== attribute.name) return;

          var selector = element.tagName + '[' + attrName + '="' + attrValue + '"]';
          try {
            var matches = document.querySelectorAll(selector);
            if (matches.length > 1 && matches.length < 6) {
              selector = '//' + element.tagName + '[@' + attrName + '="' + attrValue + '"]';
              selectors.push(selector);
            }
          } catch (e) {
            window.fconsole.log(e.message);
          }
        });
      }
      var ret = selectors.join('|functionise|');
      if (lookForParent) {
        var parent = element.parentElement;
        var parentSelectorsString = this.getElementSecondarySelectors(parent, false);
        var parentSelectors = parentSelectorsString.split('|functionise|');
        for (let i = 0; i < parentSelectors.length; i++) {
          for (let x = 0; x < selectors.length; x++) {
            ret += '|functionise|' + parentSelectors[i] + selectors[x];
          }
        }
      }
      return ret;
    } catch (e) {
      window.fconsole.log(e.message);
      return '';
    }
  };

  /**
   * Gets an XPath for an element which describes its hierarchical location.
   */
  this.getElementXPath = function (element, useClass, svg) {
    try {
      if (typeof useClass === 'undefined') useClass = false;
      // TODO: Check this if.
      if (typeof svg === 'undefined') useClass = false;

      var useIds = true;
      if (
        (element.nodeName.toLowerCase() === 'iframe' && document.location.host.indexOf('cigna') > -1) ||
        (element.nodeName.toLowerCase() === 'frame' && document.location.host.indexOf('cigna') > -1)
      ) {
        useIds = false;
      }

      if (element && element.id && !useClass && !svg && useIds) {
        const escapedId = window.WU.escapeHtml(element.id);
        const elementsWithId = document.querySelectorAll(element.nodeName.toLowerCase() + `[id="${escapedId}"]`);

        if (elementsWithId.length > 1) {
          for (let i = 0; i < elementsWithId.length; i++) {
            if (elementsWithId[i] === element) {
              return `(//${element.nodeName.toLowerCase()}[@id="${escapedId}"])[${i + 1}]`;
            }
          }
        }

        return `//${element.nodeName.toLowerCase()}[@id="${escapedId}"]`;
      } else if (element && element.id && !useClass && svg) {
        return `//*[name()='${element.nodeName.toLowerCase()}' and starts-with(@id, '${window.WU.escapeHtml(element.id)}')]`;
      } else {
        return this.getElementTreeXPath(element, useClass);
      }
    } catch (e) {
      window.fconsole.log(e.message);
      return '';
    }
  };

  this.getElementTreeXPath = function (element, useClass, useAttribute, classCountLimit, dynamicIds) {
    try {
      if (typeof useClass == 'undefined') useClass = false;

      if (typeof classCountLimit == 'undefined') classCountLimit = 1;

      if (typeof useAttribute == 'undefined') useAttribute = true;

      if (typeof dynamicIds == 'undefined')
        //we detect dynamic ids -- they usually contain some sort of numerci in them based on experience...
        dynamicIds = true;

      var useIds = true;
      if (document.location.host.indexOf('cigna') > -1 && (element.nodeName.toLowerCase() == 'iframe' || element.nodeName.toLowerCase() == 'frame')) {
        useIds = false;
      }

      this.checkNodeSupport();
      var paths = [];
      var hasSkippedElements = false;
      var selectors = '';
      var treeCounter = 0;
      // Use nodeName (instead of localName) so namespace prefix is included (if any).
      //window.fconsole.log("Getting element tree");
      //window.fconsole.log("tree counter : 0");
      for (; element && element.nodeType == 1; element = element.parentNode) {
        treeCounter++;
        //window.fconsole.log("tree counter : " + treeCounter);
        var doBreak = false;
        if (element.nodeName.toLowerCase() == 'option') continue; //we do not allow option elements.    We deal with the select directly
        var index = 0;
        // EXTRA TEST FOR ELEMENT.ID
        if (
          useIds &&
          element &&
          element.id &&
          typeof element.getAttribute('id') !== 'undefined' &&
          !useClass &&
          useAttribute &&
          (dynamicIds || (!dynamicIds && element.getAttribute('id')?.match(/\d+/g) === null))
        ) {
          //we now know that we can not expect to have singular ids per page (developers….)
          ///NOTE if we have a form that has an element call id it can collide with the id attribute!!!
          ///NOTE there for use jQuery(element).attr("id") instead of element.id

          const id = element.getAttribute('id');
          const escapedId = window.WU.escapeHtml(id);

          const tagName = element.nodeName.toLowerCase();
          const elementsWithId = document.querySelectorAll(`${tagName}[id="${escapedId}"]`);

          if (elementsWithId.length > 1) {
            // We have multiple elements to deal with…
            elementsWithId.forEach((e, i) => {
              if (e === element) {
                paths.splice(0, 0, `/descendant::${tagName}[@id="${escapedId}"][${i + 1}]`);
              }
            });
          } else {
            paths.splice(0, 0, '/' + element.nodeName.toLowerCase() + '[@id="' + window.WU.escapeHtml(element.getAttribute('id')) + '"]');
          }
          break;
        }
        //window.fconsole.log("Treepath sibling start");
        for (var sibling = element.previousSibling; sibling; sibling = sibling.previousSibling) {
          // Ignore document type declaration.
          if (sibling.nodeType == Node.DOCUMENT_TYPE_NODE) continue;

          if (sibling.nodeName == element.nodeName && !sibling.classList.contains('f-functionise'))
            // && (sibling.offsetParent !== null)) //Selenium does not count the hidden elements…
            ++index;
        }
        //window.fconsole.log("Treepath sibling end");
        var tagName = element.nodeName.toLowerCase();
        var pathIndex = '';
        var classCount = null;
        if (!useClass) {
          pathIndex = index ? '[' + (index + 1) + ']' : '[1]';
        } else {
          //window.fconsole.log("checking for class on tag: " + tagName);
          if (element.className) {
            var classs = window.WU.filterHoverClasses(element.className);
            if (classs !== '') {
              pathIndex = '[@class="' + window.WU.escapeHtml(classs) + '"]';
              if (selectors !== '') {
                selectors += '>';
              }
              try {
                // Construct the CSS selector and check the length
                var cssSelector = tagName + '.' + window.WU.escapeHtml(classs);
                var matches = document.querySelectorAll(cssSelector);
                if (matches.length === 1) {
                  doBreak = true;
                }
              } catch (e) {
                window.fconsole.log(e.message);
              }
              classCount++;
            } else {
              pathIndex = index ? '[' + (index + 1) + ']' : '[1]';
            }
          } else {
            pathIndex = index ? '[' + (index + 1) + ']' : '[1]';
          }
        }
        //window.fconsole.log("Splicing path index");
        paths.splice(0, 0, tagName + pathIndex);
        classCount = (paths.join('/').match(/class=/g) || []).length;
        if (classCount > classCountLimit) {
          hasSkippedElements = true;
          break; ///2 class definitions should be enough….
        }
      }

      //window.fconsole.log("Setting base path and returning.");
      var basePath = '/';
      if (hasSkippedElements) basePath = '//';
      //window.fconsole.log("Prepping path and returning tree");
      return paths.length ? basePath + paths.join('/') : null;
    } catch (e) {
      window.console.error(e);
      return '';
    }
  };

  this.cssEscape = function (s) {
    return CSS.escape(s);
    //return s.replace(/[!"#$%&'()*+,.\/:;<=>?@[\\\]^`{|}~]/g, "\\\\$&");
  };
  /**
   * Gets an CSS for an element which describes its hierarchical location.
   */
  this.getElementCss = function (element, useClass) {
    try {
      if (typeof useClass == 'undefined') useClass = false;

      if (element && element.id && typeof element.id !== 'undefined' && !useClass) {
        var id = element.id;
        var tagName = element.nodeName.toLowerCase();
        var cssSelector = tagName + '[id="' + window.WU.cssEscape(id) + '"]';

        var matches = document.querySelectorAll(cssSelector);

        if (matches.length > 1) {
          var csss = '';
          matches.forEach((e, i) => {
            if (e === element) {
              csss = tagName + '#' + window.WU.cssEscape(id) + ':nth-of-type(' + (i + 1) + ')';
            }
          });
          if (csss !== '') return csss;
        }

        return tagName + '#' + window.WU.cssEscape(id);
      } else {
        return this.getElementTreeCss(element, useClass);
      }
    } catch (e) {
      window.fconsole.log(e.message);
      return '';
    }
  };

  this.getElementTreeCss = function (element, useClass) {
    try {
      this.checkNodeSupport();
      var paths = [];
      var classCount = 0;
      // Use nodeName (instead of localName) so namespace prefix is included (if any).
      for (; element && element.nodeType == 1; element = element.parentNode) {
        if (element.nodeName.toLowerCase() == 'option') continue; //we do not allow option elements.    We deal with the select directly
        var index = 0;
        // EXTRA TEST FOR ELEMENT.ID
        if (element && element.id && typeof element.id !== 'undefined' && !useClass) {
          var id = element.id;
          let tagName = element.nodeName.toLowerCase();
          var cssSelector = tagName + '[id="' + window.WU.cssEscape(id) + '"]';
          var matches = document.querySelectorAll(cssSelector);

          if (matches.length > 1) {
            // We have multiple elements to deal with…
            matches.forEach(function (e, i) {
              if (e === element) {
                paths.splice(0, 0, tagName + '#' + window.WU.cssEscape(id) + ':nth-of-type(' + (i + 1) + ')');
              }
            });
          } else {
            paths.splice(0, 0, tagName + '#' + window.WU.cssEscape(id));
          }
          break;
        }

        for (var sibling = element.previousSibling; sibling; sibling = sibling.previousSibling) {
          // Ignore document type declaration.
          if (sibling.nodeType == Node.DOCUMENT_TYPE_NODE) continue;

          if (sibling.nodeName == element.nodeName)
            // && (sibling.offsetParent !== null)) //Selenium does not count the hidden elements...
            ++index;
        }

        let tagName = element.nodeName.toLowerCase();
        var pathIndex = '';
        if (!useClass) {
          pathIndex = index ? ':nth-of-type(' + (index + 1) + ')' : '';
        } else {
          if (element.className) {
            var classs = window.WU.filterHoverClasses(element.className);

            if (classs !== '') {
              pathIndex = '.' + window.WU.escapeHtml(classs);
              pathIndex = pathIndex.replace(/ /g, '.');
              classCount++;
            } else {
              pathIndex = index ? ':nth-of-type(' + (index + 1) + ')' : '';
            }
          } else {
            pathIndex = index ? ':nth-of-type(' + (index + 1) + ')' : '';
          }
        }
        paths.splice(0, 0, tagName + pathIndex);
        if (classCount > 1) break; // more than 1 class should be enough to narrow down the elements….
      }
      return paths.length ? '' + paths.join(' > ') : null;
    } catch (e) {
      window.fconsole.log(e.message);
      return '';
    }
  };

  this.checkNodeSupport = function () {
    if (this.nodeCheck) return;
    this.getBrowser();
    if (this.currentBrowser.name != 'msie' || this.currentBrowser.version > 9) return;
    if (typeof Node == 'undefined') {
      Node = {};
      Node.ELEMENT_NODE = 1;
      Node.ATTRIBUTE_NODE = 2;
      Node.TEXT_NODE = 3;
      Node.CDATA_SECTION_NODE = 4;
      Node.ENTITY_REFERENCE_NODE = 5;
      Node.ENTITY_NODE = 6;
      Node.PROCESSING_INSTRUCTION_NODE = 7;
      Node.COMMENT_NODE = 8;
      Node.DOCUMENT_NODE = 9;
      Node.DOCUMENT_TYPE_NODE = 10;
      Node.DOCUMENT_FRAGMENT_NODE = 11;
      Node.NOTATION_NODE = 12;
    }
    this.nodeCheck = true;
  };

  //this is our cookie hack that goes in place of traditional cookies
  this.cookie = function (key, val, options) {
    function getCookie(name) {
      var v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
      return v ? v[2] : null;
    }
    try {
      if (typeof val == 'undefined') return getCookie(key);

      if (typeof options == 'undefined') {
        options = { expires: 0, path: '/' };
      }
      var command = { call: 'setCookie', url: location.href, key: key, val: val, domain: new URL(document.location).host, path: options.path, expires: options.expires };
      window.chromePort.postMessage(command);
    } catch (e) {
      window.fconsole.log(e.message);
    }
  };

  this.store = function (key, val, options) {
    try {
      if (typeof val == 'undefined') return window.localStorage[key];

      if (val == '') {
        //remove request
        window.localStorage.removeItem(key);
        return;
      }
      if (typeof chromePort == 'undefined') {
        //on FF
        window.localStorage.setItem(key, val);
      } else {
        window.localStorage.setItem(key, val);
      }
    } catch (e) {
      window.fconsole.log(e.message);
    }
  };

  this.storeAndCookie = function (key, val, options) {
    if (typeof val == 'undefined') {
      //this is a read request
      var value = this.cookie(key);
      if (value == null || typeof value == 'undefined' || value == '') value = this.store(key);

      return value;
    }
    this.cookie(key, val, options);
    this.store(key, val, options);
  };

  this.countPercentage = function (lp, dp) {
    return Math.floor((dp / lp) * 100);
  };

  this.getTime = function () {
    var d = new Date();
    return d.getTime();
  };

  this.generateActionId = function () {
    let result = this.getTime() + '_' + this.randomString();
    console.trace('generateActionId', result);
    return result;
  };

  this.getASCIIOnly = function (string) {
    try {
      //we need this to allow for API explorer calls...
      if (document.URL.indexOf('www.functionizeapp.com') > -1) this.textCharacterLimit = 100000;

      if (string.length > this.textCharacterLimit) string = string.substr(0, this.textCharacterLimit);

      const cleanedString = string.replace(/([^-\xFF]|\s)*$/g, '');
      return cleanedString.trim();
    } catch (e) {
      window.fconsole.log('Unable to run regular expression on text:' + string);
      try {
        //try to limit again to make sure we do not run out of possibilities....
        if (string.length > this.textCharacterLimit) string = string.substr(0, this.textCharacterLimit);
      } catch (e) {}
    }
    return string;
  };

  this.getDateFromLinuxTime = function (time) {
    var date = new Date();
    date.setTime(parseInt(time) * 1000);
    return date;
  };

  this.WBParseCookie = function (string) {
    //
  };

  this.WBSetCookie = function () {
    // no longer in use
  };

  this.randomString = function (length) {
    var len = 10;
    if (length) {
      len = length;
    }
    var bits = 36;
    var outStr = '';
    var newStr = '';
    while (outStr.length < len) {
      newStr = Math.random().toString(bits).slice(2);
      outStr += newStr.slice(0, Math.min(newStr.length, len - outStr.length));
    }
    return outStr.toUpperCase();
  };

  this.randomNumber = function (length, notIncNumbers) {
    var chars = '0123456789';
    if (notIncNumbers) {
      notIncNumbers = notIncNumbers.toString();
      for (let i = 0; i < notIncNumbers.length; i++) {
        chars = chars.replace(notIncNumbers.charAt(i), '');
      }
    }

    var stringLength = 10;
    if (length || length === '0') {
      stringLength = Number(length);
    }

    window.fconsole.log('Random is called with length: ' + stringLength);
    var randomNumber = '';
    for (let i = 0; i < stringLength; i++) {
      var rnum = Math.floor(Math.random() * chars.length);
      if (i == 0 && rnum == 0) {
        rnum = Math.floor(Math.random() * 9 + 1);
      }
      randomNumber += chars.substring(rnum, rnum + 1);
    }
    return randomNumber;
  };

  this.randomText = function (length) {
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz';
    var textLength = 10;
    if (length) {
      textLength = length;
    }

    window.fconsole.log('Random is called with length: ' + textLength);
    var randomText = '';
    for (var i = 0; i < textLength; i++) {
      var rnum = Math.floor(Math.random() * chars.length);
      randomText += chars.substring(rnum, rnum + 1);
    }
    return randomText;
  };

  this.randomTextSmall = function (length) {
    var chars = 'abcdefghiklmnopqrstuvwxyz';
    var textLength = 10;
    if (length) {
      textLength = length;
    }

    window.fconsole.log('Random is called with length: ' + textLength);
    var randomText = '';
    for (var i = 0; i < textLength; i++) {
      var rnum = Math.floor(Math.random() * chars.length);
      randomText += chars.substring(rnum, rnum + 1);
    }
    return randomText;
  };

  this.randomTextUpper = function (length) {
    var chars = 'abcdefghiklmnopqrstuvwxyz';
    var textLength = 10;
    if (length) {
      textLength = length;
    }

    window.fconsole.log('Random is called with length: ' + textLength);
    var randomText = '';
    for (var i = 0; i < textLength; i++) {
      var rnum = Math.floor(Math.random() * chars.length);
      randomText += chars.toUpperCase().substring(rnum, rnum + 1);
    }
    return randomText;
  };

  this.randomFunctionizeappEmail = function () {
    return this.randomString(5) + '@functionizeapp.com';
  };

  this.getFunctionizeappPhone = function (strval) {
    var arrVal = strval.split('_');
    var phoneTypeindex = '0';
    if (typeof arrVal[1] != 'undefined' && arrVal[1]) {
      phoneTypeindex = arrVal[1].replace(']', '');
    }
    var number = this.randomNumber(10);
    var match = number.match(/^(\d{3})(\d{3})(\d{4})$/);
    switch (phoneTypeindex) {
      case '0': {
        // 1162391938
        return number.toString();
      }
      case '1': {
        // (116) 239-1938
        return '(' + match[1] + ') ' + match[2] + '-' + match[3];
      }
      case '2': {
        // 587 753 7028
        return match[1] + ' ' + match[2] + ' ' + match[3];
      }
      case '3': {
        // 343.578.4788
        return match[1] + '.' + match[2] + '.' + match[3];
      }
      case '4': {
        // 587-753-7028
        return match[1] + '-' + match[2] + '-' + match[3];
      }
      case '5': {
        // 1-878-758-7353
        return '1-' + match[1] + '-' + match[2] + '-' + match[3];
      }
    }
  };

  this.randomFunctionizeString = function (length) {
    return this.randomString(length);
  };

  this.randomFunctionizeNumber = function (length, notIncNumber) {
    return this.randomNumber(length, notIncNumber);
  };

  this.randomFunctionizeText = function (length) {
    return this.randomText(length);
  };

  this.randomFunctionizeTextSmall = function (length) {
    return this.randomTextSmall(length);
  };

  this.randomFunctionizeTextUpper = function (length) {
    return this.randomTextUpper(length);
  };

  this.decodeReferrer = function (referrer) {
    referrer = decodeURIComponent(referrer);

    var query = null;
    if (referrer.match(/^http:\/\/(www\.)?alltheweb.*$/i)) {
      this.searchEngne = 'AllTheWeb';
      // AllTheWeb
      if (referrer.match(/q=/)) query = referrer.replace(/^.*q=([^&]+)&?.*$/i, '$1');
    } else if (referrer.match(/^http:\/\/(www)?\.?google.*/i)) {
      this.searchEngne = 'Google';
      // Google
      if (referrer.match(/q=/)) query = referrer.replace(/^.*q=([^&]+)&?.*$/i, '$1');
    } else if (referrer.match(/^http:\/\/search\.lycos.*/i)) {
      this.searchEngne = 'Lycos';
      // Lycos
      if (referrer.match(/query=/)) query = referrer.replace(/^.*query=([^&]+)&?.*$/i, '$1');
    } else if (referrer.match(/^http:\/\/search\.msn.*/i)) {
      this.searchEngne = 'MSN';
      // MSN
      if (referrer.match(/q=/)) query = referrer.replace(/^.*p=([^&]+)&?.*$/i, '$1');
    } else if (referrer.match(/^http:\/\/search\.yahoo.*/i)) {
      this.searchEngne = 'Yahoo';
      // Yahoo
      if (referrer.match(/p=/)) query = referrer.replace(/^.*p=([^&]+)&?.*$/i, '$1');
    }

    if (query) {
      query = query.replace(/'|"/, '');
      query = query.split(/[\s,+.]+/);
    }

    return query;
  };

  this.replaceAll = function (text, strA, strB) {
    if (text == null || text == undefined || text == '') return '';
    while (text.indexOf(strA) != -1) {
      text = text.replace(strA, strB);
    }
    return text;
  };

  this.getParameterByName = function (name) {
    name = name.replace(/[[]/, '\\[').replace(/[\]]/, '\\]');
    var regexS = '[\\?&]' + name + '=([^&#]*)';
    var regex = new RegExp(regexS);
    var results = regex.exec(document.location.href);
    if (results == null) return '';
    else return decodeURIComponent(results[1].replace(/\+/g, ' '));
  };

  this.getElementDetails = function (element) {
    var wselement = new wsElement();
    wselement.tagName = element.tagName.toLowerCase();

    if (element.attributes) {
      Array.from(element.attributes).forEach((attr) => {
        var attrName = attr.name;
        var attrValue = attr.value;

        if (
          attrName.includes('functionize') ||
          attrName.includes('functionise') ||
          attrValue.includes('functionize') ||
          attrValue.includes('functionise') ||
          attrName.includes('functi0nize')
        ) {
          return;
        }

        if (attrName.toLowerCase() === 'value') {
          attrValue = element.value;
        }

        if (attrValue.includes('z-highlighted')) {
          attrValue = attrValue.replace('z-highlighted', '');
          if (attrValue === '') return;
        }

        if (attrValue.length > 20) {
          attrValue = attrValue.substr(0, 18) + '…';
        }

        wselement[attrName] = attrValue;
      });
    }

    return wselement;
  };

  this.getTopZindex = function () {
    if ((window.WS && typeof window.WS.collectStatistics !== 'undefined' && window.WS.collectStatistics) || !window.WS) return 2147483647;
    let newTop = 0;
    try {
      newTop = window.WS.getTopZindex();
    } catch (e) {
      newTop = 2147483647;
    }

    if (window.TCM != null) window.TCM.adjustTop(newTop);

    return newTop;
  };

  this.disableElement = function (e) {
    var top = e.getBoundingClientRect().top + window.scrollY; // Get the top position relative to the document
    var left = e.getBoundingClientRect().left + window.scrollX; // Get the left position relative to the document
    var width = e.offsetWidth;
    var height = e.offsetHeight;
    var zi = 2;

    var zIndex = window.getComputedStyle(e).zIndex;
    if (zIndex > zi && zIndex !== 'auto' && zIndex !== 'inherit') {
      zi = parseInt(zIndex, 10) + 1;
    }

    // Check all parents for z-index
    var parent = e.parentElement;
    while (parent) {
      var parentZIndex = window.getComputedStyle(parent).zIndex;
      if (parentZIndex > zi && parentZIndex !== 'auto' && parentZIndex !== 'inherit') {
        zi = parseInt(parentZIndex, 10) + 1;
      }
      parent = parent.parentElement;
    }

    // Create a unique id for the overlay
    var id = this.randomString();
    this.coveredElementClasses.push(id);

    // Add class to the element
    e.classList.add(id);

    // Create and style the cover element
    var cover = document.createElement('div');
    cover.id = id;
    cover.className = 'f-functionise f-functionise-coverer';
    cover.style.opacity = '0.8';
    cover.style.backgroundColor = '#333333';
    cover.style.position = 'absolute';
    cover.style.width = width + 'px';
    cover.style.height = height + 'px';
    cover.style.top = top + 'px';
    cover.style.left = left + 'px';
    cover.style.zIndex = zi;

    document.body.appendChild(cover);

    // Event listener for mouseover
    cover.addEventListener('mouseover', function () {
      var coveredElement = document.querySelector('.' + id);
      if (!coveredElement || coveredElement.offsetParent === null) {
        if (coveredElement) {
          coveredElement.classList.remove(id);
        }
        cover.remove();
      }
    });
  };

  this.enableAllElements = function () {
    // Remove all cover elements
    document.querySelectorAll('.f-functionise-coverer').forEach(function (element) {
      element.remove();
    });

    // Remove all classes from previously covered elements
    this.coveredElementClasses.forEach(function (className) {
      document.querySelectorAll('.' + className).forEach(function (element) {
        element.classList.remove(className);
      });
    });

    // Clear the list of covered element classes
    this.coveredElementClasses = [];
  };

  this.zoomBoundingRect = function (element) {
    let { top, right, bottom, left, width, height, x, y } = element.getBoundingClientRect();

    if (height === 0) {
      let beforeHeight = parseFloat(getComputedStyle(element, ':before').height);
      let afterHeight = parseFloat(getComputedStyle(element, ':after').height);
      height = beforeHeight > 0 ? beforeHeight : afterHeight > 0 ? afterHeight : height;
    }

    if (width === 0) {
      let beforeWidth = parseFloat(getComputedStyle(element, ':before').width);
      let afterWidth = parseFloat(getComputedStyle(element, ':after').width);
      width = beforeWidth > 0 ? beforeWidth : afterWidth > 0 ? afterWidth : width;
    }

    if (window.WS.zoom !== 1) {
      x = parseInt(x * window.WS.zoom);
      y = parseInt(y * window.WS.zoom);
      left = parseInt(left * window.WS.zoom);
      top = parseInt(top * window.WS.zoom);
      width = parseInt(width * window.WS.zoom);
      height = parseInt(height * window.WS.zoom);
    }
    return { top, right, bottom, left, width, height, x, y };
  };

  this.setZoomLevel = function (element) {
    //we do not set zoom on the body
    //only child elements of body are broken and need adjustment...
    window.WS.zoom = 1;
    if (!element || element === document.body || element.nodeName === 'HTML') return;
    let zoom = -1;
    try {
      zoom = parseFloat(window.getComputedStyle(element).zoom);
    } catch (e) {}
    if (!isNaN(zoom) && zoom !== 1 && zoom !== -1) {
      window.WS.zoom = zoom;
      return;
    }
    try {
      this.setZoomLevel(element.parentNode);
    } catch (e) {}
  };

  this.cleanAndFormatPointerDownTraceData = function (data) {
    let spliceIndex = -1;
    for (let i = 0; i < data.length; i++) {
      if (i < data.length - 1 && data[i].hasOwnProperty('ms') && data[i + 1].hasOwnProperty('ms') && data[i].ms > data[i + 1].ms) {
        spliceIndex = i;
      }
    }
    if (spliceIndex > -1) {
      data = data.splice(spliceIndex + 1);
    }
    return JSON.stringify(data);
  };

  //use in verification mode and other to cover elements that we want to work with for clicks or verifications...
  this.fHideElement = function (e, pageX, pageY) {
    var isSVGElement = e.closest('svg') !== null || e.tagName.toLowerCase() === 'svg';

    if (!isSVGElement) {
      if (window.WU.tippyElement !== e) {
        window.WU.tippyInstance = window.WU.showTippy(e, window.WS.getElementBubbleText(e));
      } else if (window.WU.tippyInstance) {
        window.WU.tippyInstance.show();
      }

      e.classList.add('z-highlighted');

      if (typeof e.getRootNode === 'function' && typeof e.getRootNode().host === 'object' && typeof e.getRootNode().host.shadowRoot === 'object') {
        e.getRootNode().host.classList.remove('z-highlighted');
        e.getRootNode()
          .querySelectorAll('.z-highlighted')
          .forEach((node) => {
            if (e !== node) {
              node.classList.remove('z-highlighted');
            }
          });

        let highlighted = e.getRootNode().host.shadowRoot.querySelector('style#f-highlighted');
        if (!highlighted) {
          let style = document.createElement('style');
          style.id = 'f-highlighted';
          style.innerHTML = '.z-highlighted {cursor: pointer !important;outline-offset: -2px !important;outline: rgb(0, 187, 239) solid 2px !important;}';
          e.getRootNode().host.shadowRoot.prepend(style);
        }

        setTimeout(() => {
          e.classList.remove('z-highlighted');
        }, 2000);
      }
    }

    try {
      var boundingRect = e.getBoundingClientRect();
      var top = boundingRect.top + window.pageYOffset;
      var left = boundingRect.left + window.pageXOffset;
      this.lastHiderPosition = { left: pageX, top: pageY };
      var width = e.offsetWidth - 2;
      var height = e.offsetHeight - 2;

      if (isSVGElement) {
        if (e.hasAttribute('width') && e.hasAttribute('height')) {
          width = parseInt(e.getAttribute('width'), 10);
          height = parseInt(e.getAttribute('height'), 10);
        } else {
          var rect = e.getBoundingClientRect();
          width = rect.width;
          height = rect.height;
        }
      }

      var parent = e;
      var zi = 0;
      var recurseCount = 0;

      while (recurseCount < 60) {
        recurseCount++;
        var zIndex = parseInt(window.getComputedStyle(parent).zIndex, 10);

        if (!isNaN(zIndex)) {
          if (zIndex > zi) {
            zi = zIndex;
          }
        }
        parent = parent.parentElement;
        if (!parent || parent.tagName.toLowerCase() === 'body' || parent.tagName.toLowerCase() === 'html') {
          break;
        }
      }

      zi = isNaN(zi) ? 1 : zi + 1;
      window.fconsole.log('Adding cover with z-index: ' + zi);

      if (
        document.querySelector('#setting-button')?.classList.contains('active-bottompanel') ||
        document.querySelector(`.${window.fUniqPrefix}-extruder-content`)?.offsetParent !== null
      ) {
        return false;
      }

      var cover = document.createElement('div');
      cover.id = 'f-functionise-hider';
      cover.className = 'f-functionise f-functionise-hider';
      cover.style.position = 'fixed';
      cover.style.pointerEvents = 'none';
      cover.style.width = width + 'px';
      cover.style.height = height + 'px';
      cover.style.top = top + 'px';
      cover.style.left = left + 'px';
      cover.style.zIndex = zi;
      document.body.appendChild(cover);

      return document.querySelector('#f-functionise-hider');
    } catch (e) {
      console.error(e.message);
    }
  };

  this.fShowAllElements = function () {
    // Remove 'z-highlighted' class from all elements
    document.querySelectorAll('.z-highlighted').forEach((element) => {
      element.classList.remove('z-highlighted');
    });

    // Remove all '.f-functionise-hider' elements
    document.querySelectorAll('.f-functionise-hider').forEach((element) => {
      element.remove();
    });

    // Remove the specific '#f-functionise-hider' element if it exists
    var hiderElement = document.getElementById('f-functionise-hider');
    if (hiderElement) {
      hiderElement.remove();
    }

    // Update the status
    window.WS.addedFunctioniseHider = false;
  };

  this.setSaveCoverer = function () {
    if (document.getElementById('f-functionise-save-coverer')) return;

    var cover = document.createElement('div');
    cover.id = 'f-functionise-save-coverer';
    cover.className = 'f-functionise';
    cover.style.zIndex = window.TCM.currentZIndex - 6;

    document.body.appendChild(cover);
  };

  this.removeSaveCoverer = function () {
    var cover = document.getElementById('f-functionise-save-coverer');
    if (cover) {
      cover.remove();
    }
  };

  this.setPauseCoverer = function () {
    if (document.getElementById('f-functionise-pause-coverer') || document.body.nodeName === 'FRAMESET') return;

    var cover = document.createElement('div');
    cover.id = 'f-functionise-pause-coverer';
    cover.className = 'f-functionise';
    cover.style.pointerEvents = 'none';
    cover.style.zIndex = window.TCM.currentZIndex - 1 > 1000 ? window.TCM.currentZIndex - 1 : window.WU.fTopZindex - 2;

    document.body.appendChild(cover);
  };

  this.removePauseCoverer = function () {
    var cover = document.getElementById('f-functionise-pause-coverer');
    if (cover) {
      cover.remove();
    }
  };

  this.setPendingActionCoverer = function () {
    if (document.getElementById('f-functionise-pending-action-cover')) return;

    var cover = document.createElement('div');
    cover.id = 'f-functionise-pending-action-cover';
    cover.className = 'f-functionise';
    cover.style.background = 'rgba(0,0,0,0.9)';
    cover.style.zIndex = window.TCM.currentZIndex - 6;
    cover.style.position = 'fixed';
    cover.style.top = '0';
    cover.style.left = '0';
    cover.style.right = '0';
    cover.style.bottom = '0';

    var img = document.createElement('img');
    img.style.position = 'absolute';
    img.style.top = '50%';
    img.style.left = '50%';
    img.style.transform = 'translate(-50%, -50%)';
    img.style.opacity = '.3';
    img.style.userSelect = 'none';
    img.style.webkitUserDrag = 'none';
    img.src = chrome.runtime.getURL('images/fz-spinner300-black-matte.gif');

    cover.appendChild(img);
    document.body.appendChild(cover);

    if (window.TCM.isCollapsed) {
      window.TCM.unCollapse();
    }
  };

  this.removePendingActionCoverer = function () {
    var cover = document.getElementById('f-functionise-pending-action-cover');
    if (cover) {
      cover.remove();
    }
  };

  this.stringify = function (obj) {
    var string = '';
    try {
      string = JSON.stringify(obj);
    } catch (e) {
      window.fconsole.log(e);
    }
    return string;
  };

  this.hoverEvaluator = function () {
    var selectors = [];
    var uniqueSelectors = [];

    for (let i = 0; i < document.styleSheets.length; i++) {
      console.log('have stylesheet');
      if ('rules' in document.styleSheets[i]) {
        console.log(document.styleSheets[i].rules);
        for (let j = 0; j < document.styleSheets[i].rules.length; j++) {
          if (!document.styleSheets[i].rules[j].selectorText) {
            continue;
          }

          if (document.styleSheets[i].rules[j].selectorText.indexOf(':hover') > -1 && document.styleSheets[i].rules[j].selectorText.indexOf('(:hover') == -1) {
            var hover = document.styleSheets[i].rules[j].selectorText.split(',');
            hover.forEach(function (el, index) {
              if (el.indexOf(':hover') > -1 && el.indexOf(':after') === -1 && el.indexOf(':before') === -1) {
                if (el.split(':hover')[1] !== '') {
                  //selectors.push({element: el.replace(':hover', '').trim(), parent: el.split(':hover')[0].trim()});
                  selectors.push(el.split(':hover')[0].trim());
                }
              }
            });
          }
        }
      }
    }

    if (selectors.length > 0) {
      //TODO: make this work
      //window.WS.hoverData = Array.from(new Set(selectors));
    }
  };

  this.hashCode = function (str) {
    var hash = 0;
    var i;
    var chr;

    if (str.length === 0) return hash;
    for (i = 0; i < str.length; i++) {
      chr = str.charCodeAt(i);
      hash = (hash << 5) - hash + chr;
      hash |= 0;
    }
    return hash;
  };

  this.subRoutine = function (r, str) {
    var hc = this.hashCode(str);
    if (r[hc] != undefined) {
      r[hc]++;
    } else {
      r[hc] = 1;
    }
    return r;
  };

  this.subRoutine2 = function (r, str) {
    if (r[str] != undefined) {
      r[str]++;
    } else {
      r[str] = 1;
    }
    return r;
  };

  this.getPageElementData = function () {
    var e = document.body.getElementsByTagName('*');
    var r = {};
    var a = {};
    a['textContent'] = {};
    a['value'] = {};
    a['id'] = {};
    a['type'] = {};
    a['src'] = {};
    a['href'] = {};
    a['tagName'] = {};
    a['title'] = {};
    a['previousSibling'] = {};
    a['nextSibling'] = {};
    a['parentElement'] = {};
    a['className'] = {};
    a['alt'] = {};
    a['left'] = {};
    a['top'] = {};
    a['height'] = {};
    a['width'] = {};
    a['color'] = {};
    a['backgroundColor'] = {};
    for (let n of e) {
      if (n.textContent != undefined) {
        a['textContent'] = this.subRoutine(a['textContent'], n.textContent + '');
      }
      if (n.value != undefined) {
        a['value'] = this.subRoutine(a['value'], n.value + '');
      }
      if (n.id != undefined) {
        a['id'] = this.subRoutine(a['id'], n.id + '');
      }
      if (n.type != undefined) {
        a['type'] = this.subRoutine(a['type'], n.type + '');
      }
      if (n.src != undefined) {
        a['src'] = this.subRoutine(a['src'], n.src + '');
      }
      if (n.href != undefined) {
        a['href'] = this.subRoutine(a['href'], n.href + '');
      }
      if (n.tagName != undefined) {
        a['tagName'] = this.subRoutine(a['tagName'], n.tagName + '');
      }
      if (n.title != undefined) {
        a['title'] = this.subRoutine(a['title'], n.title + '');
      }
      if (n.previousSibling != undefined) {
        a['previousSibling'] = this.subRoutine(a['previousSibling'], n.previousSibling + '');
      }
      if (n.nextSibling != undefined) {
        a['nextSibling'] = this.subRoutine(a['nextSibling'], n.nextSibling + '');
      }
      if (n.parentElement != undefined) {
        a['parentElement'] = this.subRoutine(a['parentElement'], n.parentElement + '');
      }
      if (n.className != undefined) {
        a['className'] = this.subRoutine(a['className'], n.className + '');
      }
      if (n.alt != undefined) {
        a['alt'] = this.subRoutine(a['alt'], n.alt + '');
      }

      var box = this.zoomBoundingRect(n);
      if (box.left != undefined) {
        a['left'] = this.subRoutine2(a['left'], Math.round(box.left) + '');
      }
      if (box.top != undefined) {
        a['top'] = this.subRoutine2(a['top'], Math.round(box.top) + '');
      }
      if (box.height != undefined) {
        a['height'] = this.subRoutine2(a['height'], Math.round(box.height) + '');
      }
      if (box.width != undefined) {
        a['width'] = this.subRoutine2(a['width'], Math.round(box.width) + '');
      }

      var backgroundColor = window.getComputedStyle(n, null).getPropertyValue('background-color');
      if (backgroundColor != undefined) {
        a['backgroundColor'] = this.subRoutine2(a['backgroundColor'], backgroundColor + '');
      }

      var color = window.getComputedStyle(n, null).getPropertyValue('color');
      if (color != undefined) {
        a['color'] = this.subRoutine2(a['color'], color + '');
      }
    }

    return JSON.stringify(a);
  };

  this.detectEncoding = function () {
    try {
      // Select the meta element
      var metaElement = document.querySelector('meta[http-equiv="Content-Type"]');

      if (metaElement) {
        var metaContent = metaElement.getAttribute('content');

        if (metaContent && metaContent.indexOf('charset') > -1 && metaContent.indexOf('=') > -1) {
          var metas = metaContent.split('=');
          return metas[1];
        }
      }
    } catch (e) {
      window.fconsole.log(e);
    }

    //we'll default to utf-8
    return 'utf-8';
  };

  this.stripTags = function (s) {
    return s.replace(/(<([^>]+)>)/gi, '');
  };

  this.cleanValue = function (s, doTrim, element) {
    if (typeof doTrim == 'undefined') doTrim = true;

    if (typeof s === 'object' && element && element.action === 'select') {
      console.log('optionI cleanValue returning', window.WU.cleanValue(JSON.stringify(s)));
      return window.WU.cleanValue(JSON.stringify(s));
    }

    //make sure we have a string we are dealing with...
    if (s == null || typeof s == 'undefined' || typeof s.replace != 'function') return s;

    try {
      //we need this to allow for API explorer calls...
      if (document.URL.indexOf('www.functionizeapp.com') > -1) this.textCharacterLimit = 100000;
    } catch (e) {
      window.fconsole.log(e.message);
    }

    // s = this.stripTags(s);
    if (s.length > this.textCharacterLimit) s = s.substr(0, this.textCharacterLimit);

    if (doTrim) {
      s = s.trim();
    }

    return s;
  };

  this.xPathToCss = function (xpath) {
    return xpath
      .replace(/\[(\d+?)\]/g, function (s, m1) {
        return '[' + (m1 - 1) + ']';
      })
      .replace(/\/{2}/g, '')
      .replace(/\/+/g, ' > ')
      .replace(/@/g, '')
      .replace(/\[(\d+)\]/g, ':eq($1)')
      .replace(/^\s+/, '');
  };

  this.uaMatch = function (ua) {
    ua = ua.toLowerCase();
    var match =
      /(chrome)[ /]([\w.]+)/.exec(ua) ||
      /(webkit)[ /]([\w.]+)/.exec(ua) ||
      /(opera)(?:.*version|)[ /]([\w.]+)/.exec(ua) ||
      /(msie) ([\w.]+)/.exec(ua) ||
      (ua.indexOf('compatible') < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua)) ||
      [];
    return {
      browser: match[1] || '',
      version: match[2] || '0',
    };
  };

  this.setBrowserVariable = function () {
    if (typeof window.fzeBrowser == 'undefined' || !window.fzeBrowser) {
      window.fzeBrowser = {};
    }
    var browser = {};
    var matched = this.uaMatch(navigator.userAgent);

    if (matched.browser) {
      browser[matched.browser] = true;
      browser.version = matched.version;
    }

    // Chrome is Webkit, but Webkit is also Safari.
    if (browser.chrome) {
      browser.webkit = true;
    } else if (browser.webkit) {
      browser.safari = true;
    }

    window.fzeBrowser = browser;
  };

  this.getBrowser = function () {
    if (this.currentBrowser != null) return this.currentBrowser;

    this.setBrowserVariable();
    var userAgent = navigator.userAgent.toLowerCase();
    window.fconsole.log(userAgent);
    var isChrome = /chrome/.test(navigator.userAgent.toLowerCase());

    var browser = {};
    if (isChrome) {
      window.fzeBrowser.name = 'chrome';
      userAgent = userAgent.substring(userAgent.indexOf('chrome/') + 7);
      userAgent = userAgent.substring(0, userAgent.indexOf('.'));
      window.fzeBrowser.version = userAgent;
      window.fzeBrowser.safari = false;
    } else if (window.fzeBrowser.safari) {
      window.fzeBrowser.name = 'safari';
      userAgent = userAgent.substring(userAgent.indexOf('version/') + 8);
      userAgent = userAgent.substring(0, userAgent.indexOf('.'));
      window.fzeBrowser.version = userAgent;
    } else {
      for (var prop in window.fzeBrowser) {
        if (prop != 'version') {
          browser.name = prop;
        } else {
          browser.version = window.fzeBrowser[prop];
        }
      }
    }

    this.currentBrowser = browser;
    return browser;
  };

  this.isTinymceFrame = function () {
    return document.body.id === 'tinymce';
  };

  this.isCkeFrame = function () {
    return document.body.classList.contains('cke_editable');
  };

  this.isWysiwygEditorFrame = function () {
    return this.isCkeFrame() || this.isTinymceFrame();
  };

  this.isCompatibleBrowser = function () {
    var browser = this.getBrowser();
    window.fconsole.log('Browser' + browser.name + ' ' + parseFloat(browser.version));
    if (browser.name == 'msie' && parseFloat(browser.version) >= 9) return true;

    if (browser.name == 'mozilla') {
      if (new RegExp('Trident/.*rv:([0-9]{1,}[.0-9]{0,})').exec(navigator.userAgent) != null) {
        //this is IE 11…
        browser.name = 'msie';
        browser.version = 11;
        return true;
      }
    }
    if (browser.name == 'mozilla' && parseFloat(browser.version) >= 15) return true;
    if (browser.name == 'chrome' && parseFloat(browser.version) >= 18) return true;
    if (browser.name == 'safari' && parseFloat(browser.version) >= 4) return true;
    //add safari and chrome versions here
    return false;
  };

  this.setEvent = function (event, time, e) {
    var timeEpoch = time + performance.timing.navigationStart;

    this.events[event] = timeEpoch;
    if (typeof e != 'undefined') {
      if (typeof this.eventElements[event] == 'undefined') this.eventElements[event] = new Array();

      var elementId = e.getAttribute('data-functionize-id');

      this.eventElements[event].push({ element: elementId, time: timeEpoch });
      if (this.eventElements[event].length > 20) this.eventElements[event].shift();
    }
  };

  this.getEventElements = function (event) {
    if (typeof this.eventElements[event] == 'undefined') this.eventElements[event] = new Array();

    return this.eventElements[event];
  };

  this.hasCapturedEvent = function (event, time) {
    if (typeof this.events[event] != 'undefined' && this.events[event] == time) return true;

    return false;
  };

  this.createHash = function (s) {
    try {
      return s.split('').reduce(function (a, b) {
        a = (a << 5) - a + b.charCodeAt(0);
        return a & a;
      }, 0);
    } catch (e) {}
    return '0';
  };

  this.getFormProperties = function (element) {
    var formData = {};
    var form = element.closest('form'); // Use native method to find the closest form

    if (!form) return formData;

    formData.name = form.getAttribute('name');
    formData.id = form.getAttribute('id');
    formData.length = 1; // The length is always 1 because closest finds a single element
    formData.action = form.getAttribute('action');
    return formData;
  };

  this.escapeHtml = function (html) {
    return this.htmlEncode(html);
  };

  this.htmlEncode = function (value) {
    // Create a temporary in-memory div element
    const tempDiv = document.createElement('div');

    // Set its textContent to the value (this automatically encodes the HTML entities)
    tempDiv.textContent = value;

    // Return the encoded HTML by retrieving the innerHTML of the tempDiv
    return tempDiv.innerHTML;
  };

  this.htmlDecode = function (value) {
    // Create a temporary in-memory div element
    const tempDiv = document.createElement('div');

    // Set its innerHTML to the value (this automatically decodes HTML entities)
    tempDiv.innerHTML = value;

    // Return the decoded text by retrieving the textContent of the tempDiv
    return tempDiv.textContent;
  };

  this.isPotentialSvgChild = function (tag) {
    tag = tag.toLowerCase();
    if (this.svgTags.length < 1) {
      this.svgTags.push('tspan');
      this.svgTags.push('text');
      this.svgTags.push('circle');
      this.svgTags.push('ellipse');
      this.svgTags.push('image');
      this.svgTags.push('line');
      this.svgTags.push('path');
      this.svgTags.push('polygon');
      this.svgTags.push('polyline');
      this.svgTags.push('rect');
      this.svgTags.push('use');
      this.svgTags.push('defs');
      this.svgTags.push('glyph');
      this.svgTags.push('g');
      this.svgTags.push('marker');
      this.svgTags.push('mask');
      this.svgTags.push('missing-glyph');
      this.svgTags.push('pattern');
      this.svgTags.push('svg');
      this.svgTags.push('switch');
      this.svgTags.push('symbol');
    }
    for (var i = 0; i < this.svgTags.length; i++) {
      if (this.svgTags[i] == tag) return true;
    }
    return false;
  };

  this.isString = function (o) {
    return typeof o == 'string' || (typeof o == 'object' && o.constructor === String);
  };

  this.functionizeDate = function (eValue) {
    try {
      var today = new Date();
      var eValueArr = eValue.split('[functionizeDate');
      var eValueParamsArr = eValueArr[1].split(']');
      var dateFormat = eValueParamsArr[0].split('|FUNC|');
      var eValueParamsArrParam = dateFormat[0];
      if (eValueParamsArrParam) {
        if (eValueParamsArrParam.length > 2) {
          var opr = eValueParamsArrParam.substr(0, 1);
          var type = eValueParamsArrParam.substr(-1, 1).toLowerCase();
          var eValueParamsArrParamLeft = eValueParamsArrParam.substr(1, eValueParamsArrParam.length - 2);
          if ((opr == '+' || opr == '-') && (type == 'd' || type == 'm' || type == 'y') && !isNaN(parseFloat(eValueParamsArrParamLeft)) && isFinite(eValueParamsArrParamLeft)) {
            eValueParamsArrParamLeft = parseInt(eValueParamsArrParamLeft);
            if (type == 'd') {
              if (opr == '+') {
                today.setDate(today.getDate() + eValueParamsArrParamLeft);
              } else if (opr == '-') {
                today.setDate(today.getDate() - eValueParamsArrParamLeft);
              } else {
                //console.log("SOURAV",3);
                return eValue;
              }
            }
            if (type == 'm') {
              if (opr == '+') {
                today.setMonth(today.getMonth() + eValueParamsArrParamLeft);
              } else if (opr == '-') {
                today.setMonth(today.getMonth() - eValueParamsArrParamLeft);
              } else {
                return eValue;
              }
            }
            if (type == 'y') {
              if (opr == '+') {
                today.setYear(today.getFullYear() + eValueParamsArrParamLeft);
              } else if (opr == '-') {
                today.setYear(today.getFullYear() - eValueParamsArrParamLeft);
              } else {
                return eValue;
              }
            }
          } else {
            return eValue;
          }
        } else {
          return eValue;
        }
      }

      var monthNames = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

      var date = {
        DD: today.getDate(),
        MM: today.getMonth() + 1, //January is 0!
        MMM: monthNames[today.getMonth()],
        YY: today.getFullYear().toString().slice(-2),
        YYYY: today.getFullYear(),
      };
      if (date.DD < 10) {
        date.DD = '0' + date.DD;
      }
      if (date.MM < 10) {
        date.MM = '0' + date.MM;
      }
      today = '';
      var format = null;
      if (dateFormat[1]) {
        if (dateFormat[1].includes('-')) {
          format = dateFormat[1].split('-');
          format.forEach((type, index) => {
            today += date[type] || '';
            if (index < format.length - 1) {
              today += '-';
            }
          });
        } else if (dateFormat[1].includes('/')) {
          format = dateFormat[1].split('/');
          format.forEach((type, index) => {
            today += date[type] || '';
            if (index < format.length - 1) {
              today += '/';
            }
          });
        } else {
          today = date.MM + '/' + date.DD + '/' + date.YYYY;
        }
      } else {
        today = date.MM + '/' + date.DD + '/' + date.YYYY;
      }
      return today;
    } catch (e) {}
  };

  this.scrollAndIframeValues = function () {
    try {
      var scrollValue = {};
      scrollValue['windowScroll'] = {};
      scrollValue['documentScroll'] = {};
      scrollValue['iframeScroll'] = {};

      // Window scroll positions
      scrollValue['windowScroll']['scrollTop'] = window.scrollY;
      scrollValue['windowScroll']['scrollLeft'] = window.scrollX;

      // Document scroll positions
      scrollValue['documentScroll']['scrollTop'] = document.documentElement.scrollTop || document.body.scrollTop;
      scrollValue['documentScroll']['scrollLeft'] = document.documentElement.scrollLeft || document.body.scrollLeft;

      // Iframe scroll positions
      Array.from(document.querySelectorAll('iframe')).forEach((iframe) => {
        var iframeTargetVal = window.WS.targetElement(iframe);
        var xpath = null;
        if (iframeTargetVal.xpath5) {
          xpath = iframeTargetVal.xpath5;
        } else if (iframeTargetVal.xpath4) {
          xpath = iframeTargetVal.xpath4;
        } else if (iframeTargetVal.xpath3) {
          xpath = iframeTargetVal.xpath3;
        } else if (iframeTargetVal.xpath2) {
          xpath = iframeTargetVal.xpath2;
        } else if (iframeTargetVal.xpath) {
          xpath = iframeTargetVal.xpath;
        }

        var frameRect = iframe.getBoundingClientRect();
        scrollValue['iframeScroll'][xpath] = {};
        scrollValue['iframeScroll'][xpath]['scrollTop'] = frameRect.top + window.scrollY;
        scrollValue['iframeScroll'][xpath]['scrollLeft'] = frameRect.left + window.scrollX;
      });

      return scrollValue;
    } catch (e) {
      // Handle the error here
      // console.error(e.message);
    }
  };

  this.isFunctionizeElement = function (e, alertOk = false) {
    if (e === document) return false;
    // Convert e to a DOM element if it's not already
    e = e instanceof Element ? e : document.querySelector(e);

    // Check if the element or any of its parents have the alert class
    if (alertOk) {
      let alertFound = false;
      let currentElement = e;

      while (currentElement) {
        if (currentElement.classList.contains(`${window.fUniqPrefix}-alert`)) {
          window.fconsole.log('Functionize alert found');
          return false;
        }
        currentElement = currentElement.parentElement;
      }

      if (e.classList.contains(`${window.fUniqPrefix}-alert`)) {
        window.fconsole.log('Functionize alert found');
        return false;
      }
    }

    // Check if the element or its parents have the functionize class
    let currentElement = e;
    while (currentElement) {
      if (currentElement.classList.contains(window.fUniqPrefix) || currentElement.classList.contains(`${window.fUniqPrefix}-panel`)) {
        return true;
      }
      currentElement = currentElement.parentElement;
    }

    // Check again if alertOk is false
    if (!alertOk) {
      currentElement = e;
      while (currentElement) {
        if (currentElement.classList.contains(`${window.fUniqPrefix}-alert`)) {
          return true;
        }
        currentElement = currentElement.parentElement;
      }
    }

    return false;
  };
}

//Meta Checker object here...
export function MetaChecker() {
  this.cspRaw = '';
  this.cspByType = {};
  // Sites allowed by type
  this.requiredSrc = {
    'script-src': ['https://storage-download.googleapis.com/functionize-public/', 'https://app.functionize.com'],
    'style-src': ['https://storage-download.googleapis.com/functionize-public/', 'https://app.functionize.com'],
    'img-src': ['https://storage-download.googleapis.com/functionize-public/', 'https://app.functionize.com'],
  };
  this.srcBlocked = []; // Empty if no problems found
  this.unsafeInlineEnabled = true;
  this.unsafeEvalEnabled = true;

  this.isFunctionizeContentEnabled = function () {
    if (window.TCM.isCSP) {
      return false;
    }

    // Check if CSP meta tag exists
    const metaTag = document.querySelector('meta[http-equiv="content-security-policy"]');
    if (!metaTag) {
      // No CSP defined
      return true;
    } else {
      // Inspect CSP
      this.cspRaw = metaTag.getAttribute('content');
      const cspSplit = this.cspRaw
        .split(';')
        .map((statement) => statement.trim())
        .filter(Boolean);

      // Local variables because JS object nonsense
      const cspByType = { 'default-src': [] }; // default-src is always present because it is used for logic later
      const srcBlocked = [];

      cspSplit.forEach((statement) => {
        // Type is the stuff before the first ' or space. ie default-src
        const [type, ...rest] = statement.split(/[ ']+/);
        // Remove type from statement
        const sources = rest.join(' ').split(' ').filter(Boolean);
        cspByType[type] = sources;
      });

      // Check for required sites
      for (const sourceType in this.requiredSrc) {
        this.requiredSrc[sourceType].forEach((src) => {
          if (!cspByType[sourceType]?.includes(src) && !cspByType['default-src']?.includes(src)) {
            srcBlocked.push([sourceType, src, `${sourceType} does not allow ${src}`]);
          }
        });
      }

      // Check for unsafe operations
      this.unsafeInlineEnabled = cspByType['script-src']?.includes("'unsafe-inline'");
      this.unsafeEvalEnabled = cspByType['script-src']?.includes("'unsafe-eval'");

      // Save information to object
      this.cspByType = cspByType;
      this.srcBlocked = srcBlocked;
    }

    return this.srcBlocked.length === 0 && this.unsafeInlineEnabled && this.unsafeEvalEnabled;
  };
}

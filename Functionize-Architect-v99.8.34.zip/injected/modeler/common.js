/**
 * Protect window.console method calls, e.g. console is not defined on IE
 * unless dev tools are open, and IE doesn't define console.debug
 */
export function initCommon() {
  (function() {
    // if (!window.console) {
    // window.console = {};
    //}
    // union of Chrome, FF, IE, and Safari console methods
    var m = [
      'log',
      'info',
      'warn',
      'error',
      'debug',
      'trace',
      'dir',
      'group',
      'groupCollapsed',
      'groupEnd',
      'time',
      'timeEnd',
      'profile',
      'profileEnd',
      'dirxml',
      'assert',
      'count',
      'markTimeline',
      'timeStamp',
      'clear',
    ];
    // define undefined methods as noops to prevent errors
    for (var i = 0; i < m.length; i++) {
      if (!window.console[m[i]]) {
        //window.console[m[i]] = function () { };
      }
    }
  })();

  (function() {
    if (!window.fconsole) {
      window.fconsole = {};
    }
    window.fconsole['log'] = function(message) {
      try {
        //if (typeof TCM != 'undefined' && TCM.debug)
        //window.console.log(message + " at " + document.location.href.substring(0, 100));
      } catch (e) {
        //probably IE8 or less
        //console.log(e.message);
      }
    };
  })();
  window.FzPageVariable = {};
  window.functioniseJsErrors = '';
}

export var functioniseDeviceDetect = {
  Android: function() {
    return navigator.userAgent.match(/Android/i);
  },
  BlackBerry: function() {
    return navigator.userAgent.match(/BlackBerry/i);
  },
  iOS: function() {
    return navigator.userAgent.match(/iPhone|iPad|iPod/i);
  },
  iPhone: function() {
    return navigator.userAgent.match(/iPhone/i);
  },
  iPad: function() {
    return navigator.userAgent.match(/iPad/i);
  },
  iPod: function() {
    return navigator.userAgent.match(/iPod/i);
  },
  Opera: function() {
    return navigator.userAgent.match(/Opera Mini/i);
  },
  Windows: function() {
    return navigator.userAgent.match(/IEMobile/i);
  },
  any: function() {
    return (
      functioniseDeviceDetect.Android() ||
      functioniseDeviceDetect.BlackBerry() ||
      functioniseDeviceDetect.iOS() ||
      functioniseDeviceDetect.Opera() ||
      functioniseDeviceDetect.Windows()
    );
  },
  find: function() {
    if (functioniseDeviceDetect.Android()) return 'Android';

    if (functioniseDeviceDetect.BlackBerry()) return 'BlackBerry';

    if (functioniseDeviceDetect.Opera()) return 'Opera';

    if (functioniseDeviceDetect.Windows()) return 'Windows';

    if (functioniseDeviceDetect.iPhone()) return 'iPhone';

    if (functioniseDeviceDetect.iPad()) return 'iPad';

    if (functioniseDeviceDetect.iPod()) return 'iPod';

    return '';
  },
};

export function wsElement() {
  this.value = '';
  this.text = '';
}

export function generalObject() {}

export function functioniseSettings() {
  //set defaults here
  this.retainManagerBoxPosition = true;
  this.advancedTesting = false;
  this.showRecordtimeErrors = false;
  this.hideWindowOnClose = true;
  this.helperOn = true;
  this.managerBoxTop = 30;
  this.managerBoxRight = 30;
  this.coverElementOnActionRec = true;
  this.EnableMaxScreenResolution = true;
}

export function functioniseAssocVars(index, value) {
  this.index = index;
  this.value = value;
}

export function functionisePopups(id, ref) {
  this.reference = ref;
  this.id = id;
}

export function functioniseTestResult() {}

export function functioniseCss() {
  // eslint-disable-next-line no-unused-expressions
  this.index;
  // eslint-disable-next-line no-unused-expressions
  this.style;
}

export function functioniseStyles() {
  this.styles = new Array();

  this.addStyle = function(style) {
    this.styles.push(style);
  };

  this.getStyle = function(index) {
    for (var i = 0; i < this.styles.length; i++) {
      if (this.styles[i].index == index) {
        return this.styles[i].style;
      }
    }
    return '';
  };
}

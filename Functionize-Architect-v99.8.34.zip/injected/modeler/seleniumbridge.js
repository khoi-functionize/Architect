import { functioniseTestResult } from './common';
export function SeleniumBridge() {
  this.triggerAction = function(event) {
    var method = event.detail.method;
    // Select the element using querySelector
    var element = document.querySelector("[data-functionize-el='" + event.detail.element + "']");

    window.WS.verifyCurrentElement = element;
    var result = new functioniseTestResult();
    window.TCM.isVerifying = true;

    // Retrieve properties using native methods
    result.tagName = element.tagName;
    result.index = Array.from(element.parentNode.children).indexOf(element); // Get the index of the element
    result.value = element.value || ''; // Use default empty string if no value
    result.text = element.textContent || ''; // Use textContent instead of text
    result.id = element.id;
    result.data = window.WS.targetElement(element, method, 0);

    // Get scroll position and mouse/event coordinates
    result.data.scrollTop = window.scrollY;
    result.data.scrollLeft = window.scrollX;
    result.data.mouseX = 1;
    result.data.mouseY = 1;
    result.data.eventX = 0;
    result.data.eventY = 0;
    result.data.path = '';

    result.data = this.mergeParams(result.data, event);
    window.WS.stopCollecting(result);
  };
  this.triggerSimpleAction = function(event) {
    var method = event.detail.method;
    var result = new functioniseTestResult();
    window.TCM.isVerifying = true;
    result.data = {};
    result.data.action = method;
    result.data = this.mergeParams(result.data, event);
    window.WS.stopCollecting(result);

    if (method == 'navigate') {
      setTimeout(function() {
        location = result.data.url;
      }, 100);
    }
  };
  this.triggerFunctionizeAppActions = function(event) {
    var method = event.detail.method;
    var result = new functioniseTestResult();
    window.TCM.isVerifying = true;
    result.data = {};
    result.data.action = method;
    var URL = '';

    switch (method) {
      case 'apicall':
        URL = window.WS.functionizeappAPIURL;
        break;
      case 'smsreceive':
        URL = window.WS.functionizeappSMSURL;
        break;
      case 'fileViewer':
        URL = window.WS.functionizeappFileViewer;
        break;
      case 'DBExplorer':
        URL = window.WS.functionizeappDBExplorer;
        break;
      case 'emailreceive':
        URL = window.WS.functionizeappEmailURL;
        break;
    }
    result.data.url = URL;
    window.WS.stopCollecting(result);

    if (URL)
      setTimeout(function() {
        location = URL;
      }, 100);
  };

  this.mergeParams = function(resultData, event) {
    if (typeof event.detail != 'undefined' && typeof event.detail.params != 'undefined') {
      var aparams = event.detail.params;
      for (let key in aparams) {
        // Check if the property belongs to the object itself
        if (aparams.hasOwnProperty(key)) {
          resultData[key] = aparams[key];
        }
      }
    }
    return resultData;
  };
}

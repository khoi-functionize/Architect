import { functioniseTestResult } from '../common';
import tippy from 'tippy.js';

let getEventElement = function (event) {
  if (typeof event.path !== 'undefined' && event.path.length > 0) {
    return event.path[0];
  }
  if (event.composedPath() && event.composedPath()[0]) {
    return event.composedPath()[0];
  }

  return event.target;
};

export function functioniseMessageListener(event) {
  if (event.data.call === 'setResolvePageVariable') {
    if (event.data.result && Date.now() - window.WS.functionizeValidateCustomJSTime < 1000) {
      clearTimeout(window.WS.functionizeValidateCustomJSUpdateTimer);
      window.WS.functionizeValidateCustomJSUpdateTimer = setTimeout(() => {
        if (window.WS.functionizeValidateCustomJSProperty === 'value') {
          window.WS.functionizeValidateCustomJSElement.value = event.data.result;
        } else {
          window.WS.functionizeValidateCustomJSElement.innerText = event.data.result;
        }

        window.WS.functionizeValidateCustomJSResult = event.data.result;

        console.log('updateVariableLastAction', event.data.result);
        window.WS.updateVariableLastAction({
          [window.WS.functionizeValidateCustomJSProperty]: window.WS.functionizeValidateCustomJSDisplay,
          actualstring: event.data.result,
          generatedValue: event.data.result,
        });
      }, 300);
    }

    return;
  }
  var windowVariables = null;
  if (event.data.call == 'setPageAjaxVariablesForMutation') {
    windowVariables = event.data.window;
    window.AMD.addClickAjaxCallsForAjaxPageVariables(windowVariables);
  }
  if (event.data.call === 'showDialog') {
    self.port.emit('message', {
      obj: 'TCM',
      call: 'showDialog',
      arguments: event.data.retVal,
      forVue: true,
    });
  }
  if (event.data.call == 'functioniseCustomAlert') {
    /*
    (async () => {
      while (!window.hasOwnProperty('WS')) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      clearTimeout(window.functioniseCustomAlertTimer);
      window.functioniseCustomAlertTimer = setTimeout(() => {
        console.log('calling alert');
        window.WS.customAlert(event.data.text);
      }, 500);
    })();
     */
  }
  if (event.data.call == 'functioniseCustomPrompt') {
    /*
    (async () => {
      while (!window.hasOwnProperty('WS')) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      clearTimeout(window.functionisecustomPromptTimer);
      window.functionisecustomPromptTimer = setTimeout(() => {
        window.WS.customPrompt(event.data.value, event.data.arguments);
      }, 500);
    })();
     */
  }
  if (event.data.call == 'functioniseCustomConfirm') {
    /*
    (async () => {
      while (!window.hasOwnProperty('WS')) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      clearTimeout(window.functionisecustomConfirmTimer);
      window.functionisecustomConfirmTimer = setTimeout(() => {
        window.WS.customConfirm(event.data.choice, event.data.arguments);
      }, 500);
    })();
     */
  }
  if (event.data.call == 'functioniseCustomAjax') {
    let localEvent = event.data;
    (async () => {
      while (!window.hasOwnProperty('WS') || window.WS === null) {
        console.log('waiting...');
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
      window.WS.evaluateAjaxCall(event.data.method, event.data.url, event.data.timestamp);
    })();
  }
  if (event.data.call == 'showOpenFilePicker') {
    console.log('showOpenFilePicker message all listeners', event.data);
    (async () => {
      while (!window.hasOwnProperty('TCM')) {
        console.log('waiting...');
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
      console.log('showOpenFilePicker data', event.data.data.kind, event.data.data.name);
      window.TCM.createActionWithData({ action: 'jsupload', name: event.data.data.name, kind: event.data.data.kind });
    })();
  }
  if (event.data.call == 'lazyLoad') {
    (async () => {
      while (!window.hasOwnProperty('WS')) {
        console.log('waiting...');
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
      clearTimeout(window.functionisecustomLazyLoadTimer);
      window.functionisecustomLazyLoadTimer = setTimeout(() => {
        window.WS.updateLastAction({ hasLazyLoad: true });
      }, 500);
    })();
  }
  if (event.data.call === 'functionizeAjaxVariables') {
    try {
      self.port.emit('message', {
        obj: 'TCM',
        call: 'functionizeAjaxVariables',
        arguments: event.data,
        forVue: true,
      });
    } catch (e) {
      console.log(e);
    }
  }
  if (event.data.call == 'setPageAjaxVariablesResponseForMutation') {
    var ajaxResponse = event.data.ajaxResponse;
    let element = document.getElementById('f-functionise-tc-manager-form-ajaxResponse');
    if (element) {
      element.value = JSON.stringify(ajaxResponse);
    }
  }
  if (event.data.call == 'setRelatedPageVariables') {
    if (Object.keys(event.data.pageVariables).length > 0) {
      window.WS.searchedPageVariables = event.data.pageVariables;
    } else {
      window.WS.searchedPageVariables = 'BLANK';
    }

    windowVariables = window.TCM.processWindowVariables(window.WS.searchedPageVariables);

    if (typeof windowVariables != 'object' && windowVariables == 'BLANK') windowVariables = [];

    try {
      if (typeof window.FzPageVariable !== 'undefined') {
        window.FzPageVariable.forEach((key, value) => {
          if (key.indexOf(data.pageVariableKeyword) == 0) {
            if (windowVariables == 'BLANK') windowVariables = [];
            windowVariables[`window.FzPageVariable.${key}`] = value;
          }
        });
      }
    } catch (err) {}
    window.TCM.processPageVariables(windowVariables);
    /*
    var r = 0;
    var interval = setInterval(() => {
      r++;
      if (r >= 5) {
        // No Data Found.
        clearInterval(interval);
      }
      console.log('Interval function called to process page related Variabled ' + r + ' ' + JSON.stringify(window.WS.searchedPageVariables));
      if (window.WS.searchedPageVariables == 'BLANK' && (typeof window.FzPageVariable === 'undefined' || !window.FzPageVariable || !Object.keys(window.FzPageVariable).length)) {
        // No Data Found.
        clearInterval(interval);
        window.WS.searchedPageVariables = 'BLANK';
      } else if (Object.keys(window.WS.searchedPageVariables).length > 0 || typeof window.FzPageVariable !== 'undefined') {
        var windowVariables = window.TCM.processWindowVariables(window.WS.searchedPageVariables);
        try {
          if (typeof window.FzPageVariable !== 'undefined') {
            window.FzPageVariable.forEach((key, value) => {
              if (key.indexOf(data.pageVariableKeyword) == 0) {
                if (windowVariables == 'BLANK') windowVariables = [];
                windowVariables[`window.FzPageVariable.${key}`] = value;
              }
            });
          }
        } catch (err) {}
        if (windowVariables == 'BLANK') {
          // No Data Found.
          clearInterval(interval);
        }
        clearInterval(interval);
        window.TCM.processPageVariables(windowVariables);
      }
    }, 500);

 */
  }
}
export function functioniseFullscreenchangeListener(e) {
  if (!window.TCM.isController) return;
  window.fconsole.log(document.mozFullScreenEnabled + ' ' + document.fullscreenEnabled);
  if (document.mozFullScreenEnabled || document.fullscreenEnabled) {
    const panelClass = `${window.fUniqPrefix}-panel`;
    const extruderClass = `${window.fUniqPrefix}-extruder`;

    if (!window.TCM.isFullscreen) {
      const fullscreenElement = document.mozFullScreenElement || document.fullscreenElement;
      if (fullscreenElement) {
        document.querySelectorAll(`.${panelClass}`).forEach((element) => {
          fullscreenElement.appendChild(element);
        });
        document.querySelectorAll(`.${extruderClass}`).forEach((element) => {
          fullscreenElement.appendChild(element);
        });
        window.fconsole.log(`Moving window.TCM panel .${panelClass} to ${fullscreenElement.outerHTML}`);
      }
      window.TCM.isFullscreen = true;
    } else {
      document.querySelectorAll(`.${panelClass}`).forEach((element) => {
        document.body.appendChild(element);
      });
      document.querySelectorAll(`.${extruderClass}`).forEach((element) => {
        document.body.appendChild(element);
      });
      window.fconsole.log('Moving window.TCM panel back');
      window.TCM.isFullscreen = false;
    }
  }
}
export function functioniseMouseoutListener(e) {
  // console.log('Keep tooltips ' + window.WS.settings['keepTooltipsOnVerification'] + ' ' + window.WS.settings['disableMouseout']);
  if (window.TCM && window.TCM.isVerifying) {
    if (typeof window.WS.settings['keepTooltipsOnVerification'] !== 'undefined' && window.WS.settings['keepTooltipsOnVerification']) {
      // console.log('functioniseMouseoutListener', e);
      e.preventDefault();
      e.stopImmediatePropagation();
      return;
    }
  }

  if (window.TCM && window.TCM.isVerifying && typeof window.WS.settings['disableMouseout'] !== 'undefined' && window.WS.settings['disableMouseout']) {
    e.stopPropagation();
    e.preventDefault();
    return false;
  }
  if (window.WS && window.WS.collecting == false) return;
  if (window.WU.hasCapturedEvent('mouseout', e.timeStamp)) return;
  window.WU.setEvent('mouseout', e.timeStamp);
}
export function functioniseMouseenterListener(e) {
  if (!window.WS) return;
  if (typeof window.WS.settings['disableMouseover'] === 'undefined') window.WS.settings['disableMouseover'] = false;

  if (window.WS.settings['disableMouseover']) {
    e.stopPropagation();
    e.preventDefault();
    return false;
  }
}
export function functioniseMouseleaveListener(e) {
  if (!window.WS) return;
  if (typeof window.WS.settings['disableMouseout'] === 'undefined') window.WS.settings['disableMouseout'] = false;

  if (window.WS.settings['disableMouseout'] && window.TCM.isVerifying) {
    e.stopPropagation();
    e.preventDefault();
    return false;
  }
}
export function functioniseMouseoverListener(e) {
  if (!window.WS) return;
  if (typeof window.WS.settings['disableMouseover'] === 'undefined') window.WS.settings['disableMouseover'] = false;

  let target = window.WS.isDisplayContents(e.composedPath()[0]);

  if (!window.WS.on) return;
  // TODO: discuss with tamas with this is for
  // window.AMD.prepareMetaDataForLastAction(e, 'mouseover');

  window.fconsole.log(
    'Hover ' +
      window.WS.on +
      ' ' +
      window.WS.collecting +
      ' ' +
      window.TCM.isVerifying +
      ' ' +
      window.TCM.isStopping +
      ' ' +
      window.TCM.editing +
      ' ' +
      WS.iframeUID +
      ' ' +
      target.className +
      ' ' +
      window.getComputedStyle(target).zIndex
  );

  if (e.timeStamp > 0) {
    if (window.WU.hasCapturedEvent('mouseover', e.timeStamp)) return;
    window.WU.setEvent('mouseover', e.timeStamp, target);
  }
  window.WS.hoverOnToSend = {};
  window.WS.scrollToElementOnToSend = {};

  if (target.tagName.toLowerCase() === 'textarea') {
    target.style.resize = 'none';
  }

  // return if somethign is wrong with the element...
  if (e == null || typeof e === 'undefined' || target.tagName == null || typeof target.tagName === 'undefined') return;

  // checking for elements covering our recorder...
  if (!window.WS.collectStatistics) {
    window.TCM.checkTopZIndex(target);
  }

  if (!window.WS.on || (window.TCM.isVerifying && !window.WS.collecting) || (window.TCM.isStopping && !window.WS.collecting) || window.TCM.editing) {
    if (!window.TCM.generatedDataTargetingElement && !window.TCM.flagRelatedElement && !window.TCM.projectVariableTargetingElement && !window.TCM.elementTargeting) {
      if (window.WS.settings['disableMouseover']) return false;
      return;
    }
  }

  if (target.tagName.toLocaleLowerCase() === 'iframe') {
    return;
  }

  // return on select option elements...
  if (target.tagName.toLocaleLowerCase() == 'option' || target.closest('option'))
    // we do not record into select elements.   That is executed via the select action
    return;

  // default to false for alerts
  var alertOk = false;
  // allow alerts when in collecting mode...
  if (window.WS.collecting) alertOk = true;

  // do not fire on our own elements -- with the alert exception
  if (window.WS.isFunctioniseElement(target, alertOk)) return;

  window.WS.verifyCurrentElement = target;
  window.WS.verifyCurrentElementEvent = e;

  // no iframes selected
  if (
    window.WS.collecting ||
    window.TCM.isHoveringAction ||
    window.TCM.isScrollToElementAction ||
    window.TCM.flagRelatedElement ||
    window.TCM.generatedDataTargetingElement ||
    window.TCM.projectVariableTargetingElement ||
    window.TCM.elementTargeting
  ) {
    /// collecting mode here
    window.fconsole.log('Collecting mouseover');
    window.WU.fShowAllElements();
    // window.WS.removeHighlights(true);
    clearTimeout(window.showElementTimeout);

    window.WS.verifyCurrentElement = target;
    window.WS.verifyCurrentElementEvent = e;

    clearTimeout(window.functioniseMouseTimer);
    window.WS.verifyCurrentElement = target;
    window.WS.verifyCurrentElementEvent = e;
    // window.functioniseMouseTimer = setTimeout(function () {

    if (window.WS.addingFunctioniseHider) return;
    // window.WU.fShowAllElements();
    window.WS.addingFunctioniseHider = true;
    window.WS.addedFunctioniseHider = true;
    try {
      // var cover = window.WU.fHideElement(target, e.pageX, e.pageY);
      // if (!window.WS.settings['coverElementOnActionRec']) cover = window.WS.verifyCurrentElement;

      if (
        window.TCM.flagRelatedElement ||
        window.TCM.generatedDataTargetingElement ||
        window.TCM.projectVariableTargetingElement ||
        window.TCM.elementTargeting ||
        window.WS.collecting ||
        window.TCM.isHoveringAction ||
        window.TCM.isScrollToElementAction ||
        window.WS.shiftDown
      ) {
        if (target.tagName.toLowerCase() == 'iframe' || target.tagName.toLowerCase() == 'frame') {
          window.showElementTimeout = setTimeout(function () {
            window.WU.fShowAllElements();
          }, 800);
        }
      }
    } catch (e) {
      window.fconsole.log(e.message);
    }
    window.WS.addingFunctioniseHider = false;
    // }, 18);

    var addBubble = false;
    // needs to be adjusted for the top and left margin given to body tag
    var bodyMarginTop = parseInt(window.getComputedStyle(document.body).marginTop);

    var offset = target.getBoundingClientRect();
    var offsetTop = offset.top - bodyMarginTop;

    if (addBubble) {
      var elText = window.WS.getElementBubbleText(target);
      var bubbleMsg = elText + "<hr />Functionize will analyze this element and it's attributes for visibility and content during tests.";
      tippy(target, {
        content: bubbleMsg,
      });
      /*
      if (offsetTop < 100) {
        var tooltip = window.TH.create(target, target, bubbleMsg, 0, 'top middle', 'bottom middle', false, 'verify');
      } else {
        var tooltip = window.TH.create(target, target, bubbleMsg, 0, 'bottom middle', 'top middle', false, 'verify');
      }
      window.TH.show(tooltip);
      */
    }

    if (window.WS.settings['disableMouseover']) {
      e.stopPropagation();
      e.preventDefault();
    }
    if (!window.TCM.flagRelatedElement) {
      return false;
    }
  }
  if (window.TCM.editing && !window.TCM.flagRelatedElement) {
    window.fconsole.log('Editing...');
    return false;
  }
  window.fconsole.log('Mouse over still on ' + target.tagName.toLowerCase());
  window.WS.mousex = e.pageX;
  window.WS.mousey = e.pageY;
  window.WS.mouseoverTraceX.push(e.pageX);
  window.WS.mouseoverTraceY.push(e.pageY);
  if (window.WS.mouseoverTraceX.length > 3) {
    window.WS.mouseoverTraceX.shift();
    window.WS.mouseoverTraceY.shift();
  }

  if (window.WS.settings['disableMouseover'] && !window.TCM.flagRelatedElement) {
    e.stopPropagation();
    e.preventDefault();
    return false;
  }

  if (window.WS.preCopyPaste != null && window.WS.preCopyPasteElement != null) {
    // check for copy paste operations here
    if (window.WS.preCopyPaste != window.WS.preCopyPasteElement.value) {
      // copy paste detected..   trigger action here
      console.log('createAction copy/paste', window.WS.preCopyPasteElement);
      window.WS.createAction(window.WS.preCopyPasteElement, 'input');
    }
    window.WS.preCopyPaste = null;
    window.WS.preCopyPasteElement = null;
  }
  // Get all elements of the target's tag name within the body, excluding those with a specific class and their descendants
  // var elements = Array.from(document.querySelectorAll('body ' + target.tagName)).filter(el => !el.classList.contains(window.fUniqPrefix) && !el.closest('.' + window.fUniqPrefix));
  // Find the index of the target element within the filtered elements
  // var elementIndex = elements.indexOf(target);

  // check for potentially new iframes…
  if (target.tagName.toLowerCase() == 'iframe' || target.tagName.toLowerCase() == 'frame') window.WS.disableExternalIframes();

  if (window.WS.isClicking) {
    // this is a drag even -- we record it accordingly
    if (window.WS.dragevent.firstElement == undefined) {
      window.WS.dragevent.firstElement = target;

      if (!target.getClientRects().length) {
        return { top: 0, left: 0 };
      }

      window.WS.dragevent.firstOffset = window.WU.getOffset(target);
    }
    window.fconsole.log('Clicking is on during mouse over...');
    return;
  }

  window.fconsole.log('Prepping mousedown' + target.tagName);
  // clear observe
  if (
    target.tagName != 'undefined' &&
    target.tagName.toLowerCase() != 'body' &&
    !window.WS.allowBodyTargetElement &&
    target.tagName.toLowerCase() != 'html' &&
    target.tagName.toLowerCase() != 'iframe' &&
    target.tagName.toLowerCase() != 'frame'
  ) {
    window.fconsole.log('Prepping mousedown2' + target.tagName);

    if ((e.timeStamp == window.WS.lastScrollToElementOnToSend.timestamp || e.timeStamp == window.WS.lastScrollToElementOnToSend.timestamp) && e.timeStamp > 0) {
      window.fconsole.log(e.timeStamp + ' ' + window.WS.lastScrollToElementOnToSend.timestamp);
      return;
    }

    if ((e.timeStamp == window.WS.lastHoverOnToSend.timestamp || e.timeStamp == window.WS.hoverOnToSend.timestamp) && e.timeStamp > 0) {
      window.fconsole.log(e.timeStamp + ' ' + window.WS.lastHoverOnToSend.timestamp);
      return;
    }

    var value = {};
    value.timeStamp = e.timeStamp;
    value.element = target;

    if (typeof e.offsetX !== 'undefined' && !window.WU.isPotentialSvgChild(target.tagName.toLowerCase())) {
      value.mouseX = e.offsetX;
    } else {
      value.mouseX = parseInt(e.pageX - window.WU.getOffset(target).left);
    }

    if (typeof e.offsetY !== 'undefined' && !window.WU.isPotentialSvgChild(target.tagName.toLowerCase())) {
      value.mouseY = e.offsetY;
    } else {
      value.mouseY = parseInt(e.pageY - window.WU.getOffset(target).top);
    }
    value.eventX = e.pageX;
    value.eventY = e.pageY;
    window.WS.scrollToElementOnToSend2 = value;
    window.WS.hoverOnToSend2 = value;
    window.WS.currentElement = target.tagName;
    // Get all elements that match the target's tag name within the body
    var elements = document.querySelectorAll('body ' + target.tagName);
    // Filter out elements that have the specified class or are descendants of elements with that class
    elements = Array.from(elements).filter((el) => {
      return !el.classList.contains(window.fUniqPrefix) && !el.closest('.' + window.fUniqPrefix);
    });
    // Find the index of the target element within the filtered list
    window.WS.currentElementIndex = elements.indexOf(target);

    if (window.WS.mkeyDownCounter > 20 && window.WS.mkeyDownCounter < 100000) {
      // with shift down we record the action as usual
      window.fconsole.log('Mouseover action recorder scheduled...');
      functioniseMouseoverListenerRecord();
      // in this case we cancel the event??
    }
  }
  window.fconsole.log('Mouseover done');
}
export function functioniseMouseoverListenerRecord() {
  window.fconsole.log('Recording hover called');
  if (typeof window.WS.hoverOnToSend2 !== 'undefined' && window.WS.hoverOnToSend2 != '') {
    window.WS.hoverOnToSend = window.WS.targetElement(window.WS.hoverOnToSend2.element, 'hover', window.WS.hoverOnToSend2.timeStamp); // JSON.parse(JSON.stringify(window.WS.hoverOnToSend2));

    // Set Element Data For "M"+Mouseover lister
    // var elementData = window.WS.hoverOnToSend;
    window.WS.hoverOnToSend.mouseX = window.WS.hoverOnToSend2.mouseX;
    window.WS.hoverOnToSend.mouseY = window.WS.hoverOnToSend2.mouseY;
    window.WS.hoverOnToSend.eventX = window.WS.hoverOnToSend2.eventX;
    window.WS.hoverOnToSend.eventY = window.WS.hoverOnToSend2.eventY;
    window.WS.hoverOnToSend2 = '';
    window.fconsole.log('Recording hover');
    window.WS.getRecordingData();

    // Set and build action meta previous and post state for mouse over listner
    // TODO: discuss with tamas with this is for
    // window.AMD.prepareMetaDataForLastAction('', 'mouseover', elementData);
    // var WSRecordedData = window.WS.recordedData;
    // var position = WSRecordedData.length;
    // window.AMD.buildMetaDataForLastAction('', 'mouseover', position, elementData);
  }
}
export function functioniseScrollToElementListenerRecord() {
  window.fconsole.log('Recording scroll called');
  window.WS.hasScroll = null;
  if (typeof window.WS.scrollToElementOnToSend2 !== 'undefined' && window.WS.scrollToElementOnToSend2 != '') {
    window.WS.scrollToElementOnToSend = window.WS.targetElement(window.WS.scrollToElementOnToSend2.element, 'scroll', window.WS.scrollToElementOnToSend2.timeStamp); // JSON.parse(JSON.stringify(window.WS.scrollToElementOnToSend2));

    // Set Element Data For "M"+Mouseover lister
    // var elementData = window.WS.scrollToElementOnToSend;
    window.WS.scrollToElementOnToSend.mouseX = window.WS.scrollToElementOnToSend2.mouseX;
    window.WS.scrollToElementOnToSend.mouseY = window.WS.scrollToElementOnToSend2.mouseY;
    window.WS.scrollToElementOnToSend.eventX = window.WS.scrollToElementOnToSend2.eventX;
    window.WS.scrollToElementOnToSend.eventY = window.WS.scrollToElementOnToSend2.eventY;
    window.WS.scrollToElementOnToSend.scrollToElement = true;

    window.WS.scrollToElementOnToSend2 = '';
    window.fconsole.log('Recording scroll');
    window.WS.getRecordingData();

    // Set and build action meta previous and post state for mouse over listner
    // TODO: discuss with tamas with this is for
    // window.AMD.prepareMetaDataForLastAction('', 'mouseover', elementData);
    // var WSRecordedData = window.WS.recordedData;
    // var position = WSRecordedData.length;
    // window.AMD.buildMetaDataForLastAction('', 'mouseover', position, elementData);
  }
}
export function functioniseMousedownListener(e) {
  if (typeof window.WS === 'undefined' || window.WS === null || !window.WS.on || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;

  let target = window.WS.isDisplayContents(e.composedPath()[0]);

  if (window.WS.collecting && !window.WS.isFunctioniseElement(target)) {
    // in collecting mode
    window.fconsole.log('Mousedown listener:  in collecting mode...');
    e.preventDefault();
    e.stopImmediatePropagation();
    return;
  }
  if ((window.WS.shiftDown || window.TCM.isHoveringAction || window.TCM.isScrollToElementAction) && !window.WS.isFunctioniseElement(target)) {
    e.stopPropagation();
    e.preventDefault();
    console.log('canceling mouseup action');
    // advanced panel clicks
  }
}
export function functionisePointerdownListener(e) {
  if (typeof window.WS === 'undefined' || !window.WS || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  window.WS.pointerTrace = [];
  window.WS.isPointerDown = true;
  window.WS.pointerDownTraceOffset = { x: e.pageX, y: e.pageY };
  window.WS.pointerDownTraceTimestamp = Date.now();
  window.WS.pointerDownTraceTimestampOffset = 0;

  if (document.querySelectorAll('#functionize-pointer-events').length > 0) {
    try {
      document.querySelector('#functionize-pointer-events').remove();
    } catch (e) {}
  }

  let target = window.WS.isDisplayContents(e.composedPath()[0]);

  // do not create click actions on select multiple
  if (
    window.TCM.isVerifying &&
    !window.WS.collecting &&
    (target.tagName.toLowerCase() === 'option' || target.tagName.toLowerCase() === 'optgroup' || target.closest('select') || target.closest('option'))
  ) {
    if (target.closest('select') && target.closest('select').hasAttribute('multiple')) {
      return;
    }
  }

  if (target.classList.contains('vex-dialog-button')) return false;
  // we clear the hover timeout on data recordings...
  window.fconsole.log('mousedown');

  if (target.tagName.toLowerCase() === 'iframe') {
    return;
  }

  if (target.tagName.toLowerCase() === 'html' && !target.querySelector('body').classList.contains('cke_editable')) {
    return;
  }

  if (window.WS.elementInShadowRoot(e.composedPath()) && window.WS.shadowRootSelector(e.composedPath())) {
    try {
      window.TCM.initShadowChangeListener(window.WS.shadowRootSelector(e.composedPath(), target));
    } catch (e) {
      console.log('ERROR', e);
    }
  }

  // Track signature on canvas
  // window.WS.canvasSignatureCount = 0;
  // window.WS.canvasSignatureSingle = {};
  window.WS.isMouseDown = true;

  if (window.WU.hasCapturedEvent('mousedown', e.timeStamp)) return;
  window.WU.setEvent('mousedown', e.timeStamp);
  window.WS.hoverOnToSend = {};
  window.WS.scrollToElementOnToSend = {};

  window.fconsole.log('Mousedown ' + window.WS.on + ' ' + window.WS.collecting + ' ' + window.TCM.isVerifying + ' ' + window.TCM.isStopping + ' ' + window.TCM.editing);
  if (!window.WS.on) return;

  var alertOk = false;
  if (window.WS.collecting) alertOk = true;
  if (
    ((window.TCM.isVerifying && !window.WS.collecting) || (window.TCM.isStopping && !window.WS.collecting) || window.TCM.editing) &&
    !target.classList.contains(window.fUniqPrefix + '-hider')
  ) {
    if (window.WS.isFunctioniseElement(target, alertOk)) {
      window.fconsole.log('functionise element found');
      return;
    }
    window.fconsole.log('Mousedown stopped…');
    return false;
  }

  if (window.TCM.isCachedEdit && !window.WS.isFunctioniseElement(target, alertOk)) {
    e.stopImmediatePropagation();
    e.preventDefault();
  }

  if (
    (target.tagName.toLowerCase() == 'body' && !target.classList.contains('cke_editable') && !window.WS.allowBodyTargetElement) ||
    (target.tagName.toLowerCase() == 'html' && !target.querySelector('body')?.classList.contains('cke_editable'))
  ) {
    window.fconsole.log('Mousedown cancelled on body or html target...');
    return;
  }

  window.fconsole.log('Mousedown continues…');
  window.WS.mousex = e.pageX;
  window.WS.mousey = e.pageY;

  if (window.WS.preCopyPaste != null && window.WS.preCopyPasteElement != null) {
    // check for copy paste operations here
    window.fconsole.log('Copy paste');
    if (window.WS.preCopyPaste != window.WS.preCopyPasteElement.value) {
      window.fconsole.log('Copy paste2');
      // copy paste detected..   trigger action here
      console.log('createAction copy/paste', window.WS.preCopyPasteElement);
      window.WS.createAction(window.WS.preCopyPasteElement, 'input');
    }
    window.WS.preCopyPaste = null;
    window.WS.preCopyPasteElement = null;
  }

  if (window.WS.isFunctioniseElement(target, alertOk) && !target.classList.contains(window.fUniqPrefix + '-hider')) {
    window.fconsole.log('Functionise element found2.');
    return;
  }
  // on cover elements we change the target to this...
  if (target.tagName == null || target.tagName == undefined) return;

  // interacting with unsupported elements is handled here
  if (window.WS.unsupportedParentElements.indexOf(target.tagName.toLocaleLowerCase()) > -1) {
    window.functionizeVex.dialog.alert(target.tagName.toLowerCase() + ' tags are currently not supported.   Please select another valid html element.');
    return false;
  }

  // interacting with unsupported elements is handled here
  for (var xx = 0; xx < window.WS.unsupportedParentElements.length; xx++) {
    if (target.closest(window.WS.unsupportedParentElements[xx])) {
      window.functionizeVex.dialog.alert(window.WS.unsupportedParentElements[xx] + ' tags are currently not supported.   Please select another valid html element.');
      return false;
    }
  }

  window.fconsole.log('Mousedown at collecting check…' + window.WS.collecting);
  if (window.WS.collecting) {
    // in collecting mode
    window.fconsole.log('Mousedown is in collecting mode...' + window.WS.shiftDown);
    e.preventDefault();
    e.stopImmediatePropagation();
    // set current element to be the event target from our covere
    if (!target.classList.contains(window.fUniqPrefix + '-hider')) {
      // return false;
      window.WS.verifyCurrentElement = target;
      window.WS.verifyCurrentElementEvent = e;
    }

    let unsupportedTargetElements = !window.WS.allowBodyTargetElement ? [...window.WS.unsupportedTargetElements, 'body'] : window.WS.unsupportedTargetElements;

    if (unsupportedTargetElements.indexOf(window.WS.verifyCurrentElement.tagName.toLowerCase()) > -1) {
      alert('The ' + window.WS.verifyCurrentElement.tagName.toLowerCase() + ' tag is not currently supported.   Please select another valid html element.');
      return false;
    }

    var isAlert = false;
    if (window.WS.verifyCurrentElement.closest('div.' + window.fUniqPrefix + '-alert')) {
      // next we make sure that only the text can be targetted
      if (!window.WS.verifyCurrentElement.classList.contains('vex-dialog-message')) {
        alert('You can only verify the text message in an alert box.');
        return false;
      }
      isAlert = true;
    }

    var result = new functioniseTestResult();

    // Get the element from either WS.verifyCurrentElement or the event's composedPath
    var element = window.WS.verifyCurrentElement || e.composedPath()[0]; // Use [0] to get the first element in composedPath

    result.tagName = element.tagName;
    result.index = Array.from(document.querySelectorAll(result.tagName)).indexOf(element);
    result.value = element.value || '';
    result.text = element.textContent || '';
    result.id = element.id || '';

    if (!isAlert) {
      result.data = window.WS.targetElement(window.WS.verifyCurrentElementEvent || e.composedPath()[0], 'verify', e.timeStamp);
    } else {
      result.data = {
        action: 'verify',
        element: 'functioniseAlertBox',
        text: element.textContent || '',
      };
    }
    // Get the scroll positions of the window
    result.data.scrollTop = window.scrollY || document.documentElement.scrollTop;
    result.data.scrollLeft = window.scrollX || document.documentElement.scrollLeft;

    // Get the element from either WS.verifyCurrentElement or the event's composedPath
    var selection = window.WS.verifyCurrentElement || e.composedPath()[0]; // Use [0] to get the first element in composedPath

    // Get the offset of the element
    var elementRect = selection.getBoundingClientRect();

    // Calculate mouse positions relative to the element
    result.data.mouseX = parseInt(e.pageX - (elementRect.left + window.scrollX));
    result.data.mouseY = parseInt(e.pageY - (elementRect.top + window.scrollY));

    // Store the event's page coordinates
    result.data.eventX = e.pageX;
    result.data.eventY = e.pageY;

    if (typeof document.body !== 'undefined' && typeof document.body.clientHeight !== 'undefined') {
      result.data.clientHeight = document.body.clientHeight;
    }

    result.data.path = '';
    setTimeout(function () {
      window.WS.stopCollecting(result);
    }, 250); // we delay the effect so the mouseup and click events still cancel after us….
    window.fconsole.log('Mousedown stopped...');
    return false;
  }

  window.fconsole.log('Mousedown at editing check' + window.TCM.editing);

  if (window.TCM.editing) {
    window.fconsole.log('window.TCM editing on.   Returning');
    return false;
  }

  // check for right clicks
  if (e.which > 1) {
    if (window.WS.debounceTimer) {
      clearTimeout(window.WS.debounceTimer);
    }
    window.WS.debounceTimer = setTimeout(() => {
      window.WS.rightClick(e);
      window.WS.debounceTimer = null;
    }, 100);
    return;
  }

  // reset drag event
  window.WS.lastMouseDownTime = window.WU.getTime();
  window.WS.dragevent = null;
  window.WS.dragevent = function () {};
  window.WS.isClicking = true;
  // record click start position in case of drag event
  if (!target._p0Data) {
    target._p0Data = {};
  }

  target._p0Data.p0 = {
    x: e.pageX,
    y: e.pageY,
    target: target,
    width: target.offsetWidth,
    height: target.offsetHeight,
    top: target.getBoundingClientRect().top + window.scrollY,
    left: target.getBoundingClientRect().left + window.scrollX,
  };

  // we check if the shift key is down or not for advanced editor
  if (window.WS.shiftDown) {
    console.log('//shift down means we are opening the advanced panel');
    // shift down means we are opening the advanced panel
    // normally we record on mouseup -- not in this case
    window.fconsole.log('Shift down element: ' + typeof window.WS.verifyCurrentElement);
    window.fconsole.log('Shift Down Element tag: ' + window.WS.verifyCurrentElement.tagName.toLowerCase());

    const tagName = window.WS.verifyCurrentElement.tagName.toLowerCase();
    if (!window.WS.allowBodyTargetElement && tagName !== 'body' && tagName !== 'iframe' && tagName !== 'frame') {
      window.WS.getRecordingData();

      // set coordinates for click action
      if (!target.x) {
        const rect = target.getBoundingClientRect();
        target.x = rect.left + window.scrollX;
      }
      if (!target.y) {
        const rect = target.getBoundingClientRect();
        target.y = rect.top + window.scrollY;
      }
      target.mouseX = window.WS.verifyCurrentElement.mouseX;
      target.mouseY = window.WS.verifyCurrentElement.mouseY;

      let action = 'click';
      if (window.TCM.isHoveringAction) {
        action = 'hover';
        if (window.WS.clickToSend !== '') {
          window.WS.clickToSend.action = 'hover';
        }
        window.WS.clickToSend = {};
      }
      if (window.TCM.isScrollToElementAction) {
        action = 'scroll';
        if (window.WS.clickToSend !== '') {
          window.WS.clickToSend.action = 'scroll';
          window.WS.clickToSend.scrollToElement = true;
        }
        window.WS.clickToSend = {};
      }

      if (window.TCM.isScrollToElementAction) {
        action = 'scroll';
        if (window.WS.clickToSend !== '') {
          window.WS.clickToSend.action = 'scroll';
          window.WS.clickToSend.scrollToElement = true;
        }
        window.WS.clickToSend = {};
      }

      if (!window.TCM.generatedDataTargetingElement && !window.TCM.projectVariableTargetingElement) {
        const element = window.WS.targetElement(window.WS.verifyCurrentElementEvent, action, e.timeStamp);
        if (element.action === 'click') {
          element.metaKey = e.metaKey || false;
          element.shiftKey = e.shiftKey || false;
          element.altKey = e.altKey || false;
          element.ctrlKey = e.ctrlKey || false;
        }
        window.WS.getRecordingData(element);
        window.TCM.startEdit(element);
      }
      e.preventDefault();
      e.stopImmediatePropagation();
      console.log('canceling pointerdown action');
    }
    return false;
  }

  if (!window.TCM.generatedDataTargetingElement && !window.TCM.projectVariableTargetingElement) {
    window.fconsole.log('populating click ' + window.WS.shiftDown);
    var value = window.WS.targetElement(e, 'click', e.timeStamp); /// generates the json for the current element
    if (typeof e.offsetX !== 'undefined' && !target.closest('svg')) {
      value.mouseX = e.offsetX;
    } else {
      value.mouseX = parseInt(e.pageX - window.WU.getOffset(target).left);
    }

    if (typeof e.offsetY !== 'undefined' && !target.closest('svg')) {
      value.mouseY = e.offsetY;
    } else {
      value.mouseY = parseInt(e.pageY - window.WU.getOffset(target).top);
    }
    value.eventX = e.pageX;
    value.eventY = e.pageY;

    if (value.action === 'click') {
      value.metaKey = e.metaKey || false;
      value.shiftKey = e.shiftKey || false;
      value.altKey = e.altKey || false;
      value.ctrlKey = e.ctrlKey || false;
    }

    if (typeof document.body !== 'undefined' && typeof document.body.clientHeight !== 'undefined') {
      value.clientHeight = document.body.clientHeight;
    }

    // create unique value here
    if (JSON.stringify(window.WS.clickToSend) == JSON.stringify(value) || value.timestamp == window.WS.lastClickToSend.timestamp) return; // prevent further effects
    // always observe the last hover before the click

    if (value.element != 'option' && !target.closest('option')) {
      console.log('setting the value of clicktosend');
      // we do not record clicks into select elements.   That is executed via the select action
      window.WS.clickToSend = value;
      window.WS.clickToSendCopy = value;
    }

    // we now record right away.    Multiple js frameworks cancel our events later, and thus we need to capture it early on….

    if (window.TCM.isCachedEdit && !window.WS.isFunctioniseElement(target)) return false;
    window.WS.clickEventCheck[target] = 'START';
  }

  // Hack to allow selectbox to work on chrome on linux system while recording - mouseup event is not fired until an option is selected in the select box. We track for mouse up event a manualy fire in case of element is select and the system is linux based.
  var linuxMatch = navigator.platform.match(/Linux/i);
  if (
    typeof linuxMatch !== 'undefined' &&
    linuxMatch &&
    linuxMatch.length &&
    window.WS.clickEventCheck[target] == 'START' &&
    typeof target.tagName !== 'undefined' &&
    target.tagName.toLowerCase() == 'select'
  ) {
    window.fconsole.log('Forcing pointerup listener for India office.');
    // forced means that we call the function as if the event has happened...
    // but the pointed up has not fired yet
    var forced = true;
    functionisePointerupListener(e, forced);
  }
}
export function functioniseMouseupListener(e) {
  if (typeof window.WS === 'undefined' || window.WS === null || !window.WS.on || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  window.WS.isMouseDown = false;
  let target = window.WS.isDisplayContents(e.composedPath()[0]);
  if (window.WS.isFunctioniseElement(target)) {
    return;
  }

  if (target.tagName.toLowerCase() === 'iframe') {
    return;
  }

  if (
    window.WS.shiftDown ||
    window.TCM.isHoveringAction ||
    window.TCM.isScrollToElementAction ||
    window.TCM.generatedDataTargetingElement ||
    window.TCM.projectVariableTargetingElement ||
    window.TCM.elementTargeting
  ) {
    e.stopPropagation();
    e.preventDefault();
    return;
  }
  if (window.TCM.isCachedEdit && !window.WS.isFunctioniseElement(target)) {
    e.stopImmediatePropagation();
    e.preventDefault();
    return;
  }
  if (window.WS.collecting && !window.WS.isFunctioniseElement(target)) {
    window.fconsole.log('Mouseup stopped from listener…');
    e.stopImmediatePropagation();
    e.preventDefault();
    return;
  }
  if ((window.TCM && window.TCM.isVerifying) || window.WS.collecting || (window.TCM.isStopping && !window.WS.collecting) || window.TCM.editing) {
    if (window.WS.isFunctioniseElement(target)) return;
    window.fconsole.log('Mouseup stopped…');
    return false;
  }
}
export function functionisePointerupWindowListener(e, forced) {
  if (typeof window.TCM === 'undefined' || window.TCM === null || typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;

  if (window.WS.collecting && !window.WS.isFunctioniseElement(e.composedPath()[0])) {
    window.WS.isPointerDown = false;
    window.WS.pointerDownTracing = false;
    e.stopImmediatePropagation();
    e.preventDefault();
    return false;
  }
}
export function functioniseMouseupWindowListener(e, forced) {
  if (typeof window.TCM === 'undefined' || window.TCM === null || typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;

  if (window.WS.collecting && !window.WS.isFunctioniseElement(e.composedPath()[0])) {
    window.WS.isPointerDown = false;
    window.WS.pointerDownTracing = false;
    e.stopImmediatePropagation();
    e.preventDefault();
    return false;
  }
}
export function functioniseClickWindowListener(e, forced) {
  if (typeof window.TCM === 'undefined' || window.TCM === null || typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;

  if (window.WS.collecting && !window.WS.isFunctioniseElement(e.composedPath()[0])) {
    window.WS.isPointerDown = false;
    window.WS.pointerDownTracing = false;
    e.stopImmediatePropagation();
    e.preventDefault();
    return false;
  }
}
export function functionisePointerupListener(e, forced) {
  if (typeof window.TCM === 'undefined' || window.TCM === null || typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  window.WS.isPointerDown = false;
  window.WS.pointerDownTracing = false;
  window.WS.pointerDownTraceTimestampOffset = Date.now() - window.WS.pointerDownTraceTimestamp;
  let target = window.WS.isDisplayContents(e.composedPath()[0]);
  window.WS.clickEventCheck[target] = 'REACHED';
  if (window.WS.isFunctioniseElement(target)) {
    return;
  }

  if (target.tagName.toLowerCase() === 'iframe') {
    return;
  }

  // do not create click actions on select multiple
  if (window.TCM.isVerifying && !window.WS.collecting && (target.tagName.toLowerCase() === 'option' || target.tagName.toLowerCase() === 'optgroup' || target.closest('option'))) {
    if (target.closest('select') && target.closest('select').hasAttribute('multiple')) {
      return;
    }
  }

  if (typeof forced === 'undefined') forced = false;

  var linuxMatch = navigator.platform.match(/Linux/i);
  if (
    typeof linuxMatch !== 'undefined' &&
    linuxMatch &&
    linuxMatch.length &&
    window.WS.clickEventCheck[target] == 'START' &&
    typeof target.tagName !== 'undefined' &&
    target.tagName.toLowerCase() == 'select' &&
    !forced
  ) {
    // console.log('Canceling pointerup on linux detected');
    return;
  }

  // Track signature on canvas
  if (window.WS.enableCaptureSignature && !target.closest('.f-functionise')) {
    console.log('Checking for canvas draw' + window.WS.canvasSignatureCount + ' ' + target.tagName.toLowerCase());
    if (window.WS.canvasSignatureCount > 0 && target.tagName.toLowerCase() == 'canvas') {
      console.log('window.WS.canvasSignatureSingle', window.WS.canvasSignatureSingle);
      window.WS.canvasSignature.push(window.WS.canvasSignatureSingle);
      window.WS.createSignatureAction();
      window.WS.canvasSignatureCount = 0;
      window.WS.canvasSignatureSingle = {};
      window.WS.enableCaptureSignature = false;
      return;
    }
  }

  // we do not deal with right clicks here
  if (!window.WS.on) return;
  if (window.WS.shiftDown) {
    e.stopPropagation();
    e.preventDefault();
    return false; // advanced panel clicks
  }

  // TODO: discuss with tamas with this is for
  // window.AMD.prepareMetaDataForLastAction(e, 'mouseup');

  if (window.TCM.isCachedEdit && !window.WS.isFunctioniseElement(target)) {
    e.stopImmediatePropagation();
    e.preventDefault();
  }

  if (window.WU.hasCapturedEvent('mouseup', e.timeStamp)) return;
  window.WU.setEvent('mouseup', e.timeStamp);

  if (typeof e === 'undefined' || typeof target === 'undefined' || typeof target.tagName === 'undefined') return;

  if (target.tagName.toLowerCase() == 'html' && !target.querySelector('body').classList.contains('cke_editable')) {
    return;
  }

  if ((window.TCM && window.TCM.isVerifying) || window.WS.collecting || (window.TCM.isStopping && !window.WS.collecting) || window.TCM.editing) {
    if (window.WS.isFunctioniseElement(target)) return;
    window.fconsole.log('Mouseup stopped…');
    return false;
  }

  if (window.WS.collecting) {
    e.stopImmediatePropagation();
    e.preventDefault();
    return false;
  }

  if (window.WS.isFunctioniseElement(target)) return;

  if (window.WS.collecting && !window.TCM.isStopping) {
    e.preventDefault();
    e.stopImmediatePropagation();
    console.log('returing');
    return false;
  }

  if (e.which > 1) {
    console.log('returing');
    return;
  }

  window.WS.mousex = e.pageX;
  window.WS.mousey = e.pageY;

  if (window.TCM.isHoveringAction) {
    e.preventDefault();
    e.stopImmediatePropagation();
    if (window.WS.shiftDown) {
      // we already generated the action in startEdit
      return;
    }

    if (Object.keys(window.WS.clickToSend).length > 0) {
      console.log('setting hover');
      window.WS.clickToSend.action = 'hover';
      window.WS.hoverOnToSend = window.WS.clickToSend;
      window.WS.clickToSend = {};
      // TODO: hack to fix hover after generate data. Find and reset after generate data.
      window.WS.inputToSend = {};
      window.WS.getRecordingData();
      return;
    } else if (!window.TCM.generatedDataTargetingElement && !window.TCM.projectVariableTargetingElement) {
      let value = {};
      value.timeStamp = e.timeStamp;
      value.element = target;
      if (typeof e.offsetX !== 'undefined' && !target.closest('svg')) {
        value.mouseX = e.offsetX;
      } else {
        value.mouseX = parseInt(e.pageX - window.WU.getOffset(target).left);
      }

      if (typeof e.offsetY !== 'undefined' && !target.closest('svg')) {
        value.mouseY = e.offsetY;
      } else {
        value.mouseY = parseInt(e.pageY - window.WU.getOffset(target).top);
      }
      value.eventX = e.pageX;
      value.eventY = e.pageY;
      window.WS.lastHoverOnToSend = value;
      if (value.timestamp == window.WS.lastHoverOnToSend.timestamp) {
        return; // prevent further effects
      }
      window.WS.getRecordingData();
      return;
    }
  }

  if (window.TCM.isScrollToElementAction) {
    e.preventDefault();
    e.stopImmediatePropagation();
    if (window.WS.shiftDown) {
      // we already generated the action in startEdit
      return;
    }

    if (Object.keys(window.WS.clickToSend).length > 0) {
      console.log('setting scroll');
      window.WS.clickToSend.action = 'scroll';
      window.WS.clickToSend.scrollToElement = true;
      window.WS.scrollToElementOnToSend = window.WS.clickToSend;
      window.WS.clickToSend = {};
      // TODO: hack to fix hover after generate data. Find and reset after generate data.
      window.WS.inputToSend = {};
      window.WS.getRecordingData();
      return;
    } else if (!window.TCM.generatedDataTargetingElement && !window.TCM.projectVariableTargetingElement) {
      let value = {};
      value.timeStamp = e.timeStamp;
      value.element = target;
      if (typeof e.offsetX !== 'undefined' && !target.closest('svg')) {
        value.mouseX = e.offsetX;
      } else {
        value.mouseX = parseInt(e.pageX - window.WU.getOffset(target).left);
      }

      if (typeof e.offsetY !== 'undefined' && !target.closest('svg')) {
        value.mouseY = e.offsetY;
      } else {
        value.mouseY = parseInt(e.pageY - window.WU.getOffset(target).top);
      }
      value.eventX = e.pageX;
      value.eventY = e.pageY;
      window.WS.lastScrollToElementOnToSend = value;
      if (value.timestamp == window.WS.lastScrollToElementOnToSend.timestamp) {
        return; // prevent further effects
      }
      window.WS.getRecordingData();
      return;
    }
  }

  if (window.TCM.generatedDataTargetingElement) {
    console.log('down here');
    let recData = window.WS.targetElement(e, 'input', e.timeStamp, undefined, undefined, undefined, undefined, undefined, undefined, true);
    if (window.TCM.generatedDataFunction) {
      recData['value'] = window.TCM.generatedDataFunction;
    }
    if (window.TCM.localGeneratedDataResult) {
      recData['actualstring'] = window.TCM.localGeneratedDataResult;
    }
    if (window.TCM.localGeneratedDataResult) {
      recData['generatedValue'] = window.TCM.localGeneratedDataResult;
    }

    if (
      (target.tagName.toLowerCase() == 'input' &&
        (target.type == 'email' ||
          target.type == 'number' ||
          target.type == 'password' ||
          target.type == 'search' ||
          target.type == 'tel' ||
          target.type == 'text' ||
          target.type == 'url')) ||
      target.tagName.toLowerCase() == 'textarea'
    ) {
      var input = target;
      if (typeof input !== 'undefined') {
        if (input.tagName.toLowerCase() == 'textarea') {
          input.value += window.TCM.localGeneratedDataResult;
        } else {
          let nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
          nativeInputValueSetter.call(input, window.TCM.localGeneratedDataResult);
        }
        let event = new Event('keydown', { bubbles: true });
        if (window.location.href.indexOf('nytimes') === -1) {
          event.keyCode = 32; // space
          input.dispatchEvent(event);
          event = new Event('keypress', { bubbles: true });
          event.keyCode = 32; // space
          input.dispatchEvent(event);
          event = new Event('keyup', { bubbles: true });
          event.keyCode = 32; // space
          input.dispatchEvent(event);
        }
        event = new Event('input', { bubbles: true });
        input.dispatchEvent(event);
        event = new Event('change', { bubbles: true });
        input.dispatchEvent(event);
        event = new Event('setvalue', { bubbles: true });
        input.dispatchEvent(event);
        window.WS.inputToSend = recData;
        window.WS.getRecordingData(recData);
        // window.WS.inputToSend = {};
      }
    } else if (target.tagName.toLowerCase() === 'div' && target.hasAttribute('contenteditable')) {
      target.innerText = window.TCM.localGeneratedDataResult;
      let event = new Event('keydown', { bubbles: true });
      event.keyCode = 32; // space
      target.dispatchEvent(event);
      event = new Event('keypress', { bubbles: true });
      event.keyCode = 32; // space
      target.dispatchEvent(event);
      event = new Event('keyup', { bubbles: true });
      event.keyCode = 32; // space
      target.dispatchEvent(event);
      event = new Event('input', { bubbles: true });
      target.dispatchEvent(event);
      event = new Event('change', { bubbles: true });
      target.dispatchEvent(event);
      window.WS.inputToSend = recData;
      window.WS.getRecordingData(recData);
      // window.WS.inputToSend = {};
    }
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }
  if (window.TCM.projectVariableTargetingElement) {
    let recData = window.WS.targetElement(e, 'input', e.timeStamp);
    if (window.TCM.projectVariableDisplay) {
      recData['value'] = window.TCM.projectVariableDisplay;
    } else if (window.TCM.projectVariableValue) {
      recData['value'] = window.TCM.projectVariableValue;
    }
    if (window.TCM.projectVariableLoad_name) {
      recData['projectVariableLoad_name'] = window.TCM.projectVariableLoad_name;
    }
    if (window.TCM.projectVariableLoad_attribute) {
      recData['projectVariableLoad_attribute'] = window.TCM.projectVariableLoad_attribute;
    }
    if (window.TCM.projectVariableLoad_operation) {
      recData['projectVariableLoad_operation'] = window.TCM.projectVariableLoad_operation;
    }
    if (
      (target.tagName.toLowerCase() == 'input' &&
        (target.type == 'email' ||
          target.type == 'number' ||
          target.type == 'password' ||
          target.type == 'search' ||
          target.type == 'tel' ||
          target.type == 'text' ||
          target.type == 'url')) ||
      target.tagName.toLowerCase() == 'textarea'
    ) {
      let input = target;
      if (typeof input !== 'undefined') {
        if (target.tagName.toLowerCase() == 'textarea') {
          input.value += window.TCM.projectVariableValue;
        } else {
          let nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
          nativeInputValueSetter.call(input, window.TCM.projectVariableValue);
        }
        let event = new Event('keydown', { bubbles: true });
        event.keyCode = 32; // space
        input.dispatchEvent(event);
        event = new Event('keypress', { bubbles: true });
        event.keyCode = 32; // space
        input.dispatchEvent(event);
        event = new Event('keyup', { bubbles: true });
        event.keyCode = 32; // space
        input.dispatchEvent(event);
        event = new Event('input', { bubbles: true });
        input.dispatchEvent(event);
        event = new Event('change', { bubbles: true });
        input.dispatchEvent(event);
        event = new Event('setvalue', { bubbles: true });
        input.dispatchEvent(event);
        window.WS.inputToSend = recData;
        window.WS.getRecordingData(recData);
      }
    } else if (target.tagName.toLowerCase() === 'div' && target.hasAttribute('contenteditable')) {
      target.innerText = window.TCM.projectVariableValue;
      let event = new Event('keydown', { bubbles: true });
      event.keyCode = 32; // space
      target.dispatchEvent(event);
      event = new Event('keypress', { bubbles: true });
      event.keyCode = 32; // space
      target.dispatchEvent(event);
      event = new Event('keyup', { bubbles: true });
      event.keyCode = 32; // space
      target.dispatchEvent(event);
      event = new Event('input', { bubbles: true });
      target.dispatchEvent(event);
      event = new Event('change', { bubbles: true });
      target.dispatchEvent(event);
      window.WS.inputToSend = recData;
      window.WS.getRecordingData(recData);
    } else if (target.tagName.toLowerCase() == 'select') {
      console.log('its a select');
    }

    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }
  var element = null;
  if (window.TCM.elementTargeting) {
    e.preventDefault();
    e.stopImmediatePropagation();
    element = window.WS.targetElement(window.WS.verifyCurrentElementEvent, 'target', e.timeStamp);
    window.TCM.saveElementTarget(element);
    console.log('returing');
    return false;
  }

  /*
  // the variables conditionTargetingElement and saveConditionTargetElement do not exist anywhere else
  if (window.TCM.conditionTargetingElement) {
    e.preventDefault();
    e.stopImmediatePropagation();
    element = window.WS.targetElement(window.WS.verifyCurrentElementEvent, 'target', e.timeStamp);
    window.TCM.saveConditionTargetElement(element);
    console.log('returing');
    return false;
  }
  */

  if (
    target.tagName.toLowerCase() == 'input' &&
    (target.getAttribute('type') == 'date' || target.getAttribute('type') == 'time' || target.getAttribute('type') == 'datetime-local')
  ) {
    e.preventDefault();
    e.stopImmediatePropagation();
    window.WS.clickToSend = {};
    return false;
  }

  // if its an input type number and the value has changed we update this field....
  if (target.tagName.toLowerCase() === 'input' && ['number', 'date', 'time', 'datetime-local'].includes(target.type)) {
    console.log('input and number');

    if (Object.keys(window.WS.clickToSend).length > 0) {
      // we update this action
      if (window.WS.clickToSend.value !== target.value) {
        window.WS.clickToSend.value = target.value;
        window.WS.clickToSend.action = 'input';
        window.WS.inputToSend = window.WS.clickToSend;
        window.WS.clickToSend = {};
        window.WS.getRecordingData();
        if (window.TCM.isCachedEdit && !window.WS.isFunctioniseElement(target)) return false;
        return;
      }
    } else {
      // we generate it....
      window.fconsole.log('mouseup populating');
      const value = window.WS.targetElement(e, 'input', e.timeStamp); // generates the JSON for the current element

      if (e.offsetX !== undefined && !target.closest('svg')) {
        value.mouseX = e.offsetX;
      } else {
        const rect = target.getBoundingClientRect();
        value.mouseX = parseInt(e.pageX - rect.left);
      }

      if (e.offsetY !== undefined && !target.closest('svg')) {
        value.mouseY = e.offsetY;
      } else {
        const rect = target.getBoundingClientRect();
        value.mouseY = parseInt(e.pageY - rect.top);
      }

      value.eventX = e.pageX;
      value.eventY = e.pageY;

      // create unique value here
      if (JSON.stringify(window.WS.inputToSend) === JSON.stringify(value) || value.timestamp === window.WS.lastInputToSend.timestamp) return; // prevent further effects
      window.WS.inputToSend = value;
      window.WS.getRecordingData();
      if (window.TCM.isCachedEdit && !window.WS.isFunctioniseElement(target)) return false;
      return;
    }
  }

  // we check and record event if not yet recorded
  if (
    (!window.WS.hasAction('hover', e.timeStamp) || !window.WS.hasAction('scroll', e.timeStamp) || !window.WS.hasAction('click', e.timeStamp)) &&
    Object.keys(window.WS.clickToSend || {}).length > 0
  ) {
    /* Off for now...
        if (window.functioniseApp || (functioniseDeviceDetect.any() != 'null' && functioniseDeviceDetect.any() != null)) { //mobile
            return;
        } */
    window.fconsole.log('Recording click action with timestamp: ' + e.timeStamp);
    window.WS.getRecordingData();
    // only do this after an actual click rec….
    var data = {};
    data.eventX = e.pageX;
    data.eventY = e.pageY;
    if (typeof document.body !== 'undefined' && typeof document.body.clientHeight !== 'undefined') {
      data.clientHeight = document.body.clientHeight;
    }
    data.timestamp = e.timeStamp;
    data.target = target;
    data.event = e;
    window.WS.updateLastActionByEventLocation(data); // this will decide weather to update the action to a dragby

    // var newdata = {};
    // if (window.WS.associatedKey) {
    // }
    // window.WS.updateLastAction(newdata);
  } else {
    window.fconsole.log('Click already has click action');
  }

  window.WS.isClicking = false;
  if (window.TCM.isCachedEdit && !window.WS.isFunctioniseElement(target)) return false;
}
export function functioniseContextMenuListener(e) {
  // if we get this event this late in the chain we cancel it...
  let target = getEventElement(e);
  if (window.WS == null || typeof target.tagName === 'undefined') return;
  if (window.TCM.liveEdit) return;
  e.preventDefault();
  target.classList.remove('z-flash-highlighted');
  clearTimeout(window.WS.flashTimer);
  setTimeout(function () {
    target.classList.remove('z-flash-highlighted');
  }, 50);
  return false;
}
export function functioniseFocusListener(e) {
  if (typeof window.WS === 'undefined' || window.WS == null) return;
  if (e && e.composedPath() && e.composedPath()[0]) {
    let target = window.WS.isDisplayContents(e.composedPath()[0]);
    if (window.WS == null || typeof target.tagName === 'undefined') return;
    if (target.tagName.toLowerCase() === 'iframe') {
      return;
    }
    if (target.tagName.toLowerCase() !== 'input' && target.tagName.toLowerCase() !== 'textarea' && target.getAttribute('contenteditable') !== 'true') return;
    if (typeof window.WS == 'undefined') return;
    if (target.value !== '' && target.getAttribute('contenteditable') !== 'true') {
      target.setAttribute('data-focusvalue', target.value);
    }
    if (target.getAttribute('contenteditable') === 'true' && target.innerText !== '') {
      target.setAttribute('data-focustext', target.innerText);
    }
    // removing this feature for preFocus and postFocus due to issues
    /*
    if (target !== window.WS.activeElements.post) {
      window.WS.activeElements.pre = window.WS.activeElements.post;
      window.WS.activeElements.post = target;
    }
     */
  }
}
export function functioniseDragstartListener(e) {
  if (window.WS == null) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  let target = window.WS.isDisplayContents(e.composedPath()[0]);
  if (typeof target.tagName === 'undefined') return;
  if (window.WU.hasCapturedEvent('dragstart', e.timeStamp)) return;
  window.WU.setEvent('dragstart', e.timeStamp);

  if (!window.WS.on) return;

  if (window.WS.pointerDownTracing) {
    window.WS.pointerDownDndTracing = true;
    window.WS.capturePointerPositions({ x: e.pageX, y: e.pageY });
  }

  if (target.tagName.toLowerCase() === 'iframe') {
    return;
  }

  console.log('functioniseDragstartListener', e);

  if ((window.TCM && window.TCM.isVerifying) || window.TCM.isStopping || window.WS.collecting || window.TCM.editing) {
    if (window.WS.isFunctioniseElement(target)) {
      return;
    }
    return false;
  }

  function delay(delayInms) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(2);
      }, delayInms);
    });
  }

  if (typeof e.pageX === 'undefined') {
    delay(300);
  }

  // clear the click action....
  window.WS.clickToSend = {};
  window.WS.isClicking = false;
  if (window.WS.isFunctioniseElement(target, false) && !target.classList.contains(window.fUniqPrefix + '-hider')) {
    return;
  }
  // on cover elements we change the target to this...
  if (target.tagName == null || target.tagName == undefined) return;

  // interacting with unsupported elements is handled here
  if (window.WS.unsupportedParentElements.indexOf(target.tagName.toLocaleLowerCase()) > -1) {
    window.functionizeVex.dialog.alert(target.tagName.toLowerCase() + ' tags are currently not supported.   Please select another valid html element.');
    return false;
  }

  // interacting with unsupported elements is handled here
  function hasMatchingParent(element, selectors) {
    while (element) {
      if (selectors.some((selector) => element.matches(selector))) {
        return true;
      }
      element = element.parentElement;
    }
    return false;
  }

  for (var xx = 0; xx < window.WS.unsupportedParentElements.length; xx++) {
    if (hasMatchingParent(target, window.WS.unsupportedParentElements[xx])) {
      window.functionizeVex.dialog.alert(window.WS.unsupportedParentElements[xx] + ' tags are currently not supported.   Please select another valid html element.');
      return false;
    }
  }

  console.log('populating dragstart');
  window.WS.dragElement = e.composedPath()[0];
  var value = window.WS.targetElement(e, 'html5dragdrop', e.timeStamp);
  let pageX = typeof e.pageX === 'undefined' ? window.WS.mousex : e.pageX;
  let pageY = typeof e.pageY === 'undefined' ? window.WS.mousey : e.pageY;
  let boundingClientRect = target.getBoundingClientRect();
  //if (typeof e.offsetX !== 'undefined') {
  //  value.mouseX = e.offsetX;
  //} else {
  value.mouseX = parseInt(pageX - boundingClientRect.left);
  //}
  //if (typeof e.offsetY !== 'undefined') {
  //  value.mouseY = e.offsetY;
  //} else {
  value.mouseY = parseInt(pageY - boundingClientRect.top);
  //}
  value.eventX = pageX;
  value.eventY = pageY;
  // create unique value here
  if (JSON.stringify(window.WS.html5dragstartToSend) == JSON.stringify(value)) return; // prevent further effects
  // always observe the last hover before the click

  console.log('window.WS.html5dragstart', value);
  if (value.hasOwnProperty('elementStatistics')) {
    // value.elementStatisticsDrag = JSON.parse(JSON.stringify(value.elementStatistics));
    delete value.elementStatistics;
  }
  console.log('window.WS.html5dragstart', value);
  window.WS.html5dragstart = value;
}
export function functioniseDragdropListener(e) {
  if (window.WS == null) return;
  if (!window.WS.on) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  function delay(delayInms) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(2);
      }, delayInms);
    });
  }

  if (typeof e.pageX === 'undefined') {
    delay(300);
  }

  let target = window.WS.isDisplayContents(e.composedPath()[0]);
  if (typeof target.tagName === 'undefined') return;
  window.fconsole.log('dragdrop');
  // we do not deal with right clicks here

  if (window.WU.hasCapturedEvent('dragdrop', e.timeStamp)) return;
  window.WU.setEvent('dragdrop', e.timeStamp);

  window.fconsole.log('checking dragdrop target:' + target.tagName);

  if (typeof e === 'undefined' || typeof target === 'undefined' || typeof target.tagName === 'undefined') return;

  window.fconsole.log('dragdrop continues');
  if ((window.TCM && window.TCM.isVerifying) || window.WS.collecting || window.TCM.isStopping || window.TCM.editing) {
    if (window.WS.isFunctioniseElement(target)) return;
    window.fconsole.log('Dragdrop stopped…');
    return false;
  }
  window.fconsole.log('Dragdrop continues…');
  if (window.WS.isFunctioniseElement(target)) return;

  var action = 'html5dragdrop';
  var uploadFiles = '';
  if (Object.keys(window.WS.html5dragstart).length === 0) {
    // fetch FileList object

    var files = target.files || e.dataTransfer.files;
    if (typeof files === 'undefined' || files.length < 1) return;
    // process all File objects
    for (var i = 0, f; (f = files[i]); i++) {
      window.fconsole.log('File found: ' + f.name + ' ' + f.type + ' ' + f.size);
      if (i > 0) uploadFiles += '|func|';

      uploadFiles += f.name;
    }
    // this is an html5 file action drop from the desktop
    action = 'html5drop';
  }
  window.fconsole.log('populating dragdrop');
  // event, action, timeStamp, skipML, pathOverride, init, force, dragdrop
  var value = window.WS.targetElement(e, action, e.timeStamp);
  if (value.hasOwnProperty('elementStatistics')) {
    // value.elementStatisticsDrop = JSON.parse(JSON.stringify(value.elementStatistics));
    delete value.elementStatistics;
  }
  let pageX = typeof e.pageX === 'undefined' ? window.WS.mousex : e.pageX;
  let pageY = typeof e.pageY === 'undefined' ? window.WS.mousey : e.pageY;
  let boundingClientRect = target.getBoundingClientRect();
  //if (typeof e.offsetX !== 'undefined') {
  //  value.mouseX = e.offsetX;
  //} else {
  value.mouseX = parseInt(pageX - boundingClientRect.left);
  //}
  //if (typeof e.offsetY !== 'undefined') {
  //  value.mouseY = e.offsetY;
  //} else {
  value.mouseY = parseInt(pageY - boundingClientRect.top);
  // }
  value.eventX = pageX;
  value.eventY = pageY;
  var finalValue = {};
  var prefix = 'droptarget_';
  if (uploadFiles != '' || action == 'html5drop')
    // just a html5drop action
    prefix = '';

  for (let index in value) {
    if (index == 'action') continue;
    if (index === 'elementStatisticsDrop') {
      finalValue[index] = value[index];
      continue;
    }
    finalValue[prefix + index] = value[index];
  }
  var dragStart = window.WS.html5dragstart;
  for (let index in dragStart) {
    console.log(index);
    finalValue[index] = dragStart[index];
  }
  finalValue.action = action;
  if (window.WS.pointerDownTraceTimestampOffset && window.WS.pointerDownTraceTimestampOffset > 0) {
    finalValue.pointerDownTraceTime = window.WS.pointerDownTraceTimestampOffset;
  }
  if (uploadFiles != '') finalValue.files = uploadFiles;

  window.WS.html5dragstart = {};

  window.WS.html5dragdropToSend = finalValue;
  console.log('window.WS.html5dragdropToSend', window.WS.html5dragdropToSend);
  window.WS.getRecordingData();
  window.WS.dropEventSent = true;
}
export function functioniseBeforeUnloadListener(e) {
  if (window.TCM && window.TCM.isMaster) {
    e.preventDefault();
    e.returnValue = '';
    return;
  }

  delete e['returnValue'];
}
export function functioniseDragoverListener(e) {
  if (typeof window.TCM === 'undefined' || window.TCM === null || typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (window.WS.pointerDownTracing && window.WS.pointerDownDndTracing) {
    window.WS.capturePointerPositions({ x: e.pageX, y: e.pageY });
  }
}
export function functioniseDragenterListener(e) {
  if (typeof window.TCM === 'undefined' || window.TCM === null || typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  let dragEnter = e.composedPath()[0];
  if (Object.keys(window.WS.html5dragstart).length > 0) {
    // fix for when the site moves the drag node into the drop target container
    if (window.WS.dragElement == dragEnter || window.WS.dragElement == dragEnter.parentNode) {
      dragEnter = dragEnter.parentNode;
    }
    if (window.WS.dragElement == dragEnter) {
      dragEnter = dragEnter.parentNode;
    }
    console.log('collecting site stats with getTwoSelection', window.WS.dragElement, dragEnter);
    window.WS.html5dragstart.elementStatistics = window.WS.siteStatistics.getTwoSelection(window.WS.dragElement, dragEnter);
    window.WS.html5dragstart.elementStatistics.selectedIds = [window.WS.dragElement.functionizeID, dragEnter.functionizeID];
  }
}
export function functioniseDragleaveListener(e) {
  if (typeof window.TCM === 'undefined' || window.TCM === null || typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  if (e.composedPath()[0] === window.WS.dragElement) {
    //
  }
}
export function functioniseDragendListener(e, forced) {
  if (typeof window.TCM === 'undefined' || window.TCM === null || typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  let target = window.WS.isDisplayContents(e.composedPath()[0]);

  window.WS.clickEventCheck[target] = 'REACHED';

  window.WS.isPointerDown = false;
  window.WS.pointerDownTracing = false;
  window.WS.pointerDownDndTracing = false;
  window.WS.pointerDownTraceTimestampOffset = Date.now() - window.WS.pointerDownTraceTimestamp;

  if (window.WS.lastHtml5dragdropToSend && window.WS.lastHtml5dragdropToSend.hasOwnProperty('actionId')) {
    window.WS.updateActionByActionId(
      {
        pointerDownTraceTime: window.WS.pointerDownTraceTimestampOffset,
      },
      window.WS.lastHtml5dragdropToSend.actionId
    );
  }

  functionisePointerupListener(e, true);

  if (window.WS.dropEventSent) {
    window.WS.dropEventSent = false;
    return;
  }

  if (window.WS.isFunctioniseElement(target)) {
    return;
  }

  // we do not deal with right clicks here
  if (!window.WS.on) return;
  if (window.WS.shiftDown) {
    e.stopPropagation();
    e.preventDefault();
    return false; // advanced panel clicks
  }

  if (window.TCM.isCachedEdit && !window.WS.isFunctioniseElement(target)) {
    e.stopImmediatePropagation();
    e.preventDefault();
  }

  if (window.WU.hasCapturedEvent('mouseup', e.timeStamp)) return;
  window.WU.setEvent('mouseup', e.timeStamp);

  if (typeof e === 'undefined' || typeof target === 'undefined' || typeof target.tagName === 'undefined') return;

  if (
    target.tagName.toLowerCase() === 'html' &&
    (!target.querySelector('body') || (!target.querySelector('body').classList.contains('cke_editable') && !window.WS.allowBodyTargetElement))
  ) {
    return;
  }
  if ((window.TCM && window.TCM.isVerifying) || window.WS.collecting || (window.TCM.isStopping && !window.WS.collecting) || window.TCM.editing) {
    if (window.WS.isFunctioniseElement(target)) return;
    window.fconsole.log('Mouseup stopped…');
    return false;
  }

  if (window.WS.collecting) {
    e.stopImmediatePropagation();
    e.preventDefault();
    return false;
  }

  if (window.WS.isFunctioniseElement(target)) return;

  if (window.WS.collecting && !window.TCM.isStopping) {
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }

  setTimeout(() => {
    window.WS.clickToSend = window.WS.clickToSendCopy;

    // we check and record event if not yet recorded
    if (
      (!window.WS.hasAction('hover', e.timeStamp) || !window.WS.hasAction('scroll', e.timeStamp) || !window.WS.hasAction('click', e.timeStamp)) &&
      Object.keys(window.WS.clickToSend).length > 0
    ) {
      window.WS.getRecordingData();
      // only do this after an actual click rec….
      var data = {};
      data.eventX = window.WS.mousex;
      data.eventY = window.WS.mousey;
      if (typeof document.body !== 'undefined' && typeof document.body.clientHeight !== 'undefined') {
        data.clientHeight = document.body.clientHeight;
      }
      data.timestamp = e.timeStamp;
      data.target = target;
      data.event = e;
      window.WS.updateLastActionByEventLocation(data); // this will decide weather to update the action to a dragby
    } else {
    }
  }, 300);
}
export function functioniseScrollListener(e) {
  if (window.WS == null || window.TCM.isPaused || window.WS.isPointerDown) return;
  // window.console.log('architect scroll at ' + e.composedPath()[0].tagName);
  // we do not deal with right clicks here
  if (!window.WS.on) return;

  if (!window.TCM.isScrolling && !window.TCM.captureElementScrolls) return;

  let target = e.composedPath()[0];

  if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName == 'SELECT') return;

  window.WS.clickToSend = null;
  window.WS.inputToSend = null;
  window.WS.scrollToElementOnToSend = {};
  window.WS.scrollToElementOnToSend2 = {};

  window.WS.hasScroll = true;

  // setting properties in the plugin
  if (!window.TCM.isController) window.TCM.setFramePropertiesInPlugin();

  if (!window.TCM.isScrolling && (target === window || target === document || target === document.documentElement) && !window.WS.shiftDown) {
    //console.log('architect scroll in here');
    var updateScroll = false;
    if (typeof window.userScroll != 'undefined') {
      if (window.userScroll['timestamp'] + 1000 > window.WU.getTime()) {
        updateScroll = true;
      }
    }
    if (updateScroll) {
      window.userScroll['timestamp'] = window.WU.getTime();
    } else {
      window.userScroll = {
        scrollTop: window.scrollY || document.documentElement.scrollTop,
        scrollLeft: window.scrollX || document.documentElement.scrollLeft,
        timestamp: window.WU.getTime(),
        starttime: window.WU.getTime(),
      };
    }

    //console.log('architect scroll returning up here');
    return false; // not a determined scroll action
  }

  // console.log('architect scroll here');

  if (
    (!window.TCM.isScrolling && (target === window || target === document || target === document.documentElement)) ||
    window.TCM.isVerifying ||
    window.WS.collecting ||
    (window.TCM.isStopping && !window.WS.collecting) ||
    window.TCM.editing ||
    window.TCM.isScrollToElementAction ||
    window.TCM.isHoveringAction
  ) {
    if (window.WS.isFunctioniseElement(e.composedPath()[0])) return;
    console.log('architect Scroll stopped…');
    return false;
  }
  console.log('architect Scroll continues…');
  if (window.WS.isFunctioniseElement(e.composedPath()[0])) return;

  if (window.WS.scrollDebounceTimer) {
    clearTimeout(window.WS.scrollDebounceTimer);
  }
  window.WS.scrollDebounceTimer = setTimeout(() => {
    let data;
    if (target !== window && target !== document && target !== document.documentElement) {
      data = window.WS.targetElement(e, 'scroll');
      data = Object.assign(data, {
        scrollTop: target.scrollTop,
        scrollLeft: target.scrollLeft,
        timestamp: window.WU.getTime(),
        starttime: window.WU.getTime(),
        functionizeSelected: data.elementStatistics.comp.findIndex((el) => {
          if (el[12] && el[12].hasOwnProperty('functi0nize-selected')) return true;
        }),
      });
    } else {
      data = { action: 'scroll', timestamp: window.WU.getTime() };
    }
    if (typeof WS !== 'undefined' && typeof WS.functionizeid !== 'undefined') {
      data.functionizeid = window.WS.functionizeid;
    }
    if (window.TCM.isScrolling) {
      data = Object.assign(data, { userAdded: 1 });
    }
    window.WS.scrollDebounceTimer = null;
    if (!data.hasOwnProperty('userAdded') && data.hasOwnProperty('functionizeSelected') && data.functionizeSelected === -1) {
      return;
    }
    console.log('adding window scroll', JSON.parse(JSON.stringify(data)));
    window.WS.getRecordingData(data);
  }, 300);
}
export function functioniseTouchMoveListener(e) {
  return false;
}
export function functioniseBeforePrintListener(e) {
  if (window.WS == null) return;
  window.TCM.collapse();
}
export function functioniseAfterPrintListener(e) {
  if (window.WS == null) return;
  setTimeout(() => {
    window.WS.createEscapeAction();
  }, 400);
  window.TCM.unCollapse(true);
}
export function functionizePointermoveListener(e) {
  if (window.WS == null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  let target = window.WS.isDisplayContents(e.composedPath()[0]);

  if (typeof target.tagName === 'undefined') return;
  if (window.WS.isFunctioniseElement(target)) {
    window.fconsole.log('Func el ');
    return;
  }

  // Track signature on canvas
  // Utility function to check if any parent matches the selector
  function hasMatchingParent(element, selector) {
    while (element) {
      if (element.matches(selector)) {
        return true;
      }
      element = element.parentElement;
    }
    return false;
  }

  // Utility function to get the offset of an element
  function getElementOffset(element) {
    const rect = element.getBoundingClientRect();
    return {
      left: rect.left + window.scrollX,
      top: rect.top + window.scrollY,
    };
  }

  if (window.WS.isPointerDown && window.WS.enableCaptureSignature && !hasMatchingParent(target, '.f-functionise')) {
    const tagName = target.tagName.toLowerCase();
    if (tagName === 'canvas') {
      window.WS.canvasSignatureElement = target;
      const sOffset = getElementOffset(target);
      window.WS.canvasSignatureSingle[window.WS.canvasSignatureCount] = {
        x: e.pageX - sOffset.left,
        y: e.pageY - sOffset.top,
      };
      window.WS.canvasSignatureCount++;
    }
  } else if (window.WS.isPointerDown && !hasMatchingParent(target, '.f-functionise')) {
    window.WS.capturePointerPositions({ x: e.pageX, y: e.pageY });
  }
}
export function functioniseMousemoveListener(e) {
  if (window.WS == null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  let target = window.WS.isDisplayContents(e.composedPath()[0]);

  if (typeof target.tagName === 'undefined') return;
  if (window.WS.isFunctioniseElement(target)) {
    window.fconsole.log('Func el ');
    return;
  }

  if (target.tagName === 'IFRAME' && !target.iFunctionizeID) {
    console.log('gooi hovering iframe');
    let hider = document.createElement('div');
    hider.id = `${window.fUniqPrefix}-iframe-hider`;
    hider.style = 'opacity: 0.8; background-color: rgb(51, 51, 51); position: fixed; width: 100%; height: 100%; top: 0px; left: 0px; z-index: 42; visibility: visible;';
    document.body.append(hider);
    console.log('added hider');
    window.WS.parseIframes();
    setTimeout(() => {
      document.body.removeChild(hider);
    }, 2000);
    console.log('removed hider');
  }

  if (
    window.WS.collecting ||
    window.TCM.isScrollToElementAction ||
    window.TCM.isHoveringAction ||
    window.TCM.isScrollToElementAction ||
    window.TCM.flagRelatedElement ||
    window.TCM.generatedDataTargetingElement ||
    window.TCM.projectVariableTargetingElement ||
    window.TCM.conditionTargetingElement ||
    window.TCM.elementTargeting
  ) {
    window.WU.fHideElement(target, e.pageX, e.pageY);
  }
  // window.fconsole.log('Mousemove');
  if (!window.TCM.hasSentRegistration && window.WS.isIframe) {
    if (typeof self !== 'undefined' && self.port != 'undefined') {
      self.port.emit('relay', window.TCM.registrationCommand);
    } else {
      window.TCM.sendCommand(window.TCM.registrationCommand, window.parent);
    }
    window.TCM.hasSentRegistration = true;
  }

  if (window.WS.doRecording) {
    window.lastMousemoveElement = target;
  }

  //if (!window.WS.isFunctioniseElement(target) && window.WS.scrollElements.findIndex(element => element === target) === -1) {
  //  window.WS.addScrollEventListener(target);
  //}

  if (window.WS.collecting || window.WS.shiftDown) {
    window.fconsole.log('Checking for change ' + target.tagName);
    const verifyElement = window.WS.verifyCurrentElement;

    if (verifyElement && verifyElement.children.length < 1 && target.getAttribute('id') === `${window.fUniqPrefix}-hider`) {
      if (Math.abs(window.WU.lastHiderPosition.left - e.pageX) > 100 || Math.abs(window.WU.lastHiderPosition.top - e.pageY) > 100) {
        // we allow the below to run here as movement is significant. Unlikely candidate for click
      } else {
        // we can safely return here
        return;
      }
    }
    window.fconsole.log('Checking for hider ');
    if (window.WS.addingFunctioniseHider) return;

    // check for functionise elements
    var alertOk = true;
    window.fconsole.log('Checking for func element and iframe here');
    if (window.WS.isFunctioniseElement(target, alertOk)) return;
    if (target.tagName == 'iframe' || target.tagName == 'frame') return;

    window.fconsole.log('Checking for hide class');
    if (target.classList.contains(window.fUniqPrefix + '-hider')) {
    }
  }
}
export function functioniseClickListener(e) {
  if (typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  let target = window.WS.isDisplayContents(e.composedPath()[0]);
  if (window.WS.isFunctioniseElement(target)) {
    return;
  }

  if (target.tagName.toLowerCase() === 'iframe') {
    return;
  }

  if (typeof window.WS.clickEventCheck[e.composedPath()[0]] === 'undefined' || window.WS.clickEventCheck[target] == '') {
    if (window.WS.locUrl.indexOf('internetstores-b2b.force.com') > 0) functioniseMousedownListener(e);
  }
  if (window.WS.clickEventCheck[target] === 'START') {
    functioniseMouseupListener(e);
  }
  window.WS.clickEventCheck = {};

  // we clear the hover timeout on data recordings...
  window.fconsole.log('Click ' + window.WS.on + ' ' + window.WS.collecting + ' ' + window.TCM.isVerifying + ' ' + window.TCM.isStopping + ' ' + window.TCM.editing);
  window.WS.hoverOnToSend = {};
  window.WS.scrollToElementOnToSend = {};

  if (window.TCM.isCachedEdit && !window.WS.isFunctioniseElement(target)) return false;
  // if (window.WS.focusOnElementFlag) { e.composedPath()[0].focus(); }

  if (!window.WS.on) return;

  if (window.TCM.isHoveringAction) {
    e.preventDefault();
    e.stopImmediatePropagation();
    window.TCM.setIsHoveringAction(false);
    return;
  }

  if (window.TCM.isScrollToElementAction) {
    e.preventDefault();
    e.stopImmediatePropagation();
    window.TCM.setIsScrollToElementAction(false);
    return;
  }

  if (window.TCM.generatedDataTargetingElement) {
    e.preventDefault();
    e.stopImmediatePropagation();
    window.TCM.callSetTargetGenerateData({
      generatedDataTargetingElement: false,
      generatedDataFunction: '',
      localGeneratedDataResult: '',
    });
    return;
  }

  if (window.TCM.projectVariableTargetingElement) {
    e.preventDefault();
    e.stopImmediatePropagation();
    window.TCM.callSetTargetGenerateData2({ projectVariableTargetingElement: false, projectVariableValue: '' });
    return;
  }

  if (window.TCM.elementTargeting) {
    e.preventDefault();
    e.stopImmediatePropagation();
    window.TCM.setElementTarget(false);
    return;
  }

  // Set and build action meta previous and post state for click listner
  // TODO: discuss with tamas with this is for
  // window.AMD.prepareMetaDataForLastAction(e, 'click');
  // var WSRecordedData = window.WS.recordedData;
  // var position = WSRecordedData.length;
  // window.AMD.buildMetaDataForLastAction(e, 'click', position);

  if (window.WS.shiftDown && !window.TCM.flagRelatedElement) {
    e.returnValue = false;
    e.cancelBubble = true;
    e.stopPropagation();
    e.stopImmediatePropagation();
    e.preventDefault();
    return false; // advanced panel clicks
  }
  if (window.WU.hasCapturedEvent('click', e.timeStamp)) return;
  window.WU.setEvent('click', e.timeStamp);

  if (window.WS.collecting && window.WS.isFunctioniseAlertElement(target)) {
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }

  if (window.WS.collecting && !window.TCM.isStopping && !window.WS.isTCMButton(target) && !window.WS.isFunctioniseElement(target)) {
    window.fconsole.log('Stopping click event on collector on');
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }

  if ((window.TCM && window.TCM.isVerifying) || window.WS.collecting || (window.TCM.isStopping && !window.WS.collecting) || window.TCM.editing) {
    if (window.TCM.flagRelatedElement) {
      // Remove the class from each selected element
      document.querySelectorAll('.' + window.fUniqPrefix + '-related-element').forEach((element) => {
        element.classList.remove(window.fUniqPrefix + '-related-element');
      });
      window.TCM.addRelatedElement(target);
      e.preventDefault();
      e.stopImmediatePropagation();
      return false;
    }
    if (window.WS.isFunctioniseElement(target)) return;
    window.fconsole.log('Click stopped…');
    e.preventDefault();
    e.stopImmediatePropagation();
    return false;
  }
  // window.clearInterval(timer);
  if (window.WS.isFunctioniseElement(target)) return;

  window.fconsole.log('Click continues…');

  // check for external links

  // Utility function to check if any ancestor matches the selector
  function hasAncestor(element, selector) {
    while (element) {
      if (element.matches(selector)) {
        return true;
      }
      element = element.parentElement;
    }
    return false;
  }

  // Focus handling for .CodeMirror
  if (hasAncestor(target, '.CodeMirror')) {
    target.focus();
    const codeMirrorParent = target.closest('.CodeMirror');
    if (codeMirrorParent) {
      const textarea = codeMirrorParent.parentElement.querySelector('textarea');
      if (textarea) {
        textarea.focus();
      }
    }
  }

  // Focus handling for .ace_editor and ace_content
  if (target.classList.contains('ace_content') || hasAncestor(target, '.ace_editor')) {
    target.focus();
    const aceTextInput = document.querySelector('textarea.ace_text-input');
    if (aceTextInput) {
      aceTextInput.focus();
    }
  }

  // now we check for Javascript downloads
  /* NO LONGER USED
  if (target.hasAttribute('href') && (target.getAttribute('href').indexOf('data:') === 0 || target.getAttribute('href').indexOf('blob:') === 0)) {
    // this is a pure javascriptt download
    const fp = target.getAttribute('href').split('/');
    window.WS.createDownload(fp[fp.length - 1]);
  }
   */
}
export function functioniseKeydownWindowListener(e) {
  // we clear the hover timeout on data recordings...
  if (!window.WS.on || window.WS.isRecording < 1 || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  var unicode = e.charCode ? e.charCode : e.keyCode;
  var actualkey = String.fromCharCode(unicode);
  window.fconsole.log('Keystroke: ' + actualkey);

  if ((e.shiftKey || e.keyCode === 16) && !window.WS.recorderLiteVersion) {
    window.fconsole.log('1Shift down detected' + e.composedPath()[0].tagName.toLowerCase());
    if (window.WS.shiftDown) return;

    window.TCM.setShiftDown(false);

    if (window.lastMousemoveElement == null) return;

    const targetElement = e.composedPath()[0];

    if (
      targetElement.tagName.toLowerCase() !== 'input' &&
      targetElement.tagName.toLowerCase() !== 'iframe' &&
      targetElement.tagName.toLowerCase() !== 'frame' &&
      targetElement.tagName.toLowerCase() !== 'body' &&
      !window.WS.allowBodyTargetElement
    ) {
      window.WU.fShowAllElements();
      window.WS.removeHighlights();
      clearTimeout(window.functioniseMouseTimer);

      // Check for functionise elements
      if (window.WS.isFunctioniseElement(window.lastMousemoveElement)) return;

      const lastMousemoveElement = window.lastMousemoveElement;
      if (lastMousemoveElement.tagName.toLowerCase() === 'iframe' || lastMousemoveElement.tagName.toLowerCase() === 'frame') {
        return;
      }

      window.WS.verifyCurrentElement = lastMousemoveElement;
      window.functioniseMouseTimer = setTimeout(function () {
        window.WU.fHideElement(lastMousemoveElement);
        lastMousemoveElement.classList.add('z-highlighted');
      }, 10);
    }
  }
}
export function functioniseKeyupWindowListener(e) {
  // we clear the hover timeout on data recordings...
  if (!window.WS.on || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  if (window.WS.mkeyDown) window.WS.mkeyDown = false;

  if (e.shiftKey || e.keyCode === 16) {
    window.fconsole.log('Shift up detected');
    if (!window.WS.shiftDown) return;
    window.TCM.setShiftDown(false);
    window.WU.fShowAllElements();
    clearTimeout(window.functioniseMouseTimer);
    if (!window.WS.collecting) {
      // set this back to null
      window.WS.verifyCurrentElement = null;
      window.WS.verifyCurrentElementEvent = null;
    }
    // TO DO  -- need this changed to be a function call so the above code can run  //	window.WU.fShowAllElements();
    window.TCM.setShiftDown(false);
  }
}
export function functioniseKeydownListener(e) {
  if (!window.TCM || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  window.TCM.lastKeyDown = e;
  // we clear the hover timeout on data recordings...
  window.fconsole.log('Key down ' + window.WS.on + ' | ' + window.WS.doRecording);
  if (!window.WS.on) return;

  if (e.target.tagName.toLowerCase() === 'iframe') {
    return;
  }

  if (window.WU.hasCapturedEvent('keydown', e.timeStamp)) return;
  window.WU.setEvent('keydown', e.timeStamp);

  window.WS.keyDownElement = getEventElement(e);

  if (e.keyCode === 68) {
    window.WS.dKeyDown = true;
  }

  if ((e.shiftKey || e.keyCode === 16) && !window.WS.recorderLiteVersion) {
    window.TCM.setShiftDown(true);
    console.log('Shift down detected', e.composedPath()[0].tagName);
  }

  window.WS.associatedKey = '';
  window.WS.keyboardPaste = false;
  window.WS.keyboardCopy = false;

  if (e.metaKey || e.keyCode === 224) {
    window.WS.associatedKey = 'meta';
  }
  if (e.altKey || e.keyCode === 18) {
    window.WS.associatedKey = 'alt';
  }
  if (e.ctrlKey || e.keyCode === 17) {
    window.WS.associatedKey = 'ctrl';
  }

  if (window.TCM.liveEdit && e.keyCode === 86 && (window.WS.associatedKey === 'meta' || window.WS.associatedKey === 'ctrl')) {
    window.WS.keyboardPaste = true;
  }

  if (e.keyCode == 67 && (e.metaKey || e.ctrlKey)) {
    window.WS.keyboardCopy = true;
  }

  if (window.WS.doRecording < 1) return;

  // TODO: remove this
  if (window.WS.collectMlDataOnKeydown) {
    window.WS.keyDownMlData = window.WS.collectMlData(e.composedPath()[0]);
  }

  if (e.keyCode === 13) {
    // ENTER key
    if (e.composedPath()[0].tagName.toLowerCase() !== 'html' && e.composedPath()[0].tagName.toLowerCase() !== 'textarea' && !e.composedPath()[0].hasAttribute('contenteditable')) {
      // hack to add salesforce chat window textarea
      window.fconsole.log('Enter was hit…');
      if ((e.timeStamp === window.WS.enterToSend.timestamp || e.timeStamp === window.WS.lastEnterToSend.timestamp) && e.timeStamp > 0) {
        window.fconsole.log('Not sending enter on: ' + e.timeStamp + '|' + window.WS.enterToSend.timestamp);
        return;
      }
      window.fconsole.log('Recording Enter…');
      var value = window.WS.targetElement(e, 'enter', e.timeStamp);
      window.WS.enterToSend = value;
      window.WS.getRecordingData();
      return;
    }

    if (e.composedPath()[0].tagName.toLowerCase() === 'textarea' && e.composedPath()[0].value.trim() !== '') {
      window.WS.enterToSendUp = window.WS.targetElement(e.composedPath()[0], 'enter', e.timeStamp);
      return;
    }
  }

  var unicode = e.charCode ? e.charCode : e.keyCode;
  var actualkey = String.fromCharCode(unicode);
  if (actualkey == 'M') {
    window.WS.ckeyDownCounter = 0;
    window.WS.mkeyDownCounter++;
    if (window.WS.mkeyDownCounter == 5) {
      window.WS.mkeyDownCounter = 100001; // this is so that this will not trigger again
      functioniseMouseoverListenerRecord();
      setTimeout(function () {
        window.WS.mkeyDownCounter = 0;
      }, 2000);
    }
  } else if (actualkey == 'C') {
    window.WS.mkeyDownCounter = 0;
    window.WS.ckeyDownCounter++;
    console.log('window.WS.ckeyDownCounter', window.WS.ckeyDownCounter);
    if (window.WS.ckeyDownCounter == 5) {
      console.log('Triggering checkpoint', window.WS.verifyCurrentElement);
      window.WS.ckeyDownCounter = 100001; // this is so that this will not trigger again
      if (window.TCM.verifyEnabled) {
        window.TCM.stopTask(false);

        /*
        var verifyElement = window.WS.verifyCurrentElement;
        var cover = window.WU.fHideElement(verifyElement);

        if (!window.WS.settings['coverElementOnActionRec']) {
          cover = verifyElement;
        }

        // Get the text for the bubble
        var elText = window.WS.getElementBubbleText(verifyElement);
        console.log(elText);
        var bubbleMsg = elText;

        // Initialize the tippy tooltip
        console.trace('tippy');
        tippy(verifyElement, {
          content: bubbleMsg,
        });

        // Get the element's offset
        var rect = verifyElement.getBoundingClientRect();
        var offset = {
          top: rect.top + window.scrollY,
          left: rect.left + window.scrollX
        };

        // Create and show the tooltip based on the offset position
        var tooltip;
        if (offset.top < 100) {
          tooltip = window.TH.create(cover, cover, bubbleMsg, 0, 'top middle', 'bottom middle');
        } else {
          tooltip = window.TH.create(cover, cover, bubbleMsg, 0, 'bottom middle', 'top middle');
        }
        window.TH.show(tooltip);
        */
      }
    }
  } else {
    window.WS.mkeyDownCounter = 0;
    window.WS.ckeyDownCounter = 0;
  }
}
export function simulateInputEvent(input) {
  var event = new Event('keydown', { bubbles: true });
  event.keyCode = 32; // space
  input.dispatchEvent(event);
  event = new Event('keypress', { bubbles: true });
  event.keyCode = 32; // space
  input.dispatchEvent(event);
  event = new Event('keyup', { bubbles: true });
  event.keyCode = 32; // space
  input.dispatchEvent(event);
  event = new Event('input', { bubbles: true });
  input.dispatchEvent(event);
  event = new Event('change', { bubbles: true });
  input.dispatchEvent(event);
  event = new Event('setvalue', { bubbles: true });
  input.dispatchEvent(event);
}
export function functioniseKeyupListener(e, blnTriggerRemote) {
  if (!window.TCM || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  if (window.TCM.projectVariableTargetingElement) return;

  let regex = /[^a-zA-Z\d\s:]/g;
  let key = e.keyCode || e.which;

  if (window.WS.keyboardPaste || window.WS.keyboardCopy) {
    console.log('returning window.WS.keyboardPast');
    return;
  }

  let functionizeElement = getEventElement(event);
  let functionizeElementComposedPath = e.composedPath();
  if (window.WS.keyDownElement && functionizeElement !== window.WS.keyDownElement) {
    functionizeElement = window.WS.keyDownElement;
  }

  window.WS.keyDownElement = null;

  if (window.TCM.lastKeyDown && window.TCM.lastKeyDown.target != functionizeElement && !regex.test(key)) {
    e = window.TCM.lastKeyDown;
  }
  // we clear the hover timeout on data recordings...
  window.WS.hoverOnToSend = {};
  window.WS.scrollToElementOnToSend = {};

  window.fconsole.log('Keyup1');
  if (!window.WS.on) return;

  if (functionizeElement.tagName.toLowerCase() === 'iframe') return;

  // on any keyup we cancel this flag to be safe...
  if (window.WS.shiftDown) {
    window.fconsole.log('Shiftup detected');
    window.TCM.setShiftDown(false);
    window.WU.fShowAllElements();
    // TO DO  -- need this changed to be a function call so the above code can run  //	window.WU.fShowAllElements();
    if (functionizeElement.tagName.toLowerCase() != 'input' && functionizeElement.tagName.toLowerCase() != 'textarea') return;
  }

  if (e.keyCode === 37 || e.keyCode === 38 || e.keyCode === 39 || e.keyCode === 40 || e.keyCode === 27) {
    if (functionizeElement.tagName.toLowerCase() == 'input' || functionizeElement.tagName.toLowerCase() == 'textarea') return;
    window.WS.createKeypressAction(e);
    return;
  }

  if (e.keyCode === 9 && window.WS.enableTabKeypress) {
    window.WS.createKeypressAction(e);
    return;
  }

  if (e.keyCode === 68) {
    window.WS.dKeyDown = false;
  }

  window.fconsole.log('Keyup2');
  if (!window.TCM.generatedDataTargetingElement && window.WS.doRecording < 1) return;

  if (window.WU.hasCapturedEvent('keyup', e.timeStamp)) return;
  window.WU.setEvent('keyup', e.timeStamp);

  window.fconsole.log('Keyup3');

  if (window.WS.mkeyDownCounter > 0) {
    if (window.WS.mkeyDownCounter >= 45) {
      window.WS.lastInputToSend.timestamp = e.timeStamp;
      window.WS.mkeyDownCounter = 0;
      return false;
    }
    window.WS.mkeyDownCounter = 0;
  }

  if (window.WS.ckeyDownCounter > 0 && e.keyCode !== 67) {
    window.WS.ckeyDownCounter = 0;
  }

  window.fconsole.log('Keyup4');
  // do not fire on our own elements
  if (e.keyCode != 13) {
    if (window.TCM.editing) {
      window.fconsole.log('Func editing');
      return;
    }
    if (window.WS.isFunctioniseElement(functionizeElement)) {
      window.fconsole.log('Func el ');
      return;
    }
    if (functionizeElement && functionizeElement.tagName.toLowerCase() == 'body' && !window.WS.allowBodyTargetElement && !window.WS.isIframe) {
      window.fconsole.log('body ');
      return;
    }
    if (functionizeElement && functionizeElement.tagName.toLowerCase() == 'input' && functionizeElement.getAttribute('type') == 'checkbox') return;
    if (functionizeElement && functionizeElement.tagName.toLowerCase() == 'select') return;
    if (functionizeElement && functionizeElement.tagName.toLowerCase() == 'button') return;
  }
  window.fconsole.log('Keyup5');
  if (e.keyCode === 13) {
    // ENTER key
    // we handle this now in keydown
    if (functionizeElement.tagName.toLowerCase() === 'textarea') {
      if (functionizeElement.value !== '') return;
      window.WS.enterToSend = window.WS.targetElement(functionizeElement, 'enter', e.timeStamp);
      window.WS.getRecordingData();
      return;
    }
    return;
  }

  window.fconsole.log('Keyup6');
  if ((window.WS.lastInputToSend && e.timeStamp == window.WS.lastInputToSend.timestamp) || (window.WS.inputToSend && e.timeStamp == window.WS.inputToSend.timestamp)) return;

  if (
    functionizeElement.getAttribute('readonly') !== null ||
    (functionizeElement.hasOwnProperty('disabled') && (functionizeElement.disabled === true || functionizeElement.disabled === 'disabled'))
  ) {
    return;
  }
  window.fconsole.log('Keyup7');

  let doTrigger = false;

  window.randomVariableType = '';

  console.log('Target input action from keyup gooi', functionizeElement);
  var value = window.WS.targetElement(functionizeElement, 'input', e.timeStamp, undefined, undefined, undefined, undefined, undefined, functionizeElementComposedPath);
  console.log('Target input action done', value, functionizeElementComposedPath);
  var asyncInput = false;
  var variableDisplay = null;
  let variableProperty = 'value';

  // Get the value and text content of the element
  const element = functionizeElement;
  const result = element.value ? element.value.trim() : '';
  const text = element.textContent ? element.textContent.trim() : '';

  // Regular expression to match the pattern
  const pattern = /{{.*fze\..+}}/g;

  if (result.match(pattern) || text.match(pattern)) {
    if (result.match(pattern)) {
      variableDisplay = result;
    } else {
      variableProperty = 'text';
      variableDisplay = text;
    }

    let variableValue = variableDisplay.substring(variableDisplay.lastIndexOf('{{') + 2, variableDisplay.lastIndexOf('}}')).trim();
    let existingValue = variableDisplay.split('{{')[0];

    console.log('existingValue', existingValue);
    console.log('!!fze.action', variableValue);

    if (variableValue) {
      if (variableValue.includes('fze.action(')) {
        console.log('previous action');
        window.WS.getPreviousActionData(variableValue, variableProperty, functionizeElement, existingValue);
        return;
      }

      if (variableValue.includes('fze.resource[')) {
        if (variableValue[variableValue.length - 1] === '}') {
          variableValue = variableValue.slice(0, -1);
        }
        console.log('resource variable', variableValue, variableProperty, functionizeElement, existingValue);
        window.WS.getResourceVariableData(variableValue, variableProperty, functionizeElement, existingValue);
        return;
      }

      try {
        if (variableValue === 'fze.clipboard') {
          navigator.clipboard.readText().then((result) => {
            const element = functionizeElement;
            if (element) {
              const elementValue = element.value ? element.value.trim() : '';
              const regexMatch = /{{\s*fze\..+}}/g;

              if (regexMatch.test(elementValue)) {
                value.value = variableDisplay;
                element.value = existingValue + value.value;
              } else {
                value.text = variableDisplay;
                element.textContent = existingValue + value.text;
              }
            }
            window.randomVariableType = variableDisplay;
            value.generatedValue = result;
            value.actualstring = result;
            doTrigger = true;
          });
        }

        let code = 'window.WS.functionizeValidateCustomJSResult = null; window.WS.functionizeValidateCustomJSResult = ' + variableValue;

        console.log('code here', code);

        setTimeout(code, 1);

        console.log('code result here', window.WS.functionizeValidateCustomJSResult);

        asyncInput = true;
        clearTimeout(window.WS.functionizeValidateCustomJSResultTimer);
        window.WS.functionizeValidateCustomJSResultTimer = setTimeout(
          (data) => {
            // Determine the target element based on the event path or fallback to e.target
            const targetElement = (data.e.path && data.e.path[0]) || data.e.composedPath()[0] || data.functionizeElement || data.e.target;

            if (window.WS.functionizeValidateCustomJSResult) {
              // Check if the target element exists and is of the correct type
              if (targetElement) {
                const elementValue = targetElement.value ? targetElement.value.trim() : '';
                const regexMatch = /{{\s*fze\..+}}/g;

                if (regexMatch.test(elementValue)) {
                  data.value.value = data.existingValue + data.variableDisplay;
                  targetElement.value = data.existingValue + window.WS.functionizeValidateCustomJSResult;
                } else {
                  data.value.text = data.existingValue + data.variableDisplay;
                  targetElement.textContent = data.existingValue + window.WS.functionizeValidateCustomJSResult;
                }
              }

              window.randomVariableType = data.existingValue + data.variableDisplay;
              data.value.actualstring = window.WS.functionizeValidateCustomJSResult;
              data.value.generatedValue = window.WS.functionizeValidateCustomJSResult;
              doTrigger = true;
              eventPostEvaluation(data.e, data.value, doTrigger);
              console.log('Call rec', data.value);
            }

            window.WS.inputToSend = data.value;

            if (!window.WS.inputToSend?.elementStatistics) {
              window.WS.inputToSend.elementStatistics = window.WS.collectMlData(targetElement, 'input', window.WS.inputToSend.actionId);
            }

            window.WS.getRecordingData();
          },
          300,
          { value: value, functionizeElement: functionizeElement || false, e: e, existingValue: existingValue, variableDisplay: variableDisplay }
        );
      } catch (e) {
        console.log(e);
      }
      return;
    }
  }

  // Get the target element using functionizeElement
  let el = functionizeElement;
  let eValue = el.value ? el.value.trim() : '';

  // Check if the element exists
  if (el) {
    // Get the value or text content of the element
    const elementValue = el.value ? el.value.trim() : '';
    const elementText = el.textContent.trim();

    // Define the regex pattern
    const regexPattern = /\s*?{\s*?{(.+)}\s*?}/;

    // Test the regex pattern against the value and text content
    const valueMatch = regexPattern.test(elementValue);
    const textMatch = regexPattern.test(elementText);

    // If there's a match in either the value or text content, call the function
    if (valueMatch || textMatch) {
      console.log('calling generateNewVariable from keyup');
      window.WS.generateNewVariable(functionizeElement, value.actionId);
    }
  }

  console.log('Call rec');

  if (window.WS.inputToSend && window.WS.inputToSend?.elementStatistics && window.WS.inputToSend.xpath === value.xpath) {
    value.elementStatistics = window.WS.inputToSend.elementStatistics;
  }

  window.WS.inputToSend = value;

  if (!window.WS.inputToSend?.elementStatistics && (functionizeElement || element)) {
    window.WS.inputToSend.elementStatistics = window.WS.collectMlData(functionizeElement || element, 'input', window.WS.inputToSend.actionId);
  }

  window.WS.getRecordingData();

  if (asyncInput) {
    setTimeout(() => {
      eventPostEvaluation(e, value, doTrigger);
    }, 20);
  } else {
    eventPostEvaluation(e, value, doTrigger);
  }
}
export function functioniseInputListener(e) {
  if (!window.TCM || !window.WS || !window.WS.on || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  if (e.inputType !== 'insertFromPaste') return;
  if (window.TCM.projectVariableTargetingElement) return;
  if (!window.TCM.generatedDataTargetingElement && window.WS.doRecording < 1) return;
  if (e.composedPath()[0].tagName.toLowerCase() == 'input' && e.composedPath()[0].getAttribute('type') == 'checkbox') return;
  if (e.composedPath()[0].tagName.toLowerCase() == 'select') return;
  if (
    e.composedPath()[0].getAttribute('readonly') !== null ||
    (e.composedPath()[0].hasOwnProperty('disabled') && (e.composedPath()[0].disabled === true || e.composedPath()[0].disabled === 'disabled'))
  ) {
    return;
  }

  if (e.composedPath()[0].tagName.toLowerCase() === 'iframe') {
    return;
  }

  // we only allow right click and paste in livedebug
  if (!window.TCM.liveEdit) return;

  console.log('Keyup6');
  if (e.timeStamp == window.WS.lastInputToSend.timestamp || e.timeStamp == window.WS.inputToSend.timestamp) return;

  if (
    e.composedPath()[0].getAttribute('readonly') !== null ||
    (e.composedPath()[0].hasOwnProperty('disabled') && (e.composedPath()[0].disabled === true || e.composedPath()[0].disabled === 'disabled'))
  ) {
    return;
  }

  window.fconsole.log('Keyup7');

  let doTrigger = false;

  window.randomVariableType = '';

  var value = window.WS.targetElement(e, 'input', e.timeStamp);
  window.fconsole.log('Target input action done');
  var asyncInput = false;
  let variableDisplay = false;
  let variableProperty = 'value';
  // Get the target element using e.composedPath()[0]
  let element = e.composedPath()[0] || e.target;

  // Check if the element exists
  if (element) {
    // Retrieve and trim the value or text content of the element
    const valueContent = element.value ? element.value.trim() : '';
    const textContent = element.textContent.trim();

    // Check for the presence of the pattern in the value or text content
    const isValueMatch = valueContent.match(/{{.*fze\..+}}/g);
    const isTextMatch = textContent.match(/{{.*fze\..+}}/g);

    if (isValueMatch || isTextMatch) {
      if (isValueMatch) {
        variableDisplay = valueContent;
      } else {
        variableDisplay = textContent;
        variableProperty = 'text';
      }

      let variableValue = variableDisplay.substring(variableDisplay.lastIndexOf('{{') + 2, variableDisplay.lastIndexOf('}}')).trim();
      const existingValue = variableDisplay.split('{{')[0];

      console.log('existingValue', existingValue);

      if (variableValue) {
        if (variableValue.includes('fze.pageVariable.')) {
          variableValue = variableValue.replace('fze.pageVariable.', '');
        }

        console.log('!!fze.action', variableValue);
        if (variableValue.includes('fze.action(')) {
          console.log('previous action return');
          window.WS.getPreviousActionData(variableValue, variableProperty, element, existingValue);
          return;
        }

        try {
          const code = `window.WS.functionizeValidateCustomJSResult = null; window.WS.functionizeValidateCustomJSResult = ${existingValue}${variableValue}`;
          setTimeout(() => {
            eval(code);
          }, 1);

          asyncInput = true;
          setTimeout(() => {
            if (window.WS.functionizeValidateCustomJSResult) {
              const isValMatch = element.value ? element.value.trim().match(/{{\s*fze\..+}}/g) : false;
              if (isValMatch) {
                value.value = variableDisplay;
                element.value = value.value;
              } else {
                value.text = variableDisplay;
                element.textContent = value.text;
              }
              window.randomVariableType = variableDisplay;
              value.actualstring = window.WS.functionizeValidateCustomJSResult;
              value.generatedValue = window.WS.functionizeValidateCustomJSResult;
            }
          }, 10);
        } catch (e) {
          console.log(e);
        }
      }
    }
  }

  // Check if the element exists
  if (element) {
    // Retrieve and trim the value or text content of the element
    const valueContent = element.value ? element.value.trim() : '';
    const textContent = element.textContent.trim();

    // Check for the pattern in the value or text content
    const isValueMatch = valueContent.match(/\s*?{\s*?{(.+)}\s*?}/);
    const isTextMatch = textContent.match(/\s*?{\s*?{(.+)}\s*?}/);

    if (isValueMatch || isTextMatch) {
      window.WS.generateNewVariable(element, value.actionId);
    }
  }

  if (element) {
    // Retrieve and trim the value or text content of the element
    const valueContent = element.value ? element.value.replace(/[0-9]/g, '').trim() : '';
    const textContent = element.textContent.replace(/[0-9]/g, '').trim();

    // Check if either the value or text content matches '[functionizeappEmail]'
    if (valueContent === '[functionizeappEmail]' || textContent === '[functionizeappEmail]') {
      let index;

      if (textContent === '[functionizeappEmail]') {
        index = element.textContent.replace(/[^0-9]/g, '').trim();
        if (typeof index === 'undefined') index = '';

        value.generatedValue = window.TCM.getFunctionizeappEmail(index);
        element.textContent = value.generatedValue;

        value.actualstring = value.generatedValue;
        value.text = '[functionizeappEmail' + index + ']';
      } else {
        index = element.value.replace(/[^0-9]/g, '').trim();
        if (typeof index === 'undefined') index = '';

        value.generatedValue = window.TCM.getFunctionizeappEmail(index);
        element.value = value.generatedValue;

        value.actualstring = value.generatedValue;
        value.value = '[functionizeappEmail' + index + ']';
      }

      window.randomVariableType = value.text || value.value;
      doTrigger = true;
    }
  }

  // check for phone number tag for SMS
  window.fconsole.log('Check sms');
  // Get the target element using e.composedPath()[0]
  if (element) {
    // Retrieve and trim the value of the element
    const valueContent = (element.value || '').trim();

    // Define the phone patterns
    const phonePatterns = [
      '[functionizeappPhone]',
      '[functionizeappPhone_1]',
      '[functionizeappPhone_2]',
      '[functionizeappPhone_3]',
      '[functionizeappPhone_4]',
      '[functionizeappPhone_5]',
    ];

    // Check if the value matches any of the phone patterns
    if (phonePatterns.includes(valueContent)) {
      // Generate the phone value
      value.value = valueContent;
      value.generatedValue = window.TCM.getFunctionizeappPhone(valueContent);

      // Update the element's value
      element.value = value.generatedValue;

      // Set additional properties
      value.actualstring = value.generatedValue;
      doTrigger = true;
    }
  }

  window.fconsole.log('Check random string');
  // Get the target element using e.composedPath()[0]
  if (element) {
    // Retrieve and trim the value or text content of the element
    let eValue = (element.value || '').trim();
    const textContent = (element.textContent || '').trim();

    // Determine whether to use text content or value based on the presence of '[randomString]'
    if (textContent.indexOf('[randomString') > -1) {
      eValue = textContent;
    }

    // Check for the '[randomString]' pattern
    if (eValue.indexOf('[randomString') > -1) {
      window.randomVariableType = eValue;
      const matches = eValue.match(/\[randomString(.*?)\]/);

      if (matches) {
        let length = 15;
        if (matches.length > 1 && matches[1] !== '') {
          length = parseInt(matches[1].substring(0, 2), 10);
          if (isNaN(length)) length = 15;
        }

        const replacement = window.WU.randomFunctionizeString(length);
        const preTextValue = eValue.replace(matches[0], '');

        if (textContent.indexOf('[randomString') > -1) {
          // Update text content
          value.text = eValue.replace(matches[0], replacement);
          element.textContent = value.text;
          value.actualstring = value.text;
          value.generatedValue = value.text;
          value.text = preTextValue + '[randomString';
          if (length !== 15) value.text += length;
          value.text += ']';
        } else {
          // Update value
          value.value = eValue.replace(matches[0], replacement);
          element.value = value.value;
          value.actualstring = value.value;
          value.generatedValue = value.value;
          value.value = preTextValue + '[randomString';
          if (length !== 15) value.value += length;
          value.value += ']';
        }
        doTrigger = true;
      }
    }
  }

  window.fconsole.log('Check random text');

  if (element) {
    // Retrieve and trim the value or text content of the element
    let eValue = (element.value || '').trim();
    const textContent = (element.textContent || '').trim();

    // Determine whether to use text content or value based on the presence of '[randomText]'
    if (textContent.indexOf('[randomText') > -1) {
      eValue = textContent;
    }

    // Check for the '[randomText]' pattern
    if (eValue.indexOf('[randomText') > -1) {
      window.randomVariableType = eValue;
      const matches = eValue.match(/\[randomText(.*?)\]/);

      if (matches) {
        let length = 15;
        if (matches.length > 1 && matches[1] !== '') {
          length = parseInt(matches[1].substring(0, 2), 10);
          if (isNaN(length)) length = 10;
        }

        const replacementText = window.WU.randomFunctionizeText(length);
        const preTextValue = eValue.replace(matches[0], '');

        if (textContent.indexOf('[randomText') > -1) {
          // Update text content
          value.text = eValue.replace(matches[0], replacementText);
          element.textContent = value.text;
          value.actualstring = value.text;
          value.generatedValue = value.text;
          value.text = preTextValue + '[randomText';
          if (length !== 15) value.text += length;
          value.text += ']';
        } else {
          // Update value
          value.value = eValue.replace(matches[0], replacementText);
          element.value = value.value;
          value.actualstring = value.value;
          value.generatedValue = value.value;
          value.value = preTextValue + '[randomText';
          if (length !== 15) value.value += length;
          value.value += ']';
        }
        doTrigger = true;
      }
    }
  }

  window.fconsole.log('Check random text small');

  if (element) {
    // Retrieve and trim the value or text content of the element
    let eValue = (element.value || '').trim();
    const textContent = (element.textContent || '').trim();

    // Determine whether to use text content or value based on the presence of '[randomTextSmall]'
    if (textContent.indexOf('[randomTextSmall') > -1) {
      eValue = textContent;
    }

    // Check for the '[randomTextSmall]' pattern
    if (eValue.indexOf('[randomTextSmall') > -1) {
      window.randomVariableType = eValue;
      const matches = eValue.match(/\[randomTextSmall(.*?)\]/);

      if (matches) {
        let length = 15;
        if (matches.length > 1 && matches[1] !== '') {
          length = parseInt(matches[1].substring(0, 2), 10);
          if (isNaN(length)) length = 10;
        }

        const replacementText = window.WU.randomFunctionizeTextSmall(length);
        const preTextValue = eValue.replace(matches[0], '');

        if (textContent.indexOf('[randomTextSmall') > -1) {
          // Update text content
          value.text = eValue.replace(matches[0], replacementText);
          element.textContent = value.text;
          value.actualstring = value.text;
          value.generatedValue = value.text;
          value.text = preTextValue + '[randomTextSmall';
          if (length !== 15) value.text += length;
          value.text += ']';
        } else {
          // Update value
          value.value = eValue.replace(matches[0], replacementText);
          element.value = value.value;
          value.actualstring = value.value;
          value.generatedValue = value.value;
          value.value = preTextValue + '[randomTextSmall';
          if (length !== 15) value.value += length;
          value.value += ']';
        }
        doTrigger = true;
      }
    }
  }

  window.fconsole.log('Check random text upper');

  if (element) {
    // Retrieve and trim the value or text content of the element
    let eValue = (element.value || '').trim();
    const textContent = (element.textContent || '').trim();

    // Determine whether to use text content or value based on the presence of '[randomTextUpper]'
    if (textContent.indexOf('[randomTextUpper') > -1) {
      eValue = textContent;
    }

    // Check for the '[randomTextUpper]' pattern
    if (eValue.indexOf('[randomTextUpper') > -1) {
      window.randomVariableType = eValue;
      const matches = eValue.match(/\[randomTextUpper(.*?)\]/);

      if (matches) {
        let length = 15;
        if (matches.length > 1 && matches[1] !== '') {
          length = parseInt(matches[1].substring(0, 2), 10);
          if (isNaN(length)) length = 10;
        }

        const replacementText = window.WU.randomFunctionizeTextUpper(length);
        const preTextValue = eValue.replace(matches[0], '');

        if (textContent.indexOf('[randomTextUpper') > -1) {
          // Update text content
          value.text = eValue.replace(matches[0], replacementText);
          element.textContent = value.text;
          value.actualstring = value.text;
          value.generatedValue = value.text;
          value.text = preTextValue + '[randomTextUpper';
          if (length !== 15) value.text += length;
          value.text += ']';
        } else {
          // Update value
          value.value = eValue.replace(matches[0], replacementText);
          element.value = value.value;
          value.actualstring = value.value;
          value.generatedValue = value.value;
          value.value = preTextValue + '[randomTextUpper';
          if (length !== 15) value.value += length;
          value.value += ']';
        }
        doTrigger = true;
      }
    }
  }

  window.fconsole.log('Check random text');

  if (element) {
    // Retrieve and trim the value or text content of the element
    let eValue = (element.value || '').trim();
    const textContent = (element.textContent || '').trim();

    // Determine whether to use text content or value based on the presence of '[randomNumber]'
    if (textContent.indexOf('[randomNumber') > -1) {
      eValue = textContent;
    }

    // Check for the '[randomNumber]' pattern
    if (eValue.indexOf('[randomNumber') > -1) {
      window.randomVariableType = eValue;
      const matches = eValue.match(/\[randomNumber(.*?)\]/);

      if (matches) {
        let length = 15;
        let notIncNumber = '';
        const notInc = matches[1].split('#');
        if (notInc.length > 1) {
          const notIncD = parseInt(notInc[1].toLowerCase().replace('n', ''), 10);
          if (!isNaN(notIncD) && notIncD >= 0 && notIncD < 10 && notIncD.toString() !== notInc[1]) {
            notIncNumber = notIncD;
          }
        }
        length = parseInt(notInc[0], 10);
        if (isNaN(length)) length = 15;

        const replacementNumber = window.WU.randomFunctionizeNumber(length, notIncNumber);
        const preTextValue = eValue.replace(matches[0], replacementNumber);

        if (textContent.indexOf('[randomNumber') > -1) {
          // Update text content
          value.text = preTextValue;
          element.textContent = value.text;
          value.actualstring = value.text;
          value.generatedValue = value.text;
          value.text = eValue.replace(matches[0], `[randomNumber${length !== 15 ? length : ''}${notInc.length > 1 ? `#${notInc[1]}` : ''}]`);
        } else {
          // Update value
          value.value = preTextValue;
          element.value = value.value;
          value.actualstring = value.value;
          value.generatedValue = value.value;
          value.value = eValue.replace(matches[0], `[randomNumber${length !== 15 ? length : ''}${notInc.length > 1 ? `#${notInc[1]}` : ''}]`);
        }
        doTrigger = true;
      }
    }
  }

  // Project Variables - replace into recorder
  window.fconsole.log('checking project variables');

  if (element) {
    // Retrieve and trim the value or text content of the element
    let eValue = (element.value || '').trim();
    const textContent = (element.textContent || '').trim();

    // Check for the '[projectVariable]' pattern
    if (eValue.indexOf('[projectVariable') > -1) {
      const matches = eValue.match(/\[projectVariable(.*?)\]/);

      if (matches) {
        const matchedText = matches[0].trim();
        const arrVariable = matchedText.substr(1, matchedText.length - 2).split('::');

        if (arrVariable.length > 1) {
          const strVariableName = arrVariable[1];
          alert(strVariableName);

          if (textContent.indexOf('[projectVariable') > -1) {
            // Update text content
            value.text = eValue.replace(matchedText, window.TCM.getProjectVariable(strVariableName));
            value.generatedValue = value.text;
            element.textContent = value.text;
            value.text = matchedText;
          } else {
            // Update value
            value.value = eValue.replace(matchedText, window.TCM.getProjectVariable(strVariableName));
            value.generatedValue = value.value;
            element.value = value.value;
            value.value = matchedText;
          }
          doTrigger = true;
        }
      }
    }
  }

  window.fconsole.log('Check timestamp');

  if (element) {
    // Retrieve and trim the value or text content of the element
    let eValue = (element.value || '').trim();
    const textContent = (element.textContent || '').trim();

    // Check for the '[timeStamp]' pattern
    if (eValue.indexOf('[timeStamp') > -1) {
      if (eValue.endsWith(']')) {
        const currentTime = new Date().getTime();

        if (textContent.indexOf('[timeStamp') > -1) {
          // Update text content
          value.text = eValue.replace('[timeStamp]', currentTime);
          value.generatedValue = value.text;
          value.actualstring = value.text;
          element.textContent = value.text;
          value.text = '[timeStamp]';
        } else {
          // Update value
          value.value = eValue.replace('[timeStamp]', currentTime);
          value.generatedValue = value.value;
          value.actualstring = value.value;
          element.value = value.value;
          value.value = '[timeStamp]';
        }
        doTrigger = true;
      }
    }
  }

  window.fconsole.log('Check functionize date');

  if (element) {
    // Retrieve and trim the value or text content of the element
    let eValue = (element.value || '').trim();
    const textContent = (element.textContent || '').trim();

    // Check for the '[functionizeDate]' pattern
    if (textContent.indexOf('[functionizeDate') > -1) {
      eValue = textContent;
    }

    if (eValue.indexOf('[functionizeDate') > -1) {
      window.randomVariableType = eValue;
      const matches = eValue.match(/\[functionizeDate(.*?)\]/);
      if (matches != null) {
        let length = 10;
        if (matches.length > 1 && matches[1] !== '') {
          length = parseInt(matches[1].substring(0, 2), 10);
          if (isNaN(length)) length = 10;
        }

        const functionizeDateResult = window.WU.functionizeDate(eValue);

        if (textContent.indexOf('[functionizeDate') > -1) {
          // Update text content
          value.text = eValue.replace(matches[0], functionizeDateResult);
          value.generatedValue = value.text;

          const preText = eValue.replace(matches[0], '');

          element.textContent = value.text;
          value.actualstring = value.text;
          value.text = preText + eValue;
        } else {
          // Update value
          value.value = eValue.replace(matches[0], functionizeDateResult);
          value.generatedValue = value.value;

          const preValue = eValue.replace(matches[0], '');

          element.value = value.value;
          value.actualstring = value.value;
          value.value = preValue + eValue;
        }
        doTrigger = true;
      }
    }
  }

  window.fconsole.log('Check functionizeVar');

  // Define the function variable to check for
  const funcVar = '[functionizeVariable';
  let field = 'value';
  let eValue = '';

  // Ensure the element exists and is either an input or a non-input element
  if (element) {
    // Check if the element's text content contains the funcVar substring
    const textContent = (element.textContent || '').trim();

    if (textContent.indexOf(funcVar) > -1) {
      // If the substring is found, update eValue and field
      eValue = textContent;
      field = 'text';
    }
  }

  if (eValue.indexOf(funcVar) > -1) {
    if (eValue.slice(-1) == ']') {
      window.WS.loadFunctionizeVariable(e.composedPath()[0], value, eValue, field);
      return;
    } else {
      return;
    }
  } else if (funcVar.indexOf(eValue) == 0 && eValue != '') {
    return;
  }

  window.fconsole.log('Call rec');
  window.WS.inputToSend = value;

  if (!window.WS.inputToSend?.elementStatistics && element) {
    window.WS.inputToSend.elementStatistics = window.WS.collectMlData(element, 'input', window.WS.inputToSend.actionId);
  }

  window.WS.getRecordingData();

  if (asyncInput) {
    setTimeout(() => {
      eventPostEvaluation(e, value, doTrigger);
    }, 50);
  } else {
    eventPostEvaluation(e, value, doTrigger);
  }
}
function eventPostEvaluation(e, value, doTrigger) {
  if (typeof value.actualstring !== 'undefined') {
    var lastAction = window.WS.getLastRecordedDataSegment();
    if (typeof window.TCM.runtimeReplacementStrings[lastAction.actionId] === 'undefined') {
      window.TCM.runtimeReplacementStrings[lastAction.actionId] = {};
    }
    // set Suggest Verifications Input
    if (typeof window.TCM.suggestVerificationsInput[lastAction.actionId] === 'undefined') {
      window.TCM.suggestVerificationsInput[lastAction.actionId] = {};
    }
    if (typeof value.text !== 'undefined' && value.text) {
      window.TCM.runtimeReplacementStrings[lastAction.actionId]['text'] = value.actualstring;
      window.TCM.suggestVerificationsInput[lastAction.actionId]['text'] = value.actualstring;
    }
    if (typeof value.value !== 'undefined' && value.value) {
      window.TCM.runtimeReplacementStrings[lastAction.actionId]['value'] = value.actualstring;
      window.TCM.suggestVerificationsInput[lastAction.actionId]['value'] = value.actualstring;
    }
    window.TCM.suggestVerificationsInput[lastAction.actionId]['step'] = window.WS.recordedData.length;
    if (window.randomVariableType) {
      window.WS.recordedRandomVariables[value.actualstring] = window.randomVariableType;
    }
  }

  if (doTrigger) {
    // Get the target element using e.composedPath()[0] or e.target
    const target = (e.composedPath && e.composedPath()[0]) || e.target;

    if (target) {
      // Create and dispatch keydown, keypress, and keyup events
      const events = ['keydown', 'keypress', 'keyup'];
      events.forEach((eventType) => {
        const event = new KeyboardEvent(eventType, { bubbles: true, keyCode: 32, which: 32 });
        target.dispatchEvent(event);
      });

      // Check if the target is an input element
      if (target instanceof HTMLInputElement) {
        const lastValue = target.value;
        target.value = value.actualstring;

        // Create and dispatch input, change, and custom setvalue events
        const inputEvent = new Event('input', { bubbles: true });
        const changeEvent = new Event('change', { bubbles: true });
        const setvalueEvent = new Event('setvalue', { bubbles: true });

        // Simulate input event
        const tracker = target._valueTracker;
        if (tracker) {
          tracker.setValue(lastValue);
        }
        target.dispatchEvent(inputEvent);
        target.dispatchEvent(changeEvent);
        target.dispatchEvent(setvalueEvent);
      }
    }
  }
}
export function functioniseBlurListener(e) {
  if (window.WS == null || typeof e.composedPath()[0].tagName === 'undefined') return;
  if (e.composedPath()[0].tagName.toLowerCase() != 'input' && e.composedPath()[0].tagName.toLowerCase() != 'textarea') {
    // return;
  }
  // we turn this off for now….
}
export function functionizeAddListener(event, func) {
  document.addEventListener(
    event,
    function (e) {
      return func(e);
    },
    true
  );
}
export function functionizeRemoveListener(event, func) {
  document.removeEventListener(event, func);
}
export function functionizeResizeListener(e) {
  if (window.functionizeEditMode !== 'liveEdit' || window.hasShownFzeResizeMessage) return;
  // clear the timeout
  clearTimeout(window.WS.resizeTimer);
  // start timing for event "completion"
  window.WS.resizeTimer = setTimeout(window.WS.liveEditResizeNotification, 1000);
}

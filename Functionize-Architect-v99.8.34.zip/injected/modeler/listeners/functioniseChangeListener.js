export function functioniseChangeListener(e) {
  if (window.WS == null || typeof e.composedPath()[0].tagName === 'undefined') return;
  if (typeof window.WS === 'undefined' || window.WS === null || window.TCM.isPaused) return;
  if (typeof window.TCM !== 'undefined' && window.TCM.panelOpen) return;
  if (e.composedPath()[0].tagName.toLowerCase() != 'select' && e.composedPath()[0].tagName.toLowerCase() != 'input') return;
  var element = null;
  if (e.composedPath()[0].tagName.toLowerCase() == 'input') {
    element = e.composedPath()[0];
    if (element.type !== 'file' && element.type !== 'color' && element.type !== 'date' && element.type !== 'datetime-local' && element.type !== 'time') {
      return;
    }
  }
  // we clear the hover timeout on data recordings...
  window.WS.hoverOnToSend = '';
  window.WS.scrollToElementOnToSend = '';

  if (!window.WS.on || window.WS.doRecording < 1) return;
  // do not fire on our own elements
  if (window.WS.isFunctioniseElement(e.composedPath()[0])) return;

  if (window.WS.keyboardCopy) {
    return;
  }

  // we do not record changes in disabled elements…    Js is probably setting not the user...
  element = e.composedPath()[0];
  var isInputElement = element.tagName.toLowerCase() === 'input';
  var isReadOnly = element.hasAttribute('readonly');
  var isDisabled = element.disabled;

  if ((isReadOnly && isInputElement) || isDisabled) {
    return;
  }

  let path = false;
  if (
    typeof e.composedPath()[e.composedPath().length - 1].getRootNode === 'function' &&
    typeof e.composedPath()[e.composedPath().length - 1].getRootNode().host === 'object' &&
    typeof e.composedPath()[e.composedPath().length - 1].getRootNode().host.shadowRoot === 'object'
  ) {
    path = e.composedPath();
    let shadowDom = path[path.length - 1];
    while (typeof shadowDom.getRootNode().host === 'object') {
      path.push(shadowDom.getRootNode().host);
      shadowDom = shadowDom.getRootNode().host;
    }
  }

  var value = null;

  if (e.composedPath()[0].tagName.toLowerCase() == 'select') {
    // we check for element focus…    If we do not have it its scripted…  TODO: jquery(target).is(':focus') does not work in shadow dom
    element = e.composedPath()[0];
    var isElementFocused = document.activeElement === element;
    var isLastInPathWindow = e.composedPath()[e.composedPath().length - 1] === window;

    if (!isElementFocused && isLastInPathWindow) {
      return;
    }

    value = window.WS.targetElement(e, 'select', e.timeStamp, false, path);
    if (e.timeStamp == window.WS.lastSelectToSend.timestamp) return;

    // value = window.WS.targetElement(e, 'select', e.timeStamp);
    window.WS.lastSelectToSend = value;
  } else {
    if (e.timeStamp == window.WS.lastInputToSend.timestamp) return;

    var type = e.composedPath()[0].getAttribute('type');
    window.fconsole.log('populating input on change');
    value = window.WS.targetElement(e, 'input', e.timeStamp, false);
    window.WS.lastInputToSend = value;
  }

  window.fconsole.log('Recording change event ' + e.composedPath()[0].tagName.toLowerCase());

  window.WS.getRecordingData(value, false);
}

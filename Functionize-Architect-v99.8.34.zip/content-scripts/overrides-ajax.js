function injectCode(src) {
  const script = document.createElement('script');
  script.setAttribute('id', 'functionize-overrides');
  script.setAttribute('type', 'text/javascript');

  // This is why it works!
  script.src = src;
  script.onload = function() {
    this.remove();
  };

  // This script runs before the <head> element is created,
  // so we add the script to <html> instead.
  (document.head || document.documentElement).appendChild(script);
}
if (typeof window.appended == 'undefined') {
  window.appended = false;
}
if (!window.appended) {
  window.appended = true;
  injectCode(chrome.runtime.getURL('content-scripts/overridesScript.js'));
  window.addEventListener(
    'message',
    function(event) {
      if (event.source != window) return;
      if (event.data.call == 'functioniseCustomAlert') {
        (async () => {
          while (!window.hasOwnProperty('WS')) {
            console.log('waiting for WS...', window.location.href);
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          setTimeout(() => {
            window.WS.customAlert(event.data.text);
          }, 500);
        })();
      }
      if (event.data.call == 'functioniseCustomPrompt') {
        (async () => {
          while (!window.hasOwnProperty('WS')) {
            console.log('waiting for WS...', window.location.href);
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          window.WS.customPrompt(event.data.value, event.data.arguments);
        })();
      }
      if (event.data.call == 'functioniseCustomConfirm') {
        (async () => {
          while (!window.hasOwnProperty('WS')) {
            console.log('waiting for WS...', window.location.href);
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          window.WS.customConfirm(event.data.choice, event.data.arguments);
        })();
      }
      if (event.data.call == 'functioniseCustomAjax') {
        let localEvent = event.data;
        (async () => {
          while (!window.hasOwnProperty('WS') || window.WS === null) {
            console.log('waiting for WS...', window.location.href);
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          window.WS.evaluateAjaxCall(event.data.method, event.data.url, event.data.timestamp);
        })();
      }
      if (event.data.call == 'lazyLoad') {
        (async () => {
          while (!window.hasOwnProperty('WS')) {
            console.log('waiting for WS...', window.location.href);
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
          window.WS.updateLastAction({ hasLazyLoad: true });
        })();
      }
    },
    false
  );
}

function injectCode(src) {
  const script = document.createElement('script');
  script.setAttribute('id', 'functionize-overrides-ajax');
  script.setAttribute('type', 'text/javascript');

  // This is why it works!
  script.src = src;
  script.onload = function() {
    // console.log('script injected');
    this.remove();
  };

  // This script runs before the <head> element is created,
  // so we add the script to <html> instead.
  (document.head || document.documentElement).appendChild(script);
}

injectCode(chrome.runtime.getURL('content-scripts/ajaxOverridesScript.js'));

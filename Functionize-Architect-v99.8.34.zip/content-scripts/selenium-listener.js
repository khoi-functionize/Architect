worker = chrome.runtime.connect(`${chrome.runtime.id}`, { name: 'f-evt' });

//catch window message for selenium tests...
window.addEventListener('message', function(event) {
  // We only accept messages from ourselves
  // console.log('Content script received message: ');
  if (event.source != window) return;

  if (event.data.detail.isSeleniumTest) {
    // console.log('Content script received message: ' + event.data);
    worker.postMessage(event.data);
  }
});

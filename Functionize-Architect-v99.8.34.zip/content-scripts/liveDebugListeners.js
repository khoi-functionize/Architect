window.addEventListener('FunctionizePluginDebugStartEvent', evt => {
  let local = false;
  if (
    typeof window._functionizeFzeProxyObject_ === 'object' &&
    window._functionizeFzeProxyObject_.hasOwnProperty('local') &&
    Object.keys(window._functionizeFzeProxyObject_.local).length !== 0
  ) {
    local = window._functionizeFzeProxyObject_.local;
  }
  let detail = Object.assign(evt.detail, { local: local });
  chrome.runtime.sendMessage(detail);
});

window.addEventListener('FunctionizePluginDebugStopEvent', evt => {
  chrome.runtime.sendMessage(evt.detail);
});

if (document.readyState !== 'complete') {
  document.addEventListener('readystatechange', event => {
    if (event.target.readyState === 'complete') {
      chrome.runtime.sendMessage({ type: 'runtimeDomReady' }, function(result) {});
    }
  });
} else {
  chrome.runtime.sendMessage({ type: 'runtimeDomReady' }, function(result) {});
}

var fzeRandomFrameId = Math.floor(Math.random() * new Date().getTime());
/*
requestBody and responseBody have been moved into resource variables

(function() {
  function inject() {
    const script = document.createElement('script');
    script.setAttribute('id', 'functionize-dynamic-script');
    script.setAttribute('type', 'text/javascript');
    script.text = `window.fzeRandomFrameId = "${fzeRandomFrameId}";
      let origOpen = XMLHttpRequest.prototype.open;
      window.functionizeAjaxVariables = {};
      window.functionizeAjaxLog = {};
      window.functionizeAjaxLogRequest = {};
      window.functionizeAjaxRequestVariables = {};
      window.functionizeResrouceCount = {};
      let funtionizeAjaxOpen = function(method, url, async, user, pass) {
        if (typeof async == 'undefined') {
          async = true;
        }
        var requestTime = new Date().getTime();
        window.functionizeAjaxLogRequest[url] = requestTime;
        if (!a) {
          var a = '';
        }
        if (!b) {
          var b = '';
        }
        let xhr = this;
        let serviceName = url;
        let r = new RegExp('^(?:[a-z+]+:)?//', 'i');
        if (!r.test(serviceName)) {
          if (!serviceName.startsWith('/')) {
            serviceName = location.href + serviceName;
          } else {
            serviceName = location.origin + serviceName;
          }
        }
        serviceName = serviceName.replace('https:/' + '/', '');
        serviceName = serviceName.replace('http:/' + '/', '');
        if (serviceName.indexOf('?') > -1) {
          let urlp = serviceName.split('?');
          serviceName = urlp[0];
        }
        let sp = serviceName.split('/');
        serviceName = sp[0];
        if (serviceName == '' || serviceName == '.' || serviceName == '..') {
          serviceName = sp[1];
        }
        serviceName = serviceName.replace(/\\./g, '_');
        if (typeof window.functionizeResrouceCount[serviceName] === 'undefined') {
          window.functionizeResrouceCount[serviceName] = 1;
        } else {
          window.functionizeResrouceCount[serviceName] = window.functionizeResrouceCount[serviceName] + 1;
        }
        if (typeof window.functionizeResrouceCount[url] === 'undefined') {
          window.functionizeResrouceCount[url] = 1;
        } else {
          window.functionizeResrouceCount[url] = window.functionizeResrouceCount[url] + 1;
        }
        let now = new Date().getTime();
        window.postMessage({ call: 'functioniseCustomAjax', data: { method: method, url: url, timestamp: now } }, '*');
        xhr.addEventListener(
          'readystatechange',
          function() {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
              try {
                window.functionizeAjaxLog[url + '###' + requestTime] = now;
                var serviceData = JSON.parse(xhr.response);
                window.functionizeAjaxVariables[serviceName] = serviceData;
                window.functionizeAjaxVariables[serviceName + '_' + window.functionizeResrouceCount[serviceName]] = serviceData;
                window.functionizeAjaxVariables[url] = serviceData;
                window.functionizeAjaxVariables[url + '_' + window.functionizeResrouceCount[url]] = serviceData;
              } catch (e) {
                window.functionizeAjaxVariables[serviceName] = xhr.response;
                window.functionizeAjaxVariables[serviceName + '_' + window.functionizeResrouceCount[serviceName]] = xhr.response;
              }
            }
          },
          false
        );
        origOpen.apply(xhr, [method, url, async, user, pass]);
      };
      XMLHttpRequest.prototype.open = funtionizeAjaxOpen;
      (function(send) {
        XMLHttpRequest.prototype.send = function() {
          let body = arguments[0];
          var callback = this.onreadystatechange;
          this.onreadystatechange = function() {
            if (this.readyState == 4) {
              let url = this.responseURL;
              let serviceName = this.responseURL;
              let r = new RegExp('^(?:[a-z+]+:)?//', 'i');
              if (!r.test(serviceName)) {
                if (!serviceName.startsWith('/')) {
                  serviceName = location.href + serviceName;
                } else {
                  serviceName = location.origin + serviceName;
                }
              }
              if (serviceName) {
                serviceName = serviceName.replace('https:/' + '/', '');
                serviceName = serviceName.replace('http:/' + '/', '');
                if (serviceName.indexOf('?') > -1) {
                  let urlp = serviceName.split('?');
                  serviceName = urlp[0];
                }
                let sp = serviceName.split('/');
                serviceName = sp[0];
                if (serviceName == '' || serviceName == '.' || serviceName == '..') {
                  serviceName = sp[1];
                }
                serviceName = serviceName.replace(/\\./g, '_');
                if (typeof window.functionizeResrouceCount[serviceName] === 'undefined') {
                  window.functionizeResrouceCount[serviceName] = 1;
                } else {
                  window.functionizeResrouceCount[serviceName] = window.functionizeResrouceCount[serviceName] + 1;
                }
                if (typeof window.functionizeResrouceCount[url] === 'undefined') {
                  window.functionizeResrouceCount[url] = 1;
                } else {
                  window.functionizeResrouceCount[url] = window.functionizeResrouceCount[url] + 1;
                }
                if (body) {
                  window.functionizeAjaxRequestVariables[serviceName] = body;
                  window.functionizeAjaxRequestVariables[serviceName + '_' + window.functionizeResrouceCount[serviceName]] = body;
                  window.functionizeAjaxRequestVariables[url] = body;
                  window.functionizeAjaxRequestVariables[url + '_' + window.functionizeResrouceCount[url]] = body;
                }
              }
            }
            if (callback) {
              callback.apply(this, arguments);
            }
          };
          send.apply(this, arguments);
        };
      })(XMLHttpRequest.prototype.send);
    
      const { fetch: origFetch } = window;
      window.fetch = async (...args) => {
        const response = await origFetch(...args);
        try {
          response
            .clone()
            .json()
            .then(body => {
              let serviceName = args[0];
              let r = new RegExp('^(?:[a-z+]+:)?//', 'i');
              if (!r.test(serviceName)) {
                if (!serviceName.startsWith('/')) {
                  serviceName = location.href + serviceName;
                } else {
                  serviceName = location.origin + serviceName;
                }
              }
              serviceName = serviceName.replace('https:/' + '/', '');
              serviceName = serviceName.replace('http:/' + '/', '');
              if (serviceName.indexOf('?') > -1) {
                let urlp = serviceName.split('?');
                serviceName = urlp[0];
              }
              let sp = serviceName.split('/');
              serviceName = sp[0];
              if (serviceName == '' || serviceName == '.' || serviceName == '..') {
                serviceName = sp[1];
              }
              serviceName = serviceName.replace(/\\./g, '_');
    
              if (typeof window.functionizeResrouceCount[serviceName] === 'undefined') {
                window.functionizeResrouceCount[serviceName] = 1;
              } else {
                window.functionizeResrouceCount[serviceName] = window.functionizeResrouceCount[serviceName] + 1;
              }
              if (typeof window.functionizeResrouceCount[args[0]] === 'undefined') {
                window.functionizeResrouceCount[args[0]] = 1;
              } else {
                window.functionizeResrouceCount[args[0]] = window.functionizeResrouceCount[args[0]] + 1;
              }
              if (typeof window.functionizeAjaxVariables !== 'object') {
                window.functionizeAjaxVariables = {};
              }
              if (body) {
                window.functionizeAjaxVariables[args[0]] = JSON.stringify(body);
                window.functionizeAjaxVariables[args[0] + '_' + window.functionizeResrouceCount[args[0]]] = JSON.stringify(body);
                window.functionizeAjaxVariables[serviceName] = JSON.stringify(body);
                window.functionizeAjaxVariables[serviceName + '_' + window.functionizeResrouceCount[serviceName]] = JSON.stringify(body);
              }
              return body;
            })
            .catch(err => {
                // console.log(err);
            });
        } catch (e) {
          response
            .clone()
            .text()
            .then(body => {
              let serviceName = args[0];
              let r = new RegExp('^(?:[a-z+]+:)?//', 'i');
              if (!r.test(serviceName)) {
                if (!serviceName.startsWith('/')) {
                  serviceName = location.href + serviceName;
                } else {
                  serviceName = location.origin + serviceName;
                }
              }
              serviceName = serviceName.replace('https:/' + '/', '');
              serviceName = serviceName.replace('http:/' + '/', '');
              if (serviceName.indexOf('?') > -1) {
                let urlp = serviceName.split('?');
                serviceName = urlp[0];
              }
              let sp = serviceName.split('/');
              serviceName = sp[0];
              if (serviceName == '' || serviceName == '.' || serviceName == '..') {
                serviceName = sp[1];
              }
              serviceName = serviceName.replace(/\\./g, '_');
    
              if (typeof window.functionizeResrouceCount[serviceName] === 'undefined') {
                window.functionizeResrouceCount[serviceName] = 1;
              } else {
                window.functionizeResrouceCount[serviceName] = window.functionizeResrouceCount[serviceName] + 1;
              }
              if (typeof window.functionizeResrouceCount[args[0]] === 'undefined') {
                window.functionizeResrouceCount[args[0]] = 1;
              } else {
                window.functionizeResrouceCount[args[0]] = window.functionizeResrouceCount[args[0]] + 1;
              }
              if (typeof window.functionizeAjaxVariables !== 'object') {
                window.functionizeAjaxVariables = {};
              }
              if (body) {
                window.functionizeAjaxVariables[args[0]] = JSON.stringify(body);
                window.functionizeAjaxVariables[args[0] + '_' + window.functionizeResrouceCount[args[0]]] = JSON.stringify(body);
                window.functionizeAjaxVariables[serviceName] = JSON.stringify(body);
                window.functionizeAjaxVariables[serviceName + '_' + window.functionizeResrouceCount[serviceName]] = JSON.stringify(body);
              }
              return body;
            })
            .catch(err => {
                // console.log(err);
            });
        }
    
        return response;
      };
    `;
    document.documentElement.appendChild(script);
    (document.head || document.documentElement).appendChild(script);
  }

  inject();
})();
 */

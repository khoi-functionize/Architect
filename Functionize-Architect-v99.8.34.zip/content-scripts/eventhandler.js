var worker;
if (!worker) {
  worker = chrome.runtime.connect(`${chrome.runtime.id}`, { name: 'f-evt' });
}
function checkDOM() {
  console.log('GNY Adding functionizePluginStartEvent', worker);
  (document.body || document.documentElement).addEventListener('FunctionizePluginStartEvent', evt => {
    var tue = document.querySelector('#newTestcaseURL');

    var newTestURL = '';
    if (tue != null) newTestURL = tue.value;

    var params = {
      type: 'functionizePluginStartEvent',
      detail: evt.detail,
      uri: evt.target.baseURI,
      testURL: newTestURL,
    };
    if (!worker) {
      worker = chrome.runtime.connect(`${chrome.runtime.id}`, { name: 'f-evt' });
    }

    worker.postMessage(params);
  });

  (document.body || document.documentElement).addEventListener('FunctionizePluginStopEvent', evt => {
    console.log('FunctionizePluginStopEvent', evt);
    if (!worker) {
      worker = chrome.runtime.connect(`${chrome.runtime.id}`, { name: 'f-evt' });
    }
    worker.postMessage({
      type: 'functionizePluginStopEvent',
      detail: evt.detail,
      uri: evt.target.baseURI,
    });
  });
}

function removeDisabled() {
  var resb = document.querySelector('#recTestButton');
  if (!resb) {
    setTimeout(removeDisabled, 500);
    return;
  }

  if (!resb.hasAttribute('disabled')) {
    setTimeout(removeDisabled, 500);
    return;
  }
  resb.removeAttribute('disabled');
}

if (!window.functionizePluginEventhandler) {
  window.functionizePluginEventhandler = true;
  injectCode(chrome.runtime.getURL('content-scripts/insertScript.js'));
  checkDOM();
  removeDisabled();
}

function injectCode(src) {
  console.log('GNY injectCode', chrome.runtime.getManifest().version)
  const script = document.createElement('script');
  script.setAttribute('nonce', `nonce-${Date.now()}`);
  script.setAttribute('id', 'addon-functionise');
  script.setAttribute('type', 'text/javascript');
  script.dataset.version = chrome.runtime.getManifest().version;
  // This is why it works!
  script.src = src;
  script.onload = function() {
    this.remove();
  };

  // This script runs before the <head> element is created,
  // so we add the script to <html> instead.
  (document.head || document.documentElement).appendChild(script);
}

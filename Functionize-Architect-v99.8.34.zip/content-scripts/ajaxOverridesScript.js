// does not work on salesforce
if (!window.ajaxOverridesScriptAdded) {
  window.ajaxOverridesScriptAdded = true;
  if (window.location.href.indexOf('salesforce') === -1) {
    let OrigIntersectionObserver = window.IntersectionObserver;

    function FunctionizeIntersectionObserver(callback, obj) {
      let orgCallback = callback;
      callback = function() {
        try {
          window.postMessage({ call: 'lazyLoad' }, '*');
        } catch (e) {
          console.error(e);
        }
        return orgCallback(...arguments);
      };
      return new OrigIntersectionObserver(callback, obj);
    }

    window.IntersectionObserver = FunctionizeIntersectionObserver;
  }

  if (typeof window !== 'undefined' && typeof window.showOpenFilePicker !== 'undefined') {
    (origShowOpenFilePicker => {
      window.showOpenFilePicker = async function(options) {
        let result = await origShowOpenFilePicker.apply(this, options);
        if (result[0]) {
          window.postMessage({ call: 'showOpenFilePicker', data: result[0] }, '*');
        }
        return result;
      };
    })(window.showOpenFilePicker);
  }

  let origOpen = XMLHttpRequest.prototype.open;
  window.functionizeAjaxVariables = {};
  window.functionizeAjaxLog = {};
  window.functionizeAjaxLogRequest = {};
  window.functionizeAjaxRequestVariables = {};
  window.functionizeResrouceCount = {};
  let funtionizeAjaxOpen = function(method, url, async, user, pass) {
    if (typeof async == 'undefined') {
      async = true;
    }
    if (!a) {
      var a = '';
    }
    if (!b) {
      var b = '';
    }
    let xhr = this;
    let now = new Date().getTime();
    window.postMessage({ call: 'functioniseCustomAjax', data: { method: method, url: url, timestamp: now } }, '*');
    xhr.addEventListener(
      'readystatechange',
      function() {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
          try {
            let getAbsoluteUrl = (function() {
              var a;

              return function(url) {
                if (!a) a = document.createElement('a');
                a.href = url;

                return a.href;
              };
            })();
            window.postMessage({ call: 'functionizeAjaxVariables', data: { body: xhr.response, url: [getAbsoluteUrl(url)] } }, '*');
          } catch (e) {
            console.log('Functionize - error processing resource variable', e);
          }
        }
      },
      false
    );
    origOpen.apply(xhr, [method, url, async, user, pass]);
  };
  XMLHttpRequest.prototype.open = funtionizeAjaxOpen;
  (function(send) {
    XMLHttpRequest.prototype.send = function() {
      let body = arguments[0];
      try {
        body = JSON.parse(JSON.stringify(arguments[0]));
      } catch (e) {}
      var callback = this.onreadystatechange;
      this.onreadystatechange = function() {
        if (this.readyState == 4) {
          let url = this.responseURL;
          if (url) {
            let getAbsoluteUrl = (function() {
              var a;

              return function(url) {
                if (!a) a = document.createElement('a');
                a.href = url;

                return a.href;
              };
            })();
            if (body) {
              window.postMessage({ call: 'functionizeAjaxVariables', data: { body: body, url: [getAbsoluteUrl(url)], request: true } }, '*');
            }
          }
        }
        if (callback) {
          callback.apply(this, arguments);
        }
      };
      send.apply(this, arguments);
    };
  })(XMLHttpRequest.prototype.send);

  const { fetch: origFetch } = window;
  window.fetch = async (...args) => {
    const response = await origFetch(...args);
    try {
      response
        .clone()
        .text()
        .then(body => {
          let url = args[0];
          if (body) {
            let getAbsoluteUrl = (function() {
              var a;

              return function(url) {
                if (!a) a = document.createElement('a');
                a.href = url;

                return a.href;
              };
            })();
            try {
              body = JSON.parse(body);
            } catch (e) {}
            window.postMessage(
              {
                call: 'functionizeAjaxVariables',
                data: { body: body, url: [getAbsoluteUrl(url)] },
              },
              '*'
            );
          }
          return body;
        })
        .catch(err => {
          console.log('Functionize - error processing resource variable', err);
        });
    } catch (e) {
      console.log('Functionize - error processing resource variable', e);
    }

    return response;
  };
}

function injectCode(src) {
  const script = document.createElement('script');
  script.setAttribute('id', 'functionize-overrides-ajax');
  script.setAttribute('type', 'text/javascript');

  // This is why it works!
  script.src = src;
  script.onload = function() {
    // console.log('script injected');
    this.remove();
  };

  // This script runs before the <head> element is created,
  // so we add the script to <html> instead.
  (document.head || document.documentElement).appendChild(script);
}

injectCode(chrome.runtime.getURL('content-scripts/ajaxOverridesScript.js'));

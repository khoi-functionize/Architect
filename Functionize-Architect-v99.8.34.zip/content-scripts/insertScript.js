console.log('insert script');
window.functionizePluginVersion = document.getElementById('addon-functionise').dataset.version;
window.functionizePluginInstalled = true;
window.startPluginTimeout = null;
window.functioniseTabId = '';

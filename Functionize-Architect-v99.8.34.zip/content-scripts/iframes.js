if (window !== window.parent && typeof tabId === 'undefined') {
  chrome.runtime.sendMessage({ call: 'newIframeAdded', obj: 'NULL' }, response => {
    if (response) {
      console.log('adding iframe');
    }
  });
}

HTMLElement.prototype.functionizeFocus = HTMLElement.prototype.focus;
// HTMLElement.prototype.focus = function() {};
/*
removing dialog overrides
HTMLDialogElement.prototype.showModal = function() {
  this.open = true;
};
HTMLDialogElement.prototype.close = function (p) {
  this.style.display = 'none';
  this.returnValue = p;
};
 */
function circularStringify(object, depth) {
  var fWindow = {};
  for (var p in object) {
    try {
      fWindow[p] = JSON.stringify(object[p]);
    } catch (e) {
      if (depth > 2) {
        fWindow[p] = '[CIRCULAR]';
      } else {
        fWindow[p] = circularStringify(object[p], depth + 1);
      }
    }
  }
  return fWindow;
}

window.addEventListener(
  'message',
  function (event) {
    let retValCode;
    let retVal;
    let fWindow = {};
    if (event.data.call === 'requestActivationButton') {
      window.postMessage({ call: 'requestActivationFallback' }, '*');
    }
    if (event.data.call === 'resolvePageVariable') {
      console.log('resolvePageVariable', event);
      window.functionizeSetPageVariableValue = null;
      let code = `
              window.functionizeSetPageVariableValue = ${event.data.args};
              try {
                window.functionizeSetPageVariableValue = JSON.parse(JSON.stringify(window.functionizeSetPageVariableValue));
              } catch(e) {}
              if (window.functionizeSetPageVariableValue) window.postMessage({ call: 'setResolvePageVariable', result: window.functionizeSetPageVariableValue }, '*');
            `;
      setTimeout(code, 1);

      return;
    }
    if (event.data.call === 'setFocus') {
      if (!event.data.args) {
        HTMLElement.prototype.focus = function () {};
        return;
      }
      HTMLElement.prototype.focus = HTMLElement.prototype.functionizeFocus;
    }
    if (event.data.call == 'getPageVariables') {
      fWindow = {};
      for (let p in window) {
        try {
          fWindow[p] = JSON.stringify(window[p]);
        } catch (e) {
          fWindow[p] = circularStringify(window[p], 1);
        }
      }
      window.postMessage({ call: 'setPageVariables', window: fWindow }, '*');
    }
    if (event.data.call == 'getPageVariablesForMutation') {
      fWindow = {};
      for (let p in window) {
        try {
          fWindow[p] = JSON.stringify(window[p]);
        } catch (e) {
          fWindow[p] = circularStringify(window[p], 1);
        }
      }
      window.postMessage({ call: 'setPageVariablesForMutation', window: fWindow }, '*');
    }
    if (event.data.call == 'getPageAjaxVariablesForMutation') {
      fWindow = window.functionizeAjaxLogRequest;
      window.postMessage({ call: 'setPageAjaxVariablesForMutation', window: fWindow }, '*');
    }
    if (event.data.call == 'getVariable') {
      var returnVar = '';
      try {
        returnVar = JSON.stringify(window[event.data.variableName]);
      } catch (e) {
        returnVar = circularStringify(window[event.data.variableName], 1);
      }
      window.postMessage({ call: 'setVariable', variable: returnVar }, '*');
    }
    if (event.data.call == 'getPageAjaxVariablesResponseForMutation') {
      let returnVar = '';
      try {
        returnVar = window.functionizeAjaxLog;
      } catch (e) {}
      window.postMessage(
        {
          call: 'setPageAjaxVariablesResponseForMutation',
          ajaxResponse: returnVar,
        },
        '*'
      );
    }
    if (event.data.call == 'getRelatedPageVariables') {
      console.log('getRelatedPageVariables', event.data);
      if (typeof event.data.pageVariableKeyword === 'undefined') return;
      fWindow = {};
      if (window.functionizeGetRelatedPageVariables) {
        clearTimeout(window.functionizeGetRelatedPageVariables);
      }

      window.functionizeGetRelatedPageVariables = setTimeout(() => {
        fWindow = [];
        if (event.data.pageVariableKeyword == 'window') {
          fWindow = getRelatedPageVariablesByLevel(window, event.data.pageVariableKeyword);
        } else {
          fWindow = getRelatedPageVariables(window, event.data.pageVariableKeyword);
        }
        // if (fWindow.length == 0) {
        //  fWindow = getRelatedPageVariablesByLevel(window);
        // }
        window.postMessage({ call: 'setRelatedPageVariables', pageVariables: fWindow, keyword: event.data.pageVariableKeyword }, '*');
      }, 500);
    }
    if (event.data.call == 'evaluateUserCode') {
      try {
        var sCode = event.data.evalcode.replace('var fElement', '//var fElement');
        retVal = setTimeout(sCode, 1);
        retValCode = 'Normal';
      } catch (e) {
        retVal = e.message;
        retValCode = 'Exception';

        window.postMessage(
          {
            call: 'showDialog',
            retVal: retVal,
          },
          '*'
        );
        return;
      }
      window.postMessage(
        {
          call: 'evaluateUserCodeResult',
          retVal: retVal,
          retValCode: retValCode,
        },
        '*'
      );
    }
  },
  false
);
var functionizeOrigConfirm = window.confirm;
window.confirm = function (txt) {
  var choice = functionizeOrigConfirm(txt);
  window.postMessage({ call: 'functioniseCustomConfirm', choice: choice, arguments: arguments[0] }, '*');
  return choice;
};
var functionizeOrigPrompt = window.prompt;
window.prompt = function (txt, val) {
  var value = functionizeOrigPrompt(txt, val);
  window.postMessage({ call: 'functioniseCustomPrompt', value: value, arguments: arguments[0] }, '*');
  return value;
};
var functionizeOrigAlert = window.alert;
window.alert = function (txt) {
  window.postMessage({ call: 'functioniseCustomAlert', text: arguments[0] }, '*');
};

function getRelatedPageVariables(windowd, pageVariableKeyword) {
  if (pageVariableKeyword.indexOf('window.') == 0) pageVariableKeyword = pageVariableKeyword.replace('window.', '');

  if (pageVariableKeyword.indexOf('.') > 0) {
    try {
      var pageVariableKeywordArr = pageVariableKeyword.split('.');
      var newVar = 'pageVariableKeywordValue = windowd';
      for (i = 0; i < pageVariableKeywordArr.length; i++) {
        newVar += "['" + pageVariableKeywordArr[i] + "']";
      }
      newVar += ';';
      setTimeout(newVar, 1);

      if (pageVariableKeywordValue) {
        var returnArrTemp = 'var fWindow = {};';
        var returnArrTempVarName = 'fWindow';
        for (i = 0; i < pageVariableKeywordArr.length; i++) {
          returnArrTempVarName += "['" + pageVariableKeywordArr[i] + "']";
          returnArrTemp += returnArrTempVarName + ' = {};';
        }
        returnArrTemp += returnArrTempVarName + " = '" + pageVariableKeywordValue + "';";
        setTimeout(returnArrTemp, 1);
        return fWindow;
      }
    } catch (e) {}
  }
  fWindow = {};
  let windowp = null;
  if (pageVariableKeyword.indexOf('.') > 0) {
    let pageVariableKeywordArr = pageVariableKeyword.split('.');

    for (let p in windowd) {
      if (p == pageVariableKeywordArr[0]) {
        try {
          windowdp = windowd[p];
          if (typeof windowdp != 'string' && windowdp.length > 0) {
            fWindow = getRelatedPageVariablesArray(fWindow, p, windowdp);
          } else if (typeof windowdp == 'object' && Object.keys(windowdp).length > 0) {
            fWindow[p] = JSON.stringify(windowdp);
          } else {
            fWindow[p] = JSON.stringify(windowdp);
          }
        } catch (e) {
          // fWindow[p] = circularStringify(windowdp, 1);
        }
      }
    }
  } else {
    for (let p in windowd) {
      if (p == pageVariableKeyword) {
        try {
          windowdp = windowd[p];
          if (typeof windowdp != 'string' && windowdp.length > 0) {
            fWindow = getRelatedPageVariablesArray(fWindow, p, windowdp);
          } else if (typeof windowdp == 'object' && Object.keys(windowdp).length > 0) {
            fWindow[p] = JSON.stringify(windowdp);
          } else {
            fWindow[p] = JSON.stringify(windowdp);
          }
        } catch (e) {
          // fWindow[p] = circularStringify(windowdp, 1);
        }
      }
    }
  }
  return fWindow;
}

function getRelatedPageVariablesByLevel(windowd, keyword) {
  fWindow = {};
  for (let p in windowd) {
    // if (p.indexOf(keyword) == 0) {
    try {
      fWindow[p] = JSON.stringify(windowd[p]);
    } catch (e) {
      // fWindow[p] = circularStringify(windowd[p], 1);
    }
    // }
  }
  return fWindow;
}

function getRelatedPageVariablesArray(fWindow, key, val) {
  val.forEach(function (value, index) {
    if (typeof value != 'string' && value.length > 0) {
      fWindow[key + '[' + index + ']'] = JSON.stringify(value);
    } else {
      fWindow[key + '[' + index + ']'] = getRelatedPageVariables(value);
    }
  });
  return fWindow;
}

window.fze = new Proxy(
  {
    date: new Date(),
    randomPhone: function (format = 'XXX-XXX-XXXX') {
      while (format.includes('X')) {
        format = format.replace('X', Math.floor(Math.random() * 10));
      }
      return format;
    },
    randomNumber: function (length = 3) {
      return Math.floor(Math.random() * 10 ** length);
    },
    randomText: function (length = 10) {
      var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
      var string = '';
      for (let i = 0; i < length; i++) {
        string += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return string;
    },
    randomString: function (length = 10, includeNumbers = false) {
      var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
      var string = '';
      for (let i = 0; i < length; i++) {
        string += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return string;
    },
    randomEmail: function (domain = 'example.com') {
      return (
        (Math.random() + 1)
          .toString(36)
          .substring(2, Math.random() * (12 - 8) + 8)
          .toLowerCase() +
        '@' +
        domain
      );
    },
    randomDoB: function (min, max) {
      var nowDate = new Date();
      var minDate = new Date();
      minDate.setFullYear(nowDate.getFullYear() - min);
      var maxDate = new Date();
      maxDate.setFullYear(nowDate.getFullYear() - (max + 1));
      return new Date(Math.random() * (maxDate.getTime() - minDate.getTime()) + minDate.getTime());
    },
    extractNumbers: function (string) {
      return string.replace(/\\D/g, '');
    },
    extractFloat: function (string) {
      return string.match(/[+-]?\\d+(\\.\\d+)?/g).map(function (v) {
        return parseFloat(v).toString();
      })[0];
    },
    pageVariable: function (name) {
      let variable = window.TCM.getRelatedPageVariables(name);
      return variable[name];
    },
    cookie: (name) => ('; ' + document.cookie).split(`; ${name}=`).pop().split(';')[0],
    localStorage: (name) => localStorage[name] || '',
    pageVariables: (name) => {
      try {
        return eval(name) || '';
      } catch (e) {
        return '';
      }
    },
  },
  {
    set: function (event) {
      throw new Error('Cannot assign directly to fze.VAR');
    },
  }
);

function _functionizeEvaluator_(exprFn) {
  var error = null;
  try {
    var result = exprFn(window._functionizeFzeObject_);
  } catch (e) {
    error = e;
  }
  return {
    result: result,
    error: error,
  };
}
